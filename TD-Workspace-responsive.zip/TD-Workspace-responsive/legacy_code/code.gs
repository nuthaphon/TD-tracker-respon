const SHEET_ID = '1jTAWtuuFccBm1Jy70tiBJFSgzLspRhedIhQHmbr1CkY';
const FOLDER_ID = '1-1AYQQvQ_bMCb3l2GKGqyZDIfZQv2D9K'; 

function getStartupData() {
  return {
    initial: getInitialData(), 
    jobs: getJobs()            
  };
}

function doGet() {
  return HtmlService.createTemplateFromFile('Index')
    .evaluate()
    .setTitle('TD Job Request')
    .addMetaTag('viewport', 'width=device-width, initial-scale=1')
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

function getSheetOrDie(sheetName) {
  const ss = SpreadsheetApp.openById(SHEET_ID);
  let sheet = ss.getSheetByName(sheetName);
  if (!sheet && sheetName === 'JR Issue') sheet = ss.getSheetByName('JR lssue'); 
  if (!sheet) throw new Error(`ไม่พบชีตชื่อ "${sheetName}"`);
  return sheet;
}

// ================= Security & OTP =================
function sendOtpEmail(email) {
  try {
    const otp = Math.floor(100000 + Math.random() * 900000).toString(); // สุ่มเลข 6 หลัก
    const cache = CacheService.getScriptCache();
    
    // เก็บ OTP ไว้ใน Cache 10 นาที (600 วินาที) โดยผูกกับ Email
    cache.put(email, otp, 600); 

    const subject = 'รหัสยืนยันการสมัครสมาชิก - TD Job Request';
    const body = `รหัสยืนยัน (OTP) ของคุณคือ: ${otp}\n\nรหัสนี้จะมีอายุการใช้งาน 10 นาที\nหากคุณไม่ได้ทำการสมัครสมาชิก โปรดเพิกเฉยต่อข้อความนี้`;
    
    MailApp.sendEmail(email, subject, body);
    return { success: true, message: 'ส่งรหัส OTP ไปที่อีเมลเรียบร้อยแล้ว' };
  } catch (e) {
    return { success: false, message: 'Email Error: ไม่สามารถส่งอีเมลได้ ' + e.message };
  }
}

// ================= Auth =================
function loginUser(empId, password) {
  try {
    const sheet = getSheetOrDie('User');
    const data = sheet.getDataRange().getValues();
    for (let i = 1; i < data.length; i++) {
      if (String(data[i][0]) === String(empId) && String(data[i][2]) === String(password)) {
        // คงเงื่อนไขตรวจสอบกลุ่ม TD ตามโค้ดต้นฉบับของคุณเพื่อไม่ให้กระทบผู้ใช้เดิม
        if (data[i][4] === 'TD' && data[i][7] !== 'Approved' && data[i][7] !== 'Login') {
           return { success: false, message: 'บัญชี TD Project รอการอนุมัติจาก Admin' };
        }
        return { 
          success: true, 
          user: { 
            id: data[i][0], username: data[i][1], name: data[i][3], 
            group: data[i][4], role: data[i][5], level: data[i][10], 
            permission: data[i][11], team: data[i][12] 
          } 
        };
      }
    }
    return { success: false, message: 'รหัสพนักงาน หรือ รหัสผ่าน ไม่ถูกต้อง' };
  } catch (e) {
    return { success: false, message: 'Login Error: ' + e.message };
  }
}

function registerUser(form, otpInput) {
  try {
    // 1. ตรวจสอบรหัส OTP จาก Cache
    const cache = CacheService.getScriptCache();
    const savedOtp = cache.get(form.email);
    
    if (!savedOtp || String(savedOtp) !== String(otpInput)) {
      return { success: false, message: 'รหัส OTP ไม่ถูกต้อง หรือหมดอายุแล้ว' };
    }

    const userSheet = getSheetOrDie('User');
    const groupSheet = getSheetOrDie('Group');
    const users = userSheet.getDataRange().getValues();
    
    // 2. ตรวจสอบว่ามีรหัสพนักงานนี้แล้วหรือยัง
    for(let i=1; i<users.length; i++){
      if(String(users[i][0]) === String(form.empId)) return { success: false, message: 'รหัสพนักงานนี้มีในระบบแล้ว' };
    }

    const groups = groupSheet.getDataRange().getValues();
    let groupName = "", groupCode = "";
    for(let i=1; i<groups.length; i++){
      if(String(groups[i][0]) === String(form.groupId)) { groupName = groups[i][1]; groupCode = groups[i][1]; break; }
    }

    const username = form.name + groupCode;
    // คงสถานะตามโค้ดต้นฉบับของคุณ
    const mStatus = (groupName === 'TD') ? 'Pending' : 'Login';
    let permission = "", team = "";
    
    if (groupName !== 'TD') {
      permission = (form.role === 'Manager'|| form.role === 'Departments Manager') ? 'Approver' : 'Issuer';
    } else {
      permission = (form.role === 'Manager' || form.role === 'Supervisor') ? 'Receiver' : 'Operator';
      team = (form.role === 'Supervisor' || form.role === 'Technician') ? 'B' : 'A';
    }

    userSheet.appendRow([form.empId, username, form.password, form.name, groupName, form.role, form.mobile, mStatus, form.email, "", "User", permission, team]);
    
    // ลบ OTP ออกจากระบบเมื่อสมัครสำเร็จ
    cache.remove(form.email);

    return { success: true, message: 'ลงทะเบียนสำเร็จ! เข้าสู่ระบบได้เลย' };
  } catch (e) {
    return { success: false, message: 'Register Error: ' + e.message };
  }
}

// ================= Data & Jobs =================
function getInitialData() {
  try {
    let groupData = [];
    const groupSheet = getSheetOrDie('Group');
    if (groupSheet && groupSheet.getLastRow() > 1) {
      groupData = groupSheet.getRange(2, 1, groupSheet.getLastRow()-1, 2).getValues().map(r => ({ id: r[0], name: r[1] }));
    }

    let tdUsers = [];
    const userSheet = getSheetOrDie('User');
    if (userSheet && userSheet.getLastRow() > 1) {
      const userData = userSheet.getDataRange().getValues();
      tdUsers = userData.filter(r => r[4] === 'TD').map(r => ({ username: r[1], team: r[12] }));
    }
    return { groups: groupData, tdUsers: tdUsers };
  } catch (e) {
    throw new Error("Initial Data Error: " + e.message);
  }
}

function getJobs() {
  try {
    const sheet = getSheetOrDie('JR Issue');
    
    // 1. เปลี่ยนมาใช้ getValues() ซึ่งดึงข้อมูลเร็วกว่า getDisplayValues() หลายเท่า
    const data = sheet.getDataRange().getValues();
    if (data.length < 2) return [];

    // 2. เผื่อกรณีที่มีคอลัมน์ไหนถูกจัด Format เป็น "วันที่" ใน Google Sheet
    // getValues() จะคืนค่ามาเป็น Date Object ซึ่งอาจทำให้ส่งข้อมูลกลับไปหน้าเว็บช้าหรือ error ได้
    // เราจึงสแกนแปลง Date เป็น String ก่อนส่งกลับ (ทำงานไวกว่าให้ระบบแปลงเอง)
    const optimizedData = data.map(row => {
      return row.map(cell => {
        // ถ้าเซลล์ไหนเป็นวันที่ ให้แปลงเป็นข้อความ
        if (cell instanceof Date) {
           // ปรับฟอร์แมตวันที่ให้ตรงกับที่คุณใช้ในระบบ
           return Utilities.formatDate(cell, "GMT+7", "M/d/yyyy HH:mm:ss"); 
        }
        // ถ้าเป็นข้อความหรือตัวเลขปกติ ให้ส่งค่าเดิมกลับไป
        return cell === null ? "" : cell; 
      });
    });

    return optimizedData; 
  } catch (e) {
    throw new Error('getJobs Error: ' + e.message);
  }
}

// ================= Submit, Edit & Actions =================
function submitJob(data, fileData) {
  try {
    const sheet = getSheetOrDie('JR Issue');
    const jrid = Math.random().toString(36).substring(2, 10).toUpperCase();
    const timestamp = Utilities.formatDate(new Date(), "GMT+7", "M/d/yyyy HH:mm:ss");
    const todayStr = Utilities.formatDate(new Date(), "GMT+7", "M/d/yyyy");
    const projNo = `TD - ${data.group} - ${todayStr} - ${jrid}`;
    
    let fileUrl = "";
    if (fileData && fileData.base64) {
      try {
        const folder = DriveApp.getFolderById(FOLDER_ID);
        const blob = Utilities.newBlob(Utilities.base64Decode(fileData.base64.split(',')[1]), fileData.type, fileData.name);
        fileUrl = folder.createFile(blob).getUrl();
      } catch (e) {} 
    }

    const row = new Array(31).fill('');
    row[0] = jrid; row[1] = timestamp; row[3] = data.jobType; row[4] = data.group;
    row[5] = data.requestBy; row[7] = data.attachment; row[8] = fileUrl; row[9] = data.cost;
    row[10] = data.dueDate; row[11] = 'Issued'; row[13] = data.what; row[14] = data.who;
    row[15] = data.why; row[16] = data.when; row[17] = data.where; row[18] = data.how;
    row[21] = data.assignTo; row[27] = projNo;

    sheet.appendRow(row);
    return { success: true, message: 'สร้าง Job Request สำเร็จ!', jrid: jrid };
  } catch (e) {
    return { success: false, message: 'Submit Error: ' + e.message };
  }
}

function editJob(jrid, data, fileData) {
  try {
    const sheet = getSheetOrDie('JR Issue');
    const sheetData = sheet.getDataRange().getValues();
    
    for(let i=1; i<sheetData.length; i++) {
      if(String(sheetData[i][0]) === String(jrid)) {
        const rowNum = i + 1; 
        
        sheet.getRange(rowNum, 4).setValue(data.jobType); 
        sheet.getRange(rowNum, 5).setValue(data.group); 
        sheet.getRange(rowNum, 8).setValue(data.attachment); 
        
        if (fileData && fileData.base64) {
          try {
            const folder = DriveApp.getFolderById(FOLDER_ID);
            const blob = Utilities.newBlob(Utilities.base64Decode(fileData.base64.split(',')[1]), fileData.type, fileData.name);
            const fileUrl = folder.createFile(blob).getUrl();
            sheet.getRange(rowNum, 9).setValue(fileUrl); 
          } catch(e){}
        }
        
        sheet.getRange(rowNum, 10).setValue(data.cost); 
        sheet.getRange(rowNum, 11).setValue(data.dueDate); 
        sheet.getRange(rowNum, 12).setValue('Issued'); 
        sheet.getRange(rowNum, 14).setValue(data.what); 
        sheet.getRange(rowNum, 15).setValue(data.who); 
        sheet.getRange(rowNum, 16).setValue(data.why); 
        sheet.getRange(rowNum, 17).setValue(data.when); 
        sheet.getRange(rowNum, 18).setValue(data.where); 
        sheet.getRange(rowNum, 19).setValue(data.how); 
        sheet.getRange(rowNum, 22).setValue(data.assignTo); 
        sheet.getRange(rowNum, 27).setValue(''); 

        return { success: true, message: 'แก้ไขข้อมูลสำเร็จ! สถานะกลับไปเป็น Issued' };
      }
    }
    return { success: false, message: 'ไม่พบ Job ID ที่ต้องการแก้ไข' };
  } catch (e) {
    return { success: false, message: 'Edit Error: ' + e.message };
  }
}

function updateJobStatus(jrid, action, payload) {
  try {
    const sheet = getSheetOrDie('JR Issue');
    const data = sheet.getDataRange().getValues();
    const timestamp = Utilities.formatDate(new Date(), "GMT+7", "M/d/yyyy HH:mm:ss");
    
    for(let i=1; i<data.length; i++) {
      if(String(data[i][0]) === String(jrid)) {
        const rowNum = i + 1;
        if(action === 'Approve') {
          sheet.getRange(rowNum, 12).setValue('Approved');
          sheet.getRange(rowNum, 7).setValue(payload.user); 
          sheet.getRange(rowNum, 23).setValue(timestamp);
          sheet.getRange(rowNum, 27).setValue(payload.comment);
        } else if (action === 'Reject') {
          sheet.getRange(rowNum, 12).setValue('Reject');
          sheet.getRange(rowNum, 7).setValue(payload.user); 
          sheet.getRange(rowNum, 23).setValue(timestamp);
          sheet.getRange(rowNum, 27).setValue(payload.comment);
        } else if (action === 'Revise') { 
          sheet.getRange(rowNum, 12).setValue('Revise');
          sheet.getRange(rowNum, 7).setValue(payload.user); 
          sheet.getRange(rowNum, 23).setValue(timestamp);
          sheet.getRange(rowNum, 27).setValue(payload.comment); 
        } else if (action === 'Receive') {
          sheet.getRange(rowNum, 12).setValue('Received');
          sheet.getRange(rowNum, 21).setValue(payload.user); 
          sheet.getRange(rowNum, 22).setValue(payload.assignTo); 
          sheet.getRange(rowNum, 24).setValue(timestamp);
          sheet.getRange(rowNum, 29).setValue(payload.jobCat);
        } else if (action === 'TD Reject') {
          sheet.getRange(rowNum, 12).setValue('TD Reject');
          sheet.getRange(rowNum, 21).setValue(payload.user);
          sheet.getRange(rowNum, 24).setValue(timestamp);
          sheet.getRange(rowNum, 27).setValue(payload.comment);
        } else if (action === 'Accept') {
          sheet.getRange(rowNum, 12).setValue('Accepted');
          if (payload.comment) {
            sheet.getRange(rowNum, 13).setValue(payload.comment); 
          }
          sheet.getRange(rowNum, 3).setValue(timestamp); 
        }
        return { success: true };
      }
    }
    return { success: false, message: 'ไม่พบ Job ID นี้' };
  } catch (e) {
    return { success: false, message: 'Update Error: ' + e.message };
  }
}

function recoverAccount(identifier) {
  try {
    const sheet = getSheetOrDie('User');
    const data = sheet.getDataRange().getValues();
    
    for (let i = 1; i < data.length; i++) {
      if (String(data[i][0]) === String(identifier) || String(data[i][8]) === String(identifier)) {
        const empId = data[i][0];
        const username = data[i][1];
        const password = data[i][2];
        const name = data[i][3];
        const userEmail = data[i][8];

        if (!userEmail) return { success: false, message: 'ไม่พบอีเมลในระบบ กรุณาติดต่อแอดมิน' };

        const subject = 'การกู้คืนบัญชี - TD Job Request Online';
        const body = `สวัสดีคุณ ${name},\n\nระบบได้รับคำขอกู้คืนบัญชีของคุณ ข้อมูลสำหรับการเข้าสู่ระบบมีดังนี้:\n\nรหัสพนักงาน: ${empId}\nUsername: ${username}\nPassword: ${password}\n\nกรุณาเก็บข้อมูลนี้ไว้เป็นความลับ\n\n(ระบบส่งข้อความอัตโนมัติจาก TD Job Request Online)`;
        
        MailApp.sendEmail(userEmail, subject, body);

        return { success: true, message: `ระบบได้ส่งข้อมูลเข้าสู่ระบบไปที่อีเมล ${userEmail} เรียบร้อยแล้ว` };
      }
    }
    return { success: false, message: 'ไม่พบ รหัสพนักงาน หรือ อีเมล นี้ในระบบ' };
  } catch (e) {
    return { success: false, message: 'Error: ' + e.message };
  }
}

function forceEmailAuth() {
  var myEmail = Session.getActiveUser().getEmail();
  MailApp.sendEmail(myEmail, "ทดสอบระบบ", "ระบบสามารถส่งอีเมลได้แล้วครับ!");
}
