import React from 'react';
import { Navigate, Outlet } from 'react-router-dom';
import { useAuth } from '../hooks/useAuth'; // We will create this hook next

const ProtectedRoute = () => {
  const { user, loading, userData } = useAuth();

  if (loading) {
    return <div>Loading...</div>; // Or a spinner
  }

  if (!user) {
    return <Navigate to="/login" />;
  }

  if (userData.dept === 'TD') {
    return <Outlet />;
  } else {
    return <Navigate to="/other-dashboard" />;
  }
};

export default ProtectedRoute;
