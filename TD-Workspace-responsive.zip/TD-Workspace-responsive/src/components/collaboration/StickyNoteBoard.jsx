import React, { useState, useEffect } from 'react';
import { collection, query, where, onSnapshot, addDoc, serverTimestamp } from 'firebase/firestore';
import { db } from '../../firebase';
import { useAuth } from '../../hooks/useAuth';

const StickyNoteBoard = ({ projectId }) => {
    const { user, userData } = useAuth();
    const [notes, setNotes] = useState([]);
    const [newNote, setNewNote] = useState('');

    useEffect(() => {
        if (projectId) {
            const q = query(
                collection(db, 'project_notes'),
                where('projectId', '==', projectId),
                orderBy('timestamp', 'desc')
            );
            const unsubscribe = onSnapshot(q, (snapshot) => {
                const notesData = snapshot.docs.map(doc => ({ ...doc.data(), id: doc.id }));
                setNotes(notesData);
            });
            return unsubscribe;
        }
    }, [projectId]);

    const handleAddNote = async (e) => {
        e.preventDefault();
        if (newNote.trim() === '' || !user) return;

        await addDoc(collection(db, 'project_notes'), {
            projectId,
            text: newNote,
            author: userData.name,
            timestamp: serverTimestamp(),
        });
        setNewNote('');
    };

    return (
        <div className="bg-gray-800 p-4 rounded-lg mt-6">
            <h3 className="text-xl font-bold mb-4">Sticky Notes</h3>
            <form onSubmit={handleAddNote} className="mb-4 flex">
                <input 
                    type="text" 
                    value={newNote}
                    onChange={(e) => setNewNote(e.target.value)}
                    className="flex-grow p-2 bg-gray-600 border border-gray-500 rounded-l-lg"
                    placeholder="Add a new note..."
                />
                <button type="submit" className="bg-green-500 hover:bg-green-600 text-white font-bold p-2 rounded-r-lg">Pin Note</button>
            </form>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {notes.map(note => (
                    <div key={note.id} className="bg-yellow-300 text-black p-4 rounded-lg shadow-md">
                        <p>{note.text}</p>
                        <p className="text-xs text-gray-700 mt-2">- {note.author}</p>
                    </div>
                ))}
            </div>
        </div>
    );
};

export default StickyNoteBoard;
