import React, { useState, useEffect } from 'react';
import { collection, query, where, orderBy, onSnapshot, addDoc, serverTimestamp } from 'firebase/firestore';
import { db } from '../../firebase';
import { useAuth } from '../../hooks/useAuth';

const ChatBox = ({ projectId }) => {
    const { user, userData } = useAuth();
    const [messages, setMessages] = useState([]);
    const [newMessage, setNewMessage] = useState('');

    useEffect(() => {
        if (projectId) {
            const q = query(
                collection(db, 'project_chats'),
                where('projectId', '==', projectId),
                orderBy('timestamp', 'asc')
            );
            const unsubscribe = onSnapshot(q, (snapshot) => {
                const msgs = snapshot.docs.map(doc => ({ ...doc.data(), id: doc.id }));
                setMessages(msgs);
            });
            return unsubscribe;
        }
    }, [projectId]);

    const handleSendMessage = async (e) => {
        e.preventDefault();
        if (newMessage.trim() === '' || !user) return;

        await addDoc(collection(db, 'project_chats'), {
            projectId,
            text: newMessage,
            sender: userData.name,
            timestamp: serverTimestamp(),
        });
        setNewMessage('');
    };

    return (
        <div className="bg-gray-800 p-4 rounded-lg mt-6">
            <h3 className="text-xl font-bold mb-4">Collaboration Chat</h3>
            <div className="h-64 overflow-y-auto bg-gray-700 p-4 rounded-lg mb-4">
                {messages.map(msg => (
                    <div key={msg.id} className={`mb-2 ${msg.sender === userData.name ? 'text-right' : 'text-left'}`}>
                        <p className={`inline-block p-2 rounded-lg ${msg.sender === userData.name ? 'bg-blue-600' : 'bg-gray-600'}`}>
                            <strong>{msg.sender}:</strong> {msg.text}
                        </p>
                    </div>
                ))}
            </div>
            <form onSubmit={handleSendMessage} className="flex">
                <input 
                    type="text" 
                    value={newMessage}
                    onChange={(e) => setNewMessage(e.target.value)}
                    className="flex-grow p-2 bg-gray-600 border border-gray-500 rounded-l-lg"
                    placeholder="Type a message..."
                />
                <button type="submit" className="bg-blue-500 hover:bg-blue-600 text-white font-bold p-2 rounded-r-lg">Send</button>
            </form>
        </div>
    );
};

export default ChatBox;
