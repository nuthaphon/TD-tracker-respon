import React from 'react';

const projects = [
  { id: 1, name: 'Project Alpha', status: 'In Progress', progress: 60 },
  { id: 2, name: 'Project Beta', status: 'Completed', progress: 100 },
  { id: 3, name: 'Project Gamma', status: 'On Hold', progress: 20 },
  { id: 4, name: 'Project Delta', status: 'In Progress', progress: 80 },
];

const ProjectList = () => {
  return (
    <div className="bg-white p-6 rounded-lg shadow-md">
      <h2 className="text-xl font-semibold mb-4">Projects</h2>
      <table className="w-full">
        <thead>
          <tr className="text-left text-gray-600">
            <th className="pb-2">Project Name</th>
            <th className="pb-2">Status</th>
            <th className="pb-2">Progress</th>
          </tr>
        </thead>
        <tbody>
          {projects.map((project) => (
            <tr key={project.id} className="border-b">
              <td className="py-2">{project.name}</td>
              <td className="py-2">{project.status}</td>
              <td className="py-2">
                <div className="w-full bg-gray-200 rounded-full">
                  <div
                    className="bg-blue-500 text-xs font-medium text-blue-100 text-center p-0.5 leading-none rounded-l-full"
                    style={{ width: `${project.progress}%` }}
                  >
                    {project.progress}%
                  </div>
                </div>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default ProjectList;
