import React, { useState, useEffect } from 'react';
import { collection, onSnapshot } from 'firebase/firestore';
import { db } from '../../firebase';
import JobOrderModal from './JobOrderModal';

const KanbanBoard = () => {
  const [projects, setProjects] = useState([]);
  const [selectedProject, setSelectedProject] = useState(null);
  const [isModalOpen, setIsModalOpen] = useState(false);

  useEffect(() => {
    const unsubscribe = onSnapshot(collection(db, 'projects'), (snapshot) => {
      const projectsData = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      setProjects(projectsData);
    });
    return unsubscribe;
  }, []);

  const handleCardClick = (project) => {
    setSelectedProject(project);
    setIsModalOpen(true);
  };

  const handleCloseModal = () => {
    setIsModalOpen(false);
    setSelectedProject(null);
  };

  const statuses = ['Issued', 'In Progress', 'Completed', 'On Hold'];

  const groupedProjects = projects.reduce((acc, project) => {
    const assignedTo = project.assignedTo || 'Unassigned';
    if (!acc[assignedTo]) {
      acc[assignedTo] = { 'Issued': [], 'In Progress': [], 'Completed': [], 'On Hold': [] };
    }
    acc[assignedTo][project.status]?.push(project);
    return acc;
  }, {});

  return (
    <div className="p-6 bg-gray-900 min-h-screen text-white">
        <h1 className="text-3xl font-bold mb-6">TD Kanban Board</h1>
        <div className="flex space-x-4 overflow-x-auto p-4">
            {Object.entries(groupedProjects).map(([assignee, projectsByStatus]) => (
                <div key={assignee}>
                    <h2 className="text-2xl font-bold mb-4">{assignee}</h2>
                    <div className="flex space-x-4">
                        {statuses.map(status => (
                            <div key={status} className="bg-gray-800 rounded-lg p-4 w-72 flex-shrink-0">
                                <h3 className="font-bold text-lg mb-4 text-center">{status}</h3>
                                <div className="space-y-4">
                                    {projectsByStatus[status].map(project => (
                                        <div key={project.id} 
                                             className="bg-gray-700 p-3 rounded-lg shadow-md cursor-pointer hover:bg-gray-600"
                                             onClick={() => handleCardClick(project)}>
                                            <p className="font-bold">{project.projectNo}</p>
                                            <p>{project.subject}</p>
                                        </div>
                                    ))}
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            ))}
        </div>
        {isModalOpen && selectedProject && (
            <JobOrderModal project={selectedProject} onClose={handleCloseModal} />
        )}
    </div>
  );
};

export default KanbanBoard;
