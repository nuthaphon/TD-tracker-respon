import React, { useState, useMemo } from 'react';
import { doc, updateDoc, arrayUnion, getDoc } from 'firebase/firestore';
import { db } from '../../firebase';
import { useAuth } from '../../hooks/useAuth';

// 🌟 เพิ่ม Props onClickJob เพื่อให้เรียกเปิด Modal ของหน้าหลักได้
const AutoPilotTower = ({ activeJobs, onClickJob }) => {
    const { userData } = useAuth();
    const [processingId, setProcessingId] = useState(null);

    // 🌟 1. คัดกรองงาน + ตรวจสอบสิทธิ์
    const myActionableTasks = useMemo(() => {
        if (!userData || !activeJobs) return [];
        const isAdmin = userData?.role === 'Admin';
        const userJobTitle = (userData?.jobTitle || '').toLowerCase().trim();
        const isDeptMgr = userJobTitle.includes('manager') || userJobTitle.includes('director') || isAdmin;
        const isGlobalDeptManager = userJobTitle === 'department manager' || isAdmin;
        const isTD = userData?.dept === 'TD' || isAdmin;
        const isTDManager = isTD && (userJobTitle.includes('manager') || userJobTitle.includes('director') || isAdmin);
        const isTDSup = isTD && (userJobTitle.includes('supervisor') || userJobTitle.includes('lead') || isAdmin);

        return activeJobs.filter(job => {
            const isMyDept = job.group === userData?.dept || isAdmin;
            const isRequester = job.requestBy === userData?.name || isAdmin;
            const isAssignee = job.assignTo === userData?.name;

            if (job.status === 'Issued' && ((isDeptMgr && isMyDept) || isGlobalDeptManager)) return true;
            if (job.status === 'Approved' && isTDManager) return true; 
            if (job.status === 'In Progress' && (isAssignee || isTDManager || isTDSup)) return true;
            if (job.status === 'Completed' && (isRequester || (isDeptMgr && isMyDept) || isGlobalDeptManager || isTDManager)) return true;
            if (job.status === 'Revise' && (isRequester || (isDeptMgr && isMyDept) || isGlobalDeptManager)) return true;

            return false;
        });
    }, [activeJobs, userData]);

    // 🌟 2. ฟังก์ชันจัดการ Action รวมออโต้ E-Sign
    const handleAction = async (job, actionType) => {
        // 🌟 2.1 เพิ่มหน้าต่างใส่ Comment
        let actionComment = '';
        if (['Approve', 'Revise', 'Reject', 'Complete'].includes(actionType)) {
            const userInput = window.prompt(`คุณกำลังจะกด: ${actionType} สำหรับตั๋ว ${job.projectNo}\n\nกรุณาระบุความคิดเห็น/เหตุผล (ถ้ามี):`, '');
            if (userInput === null) return; // User กดยกเลิก
            actionComment = userInput.trim();
        } else {
            if (!window.confirm(`ยืนยันการดำเนินการ: ${actionType} สำหรับงาน ${job.projectNo} ?`)) return;
        }

        setProcessingId(job.id);

        try {
            const jobRef = doc(db, 'td_job_requests', job.id);
            let nextStatus = '';
            let timelineComment = actionComment || `Tower Action: ดำเนินการ ${actionType} สำเร็จ`;
            const signData = { name: userData.name, date: new Date().toISOString() };

            if (actionType === 'Manager E-Sign' || actionType === 'Accept & E-Sign' || actionType === 'Accept') {
                if (job.projectId) {
                    const projRef = doc(db, 'td_projects', job.projectId);
                    const projSnap = await getDoc(projRef);
                    
                    if (projSnap.exists() && projSnap.data().handoverReport) {
                        if (actionType === 'Manager E-Sign') {
                            await updateDoc(projRef, { 'handoverReport.approverSign': signData });
                            await updateDoc(jobRef, {
                                timeline: arrayUnion({ status: 'Completed', by: userData.name, comment: 'ประทับตรา E-Signature (Manager) ตรวจสอบเอกสารแล้ว', timestamp: new Date().toISOString() })
                            });
                            alert('ประทับตรา E-Signature (Manager) สำเร็จ!');
                            setProcessingId(null);
                            return; 
                        } 
                        else if (actionType === 'Accept & E-Sign' || actionType === 'Accept') {
                            await updateDoc(projRef, { 
                                'handoverReport.issuerSign': signData,
                                status: 'Accepted' 
                            });
                            timelineComment = 'ประทับตรา E-Signature รับมอบงานสำเร็จ ปิดจ็อบ!';
                            nextStatus = 'Accepted';
                        }
                    } else {
                        nextStatus = 'Accepted';
                    }
                } else {
                    nextStatus = 'Accepted';
                }
            } 
            else {
                if (actionType === 'Approve') nextStatus = 'Approved';
                else if (actionType === 'Reject') nextStatus = 'Reject';
                else if (actionType === 'Revise') nextStatus = 'Revise';
                else if (actionType === 'Receive') nextStatus = 'In Progress'; 
                else if (actionType === 'Complete') nextStatus = 'Completed';  
                else if (actionType === 'Resubmit') nextStatus = 'Issued';     
            }

            if (!nextStatus) {
                alert('ไม่สามารถระบุสถานะถัดไปได้');
                setProcessingId(null);
                return;
            }

            const newEvent = { status: nextStatus, by: userData?.name, comment: timelineComment, timestamp: new Date().toISOString() };
            await updateDoc(jobRef, { status: nextStatus, timeline: arrayUnion(newEvent) });
            
            if (job.projectId && ['Completed', 'Accepted', 'In Progress', 'Reject'].includes(nextStatus)) {
                await updateDoc(doc(db, 'td_projects', job.projectId), { status: nextStatus });
            }

        } catch (error) {
            console.error("Error updating floor:", error);
            alert("เกิดข้อผิดพลาดในการดำเนินการ");
        } finally {
            setProcessingId(null);
        }
    };

    const TOWER_FLOORS = [
        { id: 'Issued', level: 'ดาดฟ้า (Rooftop)', title: '1. รออนุมัติแจ้งงาน', color: 'orange', icon: 'fa-helicopter', desc: 'จุดรับงานเข้าตึก Manager ต้องกด Approve เพื่อปล่อยงานลงด่านต่อไป' },
        { id: 'Approved', level: 'ชั้น 3 (Floor 3)', title: '2. แผนก TD รับงาน', color: 'blue', icon: 'fa-box-open', defaultAction: 'Receive', desc: 'งานผ่านการอนุมัติแล้ว รอ TD Manager กดยอมรับงานเข้าแผนก' },
        { id: 'In Progress', level: 'ชั้น 2 (Floor 2)', title: '3. กำลังปฏิบัติงาน', color: 'purple', icon: 'fa-tools', defaultAction: 'Complete', desc: 'ช่างกำลังซ่อม/สร้าง เมื่อเสร็จสิ้นให้กด Complete เพื่อส่งงานลง Lobby' },
        { id: 'Completed', level: 'ชั้น 1 (Lobby)', title: '4. ประทับตรา E-Sign & ตรวจรับ', color: 'green', icon: 'fa-file-signature', defaultAction: 'Accept', desc: 'จุดประทับตรา! Manager ต้องเซ็นอนุมัติ และผู้แจ้งต้องเซ็นรับมอบงาน' },
        { id: 'Revise', level: 'ชั้นใต้ดิน (Basement)', title: 'ห้องซ่อมแซมเอกสาร', color: 'pink', icon: 'fa-file-medical', defaultAction: 'แก้ไขข้อมูล 5W1H', desc: 'งานถูกตีกลับ ผู้แจ้งต้องแก้ไขฟอร์มและส่งกลับไปดาดฟ้าใหม่' }
    ];

    return (
        <div className="flex flex-col items-center w-full py-8 overflow-y-auto custom-scrollbar bg-bg/50 relative">
            <div className="absolute top-10 left-10 text-white/5 animate-pulse"><i className="fas fa-cloud text-6xl"></i></div>
            <div className="absolute top-20 right-20 text-white/5 animate-pulse delay-700"><i className="fas fa-cloud text-8xl"></i></div>

            <div className="mb-6 text-center relative z-10">
                <h2 className="text-3xl font-black text-primary drop-shadow-[0_0_10px_rgba(59,130,246,0.6)] uppercase tracking-widest">
                    <i className="fas fa-building mr-3"></i> AutoPilot Tower
                </h2>
                <p className="text-text/70 mt-1 text-xs">ยินดีต้อนรับคุณ <span className="text-primary font-bold">{userData?.name}</span><br/>ระบบผู้ช่วยรวบรวมงานทั้งหมดที่คุณมี</p>
            </div>

            <div className="w-full px-4 flex flex-col items-center relative z-10">
                {TOWER_FLOORS.map((floor, index) => {
                    let jobsInThisFloor = myActionableTasks.filter(j => j.status === floor.id);

                    if (floor.id === 'Completed') {
                        const isTDManager = (userData?.dept === 'TD' && (userData?.jobTitle?.toLowerCase().includes('manager') || userData?.role === 'Admin'));
                        if (isTDManager) {
                            jobsInThisFloor = jobsInThisFloor.filter(j => !j.timeline?.some(t => t.comment?.includes('ประทับตรา E-Signature (Manager)')));
                        }
                    }

                    const isTop = index === 0;
                    const isBottom = index === TOWER_FLOORS.length - 1;

                    return (
                        // 🌟 เอาแกนลิฟต์ออก และเอา margin (-mt-2) ออกเพื่อให้ตึกติดกัน
                        <div key={floor.id} className="w-full relative flex flex-col items-center">
                            
                            {/* 🌟 ปรับให้ขอบด้านบนหายไปในชั้นถัดๆ ไป (border-t-0) เพื่อให้เส้นต่อกันเนียนๆ */}
                            <div className={`w-full bg-surface/60 backdrop-blur-md border border-glass shadow-[0_10px_30px_rgba(0,0,0,0.5)] z-10 relative transition-all duration-500 hover:border-${floor.color}-500/50 group ${isTop ? 'rounded-t-2xl' : 'border-t-0'} ${isBottom ? 'rounded-b-2xl mb-10' : ''} overflow-hidden`}>
                                
                                {/* 🌟 ย้ายชื่อชั้น (Title) มาไว้ซ้าย และระดับชั้น (Level) ไปไว้ขวา */}
                                <div className={`w-full bg-surface/80 border-b border-glass px-4 py-2.5 flex items-center justify-between`}>
                                    <div className="flex items-center gap-3">
                                        <div className={`bg-${floor.color}-500/20 p-2 rounded-lg border border-${floor.color}-500/30 text-${floor.color}-400 shadow-[0_0_10px_rgba(var(--color-${floor.color}),0.2)]`}>
                                            <i className={`fas ${floor.icon} text-lg animate-pulse`}></i>
                                        </div>
                                        <div>
                                            <h3 className={`text-${floor.color}-400 font-black text-sm md:text-base leading-tight uppercase tracking-wider`}>
                                                {floor.title}
                                            </h3>
                                            <p className="text-[10px] text-text/60 leading-tight mt-0.5">{floor.desc}</p>
                                        </div>
                                    </div>
                                    
                                    <div className="text-right hidden md:block">
                                        <h4 className="text-primary font-bold text-sm bg-surface px-3 py-1 rounded border border-glass shadow-inner">{floor.level}</h4>
                                    </div>
                                </div>

                                <div className="p-4 md:p-5 min-h-[140px] flex flex-col justify-center">
                                    {jobsInThisFloor.length > 0 ? (
                                        <div className="flex gap-3 overflow-x-auto custom-scrollbar pb-2 snap-x">
                                            {jobsInThisFloor.map(job => {
                                                let actionText = floor.defaultAction;
                                                let btnColor = floor.color;

                                                let isTDManager = (userData?.dept === 'TD' && (userData?.jobTitle?.toLowerCase().includes('manager') || userData?.role === 'Admin'));
                                                let isRequester = job.requestBy === userData?.name || userData?.role === 'Admin';
                                                let isDeptMgr = userData?.jobTitle?.toLowerCase().includes('manager') || userData?.jobTitle?.toLowerCase().includes('director');

                                                if (floor.id === 'Completed') {
                                                    if (isTDManager && !isRequester) {
                                                        actionText = 'Manager E-Sign'; btnColor = 'blue';
                                                    } else if (isRequester || isDeptMgr) {
                                                        actionText = 'Accept & E-Sign'; btnColor = 'green';
                                                    }
                                                }

                                                return (
                                                    <div key={job.id} 
                                                        onClick={(e) => {
                                                            if (e.target.tagName.toLowerCase() !== 'button' && !e.target.closest('button')) {
                                                                if (onClickJob) onClickJob(job);
                                                            }
                                                        }}
                                                        className="snap-center shrink-0 w-[240px] md:w-[260px] bg-bg/80 border border-glass rounded-lg p-3 flex flex-col shadow-md transform transition-transform hover:-translate-y-1 cursor-pointer hover:shadow-[0_0_15px_rgba(255,255,255,0.1)] relative overflow-hidden"
                                                    >
                                                        <div className={`absolute top-0 left-0 right-0 h-1 bg-${btnColor}-500`}></div>
                                                        <div className="flex justify-between items-start mb-1 mt-1">
                                                            <span className="text-primary font-black text-xs truncate max-w-[130px]">{job.projectNo}</span>
                                                            <span className="text-[8px] bg-surface px-1.5 py-0.5 rounded border border-glass text-text">{job.group}</span>
                                                        </div>
                                                        <p className="text-[10px] text-text/90 line-clamp-2 flex-1 mb-3">{job.what}</p>
                                                        
                                                        <div className="flex justify-between items-end mt-auto gap-2">
                                                            <div className="text-[9px] text-text/50 truncate w-1/3">
                                                                <i className="fas fa-user mr-1"></i>{job.requestBy}
                                                            </div>
                                                            
                                                            <div className="flex gap-1">
                                                                {floor.id === 'Issued' ? (
                                                                    <>
                                                                        <button onClick={(e) => { e.stopPropagation(); handleAction(job, 'Reject'); }} disabled={processingId === job.id} className="bg-red-600 hover:bg-red-500 text-white text-[9px] font-bold px-2 py-1.5 rounded shadow transition-all disabled:opacity-50" title="Reject"><i className="fas fa-times"></i></button>
                                                                        <button onClick={(e) => { e.stopPropagation(); handleAction(job, 'Revise'); }} disabled={processingId === job.id} className="bg-orange-600 hover:bg-orange-500 text-white text-[9px] font-bold px-2 py-1.5 rounded shadow transition-all disabled:opacity-50" title="Revise"><i className="fas fa-undo"></i></button>
                                                                        <button onClick={(e) => { e.stopPropagation(); handleAction(job, 'Approve'); }} disabled={processingId === job.id} className="bg-green-600 hover:bg-green-500 text-white text-[9px] font-bold px-2 py-1.5 rounded shadow transition-all disabled:opacity-50 whitespace-nowrap">Approve ↓</button>
                                                                    </>
                                                                ) : floor.id === 'Revise' ? (
                                                                    <button onClick={(e) => { e.stopPropagation(); if (onClickJob) onClickJob(job, 'Resubmit'); }} disabled={processingId === job.id} className="bg-pink-600 hover:bg-pink-500 text-white text-[9px] font-bold px-2 py-1.5 rounded shadow transition-all disabled:opacity-50 whitespace-nowrap">
                                                                        <i className="fas fa-edit mr-1"></i> แก้ไขข้อมูล 5W1H
                                                                    </button>
                                                                ) : (
                                                                    <button 
                                                                        onClick={(e) => { e.stopPropagation(); handleAction(job, actionText); }}
                                                                        disabled={processingId === job.id}
                                                                        className={`bg-${btnColor}-600 hover:bg-${btnColor}-500 text-white text-[9px] font-bold px-2 py-1.5 rounded shadow transition-all disabled:opacity-50 whitespace-nowrap`}
                                                                    >
                                                                        {processingId === job.id ? <i className="fas fa-spinner fa-spin"></i> : (
                                                                            <>
                                                                                {actionText.includes('E-Sign') && <i className="fas fa-file-signature mr-1"></i>}
                                                                                {actionText} 
                                                                                {!actionText.includes('Manager') && <i className="fas fa-arrow-down ml-1"></i>}
                                                                            </>
                                                                        )}
                                                                    </button>
                                                                )}
                                                            </div>
                                                        </div>
                                                    </div>
                                                )
                                            })}
                                        </div>
                                    ) : (
                                        <div className="flex items-center justify-center h-[80px] border border-dashed border-glass rounded-lg bg-bg/30">
                                            <p className="text-text/40 text-xs font-medium"><i className="fas fa-wind mr-2"></i>ว่างเปล่า... ไม่มีงานให้คุณทำในชั้นนี้</p>
                                        </div>
                                    )}
                                </div>
                            </div>
                        </div>
                    );
                })}
                <div className="w-full h-3 bg-green-900/50 rounded-[100%] shadow-[0_0_30px_rgba(34,197,94,0.2)] mt-1"></div>
            </div>
        </div>
    );
};

export default AutoPilotTower;