import React, { useState, useEffect } from 'react';
import { doc, updateDoc, collection, query, where, getDocs } from 'firebase/firestore';
import { db } from '../../firebase';
import ChatBox from '../collaboration/ChatBox';
import StickyNoteBoard from '../collaboration/StickyNoteBoard';
import PartOrderForm from '../part-orders/PartOrderForm';

const JobOrderModal = ({ project, onClose }) => {
  const [assignedTo, setAssignedTo] = useState(project.assignedTo || '');
  const [status, setStatus] = useState(project.status || '');
  const [tdMembers, setTdMembers] = useState([]);

  useEffect(() => {
    const fetchTdMembers = async () => {
      const q = query(collection(db, 'users'), where('dept', '==', 'TD'));
      const querySnapshot = await getDocs(q);
      const members = querySnapshot.docs.map(doc => doc.data().name);
      setTdMembers(members);
    };
    fetchTdMembers();
  }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const projectRef = doc(db, 'projects', project.id);
      await updateDoc(projectRef, {
        assignedTo,
        status,
      });
      onClose();
    } catch (error) {
      console.error("Error updating document: ", error);
    }
  };

  return (
    <div id="jobModal" className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center">
        <div className="bg-white text-black rounded-lg shadow-2xl w-full max-w-4xl max-h-full overflow-y-auto">
            <div className="p-8">
                <div className="flex justify-between items-center mb-6">
                    <h2 className="text-3xl font-bold">Job Order Details</h2>
                    <button id="closeModal" className="text-gray-500 hover:text-gray-800 text-3xl" onClick={onClose}>&times;</button>
                </div>
                <form id="jobDetailsForm" onSubmit={handleSubmit}>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-6">
                        {/* Column 1 */}
                        <div>
                            <div className="mb-4">
                                <label htmlFor="projectNo" className="block text-sm font-bold mb-2">Project No.</label>
                                <input type="text" id="projectNo" name="projectNo" className="w-full p-3 bg-gray-100 rounded-lg" value={project.projectNo} readOnly />
                            </div>
                            <div className="mb-4">
                                <label htmlFor="projectType" className="block text-sm font-bold mb-2">Project Type</label>
                                <input type="text" id="projectType" name="projectType" className="w-full p-3 bg-gray-100 rounded-lg" value={project.projectType} readOnly />
                            </div>
                            <div className="mb-4">
                                <label htmlFor="subject" className="block text-sm font-bold mb-2">Subject</label>
                                <input type="text" id="subject" name="subject" className="w-full p-3 bg-gray-100 rounded-lg" value={project.subject} readOnly />
                            </div>
                            <div className="mb-4">
                                <label htmlFor="description" className="block text-sm font-bold mb-2">Description</label>
                                <textarea id="description" name="description" rows="4" className="w-full p-3 bg-gray-100 rounded-lg" value={project.description} readOnly></textarea>
                            </div>
                        </div>
                        {/* Column 2 */}
                        <div>
                            <div className="mb-4">
                                <label htmlFor="creationDate" className="block text-sm font-bold mb-2">Creation Date</label>
                                <input type="text" id="creationDate" name="creationDate" className="w-full p-3 bg-gray-100 rounded-lg" value={project.creationDate} readOnly />
                            </div>
                            <div className="mb-4">
                                <label htmlFor="requester" className="block text-sm font-bold mb-2">Requester</label>
                                <input type="text" id="requester" name="requester" className="w-full p-3 bg-gray-100 rounded-lg" value={project.requester} readOnly />
                            </div>
                            <div className="mb-4">
                                <label htmlFor="department" className="block text-sm font-bold mb-2">Department</label>
                                <input type="text" id="department" name="department" className="w-full p-3 bg-gray-100 rounded-lg" value={project.department} readOnly />
                            </div>
                            <div className="mb-4">
                                <label htmlFor="assignedTo" className="block text-sm font-bold mb-2">Assigned To (TD)</label>
                                <select id="assignedTo" name="assignedTo" className="w-full p-3 bg-white border border-gray-300 rounded-lg" value={assignedTo} onChange={(e) => setAssignedTo(e.target.value)}>
                                    <option value="">--Select--</option>
                                    {tdMembers.map(member => (
                                        <option key={member} value={member}>{member}</option>
                                    ))}
                                </select>
                            </div>
                            <div className="mb-4">
                                <label htmlFor="status" className="block text-sm font-bold mb-2">Status</label>
                                <select id="status" name="status" className="w-full p-3 bg-white border border-gray-300 rounded-lg" value={status} onChange={(e) => setStatus(e.target.value)}>
                                    <option value="Issued">Issued</option>
                                    <option value="In Progress">In Progress</option>
                                    <option value="On Hold">On Hold</option>
                                    <option value="Completed">Completed</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div className="mt-8 flex justify-end">
                        <button type="submit" className="bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-6 rounded-lg">Update Job Order</button>
                    </div>
                </form>
                <PartOrderForm project={project} />
                <ChatBox projectId={project.id} />
                <StickyNoteBoard projectId={project.id} />
            </div>
        </div>
    </div>
  );
};

export default JobOrderModal;
