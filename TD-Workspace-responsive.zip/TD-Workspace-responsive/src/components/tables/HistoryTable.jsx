import React, { useState, useEffect } from 'react';
import { collection, query, where, onSnapshot } from 'firebase/firestore';
import { db } from '../../firebase';
import { useAuth } from '../../hooks/useAuth';

const HistoryTable = () => {
  const { userData } = useAuth();
  const [projects, setProjects] = useState([]);

  useEffect(() => {
    if (userData) {
      const q = query(collection(db, 'projects'), where('department', '==', userData.dept));
      const unsubscribe = onSnapshot(q, (querySnapshot) => {
        const projectsData = [];
        querySnapshot.forEach((doc) => {
          projectsData.push({ ...doc.data(), id: doc.id });
        });
        setProjects(projectsData);
      });
      return unsubscribe;
    }
  }, [userData]);

  return (
    <div className="bg-gray-800 p-8 rounded-lg shadow-md w-full max-w-4xl mt-8">
      <h2 className="text-2xl font-bold mb-6 text-center">Job Request History</h2>
      <div className="overflow-x-auto"><table className="w-full text-left">
        <thead>
          <tr className="border-b border-gray-600">
            <th className="p-2">Project No.</th>
            <th className="p-2">Subject</th>
            <th className="p-2">Creation Date</th>
            <th className="p-2">Status</th>
          </tr>
        </thead>
        <tbody>
          {projects.map((project) => (
            <tr key={project.id} className="border-b border-gray-700">
              <td className="p-2">{project.projectNo}</td>
              <td className="p-2">{project.subject}</td>
              <td className="p-2">{project.creationDate}</td>
              <td className="p-2">{project.status}</td>
            </tr>
          ))}
        </tbody>
      </table></div>
    </div>
  );
};

export default HistoryTable;
