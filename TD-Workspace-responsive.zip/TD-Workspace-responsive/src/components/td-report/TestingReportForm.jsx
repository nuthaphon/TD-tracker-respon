import React, { useState, useEffect } from 'react';

const SectionWrapper = ({ title, children }) => (
    <div className="bg-gray-800 p-6 rounded-lg shadow-lg mb-6">
        <h3 className="text-xl font-bold text-purple-400 mb-4 border-b-2 border-gray-700 pb-2">{title}</h3>
        {children}
    </div>
);

const ReadOnlyField = ({ label, value }) => (
    <div>
        <label className="block text-sm font-bold text-gray-400">{label}</label>
        <p className="text-gray-200 mt-1">{value || 'N/A'}</p>
    </div>
);

const EditableField = ({ label, value, onChange, placeholder, type = 'text', rows = 3 }) => (
    <div className="mb-4">
        <label htmlFor={label} className="block text-gray-300 mb-2">{label}</label>
        {type === 'textarea' ? (
            <textarea
                id={label}
                value={value}
                onChange={onChange}
                placeholder={placeholder}
                className="w-full p-3 bg-gray-700 rounded-md text-white border border-gray-600 focus:outline-none focus:ring-2 focus:ring-purple-500"
                rows={rows}
            />
        ) : (
            <input
                type={type}
                id={label}
                value={value}
                onChange={onChange}
                placeholder={placeholder}
                className="w-full p-3 bg-gray-700 rounded-md text-white border border-gray-600 focus:outline-none focus:ring-2 focus:ring-purple-500"
            />
        )}
    </div>
);


const TestingReportForm = ({ reportData: initialData, onSave, isReadOnly = false, jobOrder, project }) => {
    const [reportData, setReportData] = useState(initialData || {
        problemState: '',
        testingDetails: '',
        conclusion: '',
        result: 'Pass',
        partList: [{ name: '', qty: 1, notes: '' }],
        pmAdvising: '',
    });
    
    useEffect(() => {
        if(initialData) {
            setReportData(initialData);
        }
    }, [initialData]);


    const handleChange = (field, value) => {
        setReportData(prev => ({ ...prev, [field]: value }));
    };
    
    const handlePartChange = (index, field, value) => {
        const updatedParts = [...reportData.partList];
        updatedParts[index][field] = value;
        handleChange('partList', updatedParts);
    };

    const addPart = () => {
        handleChange('partList', [...reportData.partList, { name: '', qty: 1, notes: '' }]);
    };
    
    const removePart = (index) => {
        const updatedParts = reportData.partList.filter((_, i) => i !== index);
        handleChange('partList', updatedParts);
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        onSave(reportData);
    };

    const renderEditableForm = () => (
        <form onSubmit={handleSubmit}>
            <SectionWrapper title="1. Problem State (5W1H)">
                <EditableField
                    label="Describe the problem in detail"
                    value={reportData.problemState}
                    onChange={(e) => handleChange('problemState', e.target.value)}
                    placeholder="Who, What, When, Where, Why, How..."
                    type="textarea"
                    rows={5}
                />
            </SectionWrapper>

            <SectionWrapper title="2. Testing Details">
                <EditableField
                    label="Describe the testing procedures and conditions"
                    value={reportData.testingDetails}
                    onChange={(e) => handleChange('testingDetails', e.target.value)}
                    type="textarea"
                    rows={8}
                />
            </SectionWrapper>
            
            <SectionWrapper title="3. Conclusion">
                <EditableField
                    label="Summarize the findings from the tests"
                    value={reportData.conclusion}
                    onChange={(e) => handleChange('conclusion', e.target.value)}
                    type="textarea"
                    rows={4}
                />
            </SectionWrapper>

            <SectionWrapper title="4. Final Result">
                 <div className="mb-4">
                    <label htmlFor="result" className="block text-gray-300 mb-2">Select the outcome of the test</label>
                    <select
                        id="result"
                        value={reportData.result}
                        onChange={(e) => handleChange('result', e.target.value)}
                        className="w-full p-3 bg-gray-700 rounded-md text-white border border-gray-600"
                    >
                        <option value="Pass">Pass</option>
                        <option value="Conditional Pass">Conditional Pass</option>
                        <option value="Fail">Fail</option>
                    </select>
                </div>
            </SectionWrapper>

            <SectionWrapper title="5. Part/Consumable List">
                {reportData.partList.map((part, index) => (
                    <div key={index} className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-4 p-3 border border-gray-700 rounded-md">
                        <EditableField label="Part Name" value={part.name} onChange={(e) => handlePartChange(index, 'name', e.target.value)} />
                        <EditableField label="Quantity" value={part.qty} onChange={(e) => handlePartChange(index, 'qty', e.target.value)} type="number" />
                        <div className="md:col-span-2">
                            <EditableField label="Notes" value={part.notes} onChange={(e) => handlePartChange(index, 'notes', e.target.value)} />
                        </div>
                         <button type="button" onClick={() => removePart(index)} className="bg-red-600 text-white px-3 py-1 rounded-md hover:bg-red-700 h-10 mt-auto">Remove</button>
                    </div>
                ))}
                <button type="button" onClick={addPart} className="mt-2 bg-purple-600 text-white font-bold py-2 px-4 rounded-md hover:bg-purple-700">
                    Add Part
                </button>
            </SectionWrapper>
            
            <SectionWrapper title="6. PM Advising">
                 <EditableField
                    label="Advice or notes for the Project Manager/Issuer"
                    value={reportData.pmAdvising}
                    onChange={(e) => handleChange('pmAdvising', e.target.value)}
                    type="textarea"
                    rows={4}
                />
            </SectionWrapper>

            <div className="flex justify-end mt-8">
                <button type="submit" className="bg-green-600 text-white font-bold py-3 px-6 rounded-lg hover:bg-green-700 transition duration-300 shadow-lg">
                    Save and Submit Report
                </button>
            </div>
        </form>
    );

    const renderReadOnlyView = () => (
        <div>
            <SectionWrapper title="1. Header Information">
                 <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                    <ReadOnlyField label="Project Name" value={project?.name} />
                    <ReadOnlyField label="Job Order" value={jobOrder?.title} />
                    <ReadOnlyField label="Department" value={project?.department} />
                    <ReadOnlyField label="Report Status" value={reportData.status} />
                    <ReadOnlyField label="Creation Date" value={reportData.createdAt?.toDate().toLocaleDateString()} />
                    <ReadOnlyField label="Accepted Date" value={reportData.acceptedAt?.toDate().toLocaleDateString()} />
                </div>
            </SectionWrapper>
             <SectionWrapper title="2. Problem State (5W1H)">
                <p className="text-gray-200 whitespace-pre-wrap">{reportData.problemState}</p>
            </SectionWrapper>
             <SectionWrapper title="3. Testing Details">
                 <p className="text-gray-200 whitespace-pre-wrap">{reportData.testingDetails}</p>
            </SectionWrapper>
             <SectionWrapper title="4. Conclusion">
                <p className="text-gray-200 whitespace-pre-wrap">{reportData.conclusion}</p>
            </SectionWrapper>
             <SectionWrapper title="5. Final Result">
                <p className={`font-bold text-lg ${
                    reportData.result === 'Pass' ? 'text-green-400' :
                    reportData.result === 'Fail' ? 'text-red-400' : 'text-yellow-400'
                }`}>{reportData.result}</p>
            </SectionWrapper>
             <SectionWrapper title="6. Part/Consumable List">
                <ul className="list-disc list-inside text-gray-200">
                    {reportData.partList?.map((part, index) => (
                        <li key={index}>{part.qty}x {part.name} - {part.notes}</li>
                    ))}
                </ul>
            </SectionWrapper>
            <SectionWrapper title="7. PM Advising">
                 <p className="text-gray-200 whitespace-pre-wrap">{reportData.pmAdvising}</p>
            </SectionWrapper>
        </div>
    );
    
    return isReadOnly ? renderReadOnlyView() : renderEditableForm();
};

export default TestingReportForm;
