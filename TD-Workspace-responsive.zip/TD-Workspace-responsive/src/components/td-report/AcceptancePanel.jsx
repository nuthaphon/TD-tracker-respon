import React, { useState } from 'react';

const AcceptancePanel = ({ report, isIssuer, onAction }) => {
    const [comment, setComment] = useState('');

    const handleAction = (action) => {
        if ((action === 'return' && !comment)) {
            alert('Please provide a comment when returning the report for edits.');
            return;
        }
        onAction(action, comment);
        setComment('');
    };

    return (
        <div className="mt-8 bg-gray-900 p-6 rounded-lg shadow-2xl">
            <h2 className="text-2xl font-bold text-white mb-4">Acception Panel</h2>
            
            {/* Comments History */}
            <div className="mb-6">
                <h3 className="text-lg font-semibold text-gray-300 mb-3">Comments Log</h3>
                <div className="space-y-4 max-h-60 overflow-y-auto pr-2">
                    {report.comments && report.comments.length > 0 ? (
                        report.comments.map((c, index) => (
                            <div key={index} className="bg-gray-800 p-3 rounded-lg">
                                <p className="text-gray-200">{c.text}</p>
                                <p className="text-xs text-gray-500 mt-2 text-right">- {c.author} on {new Date(c.createdAt.seconds * 1000).toLocaleDateString()}</p>
                            </div>
                        ))
                    ) : (
                        <p className="text-gray-500">No comments yet.</p>
                    )}
                </div>
            </div>

            {/* Action Area */}
            {isIssuer && report.status !== 'Accepted' && (
                <div>
                    <h3 className="text-lg font-semibold text-gray-300 mb-3">Your Feedback</h3>
                    <textarea
                        value={comment}
                        onChange={(e) => setComment(e.target.value)}
                        placeholder="Add your comments for acceptance or rejection..."
                        className="w-full p-3 bg-gray-700 rounded-md text-white border border-gray-600 focus:outline-none focus:ring-2 focus:ring-purple-500"
                        rows="4"
                    />
                    <div className="flex justify-end gap-4 mt-4">
                        <button 
                            onClick={() => handleAction('return')} 
                            className="bg-yellow-600 text-white font-bold py-2 px-5 rounded-lg hover:bg-yellow-700 transition duration-300"
                            disabled={!comment}
                        >
                            Return for Edit
                        </button>
                        <button 
                            onClick={() => handleAction('accept')} 
                            className="bg-green-600 text-white font-bold py-2 px-5 rounded-lg hover:bg-green-700 transition duration-300"
                        >
                            Accept Report
                        </button>
                    </div>
                </div>
            )}

            {report.status === 'Accepted' && (
                 <div className="text-center p-4 bg-green-900/50 rounded-lg">
                    <h3 className="text-xl font-bold text-green-300">Report Accepted</h3>
                    <p className="text-gray-400">This report was finalized on {report.acceptedAt?.toDate().toLocaleDateString()}.</p>
                </div>
            )}
        </div>
    );
};

export default AcceptancePanel; 
