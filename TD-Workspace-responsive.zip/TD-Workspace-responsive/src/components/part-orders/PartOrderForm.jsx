import React, { useState } from 'react';
import { collection, addDoc, serverTimestamp } from 'firebase/firestore';
import { ref, uploadBytes, getDownloadURL } from 'firebase/storage';
import { db, storage } from '../../firebase';

const PartOrderForm = ({ project }) => {
    const [item, setItem] = useState('');
    const [qty, setQty] = useState(1);
    const [spec, setSpec] = useState('');
    const [file, setFile] = useState(null);
    const [isSubmitting, setIsSubmitting] = useState(false);

    const handleFileChange = (e) => {
        if (e.target.files[0]) {
            setFile(e.target.files[0]);
        }
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        if (!item || !qty) {
            alert('Please fill in at least Item and Quantity.');
            return;
        }
        setIsSubmitting(true);

        try {
            let fileURL = '';
            if (file) {
                const storageRef = ref(storage, `part_orders/${project.id}/${file.name}`);
                await uploadBytes(storageRef, file);
                fileURL = await getDownloadURL(storageRef);
            }

            await addDoc(collection(db, 'part_orders'), {
                projectId: project.id,
                projectNo: project.projectNo,
                projectName: project.subject, 
                reserver: project.requester,
                item,
                qty,
                spec,
                fileURL,
                status: 'Ordered', // Initial status
                orderedAt: serverTimestamp(),
            });

            // Reset form
            setItem('');
            setQty(1);
            setSpec('');
            setFile(null);
            alert('Part order submitted successfully!');
        } catch (error) {
            console.error("Error submitting part order: ", error);
            alert('Failed to submit part order.');
        } finally {
            setIsSubmitting(false);
        }
    };

    return (
        <div className="bg-gray-800 p-6 rounded-lg mt-6">
            <h3 className="text-xl font-bold mb-4">Request New Part</h3>
            <form onSubmit={handleSubmit}>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <input type="text" value={project.projectNo} className="p-2 bg-gray-700 rounded-lg" readOnly />
                    <input type="text" value={project.subject} className="p-2 bg-gray-700 rounded-lg" readOnly />
                    <input type="text" value={project.requester} className="p-2 bg-gray-700 rounded-lg" readOnly />
                </div>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-4">
                    <input type="text" placeholder="Item Name" value={item} onChange={e => setItem(e.target.value)} className="p-2 bg-gray-600 rounded-lg" required />
                    <input type="number" placeholder="Quantity" value={qty} onChange={e => setQty(e.target.value)} className="p-2 bg-gray-600 rounded-lg" required min="1" />
                    <input type="text" placeholder="Specification" value={spec} onChange={e => setSpec(e.target.value)} className="p-2 bg-gray-600 rounded-lg" />
                </div>
                <div className="mt-4">
                    <label className="block text-sm font-bold mb-2">Attach File (e.g., Drawing, Spec Sheet)</label>
                    <input type="file" onChange={handleFileChange} className="w-full text-sm text-gray-400 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100" />
                </div>
                <div className="mt-6 text-right">
                    <button type="submit" disabled={isSubmitting} className="bg-green-600 hover:bg-green-700 text-white font-bold py-2 px-4 rounded-lg disabled:bg-gray-500">
                        {isSubmitting ? 'Submitting...' : 'Submit Part Order'}
                    </button>
                </div>
            </form>
        </div>
    );
};

export default PartOrderForm;
