import React, { useState, useEffect } from 'react';
import { NavLink } from 'react-router-dom';
import { useAuth } from '../../hooks/useAuth'; 
import { 
    FiHome, FiClipboard, FiUsers, FiSettings, FiArchive, 
    FiBriefcase, FiLayers, FiCalendar, FiActivity, FiMap,
    FiMenu, FiLogOut, FiX
} from 'react-icons/fi';
import ThemeToggle from '../ThemeToggle';

const Sidebar = () => {
    const [isExpanded, setIsExpanded] = useState(false);
    const [isMobileOpen, setIsMobileOpen] = useState(false);
    const { userData, logout } = useAuth(); 

    useEffect(() => {
        const handleResize = () => {
            if (window.innerWidth >= 1024) setIsMobileOpen(false);
        };
        window.addEventListener('resize', handleResize);
        return () => window.removeEventListener('resize', handleResize);
    }, []);

    const navLinks = [
        { to: "/", text: "Dashboard", icon: <FiHome />, role: ["admin", "user", "td_lead"] },
        { to: "/td", text: "TD Monthly Report", icon: <FiClipboard />, role: ["admin", "user", "td_lead"], dept: ["TD"] }, 
        { to: "/admin/users", text: "User Management", icon: <FiSettings />, role: ["admin"] },
        { to: "/job-request", text: "Job Request (TD)", icon: <FiClipboard />, role: ["admin", "user", "td_lead"], excludeDept: ["TD"] },
        { to: "/td-workspace", text: "TD Workspace", icon: <FiBriefcase />, role: ["admin", "user", "td_lead"], dept: ["TD"] },
        { to: "/part-orders", text: "Part Orders", icon: <FiArchive />, role: ["admin", "user", "td_lead"], dept: ["TD"] },
        { to: "/td-master-timeline", text: "Project Schedule Plan", icon: <FiLayers />, role: ["admin", "user", "td_lead"], dept: ["TD"] },
        { to: "/my-planner", text: "My Planner", icon: <FiCalendar />, role: ["admin", "user", "td_lead"], dept: ["TD"] },
        { to: "/td-sharing", text: "TD Sharing Area", icon: <FiMap />, role: ["admin", "user", "td_lead"], dept: ["TD"] },
        { to: "/news-feed", text: "Project Feed", icon: <FiActivity />, role: ["admin", "user", "td_lead"], dept: ["TD"] },
        { to: "/team", text: "TD Team", icon: <FiUsers />, role: ["admin", "user", "td_lead"] },
    ];

    const getInitials = (name) => {
        if (!name) return 'U';
        return name.charAt(0).toUpperCase();
    };

    const NavItems = ({ onNavClick }) => (
        <>
            {navLinks.map((link) => {
                const userRole = userData?.role?.toLowerCase();
                const userDept = userData?.dept;
                const isAdmin = userRole === 'admin';
                const hasRole = link.role.includes(userRole);
                const hasDept = link.dept ? link.dept.includes(userDept) : true;
                const isExcluded = link.excludeDept ? (link.excludeDept.includes(userDept) && !isAdmin) : false;

                if (hasRole && hasDept && !isExcluded) {
                    return (
                        <NavLink
                            key={link.to}
                            to={link.to}
                            onClick={onNavClick}
                            className={({ isActive }) =>
                                `flex items-center rounded-lg transition-all duration-200 group ${
                                    isActive 
                                        ? 'bg-primary/20 text-primary neon-text' 
                                        : 'text-text hover:bg-surface hover:text-primary'
                                } ${isExpanded || onNavClick ? 'px-4 py-3' : 'justify-center p-3'}`
                            }
                            title={!isExpanded && !onNavClick ? link.text : ""}
                        >
                            <span className={`text-xl shrink-0 transition-transform duration-300 ease-in-out group-hover:scale-125 group-hover:-translate-y-1 ${!isExpanded && !onNavClick ? 'mx-auto' : ''}`}>
                                {link.icon}
                            </span>
                            {(isExpanded || onNavClick) && (
                                <span className="ml-4 font-medium whitespace-nowrap transition-colors duration-200 group-hover:text-primary">
                                    {link.text}
                                </span>
                            )}
                        </NavLink>
                    );
                }
                return null;
            })}
        </>
    );

    const UserFooter = ({ showText }) => (
        <div className="border-t border-glass p-3 mt-auto bg-surface/50">
            <div className={`flex items-center mb-4 ${showText ? 'px-2' : 'justify-center'} group transition-transform duration-300 hover:scale-[1.02]`}>
                <ThemeToggle />
                {showText && <span className="ml-3 text-sm font-medium text-text group-hover:text-primary transition-colors">เปลี่ยนธีม</span>}
            </div>
            
            <NavLink 
                to="/profile"
                onClick={() => setIsMobileOpen(false)}
                className={({ isActive }) => 
                    `flex items-center mb-3 p-2 rounded-lg transition-all duration-200 cursor-pointer group ${
                        showText ? 'justify-start' : 'justify-center'
                    } ${isActive ? 'bg-primary/20 ring-1 ring-primary/50' : 'hover:bg-surface'}`
                }
                title={!showText ? "My Profile" : ""}
            >
                <div className="w-10 h-10 rounded-full bg-primary flex items-center justify-center font-bold text-white shadow-md shrink-0 border-2 border-glass group-hover:border-primary group-hover:scale-110 transition-all duration-300 overflow-hidden">
                    {(userData?.avatar || userData?.photoURL) ? (
                        <img src={userData.avatar || userData.photoURL} alt="Profile" className="w-full h-full object-cover bg-white" referrerPolicy="no-referrer" />
                    ) : (
                        getInitials(userData?.name || userData?.displayName || userData?.email)
                    )}
                </div>
                {showText && (
                    <div className="ml-3 overflow-hidden text-left">
                        <p className="text-sm font-semibold text-text truncate group-hover:text-primary transition-colors">
                            {userData?.name || userData?.displayName || 'User'}
                        </p>
                        <p className="text-xs text-text/70 truncate">{userData?.dept || 'Department'}</p>
                    </div>
                )}
            </NavLink>

            <button
                onClick={logout}
                className={`w-full flex items-center rounded-lg text-red-400 hover:bg-red-500/10 hover:text-red-500 transition-all duration-200 group ${
                    showText ? 'px-4 py-3' : 'justify-center p-3'
                }`}
                title={!showText ? "Logout" : ""}
            >
                <FiLogOut className={`text-xl shrink-0 transition-all duration-300 group-hover:translate-x-2 group-hover:scale-125 ${!showText ? 'mx-auto' : ''}`} />
                {showText && <span className="ml-4 font-medium whitespace-nowrap group-hover:font-bold">Logout</span>}
            </button>
        </div>
    );

    return (
        <>
            {/* MOBILE: Hamburger Button */}
            <button
                onClick={() => setIsMobileOpen(true)}
                className="lg:hidden fixed top-3 left-3 z-50 p-2 rounded-lg bg-surface text-text shadow-lg border border-glass hover:text-primary transition-colors"
                title="เปิดเมนู"
            >
                <FiMenu className="text-2xl" />
            </button>

            {/* MOBILE: Overlay */}
            {isMobileOpen && (
                <div
                    className="lg:hidden fixed inset-0 bg-black/50 z-40 backdrop-blur-sm"
                    onClick={() => setIsMobileOpen(false)}
                />
            )}

            {/* MOBILE: Drawer */}
            <div className={`
                lg:hidden fixed top-0 left-0 h-full w-72 bg-surface glass-panel text-text z-50
                flex flex-col shadow-2xl transition-transform duration-300 ease-in-out
                ${isMobileOpen ? 'translate-x-0' : '-translate-x-full'}
            `}>
                <div className="flex items-center justify-between h-16 px-4 border-b border-glass">
                    <span className="text-xl font-bold text-primary neon-text tracking-wide">TD WorkSpace</span>
                    <button onClick={() => setIsMobileOpen(false)} className="p-2 rounded-lg text-text hover:text-primary hover:bg-surface focus:outline-none transition-colors">
                        <FiX className="text-2xl" />
                    </button>
                </div>
                <div className="flex-1 overflow-y-auto custom-scrollbar mt-4">
                    <nav className="flex flex-col gap-1 px-2">
                        <NavItems onNavClick={() => setIsMobileOpen(false)} />
                    </nav>
                </div>
                <UserFooter showText={true} />
            </div>

            {/* DESKTOP: Persistent Sidebar */}
            <div className={`
                hidden lg:flex flex-col h-screen bg-surface glass-panel text-text
                transition-all duration-300 ease-in-out z-50 shadow-xl shrink-0
                ${isExpanded ? 'w-64' : 'w-20'}
            `}>
                <div className={`flex items-center h-16 border-b border-glass ${isExpanded ? 'px-4 justify-between' : 'justify-center'}`}>
                    {isExpanded && <span className="text-xl font-bold text-primary neon-text truncate tracking-wide">TD WorkSpace</span>}
                    <button 
                        onClick={() => setIsExpanded(!isExpanded)}
                        className="p-2 rounded-lg text-text hover:text-primary hover:bg-surface focus:outline-none transition-colors group"
                        title={isExpanded ? "ย่อเมนู" : "ขยายเมนู"}
                    >
                        <FiMenu className="text-2xl transition-transform duration-300 group-hover:rotate-90 group-hover:scale-110" />
                    </button>
                </div>
                <div className="flex-1 overflow-y-auto custom-scrollbar mt-4">
                    <nav className="flex flex-col gap-1 px-2">
                        <NavItems onNavClick={null} />
                    </nav>
                </div>
                <UserFooter showText={isExpanded} />
            </div>
        </>
    );
};

export default Sidebar;
