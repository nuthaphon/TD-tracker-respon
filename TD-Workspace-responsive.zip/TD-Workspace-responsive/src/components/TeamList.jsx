import React from 'react';

const teamMembers = [
  { id: 1, name: 'Alice', role: 'Project Manager', email: 'alice@example.com' },
  { id: 2, name: 'Bob', role: 'Developer', email: 'bob@example.com' },
  { id: 3, name: 'Charlie', role: 'Designer', email: 'charlie@example.com' },
  { id: 4, name: 'David', role: 'Developer', email: 'david@example.com' },
];

const TeamList = () => {
  return (
    <div className="bg-white p-6 rounded-lg shadow-md">
      <h2 className="text-xl font-semibold mb-4">Team Members</h2>
      <table className="w-full">
        <thead>
          <tr className="text-left text-gray-600">
            <th className="pb-2">Name</th>
            <th className="pb-2">Role</th>
            <th className="pb-2">Email</th>
          </tr>
        </thead>
        <tbody>
          {teamMembers.map((member) => (
            <tr key={member.id} className="border-b">
              <td className="py-2">{member.name}</td>
              <td className="py-2">{member.role}</td>
              <td className="py-2">{member.email}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default TeamList;
