import React from 'react';
import { useTheme } from '../contexts/ThemeProvider';
import { BsFillMoonStarsFill, BsSunFill, BsRainbow } from 'react-icons/bs';

const ThemeToggle = () => {
  const { theme, setTheme } = useTheme();

  // Cycle through themes on click
  const handleToggle = () => {
    if (theme === 'light') {
      setTheme('dark');
    } else if (theme === 'dark') {
      setTheme('unicorn');
    } else {
      setTheme('light');
    }
  };

  // Render an icon based on the current theme
  const getIcon = () => {
    switch (theme) {
      case 'light':
        return <BsSunFill className="text-yellow-500 w-6 h-6 animate-pulse" />;
      case 'dark':
        return <BsFillMoonStarsFill className="text-cyan-400 w-6 h-6 neon-text" />;
      case 'unicorn':
        return <BsRainbow className="text-pink-500 w-6 h-6" />;
      default:
        return <BsSunFill className="w-6 h-6" />;
    }
  };

  return (
    <button
      onClick={handleToggle}
      className="p-3 rounded-full bg-surface glass-panel hover:scale-110 transition-transform duration-300 focus:outline-none focus:ring-2 focus:ring-primary flex items-center justify-center gap-2"
      aria-label="Toggle Theme"
      title={`Current Theme: ${theme.charAt(0).toUpperCase() + theme.slice(1)}`}
    >
      {getIcon()}
    </button>
  );
};

export default ThemeToggle;
