import React, { useState } from 'react';
import { Link, Outlet } from 'react-router-dom';
import { 
  Squares2X2Icon, 
  FolderIcon, 
  UsersIcon, 
  UserCircleIcon,
  ArrowRightOnRectangleIcon,
  Bars3Icon
} from '@heroicons/react/24/outline';

const Layout = ({ children }) => {
  // สร้าง State สำหรับควบคุมการย่อ/ขยายของเมนู (เริ่มต้นให้ย่ออยู่)
  const [isExpanded, setIsExpanded] = useState(false);

  // ข้อมูลจำลองสำหรับ User (ถ้าระบบคุณมี Auth ให้ดึงข้อมูลจาก Context หรือ Hook แทน)
  const user = { name: 'TD User', avatar: 'T' };

  const handleLogout = () => {
    // โค้ดสำหรับจัดการการออกจากระบบ
    console.log('Logout clicked');
  };

  return (
    <div className="flex h-screen bg-gray-100">
      
      {/* ---------------- Sidebar ---------------- */}
      <div 
        className={`${
          isExpanded ? 'w-64' : 'w-20'
        } bg-gray-800 text-white transition-all duration-300 flex flex-col shrink-0`}
      >
        {/* ส่วนบน: ปุ่มกดขยาย/ย่อเมนู */}
        <div className="h-16 flex items-center justify-between px-4 border-b border-gray-700">
          {isExpanded && <span className="text-xl font-bold truncate">Project Tracker</span>}
          <button 
            onClick={() => setIsExpanded(!isExpanded)}
            className={`p-2 rounded-md hover:bg-gray-700 focus:outline-none ${!isExpanded ? 'mx-auto' : ''}`}
            title={isExpanded ? "ย่อเมนู" : "ขยายเมนู"}
          >
            <Bars3Icon className="w-6 h-6" />
          </button>
        </div>

        {/* ส่วนกลาง: รายการเมนู */}
        <nav className="flex-1 mt-4 space-y-2 px-2 overflow-y-auto">
          <Link to="/dashboard" className="flex items-center p-3 rounded transition duration-200 hover:bg-gray-700" title="Dashboard">
            <Squares2X2Icon className="w-6 h-6 shrink-0" />
            {isExpanded && <span className="ml-4 whitespace-nowrap">Dashboard</span>}
          </Link>
          <Link to="/projects" className="flex items-center p-3 rounded transition duration-200 hover:bg-gray-700" title="Projects">
            <FolderIcon className="w-6 h-6 shrink-0" />
            {isExpanded && <span className="ml-4 whitespace-nowrap">Projects</span>}
          </Link>
          <Link to="/team" className="flex items-center p-3 rounded transition duration-200 hover:bg-gray-700" title="Team">
            <UsersIcon className="w-6 h-6 shrink-0" />
            {isExpanded && <span className="ml-4 whitespace-nowrap">Team</span>}
          </Link>
          <Link to="/profile" className="flex items-center p-3 rounded transition duration-200 hover:bg-gray-700" title="Profile">
            <UserCircleIcon className="w-6 h-6 shrink-0" />
            {isExpanded && <span className="ml-4 whitespace-nowrap">Profile</span>}
          </Link>
        </nav>

        {/* ส่วนล่าง: อวตาร User และปุ่ม Logout */}
        <div className="border-t border-gray-700 p-2 mt-auto">
          {/* ข้อมูล User */}
          <div className={`flex items-center p-2 rounded-lg mb-2 ${isExpanded ? 'justify-start' : 'justify-center'}`}>
            <div className="w-10 h-10 rounded-full bg-blue-600 flex items-center justify-center font-bold text-lg shrink-0">
              {user.avatar}
            </div>
            {isExpanded && (
              <div className="ml-3 overflow-hidden">
                <p className="text-sm font-medium truncate">{user.name}</p>
              </div>
            )}
          </div>
          
          {/* ปุ่ม Logout */}
          <button 
            onClick={handleLogout}
            className={`w-full flex items-center p-3 rounded text-red-400 hover:bg-gray-700 hover:text-red-300 transition duration-200 ${isExpanded ? 'justify-start' : 'justify-center'}`}
            title="Logout"
          >
            <ArrowRightOnRectangleIcon className="w-6 h-6 shrink-0" />
            {isExpanded && <span className="ml-4 whitespace-nowrap">Logout</span>}
          </button>
        </div>
      </div>

      {/* ---------------- Main Content ---------------- */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* ลบ Header เดิมออก และให้เนื้อหาเริ่มจากขอบบนได้เลย */}
        <main className="flex-1 overflow-x-hidden overflow-y-auto bg-gray-200 p-6">
          {children}
          <Outlet />
        </main>
      </div>
      
    </div>
  );
};

export default Layout;