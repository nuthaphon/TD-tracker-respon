import React, { useState, useEffect } from 'react';
import { collection, query, where, getDocs, addDoc, serverTimestamp } from 'firebase/firestore';
import { db } from '../../firebase';
import { useAuth } from '../../hooks/useAuth';

const NewProjectForm = () => {
  const { userData } = useAuth();
  const [projectMode, setProjectMode] = useState('Internal');
  const [jobRequests, setJobRequests] = useState([]);
  const [selectedJobRequest, setSelectedJobRequest] = useState('');
  const [formData, setFormData] = useState({
    projectNo: '',
    projectType: 'Internal Project',
    subject: '',
    description: '',
    requester: userData ? userData.name : '',
    department: userData ? userData.dept : '',
    assignedTo: '',
    dueDate: '',
    status: 'Issued',
  });

  useEffect(() => {
    const fetchJobRequests = async () => {
      if (projectMode === 'อ้างอิงจาก Job request') {
        const q = query(collection(db, 'projects'), where('status', '==', 'Issued'));
        const snapshot = await getDocs(q);
        const requests = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
        setJobRequests(requests);
      }
    };
    fetchJobRequests();
  }, [projectMode]);

  useEffect(() => {
    if (selectedJobRequest) {
      const request = jobRequests.find(r => r.id === selectedJobRequest);
      if (request) {
        setFormData(prev => ({
          ...prev,
          subject: request.subject,
          description: request.description,
          department: request.department,
          requester: request.requester,
          assignedTo: request.assignedTo,
          dueDate: request.dueDate,
        }));
      }
    }
  }, [selectedJobRequest, jobRequests]);

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    await addDoc(collection(db, 'projects'), {
      ...formData,
      creationDate: new Date().toLocaleDateString(),
    });
    // Reset form or give feedback
  };

  return (
    <div className="bg-gray-800 p-8 rounded-lg shadow-md w-full max-w-4xl mt-8">
      <h2 className="text-2xl font-bold mb-6 text-center">Create New Project</h2>
      <form onSubmit={handleSubmit}>
        <div className="mb-4">
          <label>Project Mode</label>
          <select value={projectMode} onChange={(e) => setProjectMode(e.target.value)} className="w-full p-2 bg-gray-700 rounded-lg">
            <option value="Internal">Internal</option>
            <option value="อ้างอิงจาก Job request">อ้างอิงจาก Job request</option>
          </select>
        </div>

        {projectMode === 'อ้างอิงจาก Job request' && (
          <div className="mb-4">
            <label>Select Job Request</label>
            <select value={selectedJobRequest} onChange={(e) => setSelectedJobRequest(e.target.value)} className="w-full p-2 bg-gray-700 rounded-lg">
              <option value="">-- Select a Job Request --</option>
              {jobRequests.map(req => <option key={req.id} value={req.id}>{req.projectNo} - {req.subject}</option>)}
            </select>
          </div>
        )}

        {/* Form fields here, potentially disabled based on projectMode */}
        {/* For brevity, I'm omitting all the fields, but they would be here */}
        <button type="submit" className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-6 rounded-lg">Create Project</button>
      </form>
    </div>
  );
};

export default NewProjectForm;
