import React, { useState } from 'react';
import { addDoc, collection } from 'firebase/firestore';
import { db } from '../../firebase';
import { useAuth } from '../../hooks/useAuth';

const IssueJobRequestForm = () => {
  const { userData } = useAuth();
  const [projectType, setProjectType] = useState('');
  const [subject, setSubject] = useState('');
  const [description, setDescription] = useState('');
  const [creationDate, setCreationDate] = useState(new Date().toISOString().slice(0, 10));
  const [requester, setRequester] = useState(userData?.name || '');
  const [department, setDepartment] = useState(userData?.dept || '');

  const generateProjectId = () => {
    const date = new Date();
    const year = date.getFullYear();
    const month = (date.getMonth() + 1).toString().padStart(2, '0');
    const day = date.getDate().toString().padStart(2, '0');
    const uniqueId = Math.random().toString(36).substring(2, 10).toUpperCase();
    return `TD-${department}-${year}${month}${day}-${uniqueId}`;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await addDoc(collection(db, 'projects'), {
        projectNo: generateProjectId(),
        projectType,
        subject,
        description,
        creationDate,
        requester,
        department,
        status: 'Issued',
      });
      // Reset form
      setProjectType('');
      setSubject('');
      setDescription('');
    } catch (error) {
      console.error("Error adding document: ", error);
    }
  };

  return (
    <div className="bg-gray-800 p-8 rounded-lg shadow-md w-full max-w-2xl">
      <h2 className="text-2xl font-bold mb-6 text-center">Issue Job Request</h2>
      <form onSubmit={handleSubmit}>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div>
            <label className="block mb-2">Project No.</label>
            <input type="text" className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-lg" value="Auto-generated" readOnly />
          </div>
          <div>
            <label className="block mb-2">Project Type</label>
            <select className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-lg" value={projectType} onChange={(e) => setProjectType(e.target.value)}>
              <option value="">Select Project Type</option>
              <option value="Maintenance">Maintenance</option>
              <option value="New Project">New Project</option>
              <option value="Enhancement">Enhancement</option>
            </select>
          </div>
          <div className="col-span-2">
            <label className="block mb-2">Subject</label>
            <input type="text" className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-lg" value={subject} onChange={(e) => setSubject(e.target.value)} />
          </div>
          <div className="col-span-2">
            <label className="block mb-2">Description</label>
            <textarea className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-lg" value={description} onChange={(e) => setDescription(e.target.value)} />
          </div>
          <div>
            <label className="block mb-2">Creation Date</label>
            <input type="date" className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-lg" value={creationDate} readOnly />
          </div>
          <div>
            <label className="block mb-2">Requester</label>
            <input type="text" className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-lg" value={requester} readOnly />
          </div>
          <div>
            <label className="block mb-2">Department</label>
            <input type="text" className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-lg" value={department} readOnly />
          </div>
        </div>
        <button type="submit" className="w-full mt-6 bg-blue-500 hover:bg-blue-600 text-white font-bold py-2 px-4 rounded-lg">Submit</button>
      </form>
    </div>
  );
};

export default IssueJobRequestForm;
