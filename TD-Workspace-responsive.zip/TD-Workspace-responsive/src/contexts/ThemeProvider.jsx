import React, { createContext, useState, useEffect, useContext } from 'react';

// Create a context for the theme
const ThemeContext = createContext();

// Create a custom hook to use the ThemeContext
export const useTheme = () => {
  return useContext(ThemeContext);
};

export const ThemeProvider = ({ children }) => {
  // Initialize theme from localStorage or default to 'light' (Liquid Glass)
  const [theme, setTheme] = useState(() => {
    return localStorage.getItem('app-theme') || 'light';
  });

  useEffect(() => {
    // Determine the root element (usually <html>)
    const root = document.documentElement;

    // Remove any existing theme classes
    root.classList.remove('theme-dark', 'theme-unicorn');

    // Apply the new theme class based on state
    if (theme === 'dark') {
      root.classList.add('theme-dark');
    } else if (theme === 'unicorn') {
      root.classList.add('theme-unicorn');
    }
    // For 'light', we don't need a specific class as variables are under :root

    // Save the preference to localStorage
    localStorage.setItem('app-theme', theme);
  }, [theme]);

  // Provide the theme state and setter function to children
  return (
    <ThemeContext.Provider value={{ theme, setTheme }}>
      {children}
    </ThemeContext.Provider>
  );
};
