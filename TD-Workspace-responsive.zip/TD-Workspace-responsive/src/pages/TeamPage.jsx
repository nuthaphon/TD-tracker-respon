import React from 'react';
import TeamList from '../components/TeamList';

const TeamPage = () => {
  return (
    <div className="p-6">
      <h1 className="text-3xl font-bold mb-6">Team</h1>
      <TeamList />
    </div>
  );
};

export default TeamPage;
