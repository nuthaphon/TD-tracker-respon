import React, { useState, useEffect, useRef } from 'react';
import { useParams, useLocation, useNavigate } from 'react-router-dom'; // 🌟 เพิ่ม useNavigate
import { doc, getDoc, updateDoc, setDoc, serverTimestamp, collection, addDoc } from 'firebase/firestore';
import { db } from '../firebase';
import TestingReportForm from '../components/td-report/TestingReportForm';
import AcceptancePanel from '../components/td-report/AcceptancePanel';
import { useAuth } from '../hooks/useAuth';
import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';

const TDReportPage = () => {
    const { reportId } = useParams();
    const location = useLocation();
    const navigate = useNavigate(); // 🌟 สำหรับปุ่มย้อนกลับในหน้า Access Denied
    const { user, userData } = useAuth(); // 🌟 ดึง userData มาใช้เช็คสิทธิ์
    
    const [report, setReport] = useState(null);
    const [jobOrder, setJobOrder] = useState(null);
    const [project, setProject] = useState(null);
    const [loading, setLoading] = useState(true);
    const [isIssuer, setIsIssuer] = useState(false);
    
    const reportRef = useRef();

    // Effect to get Job Order and Project from location state (passed from Kanban)
    useEffect(() => {
        if (location.state) {
            setJobOrder(location.state.jobOrder);
            setProject(location.state.project);
        }
    }, [location.state]);

    // Effect to fetch existing report or initialize a new one
    useEffect(() => {
        const fetchReport = async () => {
            setLoading(true);
            if (reportId && reportId !== 'new') {
                const reportDocRef = doc(db, 'testingReports', reportId);
                const reportSnap = await getDoc(reportDocRef);
                if (reportSnap.exists()) {
                    const reportData = reportSnap.data();
                    setReport(reportData);
                    // Also fetch associated project and job order if not in state
                    if (!project && reportData.projectId) {
                        const projectSnap = await getDoc(doc(db, 'projects', reportData.projectId));
                        if(projectSnap.exists()) setProject(projectSnap.data());
                    }
                    if (!jobOrder && reportData.jobOrderId) {
                         const jobOrderSnap = await getDoc(doc(db, 'jobOrders', reportData.jobOrderId));
                        if(jobOrderSnap.exists()) setJobOrder(jobOrderSnap.data());
                    }

                } else {
                    console.error("No such report!");
                }
            } else if (jobOrder && project) {
                // This is a new report being created
                setReport({
                    projectId: project.id,
                    jobOrderId: jobOrder.id,
                    status: 'Draft', // Initial status
                    comments: [],
                    partList: [{ name: '', qty: 1, notes: '' }],
                    result: 'Pass',
                });
            }
            setLoading(false);
        };

        fetchReport();
    }, [reportId, jobOrder, project]);

    // Effect to check if the current user is the issuer of the job order
    useEffect(() => {
        if (user && jobOrder) {
            setIsIssuer(user.uid === jobOrder.issuerId);
        }
    }, [user, jobOrder]);

    // 🌟 ดักสิทธิ์การเข้าถึงหน้า: อนุญาตเฉพาะ TD และ Admin เท่านั้น 🌟
    const isTD = userData?.dept === 'TD' || userData?.role === 'Admin';
    if (!isTD) {
        return (
            <div className="h-full min-h-screen flex flex-col items-center justify-center text-text bg-surface">
                <i className="fas fa-lock text-6xl mb-4 text-red-500 opacity-50"></i>
                <h2 className="text-lg md:text-2xl font-bold text-text mb-2">Access Denied</h2>
                <p className="text-sm">หน้านี้สงวนสิทธิ์เฉพาะพนักงานแผนก TD เท่านั้น</p>
                <button onClick={() => navigate(-1)} className="mt-6 bg-blue-600 hover:bg-blue-500 text-text px-6 py-2.5 rounded-lg text-sm font-bold shadow-lg transition">
                    <i className="fas fa-arrow-left mr-2"></i> ย้อนกลับ
                </button>
            </div>
        );
    }

    const handleSaveReport = async (reportData) => {
        if (!user || !project || !jobOrder) {
            alert("Missing user, project, or job order details.");
            return;
        }

        const reportPayload = {
            ...reportData,
            projectId: project.id,
            jobOrderId: jobOrder.id,
            tdLeadId: user.uid, // The user creating it is the TD lead
            updatedAt: serverTimestamp(),
        };

        try {
            let docRef;
            if (reportId === 'new') {
                 // Create a new document in the 'testingReports' collection
                docRef = await addDoc(collection(db, 'testingReports'), {
                    ...reportPayload,
                    status: 'Submitted', // Change status upon first save
                    createdAt: serverTimestamp(),
                });
                 // Update the Job Order to link to this new report
                await updateDoc(doc(db, 'jobOrders', jobOrder.id), {
                    testingReportId: docRef.id,
                    status: 'For-Acceptance'
                });
                alert("Report submitted successfully!");
                // Maybe navigate away or update state to reflect the new ID
            } else {
                docRef = doc(db, 'testingReports', reportId);
                await updateDoc(docRef, {
                    ...reportPayload,
                     status: 'Submitted', // Resubmitting
                });
                await updateDoc(doc(db, 'jobOrders', jobOrder.id), {
                    status: 'For-Acceptance'
                });
                alert("Report updated and resubmitted!");
            }
        } catch (error) {
            console.error("Error saving report: ", error);
            alert("Failed to save report.");
        }
    };
    
    const handleAcceptanceAction = async (action, comment) => {
         if (!report || !user) return;

        const newComment = {
            text: comment,
            author: user.displayName || user.email,
            createdAt: new Date(),
            userId: user.uid,
        };
        
        const updatedComments = report.comments ? [...report.comments, newComment] : [newComment];
        let newStatus = report.status;
        let jobStatus = jobOrder.status;

        if (action === 'accept') {
            newStatus = 'Accepted';
            jobStatus = 'Completed'; // Or whatever terminal status is appropriate
            await updateDoc(doc(db, 'testingReports', reportId), {
                status: newStatus,
                comments: updatedComments,
                acceptedAt: serverTimestamp(),
                acceptedBy: user.uid,
            });
             await updateDoc(doc(db, 'jobOrders', jobOrder.id), { status: jobStatus });
        } else if (action === 'return') {
            newStatus = 'Returned for Edit';
            jobStatus = 'In-Progress'; // Back to TD
            await updateDoc(doc(db, 'testingReports', reportId), { 
                status: newStatus,
                comments: updatedComments 
            });
            await updateDoc(doc(db, 'jobOrders', jobOrder.id), { status: jobStatus });
        }
        
        // Refresh report data
        const updatedReportSnap = await getDoc(doc(db, 'testingReports', reportId));
        setReport(updatedReportSnap.data());
    };

    const generatePDF = () => {
        const input = reportRef.current;
        html2canvas(input, { scale: 2, backgroundColor: '#1f2937' }).then((canvas) => {
            const imgData = canvas.toDataURL('image/png');
            const pdf = new jsPDF('p', 'mm', 'a4');
            const pdfWidth = pdf.internal.pageSize.getWidth();
            const pdfHeight = pdf.internal.pageSize.getHeight();
            const imgWidth = canvas.width;
            const imgHeight = canvas.height;
            const ratio = Math.min(pdfWidth / imgWidth, pdfHeight / imgHeight);
            const imgX = (pdfWidth - imgWidth * ratio) / 2;
            const imgY = 10; // Margin from top
            pdf.addImage(imgData, 'PNG', imgX, imgY, imgWidth * ratio, imgHeight * ratio);
            pdf.save(`TD-Report-${project?.name || 'report'}.pdf`);
        });
    };


    if (loading) {
        return <div className="text-center text-text p-10">Loading Report...</div>;
    }
    
    if (!report) {
        return <div className="text-center text-red-500 p-10">Could not load report data. It may be a new report without project details.</div>;
    }

    // Determine if the form should be read-only
    let isFormReadOnly = report.status === 'Submitted' || report.status === 'Accepted' || report.status === 'Returned for Edit' && !isIssuer;
    if (isIssuer) {
        isFormReadOnly = report.status === 'Accepted' || report.status === 'Submitted';
    } else {
        isFormReadOnly = report.status === 'Accepted' || report.status === 'Submitted'
    }

    return (
        <div className="p-4 md:p-8 text-text">
            <div className="flex justify-between items-center mb-6">
                 <h1 className="text-3xl md:text-4xl font-bold">TD Testing Report</h1>
                 {report.status === 'Accepted' && (
                    <button onClick={generatePDF} className="bg-blue-600 text-text font-bold py-2 px-4 rounded-lg hover:bg-blue-700">Download as PDF</button>
                )}
            </div>

            <div ref={reportRef}>
                <TestingReportForm 
                    reportData={report} 
                    onSave={handleSaveReport} 
                    isReadOnly={isFormReadOnly} 
                    project={project}
                    jobOrder={jobOrder}
                />
            </div>

            {(report.status === 'Submitted' || report.status === 'Accepted' || report.status === 'Returned for Edit') && (
                <AcceptancePanel 
                    report={report} 
                    isIssuer={isIssuer} 
                    onAction={handleAcceptanceAction} 
                />
            )}
        </div>
    );
};

export default TDReportPage;