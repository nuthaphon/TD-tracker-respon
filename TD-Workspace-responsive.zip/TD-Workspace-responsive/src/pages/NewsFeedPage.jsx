import React, { useState, useEffect, useRef, useMemo } from 'react';
import { collection, query, orderBy, onSnapshot, addDoc, serverTimestamp, deleteDoc, doc, limit, updateDoc, arrayUnion, arrayRemove } from 'firebase/firestore';
// 🌟 นำเข้า Storage จาก Firebase
import { ref, uploadBytes, getDownloadURL, deleteObject } from 'firebase/storage';
import { db, storage } from '../firebase';
import { useAuth } from '../hooks/useAuth';
import { useNavigate } from 'react-router-dom';
import { logActivity } from '../utils/activityLogger';

// 🌟 รายการ Log กิจกรรมทั้งหมดที่จะดึงมาโชว์ในหน้า Feed 🌟
const PROJECT_ACTIONS = [
    'Updated Project Timeline', 'Updated Phase Schedule', 'Updated Phase Details', 
    'Assigned Phase Owner', 'Added Project Phase', 'Updated Project Progress', 
    'Uploaded Project File', 'Completed Project', 'E-Signed Document', 'Generated Handover Report',
    'Ordered Part', 'Updated Part Status', 'Received Part'
];

const NewsFeedPage = () => {
    const { userData, user } = useAuth();
    const navigate = useNavigate();

    // Data States
    const [manualPosts, setManualPosts] = useState([]);
    const [systemLogs, setSystemLogs] = useState([]);
    const [myProjects, setMyProjects] = useState([]);
    const [loading, setLoading] = useState(true);
    
    // Pagination State
    const [queryLimit, setQueryLimit] = useState(20);

    // Form State
    const [postText, setPostText] = useState('');
    const [selectedProjectId, setSelectedProjectId] = useState('');
    const [postAttachments, setPostAttachments] = useState([]);
    const [selectedFile, setSelectedFile] = useState(null);
    const [attachTitle, setAttachTitle] = useState('');
    const [isUploading, setIsUploading] = useState(false);
    const [isSubmitting, setIsSubmitting] = useState(false);
    const fileInputRef = useRef(null);

    // Comment State
    const [commentInputs, setCommentInputs] = useState({});
    const [showComments, setShowComments] = useState({});

    // 🌟 ดึงข้อมูล 2 แหล่ง (Posts + Logs) แบบ Real-time 🌟
    useEffect(() => {
        if (!user) return;

        // 1. ดึงโพสต์ที่คนพิมพ์เอง
        const qPosts = query(collection(db, 'td_posts'), orderBy('createdAt', 'desc'), limit(queryLimit));
        const unsubPosts = onSnapshot(qPosts, (snapshot) => {
            const fetchedPosts = snapshot.docs.map(doc => ({ id: doc.id, feedType: 'manual', ...doc.data() }));
            setManualPosts(fetchedPosts);
            setLoading(false);
        });

        // 2. ดึงประวัติกิจกรรม (Activity Logs)
        const qLogs = query(collection(db, 'activity_logs'), orderBy('timestamp', 'desc'), limit(queryLimit * 2));
        const unsubLogs = onSnapshot(qLogs, (snapshot) => {
            const fetchedLogs = snapshot.docs.map(doc => ({ id: doc.id, feedType: 'system', ...doc.data() }));
            const projectLogs = fetchedLogs.filter(log => PROJECT_ACTIONS.includes(log.action));
            setSystemLogs(projectLogs);
        });

        const unsubProjects = onSnapshot(collection(db, 'td_projects'), (snapshot) => {
            const allProj = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
            const activeMyProj = allProj.filter(p => !['Completed', 'Accepted'].includes(p.status) && (p.owner === userData?.name || p.coWorkers?.includes(userData?.name)));
            setMyProjects(activeMyProj);
        });

        return () => { unsubPosts(); unsubLogs(); unsubProjects(); };
    }, [user, userData, queryLimit]);

    // 🌟 ผสาน Posts และ Logs เข้าด้วยกัน และเรียงลำดับตามเวลาจริง 🌟
    const combinedFeed = useMemo(() => {
        const merged = [...manualPosts, ...systemLogs];
        return merged.sort((a, b) => {
            const getTime = (item) => {
                const ts = item.feedType === 'manual' ? item.createdAt : item.timestamp;
                if (!ts) return Date.now(); 
                if (typeof ts.toDate === 'function') return ts.toDate().getTime(); 
                return new Date(ts).getTime(); 
            };
            const timeA = getTime(a);
            const timeB = getTime(b);
            return timeB - timeA; 
        }).slice(0, queryLimit);
    }, [manualPosts, systemLogs, queryLimit]);

    const handleLoadMore = () => {
        setQueryLimit(prev => prev + 20);
    };

    // ------------- 🌟 ฟังก์ชันอัปโหลดไฟล์ไปที่ Firebase Storage 🌟 -------------
    const handleFileUpload = async (e) => {
        e.preventDefault();
        if (!selectedFile || !attachTitle.trim()) return alert("กรุณาตั้งชื่อไฟล์และเลือกไฟล์");
        if (selectedFile.size > 10 * 1024 * 1024) return alert("ขนาดไฟล์ใหญ่เกินไป (สูงสุด 10MB)");

        setIsUploading(true);
        try {
            const uniqueFileName = `${Date.now()}_${selectedFile.name}`;
            const storageRef = ref(storage, `newsfeed_files/${uniqueFileName}`);
            const snapshot = await uploadBytes(storageRef, selectedFile);
            const downloadURL = await getDownloadURL(snapshot.ref);

            let fileType = 'document';
            if (selectedFile.type.includes('image')) fileType = 'image';
            else if (selectedFile.type.includes('pdf')) fileType = 'docs';
            else if (selectedFile.type.includes('spreadsheet') || selectedFile.type.includes('excel') || selectedFile.name.endsWith('.csv')) fileType = 'sheets';

            setPostAttachments(prev => [...prev, {
                id: Date.now().toString(), 
                title: attachTitle, 
                url: downloadURL, 
                type: fileType,
                storagePath: `newsfeed_files/${uniqueFileName}`,
                addedBy: userData?.name, 
                timestamp: new Date().toISOString()
            }]);
            
            setAttachTitle(''); 
            setSelectedFile(null);
            if(fileInputRef.current) fileInputRef.current.value = "";
            setIsUploading(false);
        } catch (error) { 
            console.error("Upload error:", error);
            alert("เกิดข้อผิดพลาดในการอัปโหลดไฟล์ไปยัง Storage"); 
            setIsUploading(false); 
        }
    };

    const handleCreatePost = async (e) => {
        e.preventDefault();
        if (!postText.trim()) return alert("กรุณาพิมพ์ข้อความอัปเดต");
        if (selectedFile && postAttachments.length === 0) return alert("⚠️ คุณเลือกไฟล์ไว้แต่ยังไม่ได้กดปุ่ม 'คลิปหนีบกระดาษ' เพื่ออัปโหลดครับ");
        
        setIsSubmitting(true);
        try {
            const projObj = myProjects.find(p => p.id === selectedProjectId);
            await addDoc(collection(db, 'td_posts'), {
                text: postText,
                projectId: selectedProjectId || null,
                projectName: projObj ? projObj.projectName : null,
                author: userData?.name,
                authorId: user?.uid,
                authorAvatar: userData?.avatar || userData?.photoURL || null, // 🌟 แนบรูปโปรไฟล์ลงในโพสต์
                attachments: [...postAttachments], 
                likes: [], comments: [],
                createdAt: serverTimestamp()
            });
            await logActivity(user, 'Posted Update', `โพสต์อัปเดตงาน${projObj ? ` ในโปรเจกต์ ${projObj.projectName}` : ''}`);
            setPostText(''); setSelectedProjectId(''); setPostAttachments([]); 
        } catch (error) { alert("เกิดข้อผิดพลาดในการโพสต์"); } 
        finally { setIsSubmitting(false); }
    };

    const handleDeletePost = async (postItem) => {
        if(!window.confirm("คุณต้องการลบโพสต์พร้อมไฟล์แนบทั้งหมดใช่หรือไม่?")) return;
        
        try {
            // 1. เช็คว่าโพสต์นี้มีไฟล์แนบไหม ถ้ามีให้วนลบออกจาก Firebase Storage ก่อน
            if (postItem.attachments && postItem.attachments.length > 0) {
                for (const file of postItem.attachments) {
                    if (file.storagePath) { // เช็คว่ามี path อ้างอิงไหม
                        const fileRef = ref(storage, file.storagePath);
                        await deleteObject(fileRef).catch(err => console.error("Failed to delete file:", err));
                    }
                }
            }

            // 2. ลบข้อมูลโพสต์ออกจาก Firestore
            await deleteDoc(doc(db, 'td_posts', postItem.id));
            
        } catch (error) {
            console.error("Error deleting post and files:", error);
            alert("เกิดข้อผิดพลาดในการลบโพสต์");
        }
    };

    // ------------- ฟังก์ชันไลก์/คอมเมนต์ -------------
    const handleToggleLike = async (postId, currentLikes = []) => {
        const hasLiked = currentLikes.includes(user.uid);
        const postRef = doc(db, 'td_posts', postId);
        try {
            if (hasLiked) await updateDoc(postRef, { likes: arrayRemove(user.uid) });
            else await updateDoc(postRef, { likes: arrayUnion(user.uid) });
        } catch (error) { console.error("Error toggling like:", error); }
    };

    const handleToggleComments = (postId) => {
        setShowComments(prev => ({ ...prev, [postId]: !prev[postId] }));
    };

    const handleAddComment = async (e, postId) => {
        e.preventDefault();
        const text = commentInputs[postId];
        if (!text || !text.trim()) return;

        const newComment = { 
            id: Date.now().toString() + Math.random().toString(36).substr(2, 9), 
            text: text.trim(), 
            author: userData?.name, 
            authorId: user?.uid, 
            authorAvatar: userData?.avatar || userData?.photoURL || null, // 🌟 แนบรูปโปรไฟล์ลงในคอมเมนต์
            timestamp: new Date().toISOString() 
        };
        try {
            await updateDoc(doc(db, 'td_posts', postId), { comments: arrayUnion(newComment) });
            setCommentInputs(prev => ({ ...prev, [postId]: '' })); 
            setShowComments(prev => ({ ...prev, [postId]: true })); 
        } catch (error) { console.error("Error adding comment:", error); }
    };

    const handleDeleteComment = async (postId, commentObj) => {
        if (!window.confirm("ต้องการลบคอมเมนต์นี้ใช่หรือไม่?")) return;
        try { await updateDoc(doc(db, 'td_posts', postId), { comments: arrayRemove(commentObj) }); } 
        catch (error) { console.error("Error deleting comment:", error); }
    };

    // ------------- Helpers -------------
    const timeAgo = (timestamp) => {
        if (!timestamp) return 'Just now';
        const date = timestamp?.toDate ? timestamp.toDate() : new Date(timestamp);
        const seconds = Math.floor((new Date() - date) / 1000);
        if (seconds < 60) return 'เมื่อสักครู่';
        if (seconds < 3600) return `${Math.floor(seconds / 60)} นาทีที่แล้ว`;
        if (seconds < 86400) return `${Math.floor(seconds / 3600)} ชั่วโมงที่แล้ว`;
        if (seconds < 2592000) return `${Math.floor(seconds / 86400)} วันที่แล้ว`;
        return date.toLocaleDateString('th-TH');
    };

    const getThumbnailUrl = (url) => {
        if (!url) return '';
        const match = url.match(/\/d\/([a-zA-Z0-9_-]+)/);
        return match ? `https://drive.google.com/thumbnail?id=${match[1]}` : url;
    };

    const getSystemIcon = (action) => {
        if (action.includes('Progress') || action.includes('Phase')) return 'fa-tasks text-purple-400 bg-purple-500/20';
        if (action.includes('File')) return 'fa-file-upload text-primary bg-blue-500/20';
        if (action.includes('Completed') || action.includes('Sign')) return 'fa-check-circle text-green-400 bg-green-500/20';
        if (action.includes('Part')) return 'fa-box text-yellow-400 bg-yellow-500/20';
        return 'fa-bolt text-orange-400 bg-orange-500/20';
    };

    const isTD = userData?.dept === 'TD' || userData?.role === 'Admin';
    if (!isTD) {
        return (
            <div className="h-full min-h-screen flex flex-col items-center justify-center text-text bg-surface">
                <i className="fas fa-lock text-6xl mb-4 text-red-500 opacity-50"></i>
                <h2 className="text-lg md:text-2xl font-bold text-text mb-2">Access Denied</h2>
                <p className="text-sm">หน้านี้สงวนสิทธิ์เฉพาะพนักงานแผนก TD เท่านั้น</p>
                <button onClick={() => navigate(-1)} className="mt-6 bg-blue-600 hover:bg-blue-500 text-text px-6 py-2.5 rounded-lg text-sm font-bold shadow-lg transition">
                    <i className="fas fa-arrow-left mr-2"></i> ย้อนกลับ
                </button>
            </div>
        );
    }

    if (loading) return <div className="flex justify-center items-center h-full"><div className="animate-spin rounded-full h-12 w-12 border-t-2 border-blue-500"></div></div>;

    return (
        <div className="h-full flex flex-col relative w-full">
            <div className="w-full shrink-0 px-4 md:px-0">
                <div className="max-w-4xl mx-auto mb-4 border-b border-glass pb-4 pt-4">
                    <h1 className="text-lg md:text-2xl font-black text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-purple-400 tracking-wide flex items-center">
                        <i className="fas fa-stream text-primary mr-3"></i> Project Timeline & Feed
                    </h1>
                    <p className="text-xs text-text mt-1 font-bold">ศูนย์รวมโพสต์อัปเดตงาน และประวัติการทำงานอัตโนมัติ</p>
                </div>
            </div>

            <div className="flex-1 overflow-y-auto custom-scrollbar w-full">
                <div className="max-w-4xl mx-auto space-y-6 pb-10 px-4 md:px-0">
                    
                    {/* 🌟 ฟอร์มสร้างโพสต์ 🌟 */}
                    <div className="bg-surface rounded-2xl border border-glass shadow-xl overflow-hidden relative">
                        <div className="p-4 bg-surface/50 border-b border-glass flex items-center gap-3">
                            {/* 🌟 แสดงรูปโปรไฟล์ของผู้ใช้งานในส่วนฟอร์มโพสต์ */}
                            <div className="w-10 h-10 rounded-full bg-blue-600 flex items-center justify-center text-text font-bold text-lg shadow-inner overflow-hidden shrink-0 border border-glass">
                                {(userData?.avatar || userData?.photoURL) ? (
                                    <img src={userData.avatar || userData.photoURL} alt="Profile" className="w-full h-full object-cover bg-surface" referrerPolicy="no-referrer" />
                                ) : (
                                    userData?.name?.substring(0, 2).toUpperCase() || 'U'
                                )}
                            </div>
                            <span className="font-bold text-text">สร้างโพสต์อัปเดตงานใหม่</span>
                        </div>
                        
                        <form onSubmit={handleCreatePost} className="p-4">
                            <textarea 
                                value={postText} onChange={(e) => setPostText(e.target.value)} 
                                placeholder="วันนี้ทีมของคุณอัปเดตงานอะไรไปบ้าง? (พิมพ์ที่นี่...)" 
                                className="w-full bg-surface/50 border border-glass rounded-xl p-4 text-text outline-none focus:border-blue-500 resize-none mb-3 placeholder-gray-500 transition-colors" 
                                rows="3" required 
                            />
                            
                            <div className="flex flex-col sm:flex-row gap-3 mb-4">
                                <div className="flex-1">
                                    <select value={selectedProjectId} onChange={(e) => setSelectedProjectId(e.target.value)} className="w-full p-2.5 bg-surface rounded-lg border border-glass text-sm text-text outline-none focus:border-blue-500 transition-colors" style={{ backgroundColor: 'var(--color-bg)', color: 'var(--color-text)' }}>
                                        <option value="">-- ไม่เชื่อมโยงโปรเจกต์ (ประกาศทั่วไป) --</option>
                                        {myProjects.map(p => <option key={p.id} value={p.id}>{p.projectName}</option>)}
                                    </select>
                                </div>
                            </div>

                            {postAttachments.length > 0 && (
                                <div className="mb-3 flex flex-wrap gap-2 p-3 bg-surface/50 rounded-lg border border-glass">
                                    {postAttachments.map(file => (
                                        <div key={file.id} className="flex items-center gap-2 bg-surface px-3 py-1.5 rounded-full border border-glass text-xs text-primary">
                                            <i className={`fas ${file.type === 'image' ? 'fa-image text-purple-400' : 'fa-file-pdf text-red-400'}`}></i>
                                            <span className="truncate max-w-[150px]">{file.title}</span>
                                            <button type="button" onClick={() => setPostAttachments(postAttachments.filter(f => f.id !== file.id))} className="text-text hover:text-red-500"><i className="fas fa-times"></i></button>
                                        </div>
                                    ))}
                                </div>
                            )}

                            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center pt-3 border-t border-glass gap-3">
                                <div className="flex w-full sm:w-auto items-center gap-2 bg-surface/50 p-1.5 rounded-lg border border-glass">
                                    <input type="text" value={attachTitle} onChange={(e)=>setAttachTitle(e.target.value)} placeholder="ตั้งชื่อไฟล์..." className="w-24 sm:w-32 bg-transparent text-xs text-text outline-none px-2" disabled={isUploading}/>
                                    <div className="w-px h-5 bg-surface mx-1"></div>
                                    <input type="file" ref={fileInputRef} onChange={(e)=>setSelectedFile(e.target.files[0])} className="w-48 text-[10px] text-text file:mr-2 file:py-1 file:px-2 file:rounded file:border-1 file:bg-surface file:text-text cursor-pointer" disabled={isUploading}/>
                                    <button type="button" onClick={handleFileUpload} disabled={!selectedFile || !attachTitle || isUploading} className="bg-surface hover:bg-surface text-text px-3 py-1 rounded text-xs font-bold transition disabled:opacity-50">
                                        {isUploading ? <i className="fas fa-spinner fa-spin"></i> : <i className="fas fa-paperclip"></i>}
                                    </button>
                                </div>
                                
                                <button type="submit" disabled={isSubmitting || !postText.trim()} className="w-full sm:w-auto bg-blue-600 hover:bg-blue-500 text-text px-8 py-2.5 rounded-lg font-bold shadow-lg shadow-blue-500/30 transition-all disabled:opacity-50 disabled:shadow-none flex items-center justify-center">
                                    {isSubmitting ? 'กำลังโพสต์...' : <><i className="fas fa-paper-plane mr-2"></i> โพสต์อัปเดต</>}
                                </button>
                            </div>
                        </form>
                    </div>

                    {/* 🌟 กระดานแสดงผลเรียงต่อกันตรงๆ (Stacked Feed) 🌟 */}
                    <div className="space-y-5 w-full">
                        
                        {combinedFeed.map(item => {
                            // 🌟 1. กรณีเป็น โพสต์จากพนักงาน (Manual Post)
                            if (item.feedType === 'manual') {
                                const isLikedByMe = item.likes && item.likes.includes(user?.uid);
                                const likeCount = item.likes ? item.likes.length : 0;
                                const commentCount = item.comments ? item.comments.length : 0;

                                return (
                                    <div key={item.id} className="bg-surface rounded-2xl border border-glass shadow-xl overflow-hidden animate-fade-in-down w-full">
                                        <div className="p-4 flex justify-between items-start">
                                            <div className="flex items-center gap-3">
                                                {/* 🌟 แสดงรูปโปรไฟล์ของเจ้าของโพสต์ */}
                                                <div className="w-10 h-10 rounded-full bg-surface flex items-center justify-center text-text font-bold border border-glass shadow-inner shrink-0 overflow-hidden">
                                                    {item.authorAvatar ? (
                                                        <img src={item.authorAvatar} alt="Profile" className="w-full h-full object-cover bg-surface" referrerPolicy="no-referrer" />
                                                    ) : (
                                                        item.author?.substring(0, 2).toUpperCase() || 'U'
                                                    )}
                                                </div>
                                                <div className="flex flex-col">
                                                    <span className="font-bold text-primary text-sm">{item.author}</span>
                                                    <span className="text-[10px] text-text"><i className="far fa-clock mr-1"></i> {timeAgo(item.createdAt)}</span>
                                                </div>
                                            </div>
                                            {item.authorId === user?.uid && (
                                                <button onClick={() => handleDeletePost(item)} className="text-text hover:text-red-500 transition bg-surface rounded-full w-8 h-8 flex items-center justify-center border border-transparent hover:border-red-500/30">
                                                 <i className="fas fa-trash-alt text-xs"></i>
                                                </button>
                                            )}
                                        </div>

                                        <div className="px-4 pb-2">
                                            {item.projectId && (
                                                <div onClick={() => navigate(`/project/${item.projectId}`)} className="inline-flex items-center gap-2 mb-3 bg-purple-900/30 border border-purple-500/30 text-purple-600 px-3 py-1.5 rounded-lg text-xs font-bold cursor-pointer hover:bg-purple-900/50 transition">
                                                    <i className="fas fa-project-diagram"></i> Project: {item.projectName}
                                                </div>
                                            )}
                                            <p className="text-text text-sm whitespace-pre-wrap leading-relaxed">{item.text}</p>
                                        </div>

                                        {item.attachments && item.attachments.length > 0 && (
                                            <div className="px-4 pb-3 flex flex-wrap gap-2 mt-1">
                                                {item.attachments.map((file, idx) => (
                                                    file.type === 'image' ? (
                                                        <a key={idx} href={file.url} target="_blank" rel="noreferrer" className="block relative group overflow-hidden rounded-xl border border-glass hover:border-blue-500 transition-all w-32 h-20 shadow-md">
                                                            <img src={getThumbnailUrl(file.url)} alt={file.title} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300 opacity-80 group-hover:opacity-100" />
                                                            <div className="absolute inset-x-0 bottom-0 bg-black/70 p-1 backdrop-blur-sm"><p className="text-[8px] text-text font-bold truncate text-center">{file.title}</p></div>
                                                        </a>
                                                    ) : (
                                                        <a key={idx} href={file.url} target="_blank" rel="noreferrer" className="flex items-center gap-2 bg-surface hover:bg-surface border border-glass p-2 rounded-xl transition group min-w-[150px] shadow-sm">
                                                            <i className={`fas ${file.type === 'sheets' ? 'fa-file-excel text-green-500' : 'fa-file-pdf text-red-500'} text-lg`}></i>
                                                            <div className="flex flex-col overflow-hidden">
                                                                <span className="text-xs text-primary font-bold truncate group-hover:text-primary transition-colors">{file.title}</span>
                                                            </div>
                                                        </a>
                                                    )
                                                ))}
                                            </div>
                                        )}

                                        <div className="px-4 py-3 border-t border-glass/50 flex items-center gap-6 bg-surface/30">
                                            <button onClick={() => handleToggleLike(item.id, item.likes)} className={`flex items-center gap-2 text-sm font-bold transition-all ${isLikedByMe ? 'text-primary' : 'text-text hover:text-text'}`}>
                                                <i className={`fas fa-thumbs-up ${isLikedByMe ? 'scale-110 animate-bounce-short' : ''}`}></i>
                                                {likeCount} {likeCount > 0 ? 'ถูกใจ' : 'ถูกใจ'}
                                            </button>
                                            <button onClick={() => handleToggleComments(item.id)} className="flex items-center gap-2 text-sm font-bold text-text hover:text-text transition-colors">
                                                <i className="fas fa-comment-alt"></i>
                                                {commentCount} คอมเมนต์
                                            </button>
                                        </div>

                                        {showComments[item.id] && (
                                            <div className="px-4 pb-4 pt-2 bg-surface/50 border-t border-glass">
                                                <div className="space-y-3 mb-4 max-h-60 overflow-y-auto custom-scrollbar pr-1">
                                                    {(item.comments || []).map((comment) => (
                                                        <div key={comment.id} className="flex items-start gap-3 group">
                                                            {/* 🌟 แสดงรูปโปรไฟล์ของคนคอมเมนต์ */}
                                                            <div className="w-8 h-8 rounded-full bg-surface flex items-center justify-center text-text font-bold text-[10px] shrink-0 border border-glass overflow-hidden">
                                                                {comment.authorAvatar ? (
                                                                    <img src={comment.authorAvatar} alt="Profile" className="w-full h-full object-cover bg-surface" referrerPolicy="no-referrer" />
                                                                ) : (
                                                                    comment.author?.substring(0, 2).toUpperCase()
                                                                )}
                                                            </div>
                                                            <div className="flex-1 bg-surface rounded-2xl rounded-tl-sm px-4 py-2.5 relative group-hover:bg-surface/80 transition-colors border border-glass/50 shadow-sm">
                                                                <div className="flex justify-between items-start mb-0.5">
                                                                    <span className="text-xs font-bold text-primary">{comment.author}</span>
                                                                    {(comment.authorId === user?.uid || item.authorId === user?.uid) && (
                                                                        <button onClick={() => handleDeleteComment(item.id, comment)} className="text-text hover:text-red-500 opacity-0 group-hover:opacity-100 transition absolute right-3 top-2.5" title="ลบคอมเมนต์">
                                                                            <i className="fas fa-times text-[10px]"></i>
                                                                        </button>
                                                                    )}
                                                                </div>
                                                                <p className="text-xs text-text whitespace-pre-wrap">{comment.text}</p>
                                                                <span className="text-[9px] text-text block mt-1">{timeAgo(comment.timestamp)}</span>
                                                            </div>
                                                        </div>
                                                    ))}
                                                    {commentCount === 0 && <p className="text-center text-xs text-text italic py-2">ยังไม่มีคอมเมนต์ เป็นคนแรกที่ให้ความเห็นสิ!</p>}
                                                </div>
                                                <form onSubmit={(e) => handleAddComment(e, item.id)} className="flex items-center gap-3">
                                                    {/* 🌟 แสดงรูปโปรไฟล์ของช่องพิมพ์คอมเมนต์ */}
                                                    <div className="w-8 h-8 rounded-full bg-blue-600 flex items-center justify-center text-text font-bold text-[10px] shrink-0 shadow-inner overflow-hidden border border-glass">
                                                        {(userData?.avatar || userData?.photoURL) ? (
                                                            <img src={userData.avatar || userData.photoURL} alt="Profile" className="w-full h-full object-cover bg-surface" referrerPolicy="no-referrer" />
                                                        ) : (
                                                            userData?.name?.substring(0, 2).toUpperCase()
                                                        )}
                                                    </div>
                                                    <div className="flex-1 flex bg-surface border border-glass rounded-full overflow-hidden focus-within:border-blue-500 transition-colors shadow-inner">
                                                        <input type="text" value={commentInputs[item.id] || ''} onChange={(e) => setCommentInputs(prev => ({...prev, [item.id]: e.target.value}))} placeholder="เขียนคอมเมนต์..." className="flex-1 bg-transparent px-4 py-2 text-xs text-text outline-none"/>
                                                        <button type="submit" disabled={!commentInputs[item.id]?.trim()} className="px-4 bg-surface hover:bg-blue-600 text-text hover:text-text disabled:bg-surface disabled:text-text disabled:opacity-50 transition flex items-center justify-center"><i className="fas fa-paper-plane text-[10px]"></i></button>
                                                    </div>
                                                </form>
                                            </div>
                                        )}
                                    </div>
                                );
                            } 
                            
                            // 🌟 2. กรณีเป็น ประวัติกิจกรรมระบบ (System Log)
                            else {
                                const IconClasses = getSystemIcon(item.action).split(' ');
                                const faIcon = IconClasses[0];
                                const colorClasses = IconClasses.slice(1).join(' ');

                                return (
                                    <div key={item.id} className="bg-surface/50 rounded-xl border border-glass/50 shadow-sm p-3 hover:border-glass transition-colors flex items-center gap-4 animate-fade-in-down w-full">
                                        <div className={`flex items-center justify-center w-10 h-10 rounded-full shrink-0 shadow-inner ${colorClasses}`}>
                                            <i className={`fas ${faIcon} text-sm text-text`}></i>
                                        </div>
                                        <div className="flex-1 flex flex-col min-w-0">
                                            <div className="flex justify-between items-center mb-0.5">
                                                <span className="text-xs font-bold text-text truncate pr-2"><i className="fas fa-robot text-[10px] mr-1.5 text-text"></i> {item.userName || item.email?.split('@')[0] || 'System'}</span>
                                                <span className="text-[9px] text-text shrink-0"><i className="far fa-clock mr-1"></i> {timeAgo(item.timestamp)}</span>
                                            </div>
                                            <p className="text-xs text-text leading-snug truncate">
                                                <span className="text-primary font-bold">{item.action}</span>: {item.details}
                                            </p>
                                        </div>
                                    </div>
                                );
                            }
                        })}
                    </div>

                    {/* ปุ่ม Load More */}
                    {combinedFeed.length > 0 && (
                        <div className="flex justify-center pt-6 pb-4">
                            <button 
                                onClick={handleLoadMore} 
                                className="bg-surface hover:bg-surface text-primary border border-blue-500/30 px-6 py-2.5 rounded-full text-sm font-bold shadow-lg transition-all flex items-center gap-2"
                            >
                                <i className="fas fa-chevron-down"></i> โหลดโพสต์เพิ่มเติม
                            </button>
                        </div>
                    )}

                    {combinedFeed.length === 0 && (
                        <div className="text-center py-20 text-text bg-surface/30 rounded-2xl border border-glass border-dashed">
                            <i className="far fa-newspaper text-6xl mb-4 opacity-20"></i>
                            <p className="text-lg font-bold text-text">ยังไม่มีอัปเดตในระบบ</p>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};

export default NewsFeedPage;