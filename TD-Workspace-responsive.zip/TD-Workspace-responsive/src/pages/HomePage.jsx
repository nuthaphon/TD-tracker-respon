import React from 'react';
import { Link } from 'react-router-dom';

const HomePage = () => {
  return (
    <div className="bg-surface text-text min-h-screen flex flex-col items-center justify-center">
      <h1 className="text-5xl font-bold mb-8">Project Tracker</h1>
      <div className="space-x-4">
        <Link to="/login" className="bg-blue-500 hover:bg-blue-600 text-text font-bold py-2 px-4 rounded-lg">Login</Link>
        <Link to="/register" className="bg-green-500 hover:bg-green-600 text-text font-bold py-2 px-4 rounded-lg">Register</Link>
      </div>
    </div>
  );
};

export default HomePage;
