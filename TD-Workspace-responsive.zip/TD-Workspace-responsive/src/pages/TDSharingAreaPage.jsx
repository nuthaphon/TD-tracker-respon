import React, { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { collection, query, where, onSnapshot, addDoc, deleteDoc, doc, serverTimestamp } from 'firebase/firestore';
import { db } from '../firebase';
import { useAuth } from '../hooks/useAuth';
import { logActivity } from '../utils/activityLogger';

const GOOGLE_SCRIPT_URL = 'https://script.google.com/macros/s/AKfycbxYiOqkswbRHPY8g36qXZ9e88b4kdOeKXKoWl5aYGDWNe2lNo0CroF7yNXEpXWkE9LZBA/exec';

const getAttachmentIcon = (type) => {
    switch (type) {
        case 'sheets': return <i className="fas fa-file-excel text-green-600"></i>;
        case 'docs': return <i className="fas fa-file-pdf text-red-500"></i>;
        case 'image': return <i className="fas fa-image text-purple-400"></i>;
        default: return <i className="fas fa-file-alt text-text"></i>;
    }
};

const extractDriveId = (url) => {
    const match = url.match(/\/d\/([a-zA-Z0-9_-]+)/);
    return match ? match[1] : null;
};

const TDSharingAreaPage = () => {
    const { userData, user } = useAuth();
    const navigate = useNavigate();
    const [tdUsers, setTdUsers] = useState([]);
    const [loading, setLoading] = useState(true);

    // สถานะการนำทาง
    const [currentOwner, setCurrentOwner] = useState(null); // เก็บ object ของคนที่เราคลิกเข้าบ้าน
    const [folderPath, setFolderPath] = useState([{ id: 'root', name: 'Home' }]); // สำหรับ Breadcrumb
    const currentFolderId = folderPath[folderPath.length - 1].id;

    // ข้อมูลไฟล์และโฟลเดอร์
    const [items, setItems] = useState([]);
    
    // สถานะฟอร์ม
    const [newFolderName, setNewFolderName] = useState('');
    const [attachTitle, setAttachTitle] = useState('');
    const [selectedFile, setSelectedFile] = useState(null);
    const [isUploading, setIsUploading] = useState(false);
    const fileInputRef = useRef(null);

    // การพรีวิวไฟล์
    const [previewFile, setPreviewFile] = useState(null);

    // ดึงรายชื่อคนในแผนก TD สำหรับสร้างแผนที่หมู่บ้าน
    useEffect(() => {
        const qUsers = query(collection(db, 'users'), where('dept', '==', 'TD'));
        const unsub = onSnapshot(qUsers, (snapshot) => {
            const users = snapshot.docs.map(doc => ({ uid: doc.id, ...doc.data() }));
            setTdUsers(users.filter(u => u.role !== 'pending'));
            setLoading(false);
        });
        return () => unsub();
    }, []);

    // ดึงไฟล์และโฟลเดอร์เมื่อเลือกบ้านและอยู่ในโฟลเดอร์นั้นๆ
    useEffect(() => {
        if (!currentOwner) return;

        const qItems = query(
            collection(db, 'td_sharing'),
            where('ownerId', '==', currentOwner.uid),
            where('parentId', '==', currentFolderId)
        );

        const unsub = onSnapshot(qItems, (snapshot) => {
            const fetchedItems = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
            // เรียงให้โฟลเดอร์ขึ้นก่อน แล้วตามด้วยไฟล์ และเรียงตามเวลา
            fetchedItems.sort((a, b) => {
                if (a.type === 'folder' && b.type !== 'folder') return -1;
                if (a.type !== 'folder' && b.type === 'folder') return 1;
                return b.timestamp?.localeCompare(a.timestamp);
            });
            setItems(fetchedItems);
        });

        return () => unsub();
    }, [currentOwner, currentFolderId]);

    // 🌟 ดักสิทธิ์การเข้าถึงหน้า: อนุญาตเฉพาะ TD และ Admin 🌟
    const isTD = userData?.dept === 'TD' || userData?.role === 'Admin';
    if (!isTD) {
        return (
            <div className="h-full min-h-screen flex flex-col items-center justify-center text-text bg-surface">
                <i className="fas fa-lock text-6xl mb-4 text-red-500 opacity-50"></i>
                <h2 className="text-lg md:text-2xl font-bold text-text mb-2">Access Denied</h2>
                <p className="text-sm">หน้านี้สงวนสิทธิ์เฉพาะพนักงานแผนก TD เท่านั้น</p>
                <button onClick={() => navigate(-1)} className="mt-6 bg-blue-600 hover:bg-blue-500 text-text px-6 py-2.5 rounded-lg text-sm font-bold shadow-lg transition">
                    <i className="fas fa-arrow-left mr-2"></i> ย้อนกลับ
                </button>
            </div>
        );
    }

    // ฟังก์ชันสร้างโฟลเดอร์
    const handleCreateFolder = async (e) => {
        e.preventDefault();
        if (!newFolderName.trim()) return;

        try {
            await addDoc(collection(db, 'td_sharing'), {
                ownerId: currentOwner.uid,
                parentId: currentFolderId,
                type: 'folder',
                title: newFolderName,
                addedBy: userData.name,
                timestamp: new Date().toISOString(),
                createdAt: serverTimestamp()
            });
            await logActivity(user, 'Created Folder', `สร้างโฟลเดอร์ "${newFolderName}" ในพื้นที่ของ ${currentOwner.name}`);
            setNewFolderName('');
        } catch (error) {
            alert('สร้างโฟลเดอร์ไม่สำเร็จ');
        }
    };

    // ฟังก์ชันอัปโหลดไฟล์ (อ้างอิงจาก ProjectSpacePage)
    const handleFileUpload = async (e) => {
        e.preventDefault();
        if (!selectedFile || !attachTitle.trim()) return alert("กรุณาตั้งชื่อไฟล์และเลือกไฟล์ก่อนอัปโหลด");
        if (selectedFile.size > 10 * 1024 * 1024) return alert("ขนาดไฟล์ใหญ่เกินไป (สูงสุด 10MB)");

        setIsUploading(true);
        try {
            const reader = new FileReader();
            reader.readAsDataURL(selectedFile);
            reader.onload = async () => {
                const base64Data = reader.result.split(',')[1]; 
                const response = await fetch(GOOGLE_SCRIPT_URL, {
                    method: 'POST', headers: { 'Content-Type': 'text/plain;charset=utf-8' },
                    body: JSON.stringify({ fileName: `${Date.now()}_${selectedFile.name}`, mimeType: selectedFile.type, base64: base64Data })
                });
                const result = await response.json();
                
                if (result.status === 'success') {
                    let fileType = 'document';
                    if (selectedFile.type.includes('image')) fileType = 'image';
                    else if (selectedFile.type.includes('spreadsheet') || selectedFile.type.includes('excel') || selectedFile.name.endsWith('.csv')) fileType = 'sheets';
                    else if (selectedFile.type.includes('pdf')) fileType = 'docs';

                    await addDoc(collection(db, 'td_sharing'), {
                        ownerId: currentOwner.uid,
                        parentId: currentFolderId,
                        type: 'file',
                        title: attachTitle,
                        url: result.url,
                        fileType: fileType,
                        addedBy: userData.name,
                        timestamp: new Date().toISOString(),
                        createdAt: serverTimestamp()
                    });

                    await logActivity(user, 'Uploaded File', `อัปโหลดไฟล์ "${attachTitle}" ไปยังพื้นที่ของ ${currentOwner.name}`);

                    setAttachTitle(''); setSelectedFile(null);
                    if(fileInputRef.current) fileInputRef.current.value = "";
                } else { 
                    alert('อัปโหลดไม่สำเร็จ: ' + result.message); 
                }
                setIsUploading(false);
            };
        } catch (error) { 
            alert("เกิดข้อผิดพลาดในการเชื่อมต่อ"); 
            setIsUploading(false); 
        }
    };

    const handleDeleteItem = async (item, e) => {
        e.stopPropagation();
        const typeName = item.type === 'folder' ? 'โฟลเดอร์' : 'ไฟล์';
        if (!window.confirm(`ต้องการลบ${typeName} "${item.title}" ใช่หรือไม่?\n(ถ้าเป็นโฟลเดอร์ ไฟล์ข้างในอาจจะกลายเป็นไฟล์กำพร้า)`)) return;
        
        await deleteDoc(doc(db, 'td_sharing', item.id));
        await logActivity(user, `Deleted ${item.type}`, `ลบ ${typeName} "${item.title}"`);
    };

    const handleEnterFolder = (folder) => {
        setFolderPath([...folderPath, { id: folder.id, name: folder.title }]);
    };

    const handleBreadcrumbClick = (index) => {
        setFolderPath(folderPath.slice(0, index + 1));
    };

    const exitHome = () => {
        setCurrentOwner(null);
        setFolderPath([{ id: 'root', name: 'Home' }]);
    };

    if (loading) return <div className="flex justify-center items-center h-screen bg-surface"><div className="animate-spin rounded-full h-12 w-12 border-t-2 border-green-500"></div></div>;

    // --- ส่วนเรนเดอร์ ---
    return (
        <div className="min-h-screen bg-surface flex flex-col p-4 md:p-6 relative text-text">
            <div className="flex items-center gap-4 mb-6 border-b border-glass pb-4">
                {currentOwner ? (
                    <button onClick={exitHome} className="bg-surface hover:bg-surface text-text p-2.5 rounded-full shadow transition"><i className="fas fa-arrow-left"></i></button>
                ) : (
                    <button onClick={() => navigate('/')} className="bg-surface hover:bg-surface text-text p-2.5 rounded-full shadow transition"><i className="fas fa-home"></i></button>
                )}
                <div>
                    <h1 className="text-lg md:text-2xl font-bold flex items-center gap-3">
                        {currentOwner ? (
                            <>พื้นที่แชร์ไฟล์ของ: <span className="text-green-400">{currentOwner.name}</span></>
                        ) : (
                            <><i className="fas fa-map-marked-alt text-green-500"></i> TD Village (พื้นที่เก็บข้อมูลส่วนตัวและแชร์)</>
                        )}
                    </h1>
                    <p className="text-xs text-text mt-1">
                        {currentOwner ? 'จัดการโฟลเดอร์และไฟล์ (อัปโหลดผ่าน Google Drive)' : 'คลิกที่บ้านของสมาชิกเพื่อเข้าสู่แฟ้มเอกสาร'}
                    </p>
                </div>
            </div>

            {!currentOwner ? (
                /* 🌟 VIEW 1: แผนที่หมู่บ้าน (Village Map) 🌟 */
                <div className="flex-1 bg-surface/50 rounded-2xl border border-glass shadow-xl overflow-hidden relative p-8 flex flex-wrap justify-center gap-8 items-center">
                    {/* วาดเส้นถนนเทียมๆ ด้านหลัง */}
                    <div className="absolute inset-0 pointer-events-none opacity-20">
                        <svg width="100%" height="100%" xmlns="http://www.w3.org/2000/svg">
                            <defs>
                                <pattern id="grid" width="100" height="100" patternUnits="userSpaceOnUse">
                                    <path d="M 100 0 L 0 0 0 100" fill="none" stroke="#4ade80" strokeWidth="1"/>
                                </pattern>
                            </defs>
                            <rect width="100%" height="100%" fill="url(#grid)" />
                        </svg>
                    </div>

                    {tdUsers.map((member, index) => (
                        <div 
                            key={member.uid} 
                            onClick={() => setCurrentOwner(member)}
                            className="relative group cursor-pointer flex flex-col items-center justify-center transform hover:scale-110 transition-transform duration-300 z-10 w-32 h-32"
                        >
                            {/* SVG รูปบ้าน */}
                            <svg width="80" height="80" viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg" className="drop-shadow-lg group-hover:drop-shadow-[0_0_15px_rgba(74,222,128,0.8)] transition-all">
                                {/* ฐานบ้าน */}
                                <rect x="20" y="40" width="60" height="50" fill="#1f2937" stroke="#374151" strokeWidth="3" />
                                {/* หลังคา */}
                                <polygon points="10,40 50,10 90,40" fill={member.uid === user.uid ? "#4ade80" : "#3b82f6"} stroke="#1e3a8a" strokeWidth="2" />
                                {/* ประตู */}
                                <rect x="40" y="60" width="20" height="30" fill="#9ca3af" />
                                <circle cx="55" cy="75" r="2" fill="#111827" />
                                {/* หน้าต่าง */}
                                <rect x="28" y="50" width="10" height="10" fill="#fef08a" opacity="0.8" />
                                <rect x="62" y="50" width="10" height="10" fill="#fef08a" opacity="0.8" />
                            </svg>
                            {/* ป้ายชื่อ */}
                            <div className={`mt-3 px-3 py-1 rounded-full text-xs font-bold border ${member.uid === user.uid ? 'bg-green-500/20 text-green-400 border-green-500/50' : 'bg-blue-500/20 text-primary border-blue-500/50'}`}>
                                {member.name} {member.uid === user.uid && '(Me)'}
                            </div>
                        </div>
                    ))}
                </div>
            ) : (
                /* 🌟 VIEW 2: File Explorer 🌟 */
                <div className="flex flex-col lg:flex-row gap-6 flex-1">
                    
                    {/* ส่วนซ้าย: ระบบฟอร์ม (สร้างโฟลเดอร์ / อัปโหลดไฟล์) */}
                    <div className="w-full lg:w-1/3 flex flex-col gap-4">
                        <div className="bg-surface p-5 rounded-2xl border border-glass shadow-xl flex flex-col">
                            <h2 className="text-sm font-bold text-yellow-400 mb-4 uppercase"><i className="fas fa-folder-plus mr-2"></i> สร้างโฟลเดอร์ใหม่</h2>
                            <form onSubmit={handleCreateFolder} className="flex gap-2">
                                <input type="text" value={newFolderName} onChange={(e)=>setNewFolderName(e.target.value)} placeholder="ชื่อโฟลเดอร์..." className="flex-1 bg-surface border border-glass rounded px-3 py-2 text-xs text-text outline-none focus:border-yellow-500" required/>
                                <button type="submit" disabled={!newFolderName.trim()} className="bg-yellow-600 hover:bg-yellow-500 text-text px-4 py-2 rounded text-xs font-bold shadow transition"><i className="fas fa-plus"></i></button>
                            </form>
                        </div>

                        <div className="bg-surface p-5 rounded-2xl border border-glass shadow-xl flex flex-col">
                            <h2 className="text-sm font-bold text-green-400 mb-4 uppercase"><i className="fas fa-cloud-upload-alt mr-2"></i> อัปโหลดไฟล์เข้าโฟลเดอร์นี้</h2>
                            <form onSubmit={handleFileUpload} className="flex flex-col gap-3">
                                <input type="text" value={attachTitle} onChange={(e)=>setAttachTitle(e.target.value)} placeholder="ตั้งชื่อไฟล์ที่จะแสดงผล..." className="w-full bg-surface border border-glass rounded px-3 py-2 text-xs text-text outline-none focus:border-green-500" required disabled={isUploading}/>
                                <input type="file" ref={fileInputRef} onChange={(e)=>setSelectedFile(e.target.files[0])} className="w-full text-xs text-text file:mr-3 file:py-2 file:px-3 file:rounded file:border-0 file:text-xs file:font-bold file:bg-surface file:text-text hover:file:bg-surface cursor-pointer bg-surface border border-glass rounded pr-2" required disabled={isUploading}/>
                                <button type="submit" disabled={!selectedFile || !attachTitle || isUploading} className="w-full bg-green-600 hover:bg-green-500 disabled:bg-surface disabled:text-text text-text py-2.5 rounded-lg text-xs font-bold shadow transition flex items-center justify-center gap-2 mt-2">
                                    {isUploading ? <><i className="fas fa-spinner fa-spin"></i> กำลังอัปโหลด...</> : <><i className="fas fa-upload"></i> อัปโหลดไฟล์ (Google Drive)</>}
                                </button>
                            </form>
                        </div>
                    </div>

                    {/* ส่วนขวา: รายการโฟลเดอร์และไฟล์ */}
                    <div className="w-full lg:w-2/3 bg-surface p-5 rounded-2xl border border-glass shadow-xl flex flex-col">
                        
                        {/* Breadcrumbs */}
                        <div className="flex items-center gap-2 mb-6 bg-surface px-4 py-3 rounded-lg border border-glass overflow-x-auto whitespace-nowrap scrollbar-hide">
                            {folderPath.map((path, index) => (
                                <React.Fragment key={path.id}>
                                    <button onClick={() => handleBreadcrumbClick(index)} className={`text-sm font-bold transition hover:text-text ${index === folderPath.length - 1 ? 'text-primary' : 'text-text'}`}>
                                        {index === 0 ? <i className="fas fa-home"></i> : path.name}
                                    </button>
                                    {index < folderPath.length - 1 && <i className="fas fa-chevron-right text-[10px] text-text mx-1"></i>}
                                </React.Fragment>
                            ))}
                        </div>

                        {/* List Items */}
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 auto-rows-max overflow-y-auto pr-2 max-h-[600px] custom-scrollbar">
                            {items.length === 0 ? (
                                <div className="col-span-1 md:col-span-2 text-center py-16 border-2 border-dashed border-glass rounded-xl flex flex-col items-center opacity-60">
                                    <i className="fas fa-folder-open text-5xl text-text mb-4"></i>
                                    <p className="text-text">โฟลเดอร์นี้ยังว่างเปล่า</p>
                                </div>
                            ) : (
                                items.map(item => (
                                    <div key={item.id} className="bg-surface border border-glass hover:border-blue-500 p-3 rounded-xl flex justify-between items-center group transition shadow-sm">
                                        
                                        {item.type === 'folder' ? (
                                            <div className="flex items-center gap-3 cursor-pointer flex-1 overflow-hidden" onClick={() => handleEnterFolder(item)}>
                                                <div className="w-10 h-10 rounded bg-yellow-500/20 text-yellow-500 flex items-center justify-center shrink-0 text-xl"><i className="fas fa-folder"></i></div>
                                                <div className="flex flex-col overflow-hidden">
                                                    <span className="text-sm text-text font-bold truncate group-hover:text-yellow-400 transition">{item.title}</span>
                                                    <span className="text-[10px] text-text">สร้างโดย: {item.addedBy}</span>
                                                </div>
                                            </div>
                                        ) : (
                                            <div className="flex items-center gap-3 cursor-pointer flex-1 overflow-hidden" onClick={() => setPreviewFile(item)}>
                                                <div className="w-10 h-10 rounded bg-surface flex items-center justify-center shrink-0 text-xl border border-glass">{getAttachmentIcon(item.fileType)}</div>
                                                <div className="flex flex-col overflow-hidden">
                                                    <span className="text-sm text-text font-bold truncate group-hover:text-primary transition">{item.title}</span>
                                                    <span className="text-[10px] text-text">{new Date(item.timestamp).toLocaleDateString('th-TH')} • {item.addedBy}</span>
                                                </div>
                                            </div>
                                        )}

                                        {/* 🌟 เช็คสิทธิ์ปุ่มลบ: คนที่อัปโหลดไฟล์นั้นเอง และ Admin 🌟 */}
                                        {(item.addedBy === userData.name || userData.role === 'Admin') && (
                                            <button onClick={(e) => handleDeleteItem(item, e)} className="text-text hover:text-red-500 bg-surface hover:bg-surface w-8 h-8 rounded-full flex items-center justify-center shrink-0 opacity-0 group-hover:opacity-100 transition ml-2"><i className="fas fa-trash-alt text-xs"></i></button>
                                        )}
                                    </div>
                                ))
                            )}
                        </div>
                    </div>
                </div>
            )}

            {/* Modal Preview ไฟล์ (ใช้โค้ดเดิมจาก ProjectSpacePage) */}
            {previewFile && (
                <div className="fixed inset-0 bg-black/90 z-50 flex flex-col items-center justify-center p-6 backdrop-blur-sm">
                    <div className="w-full max-w-5xl bg-surface rounded-2xl border border-glass shadow-2xl overflow-hidden flex flex-col" style={{ height: '90vh' }}>
                        <div className="bg-surface p-4 border-b border-glass flex justify-between items-center shrink-0">
                            <div className="flex items-center gap-3 overflow-hidden">
                                <span className="text-xl shrink-0">{getAttachmentIcon(previewFile.fileType)}</span>
                                <h3 className="text-text font-bold text-lg truncate pr-4">{previewFile.title}</h3>
                            </div>
                            <div className="flex items-center gap-4 shrink-0">
                                <a href={previewFile.url} target="_blank" rel="noopener noreferrer" className="bg-blue-600 hover:bg-blue-500 text-text px-4 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-2 shadow whitespace-nowrap"><i className="fas fa-external-link-alt"></i> เปิดหน้าต่างใหม่ / ดาวน์โหลด</a>
                                <button onClick={() => setPreviewFile(null)} className="text-text hover:text-red-400 text-3xl leading-none transition">&times;</button>
                            </div>
                        </div>
                        <div className="flex-1 bg-surface/50 flex items-center justify-center relative overflow-hidden p-0 rounded-b-2xl">
                            {extractDriveId(previewFile.url) ? (
                                <iframe src={`https://drive.google.com/file/d/${extractDriveId(previewFile.url)}/preview`} className="w-full h-full border-0 bg-surface/5" allow="autoplay" title="preview"></iframe>
                            ) : (
                                <div className="text-center text-text">
                                    <i className="fas fa-exclamation-triangle text-4xl mb-3"></i>
                                    <p>ไฟล์นี้ไม่รองรับการพรีวิวในแอป</p>
                                    <a href={previewFile.url} target="_blank" rel="noopener noreferrer" className="text-primary underline text-sm mt-2 inline-block">คลิกที่นี่เพื่อเปิดดูในหน้าใหม่</a>
                                </div>
                            )}
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};

export default TDSharingAreaPage;