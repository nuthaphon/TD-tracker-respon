import React, { useState, useEffect, useRef, useMemo } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { doc, onSnapshot, updateDoc, arrayUnion, arrayRemove, collection, query, where, serverTimestamp, addDoc, deleteDoc, orderBy, limit } from 'firebase/firestore';
import { ref, uploadBytes, getDownloadURL } from 'firebase/storage';
import { db, storage } from '../firebase';
import { useAuth } from '../hooks/useAuth';
import { logActivity } from '../utils/activityLogger';

const formatLocalYYYYMMDD = (timestamp) => {
    const d = new Date(timestamp);
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
};

const extractDriveId = (url) => {
    if (!url) return null;
    const match = url.match(/\/d\/([a-zA-Z0-9_-]+)/);
    return match ? match[1] : null;
};

const getThumbnailUrl = (url) => {
    if (!url) return '';
    const match = url.match(/\/d\/([a-zA-Z0-9_-]+)/);
    return match ? `https://drive.google.com/thumbnail?id=${match[1]}` : url;
};

const PROJECT_ACTIONS = [
    'Updated Project Timeline', 'Updated Phase Schedule', 'Updated Phase Details', 
    'Assigned Phase Owner', 'Added Project Phase', 'Updated Project Progress', 
    'Uploaded Project File', 'Completed Project', 'E-Signed Document', 'Generated Handover Report',
    'Ordered Part', 'Updated Part Status', 'Received Part'
];

const MonthHeaders = ({ minDate, maxDate }) => {
    if (!minDate || !maxDate) return null;
    const start = new Date(minDate);
    const end = new Date(maxDate);
    const totalMs = end.getTime() - start.getTime() || 1;
    
    const months = [];
    let curr = new Date(start.getFullYear(), start.getMonth(), 1); 
    
    while (curr <= end || (curr.getFullYear() === end.getFullYear() && curr.getMonth() === end.getMonth())) {
        let nextMonth = new Date(curr.getFullYear(), curr.getMonth() + 1, 1);
        let monthEnd = new Date(nextMonth.getTime() - 1);
        
        let mStart = Math.max(start.getTime(), curr.getTime());
        let mEnd = Math.min(end.getTime(), monthEnd.getTime());
        
        let leftP = ((mStart - start.getTime()) / totalMs) * 100;
        let widthP = ((mEnd - mStart) / totalMs) * 100;
        
        months.push({
            id: curr.getTime(),
            label: curr.toLocaleDateString('en-GB', { month: 'short', year: '2-digit' }), 
            left: leftP,
            width: widthP
        });
        curr = nextMonth;
    }

    return (
        <div className="relative w-full h-5 border-b border-glass flex text-[9px] text-text font-bold uppercase overflow-hidden">
            {months.map(m => (
                <div key={m.id} className="absolute border-l border-glass h-full pl-1.5 flex items-center bg-surface/30" style={{ left: `${m.left}%`, width: `${m.width}%` }}>
                    {m.width > 5 ? m.label : ''} 
                </div>
            ))}
        </div>
    );
};

const DualSlider = ({ minDate, maxDate, startStr, endStr, type, onSave, disabled }) => {
    const minTime = new Date(minDate).getTime();
    const maxTime = new Date(maxDate).getTime();
    
    const [sTime, setSTime] = useState(startStr ? new Date(startStr).getTime() : minTime);
    const [eTime, setETime] = useState(endStr ? new Date(endStr).getTime() : maxTime);

    useEffect(() => {
        setSTime(startStr ? new Date(startStr).getTime() : minTime);
        setETime(endStr ? new Date(endStr).getTime() : maxTime);
    }, [startStr, endStr, minTime, maxTime]);

    const total = maxTime - minTime || 1;
    const leftP = Math.max(0, ((sTime - minTime) / total) * 100);
    const rightP = Math.max(0, ((maxTime - eTime) / total) * 100);

    const colorClass = type === 'plan' ? 'from-orange-500 to-yellow-400' : 'from-green-500 to-emerald-400';
    const thumbColor = type === 'plan' ? '#f97316' : '#22c55e'; 
    const tooltipBg = type === 'plan' ? 'bg-orange-500 text-text' : 'bg-green-500 text-text';
    const tooltipArrow = type === 'plan' ? 'bg-orange-500' : 'bg-green-500';

    const daysCount = Math.ceil((eTime - sTime) / 86400000) + 1; 

    const handleSave = () => {
        if (!disabled) onSave(formatLocalYYYYMMDD(sTime), formatLocalYYYYMMDD(eTime));
    };

    const formatThumbDate = (time) => new Date(time).toLocaleDateString('en-GB', {day:'2-digit', month:'short'});
    const isTooClose = ((eTime - sTime) / total) < 0.12;

    return (
        <div className="flex items-center gap-2 w-full group relative mt-4 mb-1">
            <div className="w-20 shrink-0 flex justify-between items-center bg-surface/80 px-1.5 py-0.5 rounded border border-glass shadow-inner">
                <span className={`text-[9px] font-black uppercase tracking-widest ${type === 'plan' ? 'text-orange-400' : 'text-green-400'}`}>{type}</span>
                <span className="text-[9px] text-text font-bold">{daysCount}D</span>
            </div>
            
            <div className="relative w-full h-6 flex items-center" style={{ '--thumb-color': thumbColor }}>
                <div className={`absolute -top-5 text-[8px] font-bold px-1.5 py-0.5 rounded shadow-lg z-20 whitespace-nowrap transition-all duration-200 opacity-0 group-hover:opacity-100 pointer-events-none ${tooltipBg}`} style={{ left: `${leftP}%`, transform: 'translateX(-50%)' }}>
                    {formatThumbDate(sTime)}
                    <div className={`absolute -bottom-1 left-1/2 transform -translate-x-1/2 w-1.5 h-1.5 rotate-45 ${tooltipArrow}`}></div>
                </div>

                <div className={`absolute text-[8px] font-bold px-1.5 py-0.5 rounded shadow-lg z-20 whitespace-nowrap transition-all duration-200 opacity-0 group-hover:opacity-100 pointer-events-none ${tooltipBg} ${isTooClose ? 'top-4' : '-top-5'}`} style={{ right: `${rightP}%`, transform: 'translateX(50%)' }}>
                    {isTooClose && <div className={`absolute -top-1 left-1/2 transform -translate-x-1/2 w-1.5 h-1.5 rotate-45 ${tooltipArrow}`}></div>}
                    {formatThumbDate(eTime)}
                    {!isTooClose && <div className={`absolute -bottom-1 left-1/2 transform -translate-x-1/2 w-1.5 h-1.5 rotate-45 ${tooltipArrow}`}></div>}
                </div>

                <div className="absolute w-full h-1.5 bg-surface/80 rounded-full shadow-inner border border-glass/50"></div>
                <div className={`absolute h-1.5 rounded-full shadow-[0_0_8px_rgba(0,0,0,0.5)] bg-gradient-to-r ${colorClass} transition-all duration-75 opacity-90`} style={{ left: `${leftP}%`, right: `${rightP}%` }}></div>
                
                <input type="range" min={minTime} max={maxTime} step={86400000} value={sTime} disabled={disabled} onChange={(e) => { const val = Number(e.target.value); if (val <= eTime) setSTime(val); }} onMouseUp={handleSave} onTouchEnd={handleSave} className="dual-slider-thumb absolute w-full appearance-none bg-transparent outline-none" />
                <input type="range" min={minTime} max={maxTime} step={86400000} value={eTime} disabled={disabled} onChange={(e) => { const val = Number(e.target.value); if (val >= sTime) setETime(val); }} onMouseUp={handleSave} onTouchEnd={handleSave} className="dual-slider-thumb absolute w-full appearance-none bg-transparent outline-none" />
            </div>
        </div>
    );
};

const PhaseDetailInput = ({ phaseKey, initialValue, onSave, disabled }) => {
    const [text, setText] = useState(initialValue || '');
    const textAreaRef = useRef(null);

    useEffect(() => { setText(initialValue || ''); }, [initialValue]);

    useEffect(() => {
        if (textAreaRef.current) {
            textAreaRef.current.style.height = '44px';
            const scrollHeight = textAreaRef.current.scrollHeight;
            textAreaRef.current.style.height = Math.max(44, scrollHeight) + 'px';
        }
    }, [text]);

    const handleBlur = () => {
        if (text !== (initialValue || '')) {
            onSave(phaseKey, text);
        }
    };

    return (
        <textarea
            ref={textAreaRef}
            value={text}
            onChange={(e) => setText(e.target.value)}
            onBlur={handleBlur}
            disabled={disabled}
            placeholder="รายละเอียด / ปัญหาที่พบ..."
            className="w-full bg-surface/60 border border-glass rounded p-1.5 text-[10px] text-text outline-none focus:border-blue-500 focus:bg-surface transition-colors resize-none overflow-hidden no-scrollbar"
            style={{ minHeight: '44px' }}
        />
    );
};

const ProjectSpacePage = () => {
    const { id } = useParams();
    const navigate = useNavigate();
    const { userData, user } = useAuth(); 
    const [project, setProject] = useState(null);
    
    const [jobData, setJobData] = useState(null);
    const [loading, setLoading] = useState(true);
    const [tdUsers, setTdUsers] = useState([]);

    const [chatMsg, setChatMsg] = useState('');
    const [noteText, setNoteText] = useState('');
    const [noteColor, setNoteColor] = useState('bg-yellow-200 text-yellow-900');
    const [newCoWorker, setNewCoWorker] = useState('');

    const [attachTitle, setAttachTitle] = useState('');
    const [selectedFile, setSelectedFile] = useState(null);
    const [isUploading, setIsUploading] = useState(false);
    const fileInputRef = useRef(null);
    
    const [previewFile, setPreviewFile] = useState(null);
    const [newPhaseName, setNewPhaseName] = useState('');
    const [partOrders, setPartOrders] = useState([]);
    const [showReportModal, setShowReportModal] = useState(false);
    const [reportData, setReportData] = useState({ testSummary: '', efficiencyGain: '', isPass: 'Pass' });
    const [localProgress, setLocalProgress] = useState(0);

    const [manualPosts, setManualPosts] = useState([]);
    const [systemLogs, setSystemLogs] = useState([]);
    const [queryLimit, setQueryLimit] = useState(15);

    const [postText, setPostText] = useState('');
    const [postAttachments, setPostAttachments] = useState([]);
    const [postSelectedFile, setPostSelectedFile] = useState(null);
    const [postAttachTitle, setPostAttachTitle] = useState('');
    const [isPostUploading, setIsPostUploading] = useState(false);
    const [isPostSubmitting, setIsPostSubmitting] = useState(false);
    const postFileInputRef = useRef(null);

    const [commentInputs, setCommentInputs] = useState({});
    const [showComments, setShowComments] = useState({});

    const defaultPhases = [
        { key: 'problem', label: '1. Problem & Current State' },
        { key: 'concept', label: '2. Concept Design' },
        { key: 'trial', label: '3. Trial & Validation' },
        { key: 'implement', label: '4. Implement' }
    ];

    // 🌟 Unified Permission Checks 🌟
    const isAdmin = userData?.role === 'Admin';
    const userJobTitle = (userData?.jobTitle || '').toLowerCase();
    
    const isTD = userData?.dept === 'TD' || isAdmin;
    const isTDMgrOrSup = isTD && (userJobTitle.includes('manager') || userJobTitle.includes('supervisor') || userJobTitle.includes('lead') || userJobTitle.includes('director') || isAdmin);
    
    const isOwner = project?.owner === userData?.name || project?.ownerId === userData?.uid;
    const isCoWorker = project?.coWorkers?.includes(userData?.name);
    const isTeamMember = isOwner || isCoWorker;

    // Permissions Variables
    const canEditProgressAndPlan = isTeamMember || isTDMgrOrSup || isAdmin;
    const canManageTeam = isOwner || isTDMgrOrSup || isAdmin;
    const canUploadFile = isTeamMember || isTDMgrOrSup || isAdmin;
    const canOrderParts = isTeamMember || isTDMgrOrSup || isAdmin;
    const canEditReport = isTeamMember || isTDMgrOrSup || isAdmin; 
    const canApproveSign = isTDMgrOrSup || isAdmin; 
    const canCompleteProject = isOwner || isTDMgrOrSup || isAdmin;
    
    const isIssuer = userData?.name === project?.requestBy;
    const isCompleted = ['Completed', 'Accepted'].includes(project?.status);
    const signCount = (project?.handoverReport ? 1 : 0) + (project?.handoverReport?.approverSign ? 1 : 0) + (project?.handoverReport?.issuerSign ? 1 : 0);

    useEffect(() => {
        const unsubProject = onSnapshot(doc(db, 'td_projects', id), (docSnap) => {
            if (docSnap.exists()) {
                const data = { id: docSnap.id, ...docSnap.data() };
                setProject(data);
                setLocalProgress(data.progress || 0); 
            } else {
                alert("ไม่พบโปรเจกต์นี้");
                navigate('/td-workspace');
            }
            setLoading(false);
        });

        const unsubUsers = onSnapshot(collection(db, 'users'), (snapshot) => {
            const users = snapshot.docs.map(doc => doc.data());
            setTdUsers(users.filter(u => u.dept === 'TD' && u.role !== 'pending'));
        });

        const qParts = query(collection(db, 'part_orders'), where('projectId', '==', id));
        const unsubParts = onSnapshot(qParts, (snapshot) => {
            setPartOrders(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
        });

        const qPosts = query(collection(db, 'td_posts'), where('projectId', '==', id));
        const unsubPosts = onSnapshot(qPosts, (snapshot) => {
            const p = snapshot.docs.map(doc => ({ id: doc.id, feedType: 'manual', ...doc.data() }));
            setManualPosts(p);
        });

        return () => { unsubProject(); unsubUsers(); unsubParts(); unsubPosts(); };
    }, [id, navigate]);

    useEffect(() => {
        if (project?.jobRequestId) {
            const unsubJob = onSnapshot(doc(db, 'td_job_requests', project.jobRequestId), (docSnap) => {
                if (docSnap.exists()) {
                    setJobData(docSnap.data());
                }
            });
            return () => unsubJob();
        } else {
            setJobData(null);
        }
    }, [project?.jobRequestId]);

    useEffect(() => {
        if (!project?.projectName) return;
        const qLogs = query(collection(db, 'activity_logs'), orderBy('timestamp', 'desc'), limit(150));
        const unsubLogs = onSnapshot(qLogs, (snapshot) => {
            const fetchedLogs = snapshot.docs.map(doc => ({ id: doc.id, feedType: 'system', ...doc.data() }));
            const pLogs = fetchedLogs.filter(log => 
                PROJECT_ACTIONS.includes(log.action) && 
                (log.details.includes(project.projectName) || (project.projectNoRef && project.projectNoRef !== '-' && log.details.includes(project.projectNoRef)))
            );
            setSystemLogs(pLogs);
        });
        return () => unsubLogs();
    }, [project?.projectName, project?.projectNoRef]);

    const combinedFeed = useMemo(() => {
        const merged = [...manualPosts, ...systemLogs];
        return merged.sort((a, b) => {
            const getTime = (item) => {
                const ts = item.feedType === 'manual' ? item.createdAt : item.timestamp;
                if (!ts) return Date.now(); 
                if (typeof ts.toDate === 'function') return ts.toDate().getTime(); 
                return new Date(ts).getTime(); 
            };
            const timeA = getTime(a);
            const timeB = getTime(b);
            return timeB - timeA; 
        }).slice(0, queryLimit);
    }, [manualPosts, systemLogs, queryLimit]);

    const totalFeedCount = manualPosts.length + systemLogs.length;
    const hasMoreFeed = totalFeedCount > queryLimit;

    if (!isTD) {
        return (
            <div className="h-full flex flex-col items-center justify-center text-text bg-surface">
                <i className="fas fa-lock text-6xl mb-4 text-red-500 opacity-50"></i>
                <h2 className="text-lg md:text-2xl font-bold text-text mb-2">Access Denied</h2>
                <p className="text-sm">หน้านี้สงวนสิทธิ์เฉพาะพนักงานแผนก TD เท่านั้น</p>
                <button onClick={() => navigate(-1)} className="mt-6 bg-blue-600 hover:bg-blue-500 text-text px-6 py-2.5 rounded-lg text-sm font-bold shadow-lg transition">
                    <i className="fas fa-arrow-left mr-2"></i> ย้อนกลับ
                </button>
            </div>
        );
    }

    if (loading || !project) return <div className="flex justify-center items-center h-screen bg-surface"><div className="animate-spin rounded-full h-12 w-12 border-t-2 border-purple-500"></div></div>;

    const handleLoadMoreFeed = () => setQueryLimit(prev => prev + 15);

    const handleGlobalDateChange = async (field, value) => {
        await updateDoc(doc(db, 'td_projects', id), { [field]: value });
        await logActivity(user, 'Updated Project Timeline', `กำหนดวันที่ ${field === 'projectPlanStart' ? 'เริ่ม' : 'สิ้นสุด'} โปรเจกต์ ${project.projectName}`);
    };

    const handlePhaseSave = async (phaseKey, startVal, endVal, isPlan) => {
        const updatedSchedule = { ...project.schedule };
        if (!updatedSchedule[phaseKey]) updatedSchedule[phaseKey] = {};
        
        if (isPlan) {
            updatedSchedule[phaseKey].planStart = startVal;
            updatedSchedule[phaseKey].planEnd = endVal;
        } else {
            updatedSchedule[phaseKey].actualStart = startVal;
            updatedSchedule[phaseKey].actualEnd = endVal;
        }
        await updateDoc(doc(db, 'td_projects', id), { schedule: updatedSchedule });
        const phaseLabel = project.phases?.find(p => p.key === phaseKey)?.label || phaseKey;
        await logActivity(user, 'Updated Phase Schedule', `ปรับเวลา ${isPlan ? 'Plan' : 'Actual'} ในขั้นตอน "${phaseLabel}"`);
    };

    const handlePhaseDetailSave = async (phaseKey, detailText) => {
        const updatedSchedule = { ...project.schedule };
        if (!updatedSchedule[phaseKey]) updatedSchedule[phaseKey] = {};
        updatedSchedule[phaseKey].detail = detailText; 
        await updateDoc(doc(db, 'td_projects', id), { schedule: updatedSchedule });
        const phaseLabel = project.phases?.find(p => p.key === phaseKey)?.label || phaseKey;
        await logActivity(user, 'Updated Phase Details', `อัปเดตรายละเอียดในขั้นตอน "${phaseLabel}"`);
    };

    const handlePhaseAssigneeSave = async (phaseKey, assigneeName) => {
        const updatedSchedule = { ...project.schedule };
        if (!updatedSchedule[phaseKey]) updatedSchedule[phaseKey] = {};
        updatedSchedule[phaseKey].assignee = assigneeName; 
        await updateDoc(doc(db, 'td_projects', id), { schedule: updatedSchedule });
        const phaseLabel = project.phases?.find(p => p.key === phaseKey)?.label || phaseKey;
        await logActivity(user, 'Assigned Phase Owner', `มอบหมาย ${assigneeName || 'กองกลาง'} ในขั้นตอน "${phaseLabel}"`);
    };

    const handleAddPhase = async () => {
        if (!newPhaseName.trim()) return;
        const newKey = `phase_${Date.now()}`;
        const newPhaseObj = { key: newKey, label: newPhaseName };
        let currentPhases = project.phases && project.phases.length > 0 ? project.phases : defaultPhases;
        const updatedPhases = [...currentPhases, newPhaseObj];
        await updateDoc(doc(db, 'td_projects', id), { phases: updatedPhases });
        await logActivity(user, 'Added Project Phase', `เพิ่มขั้นตอน "${newPhaseName}" ในโปรเจกต์ ${project.projectName}`);
        setNewPhaseName('');
    };

    const handleRemovePhase = async (phaseObj) => {
        if (!window.confirm(`คุณแน่ใจหรือไม่ว่าต้องการลบขั้นตอน "${phaseObj.label}" ทิ้ง?\n(ข้อมูลเวลาและรายละเอียดของขั้นตอนนี้จะหายไป)`)) return;
        let currentPhases = project.phases && project.phases.length > 0 ? project.phases : defaultPhases;
        const updatedPhases = currentPhases.filter(p => p.key !== phaseObj.key);
        await updateDoc(doc(db, 'td_projects', id), { phases: updatedPhases });
        await logActivity(user, 'Removed Project Phase', `ลบขั้นตอน "${phaseObj.label}" ออกจากโปรเจกต์ ${project.projectName}`);
    };

    const handleProgressSlide = (e) => { setLocalProgress(Number(e.target.value)); };

    const handleProgressCommit = async () => {
        if (localProgress !== project.progress) {
            await updateDoc(doc(db, 'td_projects', id), { progress: localProgress });
            await logActivity(user, 'Updated Project Progress', `อัปเดตความคืบหน้าโปรเจกต์ ${project.projectName} เป็น ${localProgress}%`);
        }
    };

    const handleAddCoWorker = async () => {
        if (!newCoWorker || project.coWorkers?.includes(newCoWorker)) return;
        await updateDoc(doc(db, 'td_projects', id), { coWorkers: arrayUnion(newCoWorker) });
        await logActivity(user, 'Added Co-Worker', `ดึงตัว ${newCoWorker} เข้าร่วมโปรเจกต์ ${project.projectName}`);
        setNewCoWorker('');
    };

    const handleRemoveCoWorker = async (coworkerName) => {
        if (!window.confirm(`คุณต้องการลบ ${coworkerName} ออกจากโปรเจกต์นี้ใช่หรือไม่?`)) return;
        await updateDoc(doc(db, 'td_projects', id), { coWorkers: arrayRemove(coworkerName) });
        await logActivity(user, 'Removed Co-Worker', `นำ ${coworkerName} ออกจากโปรเจกต์ ${project.projectName}`);
    };

    const handleSendChat = async (e) => {
        e.preventDefault();
        if (!chatMsg.trim()) return;
        const newMessage = { sender: userData.name, text: chatMsg, timestamp: new Date().toISOString() };
        await updateDoc(doc(db, 'td_projects', id), { chatMessages: arrayUnion(newMessage) });
        await logActivity(user, 'Sent Chat Message', `ส่งข้อความในโปรเจกต์ ${project.projectName}`);
        setChatMsg('');
    };

    const handleAddNote = async (e) => {
        e.preventDefault();
        if (!noteText.trim()) return;
        const newNote = { text: noteText, color: noteColor, author: userData.name, timestamp: new Date().toISOString() };
        await updateDoc(doc(db, 'td_projects', id), { stickyNotes: arrayUnion(newNote) });
        await logActivity(user, 'Added Sticky Note', `แปะ Note ใหม่ในโปรเจกต์ ${project.projectName}`);
        setNoteText('');
    };

    const handleFileUpload = async (e) => {
        e.preventDefault();
        if (!selectedFile || !attachTitle.trim()) return alert("กรุณาตั้งชื่อไฟล์และเลือกไฟล์ก่อนอัปโหลด");
        if (selectedFile.size > 10 * 1024 * 1024) return alert("ขนาดไฟล์ใหญ่เกินไป (สูงสุด 10MB)");

        setIsUploading(true);
        try {
            const uniqueFileName = `${Date.now()}_${selectedFile.name}`;
            const storageRef = ref(storage, `project_files/${id}/${uniqueFileName}`);
            const snapshot = await uploadBytes(storageRef, selectedFile);
            const downloadURL = await getDownloadURL(snapshot.ref);

            let fileType = 'document';
            if (selectedFile.type.includes('image')) fileType = 'image';
            else if (selectedFile.type.includes('spreadsheet') || selectedFile.type.includes('excel') || selectedFile.name.endsWith('.csv')) fileType = 'sheets';
            else if (selectedFile.type.includes('pdf')) fileType = 'docs';

            const newAttachment = {
                id: Date.now().toString(), title: attachTitle, url: downloadURL, type: fileType,
                addedBy: userData.name, timestamp: new Date().toISOString()
            };
            await updateDoc(doc(db, 'td_projects', id), { attachments: arrayUnion(newAttachment) });
            await logActivity(user, 'Uploaded Project File', `แนบไฟล์ "${attachTitle}" ลงในโปรเจกต์ ${project.projectName}`);

            setAttachTitle(''); setSelectedFile(null);
            if(fileInputRef.current) fileInputRef.current.value = "";
            setIsUploading(false);
        } catch (error) { 
            console.error(error);
            alert("เกิดข้อผิดพลาดในการอัปโหลดไฟล์ไปยัง Storage"); 
            setIsUploading(false); 
        }
    };

    const handleRemoveAttachment = async (attachmentObj, e) => {
        e.stopPropagation(); 
        if (!window.confirm(`ต้องการลบไฟล์แนบ "${attachmentObj.title}" ใช่หรือไม่?`)) return;
        await updateDoc(doc(db, 'td_projects', id), { attachments: arrayRemove(attachmentObj) });
        await logActivity(user, 'Removed Project File', `ลบไฟล์แนบ "${attachmentObj.title}" ออกจากโปรเจกต์ ${project.projectName}`);
    };

    const handleCompleteProject = async () => {
        if (!window.confirm("คุณแน่ใจหรือไม่ว่าต้องการปิดโปรเจกต์นี้? \nระบบจะอัปเดตสถานะกลับไปให้ผู้แจ้งงานทราบอัตโนมัติ")) return;
        try {
            await updateDoc(doc(db, 'td_projects', id), { status: 'Completed', progress: 100, completedAt: serverTimestamp() });
            if (project.jobRequestId) {
                const jobRef = doc(db, 'td_job_requests', project.jobRequestId);
                const newTimelineEvent = { status: 'Completed', by: userData.name, comment: 'โปรเจกต์ดำเนินการเสร็จสิ้น รอการตรวจสอบและ Accept จากผู้แจ้ง', timestamp: new Date().toISOString() };
                await updateDoc(jobRef, { status: 'Completed', timeline: arrayUnion(newTimelineEvent) });
            }
            await logActivity(user, 'Completed Project', `ปิดโปรเจกต์ ${project.projectName} สำเร็จแล้ว (100%)`);
            alert("ปิดโปรเจกต์สำเร็จ! แจ้งเตือนผู้ร้องขอเรียบร้อยแล้ว");
        } catch (error) { alert("เกิดข้อผิดพลาดในการปิดโปรเจกต์"); }
    };

    const handlePostFileUpload = async (e) => {
        e.preventDefault();
        if (!postSelectedFile || !postAttachTitle.trim()) return alert("กรุณาตั้งชื่อไฟล์และเลือกไฟล์");
        if (postSelectedFile.size > 10 * 1024 * 1024) return alert("ขนาดไฟล์ใหญ่เกินไป (สูงสุด 10MB)");

        setIsPostUploading(true);
        try {
            const uniqueFileName = `${Date.now()}_${postSelectedFile.name}`;
            const storageRef = ref(storage, `post_files/${id}/${uniqueFileName}`);
            const snapshot = await uploadBytes(storageRef, postSelectedFile);
            const downloadURL = await getDownloadURL(snapshot.ref);

            let fileType = 'document';
            if (postSelectedFile.type.includes('image')) fileType = 'image';
            else if (postSelectedFile.type.includes('pdf')) fileType = 'docs';
            else if (postSelectedFile.type.includes('spreadsheet') || postSelectedFile.type.includes('excel') || postSelectedFile.name.endsWith('.csv')) fileType = 'sheets';

            setPostAttachments(prev => [...prev, {
                id: Date.now().toString(), title: postAttachTitle, url: downloadURL, type: fileType,
                addedBy: userData?.name, timestamp: new Date().toISOString()
            }]);
            setPostAttachTitle(''); setPostSelectedFile(null);
            if(postFileInputRef.current) postFileInputRef.current.value = "";
            setIsPostUploading(false);
        } catch (error) { 
            console.error(error);
            alert("เกิดข้อผิดพลาดในการอัปโหลด"); 
            setIsPostUploading(false); 
        }
    };

    const handleCreateProjectPost = async (e) => {
        e.preventDefault();
        if (!postText.trim()) return alert("กรุณาพิมพ์ข้อความอัปเดต");
        if (postSelectedFile && postAttachments.length === 0) return alert("⚠️ คุณเลือกไฟล์ไว้แต่ยังไม่ได้กดปุ่ม 'คลิปหนีบกระดาษ' เพื่ออัปโหลดครับ");

        setIsPostSubmitting(true);
        try {
            await addDoc(collection(db, 'td_posts'), {
                text: postText,
                projectId: project.id,
                projectName: project.projectName,
                author: userData?.name,
                authorId: user?.uid,
                authorAvatar: userData?.avatar || userData?.photoURL || null, // 🌟 แนบรูปโปรไฟล์ลงในโพสต์
                attachments: [...postAttachments],
                likes: [], comments: [],
                createdAt: serverTimestamp()
            });
            await logActivity(user, 'Posted Project Update', `โพสต์อัปเดตในหน้าโปรเจกต์ ${project.projectName}`);
            setPostText(''); setPostAttachments([]);
        } catch (error) { alert("เกิดข้อผิดพลาดในการโพสต์"); } 
        finally { setIsPostSubmitting(false); }
    };

    const handleDeletePost = async (postId) => {
        if(!window.confirm("ต้องการลบโพสต์นี้ใช่หรือไม่?")) return;
        await deleteDoc(doc(db, 'td_posts', postId));
    };

    const handleToggleLike = async (postId, currentLikes = []) => {
        const hasLiked = currentLikes.includes(user.uid);
        const postRef = doc(db, 'td_posts', postId);
        try {
            if (hasLiked) await updateDoc(postRef, { likes: arrayRemove(user.uid) });
            else await updateDoc(postRef, { likes: arrayUnion(user.uid) });
        } catch (error) { console.error("Error toggling like:", error); }
    };

    const handleToggleComments = (postId) => {
        setShowComments(prev => ({ ...prev, [postId]: !prev[postId] }));
    };

    const handleAddComment = async (e, postId) => {
        e.preventDefault();
        const text = commentInputs[postId];
        if (!text || !text.trim()) return;

        const newComment = { 
            id: Date.now().toString() + Math.random().toString(36).substr(2, 9), 
            text: text.trim(), 
            author: userData?.name, 
            authorId: user?.uid, 
            authorAvatar: userData?.avatar || userData?.photoURL || null, // 🌟 แนบรูปโปรไฟล์ลงในคอมเมนต์
            timestamp: new Date().toISOString() 
        };
        try {
            await updateDoc(doc(db, 'td_posts', postId), { comments: arrayUnion(newComment) });
            setCommentInputs(prev => ({ ...prev, [postId]: '' })); 
            setShowComments(prev => ({ ...prev, [postId]: true })); 
        } catch (error) { console.error("Error adding comment:", error); }
    };

    const handleDeleteComment = async (postId, commentObj) => {
        if (!window.confirm("ต้องการลบคอมเมนต์นี้ใช่หรือไม่?")) return;
        try { await updateDoc(doc(db, 'td_posts', postId), { comments: arrayRemove(commentObj) }); } 
        catch (error) { console.error("Error deleting comment:", error); }
    };

    const timeAgo = (timestamp) => {
        if (!timestamp) return 'Just now';
        const date = timestamp?.toDate ? timestamp.toDate() : new Date(timestamp);
        const seconds = Math.floor((new Date() - date) / 1000);
        if (seconds < 60) return 'เมื่อสักครู่';
        if (seconds < 3600) return `${Math.floor(seconds / 60)} นาทีที่แล้ว`;
        if (seconds < 86400) return `${Math.floor(seconds / 3600)} ชั่วโมงที่แล้ว`;
        if (seconds < 2592000) return `${Math.floor(seconds / 86400)} วันที่แล้ว`;
        return date.toLocaleDateString('th-TH');
    };

    const getSystemIcon = (action) => {
        if (action.includes('Progress') || action.includes('Phase')) return 'fa-tasks text-purple-400 bg-purple-500/20';
        if (action.includes('File')) return 'fa-file-upload text-primary bg-blue-500/20';
        if (action.includes('Completed') || action.includes('Sign')) return 'fa-check-circle text-green-400 bg-green-500/20';
        if (action.includes('Part')) return 'fa-box text-yellow-400 bg-yellow-500/20';
        return 'fa-bolt text-orange-400 bg-orange-500/20';
    };

    const handleOpenReportModal = () => {
        if (project.handoverReport) {
            setReportData({
                testSummary: project.handoverReport.testSummary || '',
                efficiencyGain: project.handoverReport.efficiencyGain || '',
                isPass: project.handoverReport.isPass || 'Pass'
            });
        } else {
            const phases = project.phases && project.phases.length > 0 ? project.phases : defaultPhases;
            const trialPhase = phases.find(p => p.label.toLowerCase().includes('trial') || p.label.toLowerCase().includes('ทดสอบ'));
            let autoFillText = '';
            if (trialPhase && project.schedule && project.schedule[trialPhase.key]) {
                autoFillText = project.schedule[trialPhase.key].detail || '';
            }
            setReportData({ testSummary: autoFillText, efficiencyGain: '', isPass: 'Pass' });
        }
        setShowReportModal(true);
    };

    const handleSaveReportData = async () => {
        const currentReport = project.handoverReport || {};
        await updateDoc(doc(db, 'td_projects', id), {
            handoverReport: {
                ...currentReport,
                testSummary: reportData.testSummary,
                efficiencyGain: reportData.efficiencyGain,
                isPass: reportData.isPass,
                generatedAt: currentReport.generatedAt || new Date().toISOString(),
                generatedBy: currentReport.generatedBy || userData.name
            }
        });
    };

    const handleSignReport = async (roleType) => {
        if (!window.confirm('ยืนยันการประทับตรา E-Signature เพื่อรับรองเอกสารนี้?')) return;
        
        if (canEditReport) await handleSaveReportData();

        const signData = { name: userData.name, date: new Date().toISOString() };
        const fieldToUpdate = roleType === 'approver' ? 'handoverReport.approverSign' : 'handoverReport.issuerSign';
        
        const updatePayload = { [fieldToUpdate]: signData };
        if (roleType === 'issuer') {
            updatePayload.status = 'Accepted';
        }
        
        await updateDoc(doc(db, 'td_projects', id), updatePayload);
        
        if (roleType === 'issuer' && project.jobRequestId) {
             const jobRef = doc(db, 'td_job_requests', project.jobRequestId);
             await updateDoc(jobRef, { 
                 status: 'Accepted', 
                 timeline: arrayUnion({ status: 'Accepted', by: userData.name, comment: 'เซ็นรับมอบงานผ่านระบบ E-Signature เรียบร้อยแล้ว', timestamp: new Date().toISOString() }) 
             });
        }

        await logActivity(user, 'E-Signed Document', `ประทับตรา E-Sign (${roleType === 'approver' ? 'Manager/Sup' : 'Issuer'}) ในใบส่งมอบโปรเจกต์ ${project.projectName}`);
        alert('ประทับตรา E-Signature สำเร็จ!');
    };

    const handlePrintReport = async () => {
        if (canEditReport) {
            await handleSaveReportData();
            await logActivity(user, 'Generated Handover Report', `สร้างและพิมพ์ใบส่งมอบงานสำหรับโปรเจกต์ ${project.projectName}`);
        }

        const hr = project.handoverReport || {
             generatedBy: userData.name, generatedAt: new Date().toISOString(),
             testSummary: reportData.testSummary, efficiencyGain: reportData.efficiencyGain, isPass: reportData.isPass
        };

        const renderSignBox = (roleStr, signData, title) => {
            if (signData) {
                const d = new Date(signData.date);
                const dateStr = `${d.toLocaleDateString('th-TH')} ${d.toLocaleTimeString('th-TH',{hour:'2-digit', minute:'2-digit'})}`;
                return `
                <div class="sign-item">
                    <div class="sign-line" style="display:flex; flex-direction:column; justify-content:end; align-items:center;">
                       <span style="color:#2563eb; font-size:14px; font-weight:bold; font-style:italic; letter-spacing:1px;">✔ E-APPROVED</span>
                    </div>
                    <p><b>${roleStr}</b><br>( ${signData.name} )<br>${title}<br>วันที่: ${dateStr}</p>
                </div>
                `;
            } else {
                return `
                <div class="sign-item">
                    <div class="sign-line"></div>
                    <p><b>${roleStr}</b><br>(..................................................)<br>${title}<br>วันที่: _____/_____/_____</p>
                </div>
                `;
            }
        };

        const getLeadTime = (part) => {
            if (!part.createdAt) return '-';
            const start = part.createdAt?.toDate ? part.createdAt.toDate() : new Date(part.createdAt);
            if (part.status === 'Received' && part.eta) {
                const end = part.eta?.toDate ? part.eta.toDate() : new Date(part.eta);
                const diffTime = Math.abs(end - start);
                const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
                return diffDays === 0 ? 'วันเดียวกัน' : `${diffDays} วัน`;
            }
            return 'กำลังดำเนินการ';
        };

        const partOrderTableRows = partOrders.length > 0 
            ? partOrders.map((p, i) => `
                <tr>
                    <td style="text-align:center;">${i + 1}</td>
                    <td>${p.partName}</td>
                    <td style="text-align:center;">${p.qty}</td>
                    <td style="text-align:center; color: ${p.status === 'Received' ? '#16a34a' : '#d97706'}; font-weight:bold;">${getLeadTime(p)}</td>
                </tr>
            `).join('')
            : '<tr><td colspan="4" style="text-align:center; padding: 15px; color: #64748b;">-- ไม่มีรายการเบิกอะไหล่ในโครงการนี้ --</td></tr>';

        const ownerSignHtml = renderSignBox('ผู้ดำเนินงาน / ผู้ส่งมอบ', { name: hr.generatedBy, date: hr.generatedAt }, 'แผนก TD');
        const approverSignHtml = renderSignBox('ผู้ตรวจสอบ (TD Manager/Sup)', hr.approverSign, 'แผนก TD');
        const issuerSignHtml = renderSignBox('ผู้รับมอบ / ผู้แจ้งงาน', hr.issuerSign, `แผนก ${project.requestingDept || '-'}`);

        const logoUrl = 'https://i.postimg.cc/y89YMCnp/logo_ttm_new_1_150x152_(1).png';
        const printContent = `
        <html>
        <head>
            <title>Project Handover Report - ${project.projectName}</title>
            <link href="https://fonts.googleapis.com/css2?family=Sarabun:ital,wght@0,300;0,400;0,600;0,700;1,400&display=swap" rel="stylesheet">
            <style>
                body { font-family: 'Sarabun', sans-serif; padding: 0; margin: 0; color: #000; font-size: 14px; line-height: 1.5; }
                .header { display: flex; justify-content: space-between; align-items: flex-start; border-bottom: 2px solid #0f172a; padding-bottom: 10px; margin-bottom: 15px; }
                .logo { height: 70px; width: auto; object-fit: contain; }
                .title-area { text-align: right; }
                .doc-title { font-size: 20px; font-weight: 700; margin: 0 0 5px 0; color: #0f172a; text-transform: uppercase; }
                .doc-sub { font-size: 15px; color: #475569; margin: 0; }
                
                .section { margin-bottom: 20px; }
                .sec-title { font-size: 15px; font-weight: 700; background: #e2e8f0; padding: 4px 10px; border-left: 4px solid #3b82f6; margin-bottom: 10px; display: inline-block; width: calc(100% - 20px); }
                
                table { width: 100%; border-collapse: collapse; margin-bottom: 10px; font-size: 13px; }
                th, td { border: 1px solid #cbd5e1; padding: 8px; text-align: left; vertical-align: top; }
                th { background: #f8fafc; width: 25%; font-weight: 600; color: #334155; }
                
                .result-pass { color: #16a34a; font-weight: bold; }
                .result-cond { color: #d97706; font-weight: bold; }
                .result-fail { color: #dc2626; font-weight: bold; }

                .signature-box { display: flex; justify-content: space-between; margin-top: 40px; page-break-inside: avoid; }
                .sign-item { width: 30%; text-align: center; }
                .sign-line { border-bottom: 1px solid #000; margin-bottom: 5px; height: 35px; }
                .sign-item p { margin: 0; line-height: 1.5; font-size: 13px; }
                
                @media print { @page { size: A4 portrait; margin: 5mm; } body { -webkit-print-color-adjust: exact; print-color-adjust: exact; padding: 10px; } }
            </style>
        </head>
        <body>
            <div class="header">
                <img src="${logoUrl}" class="logo" alt="TTM Logo" onerror="this.style.display='none'"/>
                <div class="title-area">
                    <h1 class="doc-title">Project Handover & Evaluation Report</h1>
                    <p class="doc-sub">รายงานการทดสอบและส่งมอบโครงการ</p>
                    <p style="margin: 5px 0 0 0; font-size: 11px; color: #64748b;">พิมพ์อ้างอิงเมื่อ: ${new Date().toLocaleString('th-TH')} | พิมพ์โดย: ${userData.name}</p>
                </div>
            </div>

            <div class="section">
                <div class="sec-title">1. ข้อมูลทั่วไปของโครงการ (General Information)</div>
                <table>
                    <tr><th>ชื่อโครงการ (Project Name)</th><td colspan="3"><b style="font-size: 15px;">${project.projectName}</b></td></tr>
                    <tr><th>รหัสอ้างอิง (Ref No.)</th><td>${project.projectNoRef || '-'}</td><th>ผู้รับผิดชอบหลัก (Owner)</th><td>${project.owner}</td></tr>
                    <tr><th>ผู้แจ้งงาน (Requestor)</th><td>${project.requestBy || '-'}</td><th>แผนกผู้แจ้ง (Department)</th><td>${project.requestingDept || '-'}</td></tr>
                    <tr><th>วันที่เริ่มแผน (Plan Start)</th><td>${project.projectPlanStart ? new Date(project.projectPlanStart).toLocaleDateString('th-TH') : '-'}</td><th>วันที่สร้างเอกสาร (Doc Date)</th><td>${new Date(hr.generatedAt).toLocaleDateString('th-TH')}</td></tr>
                </table>
            </div>

            <div class="section">
                <div class="sec-title">2. ขอบเขตและรายละเอียด (Project Scope & Detail)</div>
                <table>
                    <tr><th>วัตถุประสงค์ (Why)</th><td>${project.why || '-'}</td></tr>
                    <tr><th>ลักษณะงาน/ปัญหา (What)</th><td>${project.what || '-'}</td></tr>
                    <tr><th>วิธีการดำเนินงาน (How)</th><td>${project.how || '-'}</td></tr>
                </table>
            </div>

            <div class="section">
                <div class="sec-title">3. สรุปผลการทดสอบและประเมิน (Validation & Evaluation)</div>
                <table>
                    <tr><th>สรุปผลการทดสอบ<br><span style="font-size:10px; font-weight:normal; color:#64748b;">(Test Summary / Result)</span></th><td style="min-height: 60px; white-space: pre-line;">${hr.testSummary || '-'}</td></tr>
                    <tr><th>ประสิทธิภาพที่ได้ / สิ่งที่ปรับปรุง<br><span style="font-size:10px; font-weight:normal; color:#64748b;">(Efficiency / Improvement)</span></th><td style="white-space: pre-line;">${hr.efficiencyGain || '-'}</td></tr>
                    <tr><th>ผลการประเมิน<br><span style="font-size:10px; font-weight:normal; color:#64748b;">(Evaluation Status)</span></th>
                        <td style="font-size: 15px;">
                            ${hr.isPass === 'Pass' ? '<span class="result-pass">☑️ ผ่านเกณฑ์ (Passed) - พร้อมใช้งาน</span>' : 
                              hr.isPass === 'Conditional' ? '<span class="result-cond">⚠️ ผ่านแบบมีเงื่อนไข (Passed with condition) - ต้องติดตามผล</span>' : 
                              '<span class="result-fail">❌ ไม่ผ่าน (Failed) - ต้องปรับปรุงแก้ไข</span>'}
                        </td>
                    </tr>
                </table>
            </div>

            <div class="section">
                <div class="sec-title">4. รายการเบิกอะไหล่ในโครงการ (Part Orders Summary)</div>
                <table>
                    <thead>
                        <tr><th style="width: 10%;">ลำดับ</th><th style="width: 50%;">ชื่อรายการ (Part Name)</th><th style="width: 15%;">จำนวน (Qty)</th><th style="width: 25%;">ระยะเวลาสั่ง (Lead Time)</th></tr>
                    </thead>
                    <tbody>
                        ${partOrderTableRows}
                    </tbody>
                </table>
            </div>

            <div class="signature-box">
                ${ownerSignHtml}
                ${approverSignHtml}
                ${issuerSignHtml}
            </div>
            
            <script>window.onload = function() { setTimeout(function() { window.print(); }, 500); }</script>
        </body>
        </html>
        `;
        
        const printWin = window.open('', '_blank');
        if (printWin) { printWin.document.open(); printWin.document.write(printContent); printWin.document.close(); } 
        else { alert('เบราว์เซอร์ของคุณบล็อก Pop-up!'); }
        
        setShowReportModal(false);
    };

    const hasGlobalTimeline = project.projectPlanStart && project.projectPlanEnd;
    const totalProjectDays = hasGlobalTimeline ? Math.ceil((new Date(project.projectPlanEnd).getTime() - new Date(project.projectPlanStart).getTime()) / 86400000) + 1 : 0;

    const getAttachmentIcon = (type) => {
        switch (type) {
            case 'drive': return <i className="fab fa-google-drive text-green-500"></i>;
            case 'sheets': return <i className="fas fa-file-excel text-green-600"></i>;
            case 'docs': return <i className="fas fa-file-pdf text-red-500"></i>;
            case 'image': return <i className="fas fa-image text-purple-400"></i>;
            default: return <i className="fas fa-file-alt text-text"></i>;
        }
    };

    const displayPhases = (project.phases && project.phases.length > 0) ? project.phases : defaultPhases;
    const teamMembersForAssign = Array.from(new Set([project.owner, ...(project.coWorkers || [])]));

    return (
        <div className="min-h-screen bg-surface flex flex-col p-4 md:p-6 relative">
            <style dangerouslySetInnerHTML={{__html: `
                .progress-slider { -webkit-appearance: none; appearance: none; background: transparent; cursor: pointer; }
                .progress-slider::-webkit-slider-thumb { -webkit-appearance: none; appearance: none; width: 22px; height: 22px; background: #fff; border: 4px solid #a855f7; border-radius: 50%; box-shadow: 0 0 10px rgba(168,85,247,0.8); transition: transform 0.1s; }
                .progress-slider::-webkit-slider-thumb:hover { transform: scale(1.2); }
                .progress-slider::-moz-range-thumb { width: 22px; height: 22px; background: #fff; border: 4px solid #a855f7; border-radius: 50%; box-shadow: 0 0 10px rgba(168,85,247,0.8); transition: transform 0.1s; }

                .dual-slider-thumb { pointer-events: none; }
                .dual-slider-thumb::-webkit-slider-thumb { -webkit-appearance: none; appearance: none; pointer-events: auto; width: 12px; height: 16px; background: #fff; border: 2.5px solid var(--thumb-color, #a855f7); border-radius: 4px; cursor: ew-resize; box-shadow: 0 0 4px rgba(0,0,0,0.5); position: relative; z-index: 30; transition: transform 0.1s;}
                .dual-slider-thumb::-webkit-slider-thumb:hover { transform: scaleY(1.1); z-index: 40; }
                .dual-slider-thumb::-moz-range-thumb { pointer-events: auto; width: 12px; height: 16px; background: #fff; border: 2.5px solid var(--thumb-color, #a855f7); border-radius: 4px; cursor: ew-resize; box-shadow: 0 0 4px rgba(0,0,0,0.5); position: relative; z-index: 30; }
                
                .no-scrollbar::-webkit-scrollbar { display: none; }
                .no-scrollbar { -ms-overflow-style: none; scrollbar-width: none; }
            `}} />

            <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6 border-b border-glass pb-4 gap-4 shrink-0">
                <div className="flex items-center gap-4">
                    <button onClick={() => navigate('/td-workspace')} className="bg-surface hover:bg-surface text-text p-2.5 rounded-full shadow transition"><i className="fas fa-arrow-left"></i></button>
                    <div>
                        <h1 className="text-lg md:text-2xl font-bold text-text flex items-center gap-3">
                            {project.projectName} 
                            <span className={`text-[10px] px-3 py-1 rounded-full border font-bold uppercase ${isCompleted ? 'bg-green-500/20 text-green-400 border-green-500' : 'bg-purple-500/20 text-purple-400 border-purple-500'}`}>
                                {project.status}
                            </span>
                        </h1>
                        <div className="flex flex-wrap items-center gap-3 mt-2">
                            <p className="text-xs text-text mr-2">
                                Ref Job: <span className="text-primary font-bold">{project.projectNoRef || '-'}</span> | Owner: <span className="text-text">{project.owner}</span>
                            </p>
                            <span className="text-[10px] px-2 py-0.5 bg-blue-500/20 text-primary border border-blue-500/50 rounded flex items-center font-bold">
                                <i className="fas fa-user mr-1.5"></i> Req By: {project.requestBy || '-'}
                            </span>
                            <span className="text-[10px] px-2 py-0.5 bg-orange-500/20 text-orange-400 border border-orange-500/50 rounded flex items-center font-bold">
                                <i className="fas fa-building mr-1.5"></i> Dept: {project.requestingDept || '-'}
                            </span>
                            <span className="text-[10px] px-2 py-0.5 bg-red-500/20 text-red-400 border border-red-500/50 rounded flex items-center font-bold">
                                <i className="fas fa-calendar-alt mr-1.5"></i> Due: {project.dueDate || '-'}
                            </span>
                        </div>
                    </div>
                </div>
                
                <div className="flex flex-col sm:flex-row items-center gap-4 w-full md:w-auto mt-2 md:mt-0">
                    <div className="flex flex-col w-full sm:w-48">
                        <div className="flex justify-between text-xs font-bold mb-1.5">
                            <span className="text-text uppercase tracking-wider text-[10px]">Progress</span>
                            <span className="text-purple-400 text-sm">{localProgress}%</span>
                        </div>
                        <input 
                            type="range" min="0" max="100" 
                            value={localProgress} 
                            onChange={handleProgressSlide} 
                            onMouseUp={handleProgressCommit}
                            onTouchEnd={handleProgressCommit}
                            disabled={isCompleted || !canEditProgressAndPlan} 
                            className={`progress-slider w-full h-2.5 rounded-full ${(!canEditProgressAndPlan || isCompleted) ? 'cursor-not-allowed opacity-70' : ''}`} 
                            style={{ background: `linear-gradient(to right, #a855f7 ${localProgress}%, #374151 ${localProgress}%)` }}
                        />
                    </div>
                    
                    <div className="flex gap-2 w-full sm:w-auto">
                        <div className="flex flex-col items-center flex-1 sm:flex-none">
                            {localProgress === 100 || project.handoverReport ? (
                                <>
                                    <button onClick={handleOpenReportModal} className="w-full bg-indigo-600 hover:bg-indigo-500 text-text px-4 py-2.5 rounded-xl text-sm font-bold shadow-[0_0_15px_rgba(79,70,229,0.4)] transition flex items-center justify-center whitespace-nowrap animate-fade-in" title="สร้าง/ดูใบรายงานการส่งมอบงาน">
                                        <i className="fas fa-file-signature mr-2"></i> Report
                                    </button>
                                    {project.handoverReport && (
                                        <span className={`text-[9px] mt-1 font-bold tracking-wide ${signCount === 3 ? 'text-green-400' : 'text-yellow-400'}`}>
                                            {signCount === 3 ? <><i className="fas fa-check-double mr-0.5"></i> อนุมัติครบถ้วน</> : <><i className="fas fa-clock mr-0.5"></i> รอ E-Sign ({signCount}/3)</>}
                                        </span>
                                    )}
                                </>
                            ) : (
                                <button disabled className="w-full bg-surface text-text px-4 py-2.5 rounded-xl text-sm font-bold border border-glass flex items-center justify-center whitespace-nowrap cursor-not-allowed shadow-inner" title="กรุณาสไลด์ Progress ให้ถึง 100% เพื่อปลดล็อคการออก Report">
                                    <i className="fas fa-lock mr-2"></i> Report
                                </button>
                            )}
                        </div>

                        {!isCompleted && canCompleteProject && (
                            <button onClick={handleCompleteProject} className="flex-1 sm:flex-none bg-green-600 hover:bg-green-500 text-text px-5 py-2.5 rounded-xl text-sm font-bold shadow-[0_0_15px_rgba(22,163,74,0.4)] transition flex items-center justify-center whitespace-nowrap h-[40px]">
                                <i className="fas fa-flag-checkered mr-2"></i> จบงาน
                            </button>
                        )}
                    </div>
                </div>
            </div>

            <div className="bg-surface p-5 rounded-2xl border border-glass shadow-xl mb-6 relative overflow-hidden flex flex-col items-center">
                <h2 className="text-sm font-bold text-text mb-6 w-full text-left"><i className="fas fa-subway text-primary mr-2"></i> Project Status Tracker</h2>
                
                {(() => {
                    const isStandalone = !project.jobRequestId;
                    let level = 3; 
                    if (project.status === 'Completed') level = 4;
                    if (project.status === 'Accepted') level = 5;

                    const lineWidths = ['0%', '25%', '50%', '75%', '100%'];
                    const lineWidth = lineWidths[level - 1];

                    const getStepClass = (stepLevel) => {
                        if (isStandalone && stepLevel < 3) return 'bg-surface border-glass text-text opacity-50'; 
                        if (stepLevel === level) {
                            if (level === 5) return 'bg-green-600 border-green-400 text-text shadow-[0_0_15px_rgba(34,197,94,0.8)]';
                            return 'bg-blue-600 border-blue-400 text-text shadow-[0_0_15px_rgba(59,130,246,0.8)]';
                        }
                        if (stepLevel < level) return 'bg-green-600 border-green-400 text-text shadow-[0_0_10px_rgba(34,197,94,0.3)]';
                        return 'bg-surface border-glass text-text';
                    };

                    let approverName = 'รออนุมัติ';
                    if (isStandalone) {
                        approverName = 'สร้างโดย TD';
                    } else if (jobData && jobData.timeline) {
                        const approveEvent = [...jobData.timeline].reverse().find(t => t.status === 'Approved');
                        if (approveEvent && approveEvent.by) {
                            approverName = approveEvent.by;
                        } else {
                            approverName = 'Manager (TD)'; 
                        }
                    }

                    return (
                        <div className="flex items-start justify-between w-full max-w-4xl relative mt-2 mb-2">
                            <div className="absolute left-10 right-10 top-5 h-1.5 bg-surface z-0 rounded-full"></div>
                            <div className="absolute left-10 right-10 top-5 h-1.5 z-0 rounded-full overflow-hidden">
                                <div className="h-full bg-green-500 transition-all duration-700" style={{ width: lineWidth }}></div>
                            </div>
                            
                            <div className="flex flex-col items-center w-24 z-10">
                                <div className={`w-10 h-10 rounded-full flex items-center justify-center transition-all border-2 ${getStepClass(1)}`}><i className="fas fa-file-alt text-base"></i></div>
                                <span className={`text-xs font-bold mt-2 ${isStandalone ? 'text-text' : 'text-text'}`}>Issued</span>
                                <span className={`text-[9px] text-center mt-1 ${isStandalone ? 'text-text' : 'text-text'}`}>{isStandalone ? '(ข้าม)' : (jobData?.requestBy || 'ผู้แจ้งงาน')}</span>
                            </div>
                            <div className="flex flex-col items-center w-24 z-10">
                                <div className={`w-10 h-10 rounded-full flex items-center justify-center transition-all border-2 ${getStepClass(2)}`}><i className="fas fa-check-double text-base"></i></div>
                                <span className={`text-xs font-bold mt-2 ${isStandalone ? 'text-text' : 'text-text'}`}>Approved</span>
                                <span className={`text-[9px] text-center mt-1 ${isStandalone ? 'text-text' : 'text-text'}`}>{approverName}</span>
                            </div>
                            <div className="flex flex-col items-center w-32 z-10">
                                <div className={`w-12 h-12 rounded-full flex items-center justify-center transition-all border-2 ${getStepClass(3)} -mt-1`}><i className="fas fa-cogs text-lg"></i></div>
                                <span className="text-sm font-bold mt-1.5 text-primary drop-shadow-md">In Progress</span>
                                <span className="text-[10px] text-purple-300 text-center mt-1 font-bold bg-purple-900/50 px-3 py-1 rounded-full border border-purple-500/30">Progress: {localProgress}%</span>
                            </div>
                            <div className="flex flex-col items-center w-24 z-10">
                                <div className={`w-10 h-10 rounded-full flex items-center justify-center transition-all border-2 ${getStepClass(4)}`}><i className="fas fa-flag-checkered text-base"></i></div>
                                <span className="text-xs font-bold mt-2 text-text">Completed</span>
                                <span className="text-[9px] text-text text-center mt-1">TD ส่งมอบ</span>
                            </div>
                            <div className="flex flex-col items-center w-24 z-10">
                                <div className={`w-10 h-10 rounded-full flex items-center justify-center transition-all border-2 ${getStepClass(5)}`}><i className="fas fa-handshake text-base"></i></div>
                                <span className="text-xs font-bold mt-2 text-text">Accepted</span>
                                <span className="text-[9px] text-text text-center mt-1">ผู้แจ้งรับมอบ</span>
                            </div>
                        </div>
                    );
                })()}
            </div>

            <div className="w-full flex flex-col xl:flex-row gap-6 pb-6">
                <div className="w-full xl:w-2/3 space-y-6 flex flex-col">
                    
                    {/* SCHEDULE PLAN SECTION */}
                    <div className="bg-surface p-4 md:p-5 rounded-2xl border border-glass shadow-xl flex flex-col w-full">
                        <div className="flex flex-col md:flex-row justify-between items-start md:items-end mb-3 border-b border-glass pb-3 gap-4">
                            <h2 className="text-lg font-bold text-primary"><i className="fas fa-stream mr-2"></i> Schedule Plan</h2>
                            
                            <div className="flex items-center gap-3 bg-surface p-2 rounded-lg border border-glass shadow-inner">
                                <div className="flex items-center gap-2">
                                    <span className="text-[10px] text-text font-bold uppercase"><i className="fas fa-calendar text-primary mr-1"></i> Timeframe:</span>
                                    <input type="date" value={project.projectPlanStart || ''} onChange={(e) => handleGlobalDateChange('projectPlanStart', e.target.value)} disabled={isCompleted || !canEditProgressAndPlan} className="bg-surface border border-glass text-text text-[9px] p-1 rounded outline-none focus:border-purple-500 disabled:opacity-60"/>
                                    <span className="text-text">-</span>
                                    <input type="date" value={project.projectPlanEnd || ''} onChange={(e) => handleGlobalDateChange('projectPlanEnd', e.target.value)} disabled={isCompleted || !canEditProgressAndPlan} className="bg-surface border border-glass text-text text-[9px] p-1 rounded outline-none focus:border-purple-500 disabled:opacity-60"/>
                                </div>
                                {hasGlobalTimeline && (
                                    <div className="border-l border-glass pl-3 ml-1 text-center">
                                        <span className="block text-[8px] text-text font-bold uppercase">Total Days</span>
                                        <span className="text-purple-400 font-black text-sm leading-none">{totalProjectDays}</span>
                                    </div>
                                )}
                            </div>
                        </div>
                        
                        {!hasGlobalTimeline ? (
                            <div className="text-center p-8 bg-surface/50 rounded-xl border-2 border-dashed border-glass text-text flex flex-col items-center">
                                <i className="fas fa-calendar-plus text-4xl mb-3 text-text"></i>
                                <p className="font-bold text-sm">กรุณากำหนด "Timeframe" ด้านบนก่อน</p>
                                <p className="text-xs mt-1">เพื่อเปิดใช้งานระบบวางแผนงาน (Gantt Chart)</p>
                            </div>
                        ) : (
                            <div className="w-full pb-2">
                                <div className="hidden md:flex w-full mb-1">
                                    <div className="w-48 shrink-0 mr-3 h-5 border-b border-glass flex items-center text-[10px] text-text font-bold uppercase tracking-wider">
                                        <i className="fas fa-tasks mr-2 text-primary"></i> Phase / ขั้นตอนดำเนินงาน
                                    </div> 
                                    <div className="flex-1 flex pl-2">
                                        <div className="w-20 shrink-0 mr-2"></div>
                                        <div className="flex-1 border-l border-glass relative">
                                            <MonthHeaders minDate={project.projectPlanStart} maxDate={project.projectPlanEnd} />
                                        </div>
                                    </div>
                                </div>

                                <div className="space-y-0">
                                    {displayPhases.map((phase, index) => {
                                        let isDelayed = false;
                                        if (project.schedule?.[phase.key]?.planEnd && project.schedule?.[phase.key]?.actualEnd) {
                                            const pEndMs = new Date(project.schedule[phase.key].planEnd).getTime();
                                            const aEndMs = new Date(project.schedule[phase.key].actualEnd).getTime();
                                            isDelayed = aEndMs > pEndMs; 
                                        }

                                        const currentAssignee = project.schedule?.[phase.key]?.assignee;
                                        const phaseMembers = [...teamMembersForAssign];
                                        if (currentAssignee && !phaseMembers.includes(currentAssignee)) {
                                            phaseMembers.push(currentAssignee);
                                        }

                                        return (
                                            <div key={phase.key} className={`group flex flex-col md:flex-row w-full py-3 items-center ${index !== displayPhases.length - 1 ? 'border-b border-glass/50' : ''} hover:bg-surface/10 transition duration-300`}>
                                                
                                                <div className="w-full md:w-48 shrink-0 md:mr-3 mb-3 md:mb-0 flex flex-col justify-center">
                                                    <div className="flex justify-between items-start mb-1.5 pr-2">
                                                        <h3 className="font-bold text-text text-[13px] text-primary tracking-wide flex items-center gap-2 truncate" title={phase.label}>
                                                            {phase.label}
                                                            {isDelayed && (
                                                                <i className="fas fa-exclamation-triangle text-red-500 animate-pulse" title="ระวัง! ขั้นตอนนี้ล่าช้ากว่าแผนที่วางไว้"></i>
                                                            )}
                                                        </h3>
                                                        {(canManageTeam && !isCompleted) && (
                                                            <button onClick={() => handleRemovePhase(phase)} className="text-text hover:text-red-500 transition opacity-0 group-hover:opacity-100 shrink-0" title="ลบขั้นตอนนี้ทิ้ง">
                                                                <i className="fas fa-trash-alt text-[10px]"></i>
                                                            </button>
                                                        )}
                                                    </div>

                                                    <div className="mb-2 pr-2">
                                                        <div className="flex items-center bg-surface/60 border border-glass rounded px-1.5 py-1 transition hover:border-purple-500">
                                                            <i className="fas fa-user-circle text-text mr-2 text-[10px]"></i>
                                                            <select value={currentAssignee || ''} onChange={(e) => handlePhaseAssigneeSave(phase.key, e.target.value)} disabled={isCompleted || !canEditProgressAndPlan} className="bg-transparent border-none outline-none text-[10px] text-purple-500 w-full cursor-pointer appearance-none disabled:opacity-60">
                                                                <option value="" className="text-text bg-surface">-- ผู้รับผิดชอบ --</option>
                                                                {phaseMembers.map(member => (
                                                                    <option key={member} value={member} className="bg-surface text-text">{member}</option>
                                                                ))}
                                                            </select>
                                                            <i className="fas fa-chevron-down text-text text-[8px] pointer-events-none"></i>
                                                        </div>
                                                    </div>

                                                    <PhaseDetailInput phaseKey={phase.key} initialValue={project.schedule?.[phase.key]?.detail} onSave={handlePhaseDetailSave} disabled={isCompleted || !canEditProgressAndPlan}/>
                                                </div>

                                                <div className="flex-1 flex flex-col justify-center md:border-l border-glass/30 md:pl-2 w-full min-w-0">
                                                    <DualSlider minDate={project.projectPlanStart} maxDate={project.projectPlanEnd} startStr={project.schedule?.[phase.key]?.planStart} endStr={project.schedule?.[phase.key]?.planEnd} type="plan" disabled={isCompleted || !canEditProgressAndPlan} onSave={(s, e) => handlePhaseSave(phase.key, s, e, true)} />
                                                    <DualSlider minDate={project.projectPlanStart} maxDate={project.projectPlanEnd} startStr={project.schedule?.[phase.key]?.actualStart} endStr={project.schedule?.[phase.key]?.actualEnd} type="actual" disabled={isCompleted || !canEditProgressAndPlan} onSave={(s, e) => handlePhaseSave(phase.key, s, e, false)} />
                                                </div>
                                            </div>
                                        );
                                    })}
                                </div>

                                {(canManageTeam && !isCompleted) && (
                                    <div className="mt-4 pt-4 border-t border-glass/50 flex flex-wrap items-center gap-2">
                                        <input type="text" value={newPhaseName} onChange={(e) => setNewPhaseName(e.target.value)} placeholder="+ เพิ่มขั้นตอนใหม่ (เช่น ทำ BOQ)" className="bg-surface border border-glass rounded px-3 py-1.5 text-xs text-text outline-none focus:border-blue-500 w-48 shrink-0" />
                                        <button onClick={handleAddPhase} disabled={!newPhaseName.trim()} className="bg-blue-600 hover:bg-blue-500 text-text px-4 py-1.5 rounded text-xs font-bold shadow disabled:opacity-50 transition">เพิ่ม</button>
                                    </div>
                                )}

                            </div>
                        )}
                    </div>

                    <div className="flex flex-col md:flex-row gap-6">
                        <div className="bg-surface/60 p-5 rounded-2xl border border-glass shadow-inner flex-1 flex flex-col">
                            <h2 className="text-sm font-bold text-text mb-3 uppercase tracking-wider"><i className="fas fa-list mr-2"></i> Project Details (5W1H)</h2>
                            <div className="grid grid-cols-2 gap-x-4 gap-y-2 text-xs">
                                <div className="col-span-2 bg-surface p-3 rounded"><span className="text-text font-bold block mb-1">What:</span> <span className="text-text">{project.what}</span></div>
                                <div className="col-span-2 bg-surface p-3 rounded"><span className="text-text font-bold block mb-1">How:</span> <span className="text-primary">{project.how}</span></div>
                                <div className="bg-surface p-2 rounded"><span className="text-text font-bold">Who:</span> {project.who}</div>
                                <div className="bg-surface p-2 rounded"><span className="text-text font-bold">Where:</span> {project.where}</div>
                                <div className="bg-surface p-2 rounded"><span className="text-text font-bold">Why:</span> {project.why}</div>
                                <div className="bg-surface p-2 rounded"><span className="text-text font-bold">Budget:</span> <span className="text-red-400 font-bold">{project.cost ? `${Number(project.cost).toLocaleString()} THB` : '-'}</span></div>
                            </div>
                            
                            {jobData?.timeline && jobData.timeline.filter(t => t.comment).length > 0 && (
                                <div className="mt-4 pt-4 border-t border-glass/50">
                                    <h3 className="text-[11px] font-bold text-orange-400 mb-3 uppercase tracking-wider"><i className="fas fa-comment-dots mr-1.5"></i> Manager / Approver Comments</h3>
                                    <div className="space-y-2.5">
                                        {jobData.timeline.filter(t => t.comment).map((t, i) => (
                                            <div key={i} className="bg-surface/80 p-3 rounded-lg border-l-4 border-orange-500 shadow-sm relative">
                                                <i className="fas fa-quote-left absolute top-2 right-3 text-text text-lg opacity-50"></i>
                                                <span className="text-[10px] text-text block mb-1 font-bold">
                                                    <i className="fas fa-user-circle mr-1"></i> {t.by} 
                                                    <span className="bg-surface px-1.5 py-0.5 rounded ml-2 font-normal">[{t.status}]</span>
                                                </span>
                                                <p className="text-xs text-text leading-relaxed">{t.comment}</p>
                                            </div>
                                        ))}
                                    </div>
                                </div>
                            )}
                        </div>

                        <div className="bg-surface/80 p-5 rounded-2xl border border-glass shadow-md md:w-1/3 flex flex-col">
                            <h2 className="text-sm font-bold text-green-400 mb-3 uppercase tracking-wider"><i className="fas fa-cloud-upload-alt mr-2"></i> Attachments / Files</h2>
                            <div className="w-full mb-3 space-y-2">
                                {project.attachments?.map((file, idx) => {
                                    const canRemoveFile = file.addedBy === userData?.name || isOwner || isTDMgrOrSup || isAdmin;
                                    return (
                                        <div key={idx} className="bg-surface border border-glass p-2 rounded-lg flex justify-between items-center group hover:border-green-500 transition cursor-pointer relative" onClick={() => setPreviewFile(file)}>
                                            <div className="flex items-center gap-2 overflow-hidden flex-1" title="คลิกเพื่อดูตัวอย่างไฟล์">
                                                <div className="w-8 h-8 rounded bg-surface flex items-center justify-center shrink-0 text-base">{getAttachmentIcon(file.type)}</div>
                                                <div className="flex flex-col overflow-hidden">
                                                    <span className="text-xs text-text font-bold truncate">{file.title}</span>
                                                    <span className="text-[9px] text-text">By {file.addedBy}</span>
                                                </div>
                                            </div>
                                            {(canRemoveFile && !isCompleted) && (
                                                <button onClick={(e) => handleRemoveAttachment(file, e)} className="text-text hover:text-red-500 hover:bg-surface w-7 h-7 rounded-full flex items-center justify-center shrink-0 opacity-0 group-hover:opacity-100 transition shadow-inner absolute right-1"><i className="fas fa-trash-alt text-[10px]"></i></button>
                                            )}
                                        </div>
                                    )
                                })}
                                {(!project.attachments || project.attachments.length === 0) && (
                                    <div className="text-center py-6 text-text flex flex-col items-center border-2 border-dashed border-glass rounded-lg">
                                        <i className="fas fa-file-upload text-3xl mb-2 opacity-30"></i><span className="text-[10px]">อัปโหลดไฟล์ของโปรเจกต์นี้</span>
                                    </div>
                                )}
                            </div>

                            {(!isCompleted && canUploadFile) && (
                                <form onSubmit={handleFileUpload} className="mt-auto border-t border-glass pt-3 flex flex-col gap-2">
                                    <input type="text" value={attachTitle} onChange={(e)=>setAttachTitle(e.target.value)} placeholder="ตั้งชื่อไฟล์ (เช่น รูปหน้างาน, แบบ CAD)" className="w-full bg-surface border border-glass rounded px-2.5 py-1.5 text-[10px] text-text outline-none focus:border-green-500" required disabled={isUploading}/>
                                    <div className="flex gap-2 items-center">
                                        <input type="file" ref={fileInputRef} onChange={(e)=>setSelectedFile(e.target.files[0])} className="flex-1 text-[10px] text-text file:mr-2 file:py-1.5 file:px-2 file:rounded file:border-1 file:text-[10px] file:font-bold file:bg-surface file:text-text hover:file:bg-surface cursor-pointer bg-surface border border-glass rounded pr-1 overflow-hidden" required disabled={isUploading}/>
                                        <button type="submit" disabled={!selectedFile || !attachTitle || isUploading} className="bg-green-600 hover:bg-green-500 disabled:bg-surface disabled:text-text text-text px-3 py-1.5 rounded text-[10px] font-bold shadow transition flex items-center justify-center min-w-[70px] h-[34px]">{isUploading ? <i className="fas fa-spinner fa-spin"></i> : <span><i className="fas fa-upload mr-1"></i>อัปโหลด</span>}</button>
                                    </div>
                                </form>
                            )}
                        </div>
                    </div>
                </div>

                <div className="w-full xl:w-1/3 flex flex-col gap-6 h-fit">
                    
                    <div className="bg-surface p-5 rounded-2xl border border-glass shadow-xl">
                        <h2 className="text-sm font-bold text-primary mb-3"><i className="fas fa-users mr-2"></i> Team Collaboration</h2>
                        <div className="flex flex-wrap gap-2 mb-3">
                            <span className="bg-purple-600 text-text text-[10px] px-3 py-1.5 rounded-full font-bold shadow border border-purple-500"><i className="fas fa-crown mr-1"></i> {project.owner}</span>
                            {project.coWorkers?.map((cw, idx) => (
                                <span key={idx} className="bg-surface text-text text-[10px] pl-3 pr-1 py-1 rounded-full border border-glass flex items-center gap-1.5">
                                    {cw}
                                    {(canManageTeam && !isCompleted) && (
                                        <button onClick={() => handleRemoveCoWorker(cw)} className="bg-surface hover:bg-red-500 text-text hover:text-text w-4 h-4 rounded-full flex items-center justify-center transition-colors shadow-inner" title="ลบออกจากโปรเจกต์"><i className="fas fa-times text-[8px]"></i></button>
                                    )}
                                </span>
                            ))}
                        </div>
                        {(!isCompleted && canManageTeam) && (
                            <div className="flex gap-2">
                                <select value={newCoWorker} onChange={(e) => setNewCoWorker(e.target.value)} className="flex-1 bg-surface border border-glass rounded text-text text-xs p-2 outline-none">
                                    <option value="">+ เพิ่มผู้ร่วมงาน (TD)</option>
                                    {tdUsers.map(u => <option key={u.name} value={u.name} style={{ backgroundColor: 'var(--color-bg)', color: 'var(--color-text)' }}>{u.name}</option>)}
                                </select>
                                <button onClick={handleAddCoWorker} disabled={!newCoWorker} className="bg-blue-600 hover:bg-blue-500 text-text px-3 rounded text-xs font-bold disabled:opacity-50"><i className="fas fa-plus"></i></button>
                            </div>
                        )}
                    </div>

                    <div className="bg-surface p-5 rounded-2xl border border-glass shadow-xl flex flex-col">
                        <div className="flex justify-between items-center mb-3 border-b border-glass pb-2">
                            <h2 className="text-sm font-bold text-yellow-400"><i className="fas fa-tools mr-2"></i> Part Orders</h2>
                            {canOrderParts && (
                                <button 
                                    onClick={() => navigate('/part-orders', { state: { openOrderForm: true, projectId: id } })} 
                                    className="text-[10px] bg-surface hover:bg-yellow-600 text-text px-3 py-1 rounded transition shadow-sm"
                                >
                                    สั่งเพิ่ม <i className="fas fa-external-link-alt ml-1"></i>
                                </button>
                            )}
                        </div>
                        
                        <div className="w-full mb-1 space-y-2">
                            {partOrders.map(part => (
                                <div key={part.id} className="bg-surface border border-glass p-2.5 rounded-lg flex justify-between items-center">
                                    <div className="flex flex-col overflow-hidden mr-2 w-full">
                                        <span className="text-xs text-text font-bold truncate" title={part.partName}>
                                            {part.partName} <span className="text-text">x{part.qty}</span>
                                        </span>
                                        
                                        {(part.link || part.fileUrl) && (
                                            <div className="flex items-center gap-3 mt-1">
                                                {part.link && (
                                                    <a href={part.link} target="_blank" rel="noreferrer" className="text-[10px] text-purple-400 hover:underline flex items-center gap-1">
                                                        <i className="fas fa-external-link-alt"></i> Link
                                                    </a>
                                                )}
                                                {part.fileUrl && (
                                                    <a href={part.fileUrl} target="_blank" rel="noreferrer" className="text-[10px] text-green-400 hover:underline flex items-center gap-1 truncate max-w-[120px]">
                                                        <i className="fas fa-paperclip"></i> {part.fileName || 'ไฟล์แนบ'}
                                                    </a>
                                                )}
                                            </div>
                                        )}

                                        <span className="text-[9px] text-text mt-1">
                                            ETA: {part.eta ? part.eta.toDate().toLocaleDateString('th-TH') : 'รอของ / กำลังดำเนินการ'}
                                        </span>
                                    </div>
                                    <span className={`text-[9px] px-2 py-1 rounded font-bold whitespace-nowrap shrink-0 ${
                                        part.status === 'Received' ? 'bg-green-500/20 text-green-400 border border-green-500/30' : 
                                        part.status.includes('Ordered') ? 'bg-blue-500/20 text-primary border border-blue-500/30' :
                                        part.status.includes('Cancelled') ? 'bg-red-500/20 text-red-400 border border-red-500/30' :
                                        'bg-surface text-text border border-glass'
                                    }`}>
                                        {part.status}
                                    </span>
                                </div>
                            ))}
                            {partOrders.length === 0 && <p className="text-xs text-text text-center py-4 italic border-2 border-dashed border-glass rounded-lg">ยังไม่มีการเบิกอะไหล่</p>}
                        </div>
                    </div>

                    <div className="bg-surface p-5 rounded-2xl border border-glass shadow-xl flex flex-col">
                        <h2 className="text-sm font-bold text-orange-300 mb-3"><i className="fas fa-sticky-note mr-2"></i> Sticky Notes</h2>
                        <div className="w-full mb-3 space-y-2">
                            {project.stickyNotes?.map((note, idx) => (
                                <div key={idx} className={`${note.color} p-3 rounded-lg shadow-sm transform rotate-1 hover:rotate-0 transition duration-300`}>
                                    <p className="text-sm font-medium mb-2 leading-tight">{note.text}</p>
                                    <div className="text-[9px] opacity-70 flex justify-between mt-1"><span>{note.author}</span> <span>{new Date(note.timestamp).toLocaleDateString('th-TH')}</span></div>
                                </div>
                            ))}
                            {(!project.stickyNotes || project.stickyNotes.length === 0) && <p className="text-xs text-text text-center py-4 italic">ยังไม่มี Note</p>}
                        </div>
                        {!isCompleted && (
                            <form onSubmit={handleAddNote} className="mt-auto border-t border-glass pt-3">
                                <textarea value={noteText} onChange={(e)=>setNoteText(e.target.value)} placeholder="พิมพ์ข้อความ Note..." className="w-full bg-surface border border-glass rounded p-2 text-xs text-text mb-2 outline-none focus:border-orange-500" rows="2" required></textarea>
                                <div className="flex justify-between items-center">
                                    <div className="flex gap-1">
                                        <button type="button" onClick={()=>setNoteColor('bg-yellow-200 text-yellow-900')} className={`w-5 h-5 rounded-full bg-yellow-200 border-2 ${noteColor.includes('yellow') ? 'border-white' : 'border-transparent'}`}></button>
                                        <button type="button" onClick={()=>setNoteColor('bg-green-200 text-green-900')} className={`w-5 h-5 rounded-full bg-green-200 border-2 ${noteColor.includes('green') ? 'border-white' : 'border-transparent'}`}></button>
                                        <button type="button" onClick={()=>setNoteColor('bg-pink-200 text-pink-900')} className={`w-5 h-5 rounded-full bg-pink-200 border-2 ${noteColor.includes('pink') ? 'border-white' : 'border-transparent'}`}></button>
                                        <button type="button" onClick={()=>setNoteColor('bg-blue-200 text-primary')} className={`w-5 h-5 rounded-full bg-blue-200 border-2 ${noteColor.includes('blue') ? 'border-white' : 'border-transparent'}`}></button>
                                    </div>
                                    <button type="submit" className="bg-orange-600 hover:bg-orange-500 text-text px-4 py-1.5 rounded text-xs font-bold">แปะ Note</button>
                                </div>
                            </form>
                        )}
                    </div>

                    <div className="bg-surface p-5 rounded-2xl border border-glass shadow-xl flex flex-col">
                        <h2 className="text-sm font-bold text-green-400 mb-3"><i className="fas fa-comments mr-2"></i> Team Chat</h2>
                        <div className="w-full bg-surface rounded-lg p-3 mb-3 space-y-3 flex flex-col">
                            {project.chatMessages?.map((msg, idx) => {
                                const isMe = msg.sender === userData.name;
                                return (
                                    <div key={idx} className={`flex flex-col ${isMe ? 'items-end' : 'items-start'}`}>
                                        <span className="text-[9px] text-text mb-0.5">{msg.sender} • {new Date(msg.timestamp).toLocaleTimeString('th-TH', {hour: '2-digit', minute:'2-digit'})}</span>
                                        <div className={`px-3 py-1.5 rounded-xl text-xs max-w-[85%] break-words ${isMe ? 'bg-blue-600 text-text rounded-tr-none' : 'bg-surface text-text rounded-tl-none'}`}>
                                            {msg.text}
                                        </div>
                                    </div>
                                )
                            })}
                            {(!project.chatMessages || project.chatMessages.length === 0) && <p className="text-xs text-text text-center m-auto">ส่งข้อความทักทายทีมงานได้เลย</p>}
                        </div>
                        {!isCompleted && (
                            <form onSubmit={handleSendChat} className="flex gap-2">
                                <input type="text" value={chatMsg} onChange={(e)=>setChatMsg(e.target.value)} placeholder="พิมพ์ข้อความ..." className="flex-1 bg-surface border border-glass rounded-full px-3 py-1.5 text-xs text-text outline-none focus:border-green-500" required />
                                <button type="submit" className="bg-green-600 hover:bg-green-500 w-8 h-8 rounded-full flex items-center justify-center text-text"><i className="fas fa-paper-plane text-xs"></i></button>
                            </form>
                        )}
                    </div>

                </div>
            </div>

            {/* 🌟 แสดงพรีวิวไฟล์ 🌟 */}
            {previewFile && (
                <div className="fixed inset-0 bg-black/90 z-50 flex flex-col items-center justify-center p-6 backdrop-blur-sm">
                    <div className="w-full max-w-5xl bg-surface rounded-2xl border border-glass shadow-2xl overflow-hidden flex flex-col" style={{ height: '90vh' }}>
                        <div className="bg-surface p-4 border-b border-glass flex justify-between items-center shrink-0">
                            <div className="flex items-center gap-3 overflow-hidden">
                                <span className="text-xl shrink-0">{getAttachmentIcon(previewFile.type)}</span>
                                <h3 className="text-text font-bold text-lg truncate pr-4">{previewFile.title}</h3>
                            </div>
                            <div className="flex items-center gap-4 shrink-0">
                                <a href={previewFile.url} target="_blank" rel="noopener noreferrer" className="bg-blue-600 hover:bg-blue-500 text-text px-4 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-2 shadow whitespace-nowrap"><i className="fas fa-external-link-alt"></i> เปิดหน้าต่างใหม่</a>
                                <button onClick={() => setPreviewFile(null)} className="text-text hover:text-red-400 text-3xl leading-none transition">&times;</button>
                            </div>
                        </div>
                        <div className="flex-1 bg-surface/50 flex items-center justify-center relative overflow-hidden p-4 rounded-b-2xl">
                            {extractDriveId(previewFile.url) ? (
                                <iframe src={`https://drive.google.com/file/d/${extractDriveId(previewFile.url)}/preview`} className="w-full h-full border-0 bg-surface/5" allow="autoplay"></iframe>
                            ) : previewFile.type === 'image' ? (
                                <img src={previewFile.url} className="max-w-full max-h-full object-contain rounded" alt="preview" />
                            ) : (
                                <div className="text-center text-text">
                                    <i className="fas fa-exclamation-triangle text-4xl mb-3"></i>
                                    <p>ไฟล์ประเภทนี้ไม่รองรับการพรีวิวในหน้าต่างนี้</p>
                                    <a href={previewFile.url} target="_blank" rel="noopener noreferrer" className="text-primary underline text-sm mt-2 inline-block">คลิกที่นี่เพื่อดาวน์โหลด / เปิดดูในหน้าใหม่</a>
                                </div>
                            )}
                        </div>
                    </div>
                </div>
            )}

            {/* Modal สำหรับพิมพ์ใบส่งมอบงาน */}
            {showReportModal && (
                <div className="fixed inset-0 bg-black/10 flex justify-center items-center z-[60] p-4 backdrop-blur-sm">
                    <div className="bg-surface w-full max-w-2xl p-6 rounded-2xl border border-glass shadow-2xl relative animate-fade-in-down">
                        <button onClick={() => setShowReportModal(false)} className="absolute top-4 right-4 text-text hover:text-text text-2xl font-bold">&times;</button>
                        
                        <h2 className="text-xl font-bold text-text mb-2 flex items-center gap-2">
                            <i className="fas fa-file-contract text-indigo-400"></i> ใบส่งมอบและประเมินผล (E-Signature)
                        </h2>
                        <p className="text-xs text-text mb-5 border-b border-glass pb-3">
                            {canEditReport ? "คุณสามารถแก้ไขข้อมูลและกดเซ็นเอกสารได้" : "โหมดดูเอกสาร: ข้อมูลถูกเขียนโดยฝ่าย TD"}
                        </p>
                        
                        <div className="space-y-4">
                            <div>
                                <label className="text-xs text-text font-bold mb-1 block">สรุปผลการทดสอบ (Test Summary)</label>
                                <textarea 
                                    value={reportData.testSummary} 
                                    onChange={(e) => setReportData({...reportData, testSummary: e.target.value})}
                                    disabled={!canEditReport}
                                    className="w-full bg-surface border border-glass rounded p-2.5 text-sm text-text outline-none focus:border-indigo-500 disabled:opacity-70 disabled:cursor-not-allowed"
                                    rows="2"
                                    placeholder="เช่น เดินเครื่องได้ต่อเนื่อง 24 ชม. ไม่พบปัญหาชิ้นงานติดขัด..."
                                ></textarea>
                            </div>

                            <div>
                                <label className="text-xs text-text font-bold mb-1 block">ประสิทธิภาพที่ได้ / สิ่งที่ปรับปรุง (Efficiency / Improvement)</label>
                                <textarea 
                                    value={reportData.efficiencyGain} 
                                    onChange={(e) => setReportData({...reportData, efficiencyGain: e.target.value})}
                                    disabled={!canEditReport}
                                    className="w-full bg-surface border border-glass rounded p-2.5 text-sm text-text outline-none focus:border-indigo-500 disabled:opacity-70 disabled:cursor-not-allowed"
                                    rows="2"
                                    placeholder="เช่น ลดเวลา Cycle time ได้ 5 วินาที, ลด Reject จาก 2% เหลือ 0.5%..."
                                ></textarea>
                            </div>

                            <div>
                                <label className="text-xs text-text font-bold mb-1 block">ผลการประเมิน (Evaluation Status)</label>
                                <select 
                                    value={reportData.isPass}
                                    onChange={(e) => setReportData({...reportData, isPass: e.target.value})}
                                    disabled={!canEditReport}
                                    className="w-full bg-surface border border-glass rounded p-2.5 text-sm font-bold outline-none focus:border-indigo-500 text-text disabled:opacity-70 disabled:cursor-not-allowed"
                                >
                                    <option value="Pass" className="text-green-400">✅ ผ่านเกณฑ์ (Passed) - พร้อมใช้งาน</option>
                                    <option value="Conditional" className="text-yellow-400">⚠️ ผ่านแบบมีเงื่อนไข - ต้องติดตามผล</option>
                                    <option value="Fail" className="text-red-400">❌ ไม่ผ่าน (Failed) - ต้องปรับปรุงแก้ไข</option>
                                </select>
                            </div>
                        </div>

                        <div className="grid grid-cols-3 gap-3 mt-6 border-t border-glass pt-5">
                            <div className="bg-surface/80 p-3 rounded-xl border border-glass flex flex-col items-center justify-center text-center h-24">
                                <p className="text-[10px] text-text mb-1">1. ผู้ส่งมอบ (TD)</p>
                                {project.handoverReport ? (
                                    <div className="animate-fade-in">
                                        <span className="text-green-400 text-[10px] font-bold"><i className="fas fa-check-circle"></i> E-Signed</span>
                                        <p className="text-xs text-text font-bold mt-1 truncate w-full px-2" title={project.handoverReport.generatedBy}>{project.handoverReport.generatedBy}</p>
                                    </div>
                                ) : canEditReport ? (
                                    <span className="text-[10px] text-text">สร้าง Report เพื่อเซ็น</span>
                                ) : (
                                    <span className="text-[10px] text-yellow-500">รอ TD สร้างเอกสาร</span>
                                )}
                            </div>

                            <div className="bg-surface/80 p-3 rounded-xl border border-glass flex flex-col items-center justify-center text-center h-24 relative overflow-hidden">
                                <p className="text-[10px] text-text mb-1 z-10 relative">2. ผู้ตรวจสอบ (Manager/Sup)</p>
                                {project.handoverReport?.approverSign ? (
                                    <div className="animate-fade-in z-10 relative">
                                        <span className="text-primary text-[10px] font-bold"><i className="fas fa-check-circle"></i> E-Signed</span>
                                        <p className="text-xs text-text font-bold mt-1 truncate w-full px-2" title={project.handoverReport.approverSign.name}>{project.handoverReport.approverSign.name}</p>
                                    </div>
                                ) : canApproveSign ? (
                                    <button onClick={() => handleSignReport('approver')} disabled={!project.handoverReport} className="bg-blue-600 hover:bg-blue-500 text-text text-[10px] px-3 py-1.5 rounded shadow disabled:opacity-50 transition z-10 relative">กดเซ็นรับรอง</button>
                                ) : (
                                    <span className="text-[10px] text-yellow-500 z-10 relative">รอตรวจสอบ</span>
                                )}
                                {project.handoverReport?.approverSign && <i className="fas fa-stamp absolute -right-2 -bottom-2 text-5xl text-primary/10 -rotate-12"></i>}
                            </div>

                            <div className="bg-surface/80 p-3 rounded-xl border border-glass flex flex-col items-center justify-center text-center h-24 relative overflow-hidden">
                                <p className="text-[10px] text-text mb-1 z-10 relative">3. ผู้รับมอบ (Issuer)</p>
                                {project.handoverReport?.issuerSign ? (
                                    <div className="animate-fade-in z-10 relative">
                                        <span className="text-green-400 text-[10px] font-bold"><i className="fas fa-check-circle"></i> E-Signed</span>
                                        <p className="text-xs text-text font-bold mt-1 truncate w-full px-2" title={project.handoverReport.issuerSign.name}>{project.handoverReport.issuerSign.name}</p>
                                    </div>
                                ) : isIssuer ? (
                                    <button onClick={() => handleSignReport('issuer')} disabled={!project.handoverReport} className="bg-green-600 hover:bg-green-500 text-text text-[10px] px-3 py-1.5 rounded shadow disabled:opacity-50 transition z-10 relative">กดรับมอบงาน</button>
                                ) : (
                                    <span className="text-[10px] text-yellow-500 z-10 relative">รอรับมอบ</span>
                                )}
                                {project.handoverReport?.issuerSign && <i className="fas fa-stamp absolute -right-2 -bottom-2 text-5xl text-green-500/10 -rotate-12"></i>}
                            </div>
                        </div>

                        <div className="mt-6 flex justify-end gap-3 pt-4">
                            <button onClick={() => setShowReportModal(false)} className="px-4 py-2 text-sm font-bold text-text hover:text-text transition">ปิดหน้าต่าง</button>
                            <button onClick={handlePrintReport} className="bg-indigo-600 hover:bg-indigo-500 text-text px-5 py-2 rounded-lg text-sm font-bold shadow-lg transition flex items-center gap-2">
                                <i className="fas fa-print"></i> {canEditReport ? (!project.handoverReport ? 'สร้างเอกสาร & Print' : 'บันทึก & Print') : 'Print / Save PDF'}
                            </button>
                        </div>
                    </div>
                </div>
            )}
            
            {/* 🌟 ---------------- เริ่มบล็อก Project Timeline Updates ---------------- 🌟 */}
            <div className="mt-6 xl:col-span-3 w-full">
                <h2 className="text-xl font-bold text-primary mb-4 uppercase tracking-wider flex items-center">
                    <i className="fas fa-rss-square mr-3"></i> Project Updates & Feed
                </h2>
                
                {!isCompleted && (
                    <div className="bg-surface rounded-2xl border border-glass shadow-xl overflow-hidden relative mb-6">
                        <div className="p-4 bg-surface/50 border-b border-glass flex items-center gap-3">
                            {/* 🌟 แสดงรูปโปรไฟล์ของผู้ใช้งานในส่วนฟอร์มโพสต์ (Project Space) */}
                            <div className="w-10 h-10 rounded-full bg-blue-600 flex items-center justify-center text-text font-bold text-lg shadow-inner overflow-hidden shrink-0 border border-glass">
                                {(userData?.avatar || userData?.photoURL) ? (
                                    <img src={userData.avatar || userData.photoURL} alt="Profile" className="w-full h-full object-cover bg-surface" referrerPolicy="no-referrer" />
                                ) : (
                                    userData?.name?.substring(0, 2).toUpperCase() || 'U'
                                )}
                            </div>
                            <span className="font-bold text-text text-sm">สร้างโพสต์อัปเดตงาน</span>
                        </div>

                        <form onSubmit={handleCreateProjectPost} className="p-4">
                            <textarea 
                                value={postText} onChange={(e) => setPostText(e.target.value)} 
                                placeholder="ความคืบหน้าของโปรเจกต์นี้..." 
                                className="w-full bg-surface/50 border border-glass rounded-xl p-4 text-text outline-none focus:border-blue-500 resize-none mb-3 placeholder-gray-500 transition-colors" 
                                rows="3" required 
                            />

                            {postAttachments.length > 0 && (
                                <div className="mb-3 flex flex-wrap gap-2 p-3 bg-surface/50 rounded-lg border border-glass">
                                    {postAttachments.map(file => (
                                        <div key={file.id} className="flex items-center gap-2 bg-surface px-3 py-1.5 rounded-full border border-glass text-xs text-primary">
                                            <i className={`fas ${file.type === 'image' ? 'fa-image text-purple-400' : 'fa-file-pdf text-red-400'}`}></i>
                                            <span className="truncate max-w-[150px]">{file.title}</span>
                                            <button type="button" onClick={() => setPostAttachments(postAttachments.filter(f => f.id !== file.id))} className="text-text hover:text-red-500"><i className="fas fa-times"></i></button>
                                        </div>
                                    ))}
                                </div>
                            )}

                            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center pt-3 border-t border-glass gap-3">
                                <div className="flex w-full sm:w-auto items-center gap-2 bg-surface/50 p-1.5 rounded-lg border border-glass">
                                    <input type="text" value={postAttachTitle} onChange={(e)=>setPostAttachTitle(e.target.value)} placeholder="ตั้งชื่อไฟล์..." className="w-24 sm:w-32 bg-transparent text-xs text-text outline-none px-2" disabled={isPostUploading}/>
                                    <div className="w-px h-5 bg-surface mx-1"></div>
                                    <input type="file" ref={postFileInputRef} onChange={(e)=>setPostSelectedFile(e.target.files[0])} className="w-48 text-[10px] text-text file:mr-2 file:py-1 file:px-2 file:rounded file:border-1 file:bg-surface file:text-text cursor-pointer" disabled={isPostUploading}/>
                                    <button type="button" onClick={handlePostFileUpload} disabled={!postSelectedFile || !postAttachTitle || isPostUploading} className="bg-surface hover:bg-surface text-text px-3 py-1 rounded text-xs font-bold transition disabled:opacity-50">
                                        {isPostUploading ? <i className="fas fa-spinner fa-spin"></i> : <i className="fas fa-paperclip"></i>}
                                    </button>
                                </div>
                                
                                <button type="submit" disabled={isPostSubmitting || !postText.trim()} className="w-full sm:w-auto bg-blue-600 hover:bg-blue-500 text-text px-8 py-2.5 rounded-lg font-bold shadow-lg shadow-blue-500/30 transition-all disabled:opacity-50 disabled:shadow-none flex items-center justify-center">
                                    {isPostSubmitting ? 'กำลังโพสต์...' : <><i className="fas fa-paper-plane mr-2"></i> โพสต์อัปเดต</>}
                                </button>
                            </div>
                        </form>
                    </div>
                )}

                <div className="space-y-5 w-full pb-10">
                    {combinedFeed.map(item => {
                        if (item.feedType === 'manual') {
                            const isLikedByMe = item.likes && item.likes.includes(user?.uid);
                            const likeCount = item.likes ? item.likes.length : 0;
                            const commentCount = item.comments ? item.comments.length : 0;

                            return (
                                <div key={item.id} className="bg-surface rounded-2xl border border-glass shadow-xl overflow-hidden animate-fade-in-down w-full">
                                    <div className="p-4 flex justify-between items-start">
                                        <div className="flex items-center gap-3">
                                            {/* 🌟 แสดงรูปโปรไฟล์ของเจ้าของโพสต์ (Project Space) */}
                                            <div className="w-10 h-10 rounded-full bg-surface flex items-center justify-center text-text font-bold border border-glass shadow-inner shrink-0 overflow-hidden">
                                                {item.authorAvatar ? (
                                                    <img src={item.authorAvatar} alt="Profile" className="w-full h-full object-cover bg-surface" referrerPolicy="no-referrer" />
                                                ) : (
                                                    item.author?.substring(0, 2).toUpperCase() || 'U'
                                                )}
                                            </div>
                                            <div className="flex flex-col">
                                                <span className="font-bold text-primary text-sm">{item.author}</span>
                                                <span className="text-[10px] text-text"><i className="far fa-clock mr-1"></i> {timeAgo(item.createdAt)}</span>
                                            </div>
                                        </div>
                                        {item.authorId === user?.uid && (
                                            <button onClick={() => handleDeletePost(item.id)} className="text-text hover:text-red-500 transition bg-surface rounded-full w-8 h-8 flex items-center justify-center border border-transparent hover:border-red-500/30"><i className="fas fa-trash-alt text-xs"></i></button>
                                        )}
                                    </div>

                                    <div className="px-4 pb-2">
                                        <p className="text-text text-sm whitespace-pre-wrap leading-relaxed">{item.text}</p>
                                    </div>

                                    {item.attachments && item.attachments.length > 0 && (
                                        <div className="px-4 pb-3 flex flex-wrap gap-2 mt-1">
                                            {item.attachments.map((file, idx) => (
                                                file.type === 'image' ? (
                                                    <a key={idx} href={file.url} target="_blank" rel="noreferrer" className="block relative group overflow-hidden rounded-xl border border-glass hover:border-blue-500 transition-all w-32 h-20 shadow-md">
                                                        <img src={getThumbnailUrl(file.url)} alt={file.title} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300 opacity-80 group-hover:opacity-100" />
                                                        <div className="absolute inset-x-0 bottom-0 bg-black/70 p-1 backdrop-blur-sm"><p className="text-[8px] text-text font-bold truncate text-center">{file.title}</p></div>
                                                    </a>
                                                ) : (
                                                    <a key={idx} href={file.url} target="_blank" rel="noreferrer" className="flex items-center gap-2 bg-surface hover:bg-surface border border-glass p-2 rounded-xl transition group min-w-[150px] shadow-sm">
                                                        <i className={`fas ${file.type === 'sheets' ? 'fa-file-excel text-green-500' : 'fa-file-pdf text-red-500'} text-lg`}></i>
                                                        <div className="flex flex-col overflow-hidden">
                                                            <span className="text-xs text-primary font-bold truncate group-hover:text-primary transition-colors">{file.title}</span>
                                                        </div>
                                                    </a>
                                                )
                                            ))}
                                        </div>
                                    )}

                                    <div className="px-4 py-3 border-t border-glass/50 flex items-center gap-6 bg-surface/30">
                                        <button onClick={() => handleToggleLike(item.id, item.likes)} className={`flex items-center gap-2 text-sm font-bold transition-all ${isLikedByMe ? 'text-primary' : 'text-text hover:text-text'}`}>
                                            <i className={`fas fa-thumbs-up ${isLikedByMe ? 'scale-110 animate-bounce-short' : ''}`}></i>
                                            {likeCount} {likeCount > 0 ? 'ถูกใจ' : 'ถูกใจ'}
                                        </button>
                                        <button onClick={() => handleToggleComments(item.id)} className="flex items-center gap-2 text-sm font-bold text-text hover:text-text transition-colors">
                                            <i className="fas fa-comment-alt"></i>
                                            {commentCount} คอมเมนต์
                                        </button>
                                    </div>

                                    {showComments[item.id] && (
                                        <div className="px-4 pb-4 pt-2 bg-surface/50 border-t border-glass">
                                            <div className="space-y-3 mb-4 max-h-60 overflow-y-auto custom-scrollbar pr-1">
                                                {(item.comments || []).map((comment) => (
                                                    <div key={comment.id} className="flex items-start gap-3 group">
                                                        {/* 🌟 แสดงรูปโปรไฟล์ของคนคอมเมนต์ (Project Space) */}
                                                        <div className="w-8 h-8 rounded-full bg-surface flex items-center justify-center text-text font-bold text-[10px] shrink-0 border border-glass overflow-hidden">
                                                            {comment.authorAvatar ? (
                                                                <img src={comment.authorAvatar} alt="Profile" className="w-full h-full object-cover bg-surface" referrerPolicy="no-referrer" />
                                                            ) : (
                                                                comment.author?.substring(0, 2).toUpperCase()
                                                            )}
                                                        </div>
                                                        <div className="flex-1 bg-surface rounded-2xl rounded-tl-sm px-4 py-2.5 relative group-hover:bg-surface/80 transition-colors border border-glass/50 shadow-sm">
                                                            <div className="flex justify-between items-start mb-0.5">
                                                                <span className="text-xs font-bold text-primary">{comment.author}</span>
                                                                {(comment.authorId === user?.uid || item.authorId === user?.uid) && (
                                                                    <button onClick={() => handleDeleteComment(item.id, comment)} className="text-text hover:text-red-500 opacity-0 group-hover:opacity-100 transition absolute right-3 top-2.5" title="ลบคอมเมนต์">
                                                                        <i className="fas fa-times text-[10px]"></i>
                                                                    </button>
                                                                )}
                                                            </div>
                                                            <p className="text-xs text-text whitespace-pre-wrap">{comment.text}</p>
                                                            <span className="text-[9px] text-text block mt-1">{timeAgo(comment.timestamp)}</span>
                                                        </div>
                                                    </div>
                                                ))}
                                                {commentCount === 0 && <p className="text-center text-xs text-text italic py-2">ยังไม่มีคอมเมนต์ เป็นคนแรกที่ให้ความเห็นสิ!</p>}
                                            </div>
                                            <form onSubmit={(e) => handleAddComment(e, item.id)} className="flex items-center gap-3">
                                                {/* 🌟 แสดงรูปโปรไฟล์ของช่องพิมพ์คอมเมนต์ (Project Space) */}
                                                <div className="w-8 h-8 rounded-full bg-blue-600 flex items-center justify-center text-text font-bold text-[10px] shrink-0 shadow-inner overflow-hidden border border-glass">
                                                    {(userData?.avatar || userData?.photoURL) ? (
                                                        <img src={userData.avatar || userData.photoURL} alt="Profile" className="w-full h-full object-cover bg-surface" referrerPolicy="no-referrer" />
                                                    ) : (
                                                        userData?.name?.substring(0, 2).toUpperCase()
                                                    )}
                                                </div>
                                                <div className="flex-1 flex bg-surface border border-glass rounded-full overflow-hidden focus-within:border-blue-500 transition-colors shadow-inner">
                                                    <input type="text" value={commentInputs[item.id] || ''} onChange={(e) => setCommentInputs(prev => ({...prev, [item.id]: e.target.value}))} placeholder="เขียนคอมเมนต์..." className="flex-1 bg-transparent px-4 py-2 text-xs text-text outline-none"/>
                                                    <button type="submit" disabled={!commentInputs[item.id]?.trim()} className="px-4 bg-surface hover:bg-blue-600 text-text hover:text-text disabled:bg-surface disabled:text-text disabled:opacity-50 transition flex items-center justify-center"><i className="fas fa-paper-plane text-[10px]"></i></button>
                                                </div>
                                            </form>
                                        </div>
                                    )}
                                </div>
                            );
                        } 
                        
                        else {
                            const IconClasses = getSystemIcon(item.action).split(' ');
                            const faIcon = IconClasses[0];
                            const colorClasses = IconClasses.slice(1).join(' ');

                            return (
                                <div key={item.id} className="bg-surface/50 rounded-xl border border-glass/50 shadow-sm p-3 hover:border-glass transition-colors flex items-center gap-4 animate-fade-in-down w-full">
                                    <div className={`flex items-center justify-center w-10 h-10 rounded-full shrink-0 shadow-inner ${colorClasses}`}>
                                        <i className={`fas ${faIcon} text-sm text-text`}></i>
                                    </div>
                                    <div className="flex-1 flex flex-col min-w-0">
                                        <div className="flex justify-between items-center mb-0.5">
                                            <span className="text-xs font-bold text-text truncate pr-2"><i className="fas fa-robot text-[10px] mr-1.5 text-text"></i> {item.userName || item.email?.split('@')[0] || 'System'}</span>
                                            <span className="text-[9px] text-text shrink-0"><i className="far fa-clock mr-1"></i> {timeAgo(item.timestamp)}</span>
                                        </div>
                                        <p className="text-xs text-text leading-snug truncate">
                                            <span className="text-primary font-bold">{item.action}</span>: {item.details}
                                        </p>
                                    </div>
                                </div>
                            );
                        }
                    })}
                    
                    {hasMoreFeed && (
                        <div className="flex justify-center pt-4 pb-4">
                            <button 
                                onClick={handleLoadMoreFeed} 
                                className="bg-surface hover:bg-surface text-primary border border-blue-500/30 px-6 py-2.5 rounded-full text-sm font-bold shadow-lg transition-all flex items-center gap-2"
                            >
                                <i className="fas fa-chevron-down"></i> โหลดโพสต์เพิ่มเติม
                            </button>
                        </div>
                    )}

                    {combinedFeed.length === 0 && (
                        <div className="text-center py-10 bg-surface/50 rounded-2xl border border-glass border-dashed text-text">
                            <i className="far fa-newspaper text-4xl mb-3 opacity-30"></i>
                            <p className="text-sm font-bold">ยังไม่มีการอัปเดตไทม์ไลน์ในโปรเจกต์นี้</p>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};

export default ProjectSpacePage;