import React, { useState, useEffect, useMemo } from 'react';
import { collection, query, onSnapshot, addDoc, updateDoc, doc, deleteDoc, serverTimestamp } from 'firebase/firestore';
import { db } from '../firebase';
import { useAuth } from '../hooks/useAuth';
import { useNavigate } from 'react-router-dom';
import { logActivity } from '../utils/activityLogger';

const toLocalYYYYMMDD = (date) => {
    const d = new Date(date);
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
};

// ฟังก์ชันเช็คว่า Timestamp/Date นี้คือ "วันนี้" หรือไม่
const isToday = (ts) => {
    if (!ts) return false;
    const d = ts.toDate ? ts.toDate() : new Date(ts);
    if (isNaN(d)) return false;
    const today = new Date();
    return d.getDate() === today.getDate() && d.getMonth() === today.getMonth() && d.getFullYear() === today.getFullYear();
};

const MyPlannerPage = () => {
    const { userData, user } = useAuth();
    const navigate = useNavigate();

    // States
    const [viewMode, setViewMode] = useState('personal'); 
    const [currentMonth, setCurrentMonth] = useState(new Date());
    const [workloadDate, setWorkloadDate] = useState(toLocalYYYYMMDD(new Date()));
    
    const [allTasks, setAllTasks] = useState([]);
    const [allJobs, setAllJobs] = useState([]);
    const [allProjects, setAllProjects] = useState([]);
    const [allPartOrders, setAllPartOrders] = useState([]); 
    const [allUsers, setAllUsers] = useState([]);
    const [loading, setLoading] = useState(true);

    const [showTaskModal, setShowTaskModal] = useState(false);
    const [viewTaskModal, setViewTaskModal] = useState({ isOpen: false, task: null });
    
    const [isEditing, setIsEditing] = useState(false);
    const [editTaskObj, setEditTaskObj] = useState(null);
    const [taskForm, setTaskForm] = useState({ title: '', type: 'Task', time: '09:00', details: '', date: toLocalYYYYMMDD(new Date()), taggedUsers: [] });
    const [isSubmitting, setIsSubmitting] = useState(false);

    // ==========================================
    // 🛡️ ROLE-BASED ACCESS CONTROL (RBAC) 🛡️
    // ==========================================
    const isAdmin = userData?.role === 'Admin';
    const isTD = userData?.dept === 'TD' || isAdmin;
    const isEngineer = userData?.dept === 'Engineer';
    const isTDManager = isTD && (['Manager', 'Department manager', 'Supervisor'].includes(userData?.jobTitle) || isAdmin);

    // 1. สิทธิ์การเข้าถึงหน้า (Page Access): เฉพาะ TD ทุกคน และ Admin
    const canAccessMenu = isTD || isAdmin;
    // ==========================================

    useEffect(() => {
        if (!userData || !user) return;

        const unsubUsers = onSnapshot(collection(db, 'users'), (snapshot) => {
            // บังคับใส่ uid เสมอ เพื่อป้องกันปัญหา key เป็น undefined
            setAllUsers(snapshot.docs.map(doc => ({ uid: doc.id, ...doc.data() })));
        });

        const unsubTasks = onSnapshot(collection(db, 'td_personal_tasks'), (snapshot) => {
            setAllTasks(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
        });

        const unsubJobs = onSnapshot(collection(db, 'td_job_requests'), (snapshot) => {
            setAllJobs(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
        });

        const unsubProjects = onSnapshot(collection(db, 'td_projects'), (snapshot) => {
            setAllProjects(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
        });

        // ดึงข้อมูล Part Orders
        const unsubParts = onSnapshot(collection(db, 'part_orders'), (snapshot) => {
            setAllPartOrders(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
            setLoading(false);
        });

        return () => { unsubTasks(); unsubJobs(); unsubProjects(); unsubUsers(); unsubParts(); };
    }, [userData, user]);

    const personalTasks = useMemo(() => allTasks.filter(t => {
        if (t.userId === user?.uid) return true; 
        if (t.invitedUsers?.includes(user?.uid) && t.inviteStatus?.[user?.uid] !== 'declined') return true; 
        return false;
    }), [allTasks, user?.uid]);
    
    const overdueTasks = useMemo(() => {
        const todayTime = new Date().setHours(0,0,0,0);
        return personalTasks.filter(t => {
            const isPending = t.invitedUsers?.includes(user?.uid) && t.userId !== user?.uid && t.inviteStatus?.[user?.uid] === 'pending';
            return !t.isCompleted && new Date(t.date).setHours(0,0,0,0) < todayTime && !isPending;
        });
    }, [personalTasks, user?.uid]);

    // สร้าง Smart To-Do List (รวมอะไหล่และจำการ Action ในวันนี้)
    const smartTodos = useMemo(() => {
        const pending = [];
        const completedToday = [];
        const todayTime = new Date().setHours(0,0,0,0);

        // 1. Personal Tasks
        personalTasks.forEach(t => {
            const taskTime = new Date(t.date).setHours(0,0,0,0);
            const isInvited = t.invitedUsers?.includes(user?.uid) && t.userId !== user?.uid;
            const isPendingInvite = isInvited && t.inviteStatus?.[user?.uid] === 'pending';

            if (t.isCompleted) {
                // โชว์งานที่ทำเสร็จ "วันนี้" (อิงจากวันที่กดเสร็จ หรือ วันที่ถูกกำหนดไว้)
                const updatedToday = isToday(t.updatedAt);
                if (taskTime === todayTime || updatedToday) {
                    completedToday.push({ id: `task_${t.id}`, text: t.title, icon: 'fa-check', isTask: true, taskObj: t, isDone: true, isPendingInvite: false });
                }
            } else {
                const isOverdue = taskTime < todayTime && !isPendingInvite;
                if (taskTime <= todayTime || isPendingInvite) {
                    pending.push({ 
                        id: `task_${t.id}`, 
                        text: `${t.title} ${isOverdue ? '(เกินกำหนด)' : ''}`, 
                        icon: isPendingInvite ? 'fa-envelope-open-text' : 'fa-thumbtack', 
                        color: isPendingInvite ? 'text-pink-400' : (isOverdue ? 'text-red-400' : 'text-orange-400'), 
                        bg: isPendingInvite ? 'bg-pink-500/20' : (isOverdue ? 'bg-red-500/20' : 'bg-orange-500/20'), 
                        border: isPendingInvite ? 'border-pink-500' : (isOverdue ? 'border-red-500' : 'border-orange-500'),
                        isTask: true, 
                        taskObj: t, 
                        isDone: false,
                        isOverdue,
                        isPendingInvite
                    });
                }
            }
        });

        // 2. Part Orders (สำหรับแผนก TD เท่านั้น รวบเป็น 1 บล็อค)
        if (isTD) {
            let pendingPartsCount = 0;
            let receivedTodayCount = 0;

            allPartOrders.forEach(p => {
                if (p.status === 'Received') {
                    if (isToday(p.updated_at)) receivedTodayCount++;
                } else if (p.status !== 'Cancelled') {
                    pendingPartsCount++;
                }
            });

            if (receivedTodayCount > 0) {
                completedToday.push({ id: 'part_received_summary', text: `รับอะไหล่เรียบร้อยแล้ววันนี้ (${receivedTodayCount} รายการ)`, icon: 'fa-box', isTask: false, isDone: true, link: '/part-orders' });
            }

            if (pendingPartsCount > 0) {
                pending.push({ id: 'part_pending_summary', text: `มีรายการรอรับอะไหล่เข้าคลัง (${pendingPartsCount} รายการ)`, icon: 'fa-box', color: 'text-primary', bg: 'bg-blue-500/20', border: 'border-blue-500', isTask: false, isDone: false, link: '/part-orders' });
            }
        }

        // 3. Jobs (Approve / Receive) สำหรับหัวหน้า
        if (isTDManager) {
            allJobs.forEach(j => {
                if (j.status === 'Issued') {
                    pending.push({ id: `approve_${j.id}`, text: `Approve Job Req. No. ${j.projectNo}`, icon: 'fa-check-circle', color: 'text-yellow-400', bg: 'bg-yellow-500/20', border: 'border-yellow-500', link: '/job-request', isDone: false });
                } else {
                    const approvedToday = j.timeline?.find(x => x.status === 'Approved' && isToday(x.timestamp) && x.by === userData?.name);
                    if (approvedToday) {
                        completedToday.push({ id: `approve_${j.id}_done`, text: `Approve Job Req. No. ${j.projectNo}`, icon: 'fa-check-circle', isTask: false, isDone: true, link: '/job-request' });
                    }
                }

                if (j.status === 'Approved') {
                    pending.push({ id: `receive_${j.id}`, text: `รับงาน & มอบหมาย Job No. ${j.projectNo}`, icon: 'fa-hand-holding', color: 'text-cyan-400', bg: 'bg-cyan-500/20', border: 'border-cyan-500', link: '/td-workspace', isDone: false });
                } else {
                    const receivedToday = j.timeline?.find(x => x.status === 'In Progress' && isToday(x.timestamp) && x.by === userData?.name);
                    if (receivedToday) {
                        completedToday.push({ id: `receive_${j.id}_done`, text: `รับงาน & มอบหมาย Job No. ${j.projectNo}`, icon: 'fa-hand-holding', isTask: false, isDone: true, link: '/td-workspace' });
                    }
                }
            });
        }

        // 4. Jobs -> Projects & Active Projects
        if (isTD) {
            allJobs.forEach(j => {
                if (['In Progress', 'Received'].includes(j.status) && j.assignTo === userData?.name && !j.projectId) {
                    pending.push({ id: `create_proj_${j.id}`, text: `สร้างโปรเจกต์จาก Job No. ${j.projectNo}`, icon: 'fa-rocket', color: 'text-orange-400', bg: 'bg-orange-500/20', border: 'border-orange-500', link: '/td-workspace', isDone: false });
                }
            });

            allProjects.forEach(p => {
                const isMyProject = p.owner === userData?.name || p.coWorkers?.includes(userData?.name);
                if (isMyProject) {
                    if (['Completed', 'Accepted'].includes(p.status)) {
                        if (isToday(p.completedAt)) {
                            completedToday.push({ id: `exec_proj_${p.id}_done`, text: `ปิดโปรเจกต์: ${p.projectName}`, icon: 'fa-cogs', isTask: false, isDone: true, link: `/project/${p.id}` });
                        }
                    } else {
                        pending.push({ id: `exec_proj_${p.id}`, text: `ดำเนินการโปรเจกต์: ${p.projectName}`, icon: 'fa-cogs', color: 'text-purple-400', bg: 'bg-purple-500/20', border: 'border-purple-500', link: `/project/${p.id}`, isDone: false });
                    }
                }
            });
        }

        // ลบรายการซ้ำซ้อน
        const uniqueCompleted = Array.from(new Map(completedToday.map(item => [item.id, item])).values());

        // จัดเรียง Pending: คำเชิญขึ้นก่อน -> งานค้าง -> งานวันนี้
        pending.sort((a, b) => {
            if (a.isPendingInvite && !b.isPendingInvite) return -1;
            if (!a.isPendingInvite && b.isPendingInvite) return 1;
            if (a.isOverdue && !b.isOverdue) return -1;
            if (!a.isOverdue && b.isOverdue) return 1;
            return 0;
        });

        return [...pending, ...uniqueCompleted];
    }, [allTasks, allJobs, allProjects, allPartOrders, userData, isTD, isTDManager, isEngineer, user?.uid]);

    const calendarDays = useMemo(() => {
        const year = currentMonth.getFullYear();
        const month = currentMonth.getMonth();
        const firstDayOfMonth = new Date(year, month, 1);
        const lastDayOfMonth = new Date(year, month + 1, 0);
        const days = [];
        for (let i = 0; i < firstDayOfMonth.getDay(); i++) { days.push(null); }
        for (let i = 1; i <= lastDayOfMonth.getDate(); i++) { days.push(new Date(year, month, i)); }
        return days;
    }, [currentMonth]);

    const changeMonth = (offset) => {
        const newMonth = new Date(currentMonth);
        newMonth.setMonth(currentMonth.getMonth() + offset);
        setCurrentMonth(newMonth);
    };

    const openTaskModalForDate = (date) => {
        setTaskForm({ title: '', type: 'Task', time: '09:00', details: '', date: toLocalYYYYMMDD(date), taggedUsers: [] });
        setIsEditing(false);
        setEditTaskObj(null);
        setShowTaskModal(true);
    };

    const openEditModal = (task) => {
        setTaskForm({ 
            title: task.title, type: task.type, time: task.time, 
            details: task.details || '', date: task.date, 
            taggedUsers: task.invitedUsers || [] 
        });
        setIsEditing(true);
        setEditTaskObj(task);
        setViewTaskModal({ isOpen: false, task: null });
        setShowTaskModal(true);
    };

    const handleSaveTask = async (e) => {
        e.preventDefault();
        if (!taskForm.title.trim()) return;
        setIsSubmitting(true);
        try {
            const currentInviteStatus = isEditing && editTaskObj?.inviteStatus ? editTaskObj.inviteStatus : {};
            const newInviteStatus = {};
            taskForm.taggedUsers.forEach(uid => {
                newInviteStatus[uid] = currentInviteStatus[uid] || 'pending'; 
            });

            const payload = {
                title: taskForm.title, 
                type: taskForm.type, 
                time: taskForm.time, 
                date: taskForm.date,
                details: taskForm.details, 
                invitedUsers: taskForm.taggedUsers,
                inviteStatus: newInviteStatus
            };

            if (isEditing) {
                await updateDoc(doc(db, 'td_personal_tasks', editTaskObj.id), payload);
                await logActivity(user, 'Updated Appointment', `แก้ไขนัดหมาย: ${taskForm.title}`);
            } else {
                payload.userId = user.uid;
                payload.userName = userData.name;
                payload.isCompleted = false;
                payload.createdAt = serverTimestamp();
                await addDoc(collection(db, 'td_personal_tasks'), payload);
                await logActivity(user, 'Added Appointment', `สร้างนัดหมาย: ${taskForm.title}`);
            }
            setShowTaskModal(false);
        } catch (error) { alert(`เกิดข้อผิดพลาด: ${error.message}`); } 
        finally { setIsSubmitting(false); }
    };

    // เลือกลบหรือเพิ่ม Tag ได้หลายคน
    const toggleTagUser = (uid) => {
        setTaskForm(prev => {
            const isTagged = prev.taggedUsers.includes(uid);
            return {
                ...prev,
                taggedUsers: isTagged 
                    ? prev.taggedUsers.filter(id => id !== uid) 
                    : [...prev.taggedUsers, uid] 
            };
        });
    };

    // 🌟 2. ฟังก์ชันติ๊กทำงานเสร็จ (เฉพาะเจ้าของงานหรือคนที่ได้รับ Assign) 🌟
    const handleToggleTaskComplete = async (e, task) => {
        e.stopPropagation(); 
        
        const isOwner = task.userId === user?.uid;
        const isAssignee = task.invitedUsers?.includes(user?.uid) && task.inviteStatus?.[user?.uid] === 'accepted';
        
        if (!isOwner && !isAssignee) {
            alert('คุณไม่มีสิทธิ์อัปเดตสถานะงานนี้ (อนุญาตเฉพาะเจ้าของงานหรือผู้ที่ตอบรับการมอบหมายแล้วเท่านั้น)');
            return;
        }

        try { 
            await updateDoc(doc(db, 'td_personal_tasks', task.id), { 
                isCompleted: !task.isCompleted,
                updatedAt: serverTimestamp() 
            }); 
        } 
        catch (error) { console.error("Error updating task:", error); }
    };

    const handleAcceptInvite = async (e, taskId) => {
        e.stopPropagation();
        try { await updateDoc(doc(db, 'td_personal_tasks', taskId), { [`inviteStatus.${user.uid}`]: 'accepted' }); } 
        catch (error) { console.error(error); }
    };

    const handleDeclineInvite = async (e, taskId) => {
        e.stopPropagation();
        try { await updateDoc(doc(db, 'td_personal_tasks', taskId), { [`inviteStatus.${user.uid}`]: 'declined' }); } 
        catch (error) { console.error(error); }
    };

    const deleteTask = async (e, id, title) => {
        e.stopPropagation();
        if (!window.confirm('ต้องการลบนัดหมายนี้ใช่หรือไม่?')) return;
        try {
            await deleteDoc(doc(db, 'td_personal_tasks', id));
            await logActivity(user, 'Deleted Appointment', `ลบนัดหมาย: ${title}`);
            setViewTaskModal({ isOpen: false, task: null });
        } catch (error) { alert(`เกิดข้อผิดพลาด: ${error.message}`); }
    };

    const getTaskIcon = (type) => {
        if (type === 'Meeting') return 'fa-handshake text-primary';
        if (type === 'Test') return 'fa-vial text-purple-500';
        return 'fa-thumbtack text-orange-400';
    };

    // ดักบล็อคสิทธิ์ ถ้าไม่ใช่คนในแผนก TD หรือ Admin จะเข้าหน้านี้ไม่ได้
    if (!canAccessMenu) {
        return (
            <div className="flex h-full items-center justify-center text-xl text-red-500 font-bold">
                <i className="fas fa-lock mr-2"></i> คุณไม่มีสิทธิ์เข้าถึงหน้านี้
            </div>
        );
    }

    if (loading) return <div className="flex justify-center items-center h-full"><div className="animate-spin rounded-full h-12 w-12 border-t-2 border-indigo-500"></div></div>;

    const tdTeamMembers = allUsers.filter(u => u.dept === 'TD' && u.role !== 'pending');

    return (
        <div className="h-full flex flex-col pb-6 relative">
            
            {/* Header & Toggle Mode */}
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6 border-b border-glass pb-4 gap-4 shrink-0">
                <div>
                    <h1 className="text-lg md:text-2xl font-black text-transparent bg-clip-text bg-gradient-to-r from-indigo-400 to-purple-500 tracking-wide">
                        <i className={`fas ${viewMode === 'personal' ? 'fa-calendar-check' : 'fa-users'} text-indigo-500 mr-2`}></i> 
                        {viewMode === 'personal' ? 'TD Planner & To-Do' : 'Team Daily Workload'}
                    </h1>
                    <p className="text-xs text-text mt-1 font-bold">
                        {viewMode === 'personal' ? 'ศูนย์รวมงานที่ต้องทำ และปฏิทินนัดหมายส่วนตัว' : 'กระดานตรวจสอบปริมาณงานของคนในทีม TD รายบุคคล'}
                    </p>
                </div>
                
                {/* 3. ดู Team Workload (เห็นได้ทุกคนที่เข้าหน้านี้) */}
                <div className="flex items-center bg-surface rounded-lg p-1.5 shadow-inner border border-glass shrink-0">
                    <button onClick={() => setViewMode('personal')} className={`px-4 py-1.5 rounded-md text-xs font-bold transition-all ${viewMode === 'personal' ? 'bg-indigo-600 text-text shadow-md' : 'text-text hover:text-text hover:bg-surface'}`}>
                        <i className="fas fa-user mr-1.5"></i> My Planner
                    </button>
                    <button onClick={() => setViewMode('team')} className={`px-4 py-1.5 rounded-md text-xs font-bold transition-all ${viewMode === 'team' ? 'bg-purple-600 text-text shadow-md' : 'text-text hover:text-text hover:bg-surface'}`}>
                        <i className="fas fa-users mr-1.5"></i> Team Workload
                    </button>
                </div>
            </div>

            {viewMode === 'personal' ? (
                // 🌟 โหมดส่วนตัว (Personal Planner) 🌟
                <div className="flex-1 flex flex-col xl:flex-row gap-6 overflow-hidden">
                    <div className="w-full xl:w-1/3 bg-surface/50 rounded-2xl border border-glass p-5 flex flex-col h-[450px] xl:h-full shadow-inner relative overflow-hidden">
                        <div className="flex justify-between items-center border-b border-glass pb-3 mb-4 shrink-0">
                            <h2 className="text-lg font-bold text-text"><i className="fas fa-clipboard-list text-purple-400 mr-2"></i> My Action Items & To do list</h2>
                            <span className="text-[10px] bg-purple-900/50 text-text px-2 py-1 rounded-full border border-purple-500/30 font-bold">{smartTodos.filter(t => !t.isDone).length} Pending</span>
                        </div>

                        {overdueTasks.length > 0 && (
                            <div className="bg-red-900/40 border border-red-500/50 rounded-lg p-3 mb-4 shrink-0 flex items-start gap-3 shadow-lg animate-pulse">
                                <i className="fas fa-exclamation-triangle text-red-500 mt-0.5 text-lg"></i>
                                <div>
                                    <p className="text-xs font-bold text-red-400 leading-tight">แจ้งเตือนงานค้าง!</p>
                                    <p className="text-[10px] text-red-200 mt-1">มีนัดหมาย/แผนงานที่ผ่านมาแล้ว แต่ยังไม่ได้ติ๊กทำเครื่องหมายว่าเสร็จสิ้น จำนวน {overdueTasks.length} รายการ กรุณาเคลียร์งานให้เป็นปัจจุบัน</p>
                                </div>
                            </div>
                        )}

                        <div className="flex-1 overflow-y-auto custom-scrollbar pr-2 relative">
                            {smartTodos.length === 0 ? (
                                <div className="h-full flex flex-col items-center justify-center text-text opacity-60">
                                    <i className="fas fa-glass-cheers text-5xl mb-3 text-green-500/50"></i>
                                    <p className="font-bold text-text">ยอดเยี่ยม! เคลียร์งานหมดแล้ว</p>
                                </div>
                            ) : (
                                <div className="relative border-l-2 border-glass ml-3 space-y-4 pt-2 pb-2">
                                    {smartTodos.map((todo, index) => {
                                        // เช็คสิทธิ์ปุ่มขีดฆ่าก่อน render
                                        let canCheckOff = false;
                                        if (todo.isTask) {
                                            const isOwner = todo.taskObj.userId === user?.uid;
                                            const isAssignee = todo.taskObj.invitedUsers?.includes(user?.uid) && todo.taskObj.inviteStatus?.[user?.uid] === 'accepted';
                                            canCheckOff = isOwner || isAssignee;
                                        }

                                        return (
                                        <div 
                                            key={`${todo.id}_${index}`} 
                                            className="relative pl-6 animate-fade-in group cursor-pointer" 
                                            onClick={() => {
                                                if (todo.isTask) setViewTaskModal({ isOpen: true, task: todo.taskObj });
                                                else if (todo.link) navigate(todo.link);
                                            }}
                                        >
                                            <span className={`absolute -left-[11px] top-1.5 w-5 h-5 rounded-full border-2 flex items-center justify-center shadow-inner z-10 transition-transform ${todo.isDone ? 'bg-surface border-green-500' : `bg-surface ${todo.border} group-hover:scale-110`}`}>
                                                <i className={`fas ${todo.isDone ? 'fa-check text-[10px] text-green-500' : `${todo.icon} text-[9px] ${todo.color}`}`}></i>
                                            </span>
                                            
                                            <div className={`p-3.5 rounded-xl border shadow-sm transition-all relative overflow-hidden flex flex-col gap-2 ${todo.isDone ? 'bg-surface/30 border-glass/50 opacity-60 grayscale' : `bg-surface/60 border-glass group-hover:border-purple-500 ${todo.bg} hover:bg-surface`} ${todo.isOverdue ? 'border-red-500/50 bg-red-900/10' : ''}`}>
                                                
                                                <div className="flex items-start gap-3 w-full">
                                                    {todo.isTask && !todo.isPendingInvite && canCheckOff && (
                                                        <div 
                                                            onClick={(e) => handleToggleTaskComplete(e, todo.taskObj)}
                                                            className={`w-4 h-4 rounded border shrink-0 flex items-center justify-center transition-colors cursor-pointer mt-0.5 ${todo.isDone ? 'bg-green-500/20 border-green-500' : 'border-glass hover:border-green-400 hover:bg-green-400/20'}`}
                                                            title={todo.isDone ? 'ยกเลิกการขีดฆ่า' : 'คลิกเพื่อขีดฆ่าเสร็จสิ้น'}
                                                        >
                                                            {todo.isDone && <i className="fas fa-check text-[8px] text-green-500"></i>}
                                                        </div>
                                                    )}
                                                    
                                                    <div className="flex-1 min-w-0">
                                                        <p className={`text-xs font-medium leading-relaxed truncate pr-2 ${todo.isDone ? 'text-text line-through' : 'text-text'} ${todo.isOverdue ? 'text-red-300 font-bold' : ''} ${todo.isPendingInvite ? 'text-pink-300 font-bold' : ''}`} title={todo.text}>
                                                            {todo.text}
                                                        </p>
                                                        {todo.isPendingInvite ? (
                                                            <p className="text-[9px] text-pink-400 mt-0.5 border-l-2 border-pink-500 pl-1.5 py-0.5 bg-pink-900/20 rounded-r">
                                                                <i className="fas fa-user-tag mr-1"></i> เชิญโดย: {todo.taskObj.userName}
                                                            </p>
                                                        ) : (
                                                            <>
                                                                {todo.isTask && !todo.isDone && <p className="text-[9px] text-text mt-0.5"><i className="far fa-hand-pointer mr-1"></i>ติ๊กกล่องซ้ายเพื่อขีดฆ่า หรือคลิกตรงนี้เพื่อดูรายละเอียด</p>}
                                                                {!todo.isTask && !todo.isDone && <p className="text-[9px] text-primary mt-0.5"><i className="fas fa-external-link-alt mr-1"></i>คลิกเพื่อไปทำรายการที่หน้างาน</p>}
                                                            </>
                                                        )}
                                                    </div>

                                                    {!todo.isDone && !todo.isTask && <i className="fas fa-arrow-right text-primary group-hover:translate-x-1 transition-transform shrink-0 mt-0.5"></i>}
                                                </div>

                                                {/* 🌟 ปุ่มตอบรับคำเชิญ 🌟 */}
                                                {todo.isPendingInvite && (
                                                    <div className="flex gap-2 mt-1.5 pt-2 border-t border-pink-500/30">
                                                        <button onClick={(e) => handleAcceptInvite(e, todo.taskObj.id)} className="flex-1 bg-green-600 hover:bg-green-500 text-text py-1.5 rounded text-[10px] font-bold shadow transition"><i className="fas fa-check mr-1"></i> รับคำเชิญ</button>
                                                        <button onClick={(e) => handleDeclineInvite(e, todo.taskObj.id)} className="flex-1 bg-red-600 hover:bg-red-500 text-text py-1.5 rounded text-[10px] font-bold shadow transition"><i className="fas fa-times mr-1"></i> ปฏิเสธ</button>
                                                    </div>
                                                )}
                                            </div>
                                        </div>
                                    )})}
                                </div>
                            )}
                        </div>
                    </div>

                    {/* Full-Month Calendar */}
                    <div className="w-full xl:w-2/3 bg-surface rounded-2xl border border-glass shadow-xl flex flex-col h-[700px] xl:h-full overflow-hidden">
                        <div className="p-4 border-b border-glass bg-surface/50 flex flex-col sm:flex-row justify-between items-center shrink-0 gap-3">
                            <div className="flex flex-wrap justify-center gap-3 text-[10px] font-bold bg-surface px-3 py-1.5 rounded-lg border border-glass w-full xl:w-auto">
                                {isTD ? (
                                    <span className="text-purple-400 flex items-center"><span className="w-2 h-2 rounded-full bg-purple-500 mr-1.5"></span> Project</span>
                                ) : (
                                    <span className="text-primary flex items-center"><span className="w-2 h-2 rounded-full bg-blue-500 mr-1.5"></span> Job Req.</span>
                                )}
                                <span className="text-orange-400 flex items-center"><span className="w-2 h-2 rounded-full bg-orange-500 mr-1.5"></span> Appt.</span>
                            </div>

                            <div className="flex items-center gap-2 sm:gap-3 w-full xl:w-auto justify-center">
                                <button onClick={() => changeMonth(-1)} className="w-8 h-8 rounded-full bg-surface hover:bg-surface text-text flex items-center justify-center transition shrink-0"><i className="fas fa-chevron-left text-xs"></i></button>
                                <div className="relative flex items-center justify-center cursor-pointer group shrink-0">
                                    <h2 className="text-base sm:text-lg font-bold text-text uppercase tracking-wider w-28 sm:w-36 text-center group-hover:text-indigo-400 transition-colors">
                                        {currentMonth.toLocaleDateString('en-GB', { month: 'short', year: 'numeric' })}
                                        <i className="fas fa-caret-down text-[10px] ml-1.5 opacity-50"></i>
                                    </h2>
                                    <input type="month" value={`${currentMonth.getFullYear()}-${String(currentMonth.getMonth() + 1).padStart(2, '0')}`} onChange={(e) => { if (e.target.value) { const [year, month] = e.target.value.split('-'); setCurrentMonth(new Date(year, month - 1, 1)); } }} className="absolute inset-0 w-full h-full opacity-0 cursor-pointer" />
                                </div>
                                <button onClick={() => changeMonth(1)} className="w-8 h-8 rounded-full bg-surface hover:bg-surface text-text flex items-center justify-center transition shrink-0"><i className="fas fa-chevron-right text-xs"></i></button>
                                <button onClick={() => setCurrentMonth(new Date())} className="bg-surface border border-glass hover:bg-indigo-600 hover:text-text hover:border-indigo-500 text-xs font-bold text-text px-3 py-1.5 rounded-lg transition shadow shrink-0">Today</button>
                            </div>

                            {/* 4. การสร้างนัดหมาย / เพิ่มงาน (เห็นได้ทุกคนที่เข้าหน้านี้) */}
                            <button onClick={() => openTaskModalForDate(new Date())} className="bg-indigo-600 hover:bg-indigo-500 text-text px-3 py-2 rounded-lg text-xs font-bold shadow transition flex items-center shrink-0 w-full xl:w-auto justify-center mt-2 xl:mt-0">
                                <i className="fas fa-plus sm:mr-2"></i> <span className="hidden sm:inline">Add</span>
                            </button>
                        </div>

                        <div className="flex-1 flex flex-col overflow-hidden p-2">
                            <div className="grid grid-cols-7 gap-1 mb-1 shrink-0">
                                {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map(day => (
                                    <div key={day} className="text-center text-[10px] font-bold text-text uppercase bg-surface/50 py-1.5 rounded">{day}</div>
                                ))}
                            </div>

                            <div className="grid grid-cols-7 gap-1 flex-1 overflow-y-auto custom-scrollbar pr-1 pb-1">
                                {calendarDays.map((date, i) => {
                                    if (!date) return <div key={`empty-${i}`} className="bg-surface/30 rounded-lg min-h-[100px]"></div>;

                                    const dateStrLocal = toLocalYYYYMMDD(date);
                                    const currentCellTime = date.setHours(0,0,0,0);
                                    const todayTime = new Date().setHours(0,0,0,0);
                                    const isTodayCell = currentCellTime === todayTime;
                                    
                                    const dayTasks = personalTasks.filter(t => t.date === dateStrLocal).sort((a,b) => a.time.localeCompare(b.time));
                                    
                                    const dayJobs = !isTD ? allJobs.filter(j => {
                                        if (j.requestBy !== userData?.name) return false;
                                        if (!j.dueDate) return false;
                                        const jobDue = new Date(j.dueDate).setHours(0,0,0,0);
                                        return currentCellTime === jobDue || (currentCellTime > jobDue && currentCellTime <= todayTime && !['Completed', 'Accepted', 'Cancelled', 'Reject'].includes(j.status));
                                    }) : [];

                                    const dayProjects = isTD ? allProjects.filter(p => {
                                        if (p.status === 'Completed' || p.status === 'Accepted') return false;
                                        if (!p.projectPlanStart || !p.projectPlanEnd) return false;
                                        if (p.owner !== userData?.name && !p.coWorkers?.includes(userData?.name)) return false;
                                        const s = new Date(p.projectPlanStart).setHours(0,0,0,0);
                                        const e = new Date(p.projectPlanEnd).setHours(23,59,59,999);
                                        return currentCellTime >= s && currentCellTime <= e;
                                    }) : [];

                                    return (
                                        <div 
                                            key={`date-${i}`} 
                                            onClick={() => openTaskModalForDate(date)}
                                            className={`bg-surface border ${isTodayCell ? 'border-indigo-500 shadow-[inset_0_0_15px_rgba(99,102,241,0.2)]' : 'border-glass/50'} rounded-lg min-h-[120px] p-1 flex flex-col hover:border-glass cursor-pointer transition-colors overflow-hidden group`}
                                        >
                                            <div className="flex justify-between items-start mb-1 shrink-0">
                                                <span className={`text-[11px] font-bold w-6 h-6 flex items-center justify-center rounded-full ${isTodayCell ? 'bg-indigo-600 text-text' : 'text-text group-hover:text-text'}`}>
                                                    {date.getDate()}
                                                </span>
                                            </div>

                                            <div className="flex-1 overflow-y-auto no-scrollbar space-y-1">
                                                {dayJobs.map(j => {
                                                    const isOverdue = currentCellTime > new Date(j.dueDate).setHours(0,0,0,0);
                                                    return (
                                                        <div key={`j-${j.id}`} onClick={(e) => { e.stopPropagation(); navigate('/job-request'); }} className={`border-l-2 pl-1.5 py-1 hover:bg-surface rounded-r transition cursor-pointer ${isOverdue ? 'border-red-500 bg-red-900/10' : 'border-blue-500 bg-blue-900/10'}`}>
                                                            <div className={`text-[9px] font-bold truncate leading-tight ${isOverdue ? 'text-red-300' : 'text-primary'}`} title={j.projectNo}>- {j.projectNo}</div>
                                                        </div>
                                                    )
                                                })}
                                                {dayProjects.map(p => (
                                                    <div key={`p-${p.id}`} onClick={(e) => { e.stopPropagation(); navigate(`/project/${p.id}`); }} className="border-l-2 border-purple-500 bg-purple-900/10 pl-1.5 py-1 hover:bg-surface rounded-r transition cursor-pointer">
                                                        <div className="text-[9px] font-bold text-purple-600 truncate leading-tight" title={p.projectName}>- {p.projectName}</div>
                                                    </div>
                                                ))}
                                                {dayTasks.map(t => {
                                                    const isPending = t.invitedUsers?.includes(user?.uid) && t.userId !== user?.uid && t.inviteStatus?.[user?.uid] === 'pending';
                                                    return (
                                                        <div key={`t-${t.id}`} onClick={(e) => { e.stopPropagation(); setViewTaskModal({ isOpen: true, task: t }); }} className={`border-l-2 pl-1.5 py-1 hover:bg-surface rounded-r transition cursor-pointer flex items-center justify-between ${t.isCompleted ? 'border-glass bg-surface/30 opacity-50 line-through' : (isPending ? 'border-pink-500 bg-pink-900/10 animate-pulse' : 'border-orange-400 bg-orange-900/10')}`}>
                                                            <div className={`text-[9px] font-bold truncate leading-tight ${t.isCompleted ? 'text-text' : (isPending ? 'text-pink-300' : 'text-orange-300')}`} title={t.title}>- {t.title}</div>
                                                            {isPending && <i className="fas fa-exclamation-circle text-pink-500 text-[8px] mr-1"></i>}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        </div>
                                    );
                                })}
                            </div>
                        </div>
                    </div>
                </div>
            ) : (
                // 🌟 โหมด Team Daily Workload Dashboard 🌟
                <div className="flex-1 bg-surface/50 rounded-2xl border border-glass shadow-xl p-5 flex flex-col overflow-hidden animate-fade-in">
                    <div className="flex justify-between items-center mb-6 border-b border-glass pb-4 shrink-0">
                        <h2 className="text-xl font-bold text-text flex items-center">
                            <i className="fas fa-chart-bar text-purple-400 mr-3"></i> สรุปปริมาณงานรายวัน (TD Department)
                        </h2>
                        <div className="flex items-center gap-3 bg-surface p-1.5 rounded-lg border border-glass">
                            <span className="text-[10px] text-text font-bold uppercase pl-2">เลือกวันที่ตรวจสอบ:</span>
                            <input 
                                type="date" 
                                value={workloadDate} 
                                onChange={(e) => setWorkloadDate(e.target.value)} 
                                className="bg-surface border border-glass text-text text-xs p-1.5 rounded outline-none focus:border-purple-500 cursor-pointer"
                            />
                        </div>
                    </div>

                    <div className="flex-1 overflow-y-auto custom-scrollbar pr-2 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5 content-start">
                        {tdTeamMembers.map(member => {
                            const wlTime = new Date(workloadDate).setHours(0,0,0,0);
                            
                            // หางานของ Member คนนี้ในวันที่เลือก (รวมงานตัวเอง และงานที่โดน Tag แล้วตอบรับ)
                            const mTasks = allTasks.filter(t => {
                                const isOwner = t.userId === member.uid;
                                const isTaggedAndAccepted = t.invitedUsers?.includes(member.uid) && t.inviteStatus?.[member.uid] === 'accepted';
                                return (isOwner || isTaggedAndAccepted) && new Date(t.date).setHours(0,0,0,0) === wlTime;
                            });

                            const mProjects = allProjects.filter(p => {
                                if (p.status === 'Completed' || p.status === 'Accepted') return false;
                                if (p.owner !== member.name && !p.coWorkers?.includes(member.name)) return false;
                                if (!p.projectPlanStart || !p.projectPlanEnd) return false;
                                const s = new Date(p.projectPlanStart).setHours(0,0,0,0);
                                const e = new Date(p.projectPlanEnd).setHours(23,59,59,999);
                                return wlTime >= s && wlTime <= e;
                            });
                            
                            const completedTasksCount = mTasks.filter(t => t.isCompleted).length;
                            const totalTasksCount = mTasks.length;
                            const progressPercent = totalTasksCount === 0 ? 0 : Math.round((completedTasksCount / totalTasksCount) * 100);

                            return (
                                <div key={member.uid} className="bg-surface/80 border border-glass rounded-xl overflow-hidden hover:border-purple-500/50 transition-colors flex flex-col h-72">
                                    <div className="p-3 border-b border-glass flex items-center justify-between bg-surface/30 shrink-0">
                                        <div className="flex items-center gap-3">
                                            <div className="w-10 h-10 rounded-full bg-gradient-to-tr from-indigo-500 to-purple-600 flex items-center justify-center text-text font-bold shadow-inner">
                                                {member.name.substring(0, 2).toUpperCase()}
                                            </div>
                                            <div>
                                                <h3 className="text-sm font-bold text-text leading-tight">{member.name}</h3>
                                                <span className="text-[10px] text-text">{member.jobTitle || 'TD Member'}</span>
                                            </div>
                                        </div>
                                        <div className="text-center">
                                            <span className="block text-[10px] text-text font-bold uppercase mb-0.5">Task Success</span>
                                            <span className={`text-xs font-black px-2 py-0.5 rounded ${progressPercent === 100 ? 'bg-green-500/20 text-green-400' : 'bg-surface text-purple-400'}`}>{progressPercent}%</span>
                                        </div>
                                    </div>
                                    
                                    <div className="p-3 flex-1 overflow-y-auto no-scrollbar space-y-3">
                                        <div>
                                            <h4 className="text-[10px] font-bold text-orange-400 mb-1.5 uppercase border-b border-glass pb-1"><i className="fas fa-thumbtack mr-1"></i> Appointments / Tasks ({mTasks.length})</h4>
                                            {mTasks.length > 0 ? (
                                                <div className="space-y-1.5">
                                                    {mTasks.map((t, idx) => (
                                                        <div key={`mtask-${t.id}-${idx}`} className="flex items-start gap-2 bg-surface/50 p-1.5 rounded border border-glass">
                                                            <i className={`fas ${t.isCompleted ? 'fa-check-square text-green-500' : 'fa-square text-text'} mt-0.5 text-[10px]`}></i>
                                                            <div className="flex-1 min-w-0">
                                                                <p className={`text-[10px] truncate ${t.isCompleted ? 'text-text line-through' : 'text-text'}`} title={t.title}>{t.title}</p>
                                                            </div>
                                                        </div>
                                                    ))}
                                                </div>
                                            ) : (
                                                <p className="text-[10px] text-text italic">ไม่มีนัดหมายส่วนตัว</p>
                                            )}
                                        </div>

                                        <div>
                                            <h4 className="text-[10px] font-bold text-purple-400 mb-1.5 uppercase border-b border-glass pb-1"><i className="fas fa-cogs mr-1"></i> Active Projects ({mProjects.length})</h4>
                                            {mProjects.length > 0 ? (
                                                <div className="space-y-1.5">
                                                    {mProjects.map((p, idx) => (
                                                        <div key={`mproj-${p.id}-${idx}`} className="bg-surface/50 p-1.5 rounded border border-glass flex justify-between items-center">
                                                            <span className="text-[10px] text-purple-500 truncate pr-2 flex-1" title={p.projectName}>- {p.projectName}</span>
                                                            <span className="text-[9px] text-text shrink-0">Prog: {p.progress || 0}%</span>
                                                        </div>
                                                    ))}
                                                </div>
                                            ) : (
                                                <p className="text-[10px] text-text italic">ไม่มีโปรเจกต์ที่ Active</p>
                                            )}
                                        </div>
                                    </div>
                                </div>
                            );
                        })}
                    </div>
                </div>
            )}

            {/* 🌟 Modal: View Appointment Details 🌟 */}
            {viewTaskModal.isOpen && viewTaskModal.task && (
                <div className="fixed inset-0 bg-black/80 flex justify-center items-center z-[60] p-4 backdrop-blur-sm animate-fade-in" onClick={() => setViewTaskModal({ isOpen: false, task: null })}>
                    <div className="bg-surface w-full max-w-sm rounded-2xl shadow-2xl border border-glass overflow-hidden animate-fade-in-down" onClick={(e) => e.stopPropagation()}>
                        <div className="p-5 border-b border-glass relative bg-surface/50">
                            <div className="absolute top-4 right-4 flex gap-3 items-center">
                                {/* ปุ่ม Edit (ให้เฉพาะเจ้าของงานที่สร้างขึ้นมาเห็น) */}
                                {viewTaskModal.task.userId === user?.uid && (
                                    <button type="button" onClick={() => openEditModal(viewTaskModal.task)} className="text-primary hover:text-primary text-sm font-bold transition"><i className="fas fa-edit"></i> Edit</button>
                                )}
                                <button type="button" onClick={() => setViewTaskModal({ isOpen: false, task: null })} className="text-text hover:text-text text-xl font-bold">&times;</button>
                            </div>
                            
                            <div className="flex items-center gap-3 mb-2 pr-20">
                                <span className={`w-10 h-10 shrink-0 rounded-xl flex items-center justify-center border text-lg bg-surface`}>
                                    <i className={`fas ${getTaskIcon(viewTaskModal.task.type)}`}></i>
                                </span>
                                <div className="min-w-0 flex-1">
                                    <h2 className="text-lg font-bold text-text leading-tight truncate">{viewTaskModal.task.title}</h2>
                                    <span className="text-[10px] bg-surface text-text px-2 py-0.5 rounded uppercase font-bold inline-block mt-1">{viewTaskModal.task.type}</span>
                                </div>
                            </div>
                        </div>
                        <div className="p-6 space-y-4">
                            <div className="flex justify-between items-center bg-surface/50 p-3 rounded-lg border border-glass">
                                <div>
                                    <p className="text-[10px] text-text uppercase font-bold mb-1">Date & Time</p>
                                    <p className="text-sm font-bold text-text"><i className="far fa-calendar-alt text-indigo-400 mr-2"></i>{new Date(viewTaskModal.task.date).toLocaleDateString('th-TH')} <span className="ml-2 text-indigo-300">{viewTaskModal.task.time}</span></p>
                                </div>
                            </div>
                            
                            {/* แสดงคนสร้าง และคนที่ถูก Tag */}
                            <div>
                                <p className="text-[10px] text-text uppercase font-bold mb-1">Created By</p>
                                <p className="text-xs text-text bg-surface/30 p-2 rounded-lg border border-glass flex items-center gap-2">
                                    <i className="fas fa-user-circle text-text"></i> {viewTaskModal.task.userName}
                                </p>
                            </div>

                            {viewTaskModal.task.invitedUsers?.length > 0 && (
                                <div>
                                    <p className="text-[10px] text-text uppercase font-bold mb-1.5">Tagged Member</p>
                                    <div className="flex flex-wrap gap-2">
                                        {viewTaskModal.task.invitedUsers.map(uid => {
                                            const member = allUsers.find(u => u.uid === uid);
                                            const status = viewTaskModal.task.inviteStatus?.[uid];
                                            const statusColor = status === 'accepted' ? 'text-green-400 border-green-500/50 bg-green-500/10' : status === 'declined' ? 'text-red-400 border-red-500/50 bg-red-500/10' : 'text-text border-glass bg-surface';
                                            return (
                                                <span key={uid} className={`text-[9px] px-2 py-1 rounded border flex items-center gap-1 ${statusColor}`}>
                                                    {member?.name || 'Unknown'} 
                                                    {status === 'accepted' && <i className="fas fa-check-circle"></i>}
                                                    {status === 'pending' && <i className="fas fa-clock"></i>}
                                                    {status === 'declined' && <i className="fas fa-times-circle"></i>}
                                                </span>
                                            )
                                        })}
                                    </div>
                                </div>
                            )}

                            {viewTaskModal.task.details && (
                                <div>
                                    <p className="text-[10px] text-text uppercase font-bold mb-1">Details / Location</p>
                                    <p className="text-xs text-text bg-surface/30 p-3 rounded-lg border border-glass leading-relaxed whitespace-pre-line">{viewTaskModal.task.details}</p>
                                </div>
                            )}
                        </div>
                        
                        <div className="p-4 border-t border-glass bg-surface flex justify-between items-center gap-3">
                            {viewTaskModal.task.userId === user?.uid ? (
                                <button onClick={(e) => deleteTask(e, viewTaskModal.task.id, viewTaskModal.task.title)} className="text-xs text-red-400 hover:text-red-300 font-bold px-3 py-2 rounded-lg hover:bg-red-900/20 transition"><i className="fas fa-trash-alt mr-1"></i> ลบนัดหมาย</button>
                            ) : <div></div>}
                            
                            {/* เช็คสิทธิ์ปุ่มติ๊กเสร็จใน Modal (ต้องเป็นเจ้าของ หรือ Tagged ที่ Accepted เท่านั้น) */}
                            {(() => {
                                const isOwner = viewTaskModal.task.userId === user?.uid;
                                const isAssignee = viewTaskModal.task.invitedUsers?.includes(user?.uid) && viewTaskModal.task.inviteStatus?.[user?.uid] === 'accepted';
                                if(isOwner || isAssignee) {
                                    return (
                                        <button onClick={(e) => { handleToggleTaskComplete(e, viewTaskModal.task); setViewTaskModal({ isOpen: false, task: null }); }} className={`px-5 py-2 rounded-lg text-xs font-bold transition shadow flex items-center gap-2 ${viewTaskModal.task.isCompleted ? 'bg-surface text-text hover:bg-surface' : 'bg-green-600 hover:bg-green-500 text-text'}`}>
                                            <i className={`fas ${viewTaskModal.task.isCompleted ? 'fa-undo' : 'fa-check'}`}></i> 
                                            {viewTaskModal.task.isCompleted ? 'ทำเครื่องหมายว่ายังไม่เสร็จ' : 'มาร์คว่าทำเสร็จแล้ว'}
                                        </button>
                                    );
                                }
                                return null;
                            })()}
                        </div>
                    </div>
                </div>
            )}

            {/* 🌟 Modal: Create / Edit Appointment 🌟 */}
            {showTaskModal && (
                <div className="fixed inset-0 bg-black/10 flex justify-center items-center z-50 p-4 backdrop-blur-sm animate-fade-in overflow-y-auto">
                    <form onSubmit={handleSaveTask} className="bg-surface w-full max-w-md rounded-2xl shadow-2xl border border-glass overflow-hidden animate-fade-in-down my-auto">
                        <div className="bg-surface p-5 border-b border-glass relative">
                            <button type="button" onClick={() => setShowTaskModal(false)} className="absolute top-4 right-4 text-text hover:text-red-300 text-2xl font-bold">&times;</button>
                            <h2 className="text-xl font-bold text-primary"><i className={`fas ${isEditing ? 'fa-edit' : 'fa-calendar-plus'} text-primary mr-2`}></i> {isEditing ? 'แก้ไขนัดหมาย' : 'สร้างนัดหมาย / แผนงาน'}</h2>
                        </div>
                        <div className="p-6 space-y-4 max-h-[60vh] overflow-y-auto custom-scrollbar pr-2">
                            <div>
                                <label className="block text-xs font-bold text-text mb-1.5 uppercase">หัวข้องาน (Title) *</label>
                                <input type="text" value={taskForm.title} onChange={(e) => setTaskForm({...taskForm, title: e.target.value})} required className="w-full p-2.5 bg-surface rounded-lg border border-glass text-text outline-none focus:border-indigo-500" placeholder="เช่น ประชุมทีม, เข้าหน้างานทดสอบ..." autoFocus/>
                            </div>
                            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                                <div>
                                    <label className="block text-xs font-bold text-text mb-1.5 uppercase">วันที่ (Date) *</label>
                                    <input type="date" value={taskForm.date} onChange={(e) => setTaskForm({...taskForm, date: e.target.value})} required className="w-full p-2.5 bg-surface rounded-lg border border-glass text-text outline-none focus:border-indigo-500"/>
                                </div>
                                <div>
                                    <label className="block text-xs font-bold text-text mb-1.5 uppercase">เวลา (Time)</label>
                                    <input type="time" value={taskForm.time} onChange={(e) => setTaskForm({...taskForm, time: e.target.value})} required className="w-full p-2.5 bg-surface rounded-lg border border-glass text-text outline-none focus:border-indigo-500"/>
                                </div>
                                <div>
                                    <label className="block text-xs font-bold text-text mb-1.5 uppercase">ประเภท (Type)</label>
                                    <select value={taskForm.type} onChange={(e) => setTaskForm({...taskForm, type: e.target.value})} className="w-full p-2.5 bg-surface rounded-lg border border-glass text-text outline-none focus:border-indigo-500" style={{ backgroundColor: 'var(--color-bg)', color: 'var(--color-text)' }}>
                                        <option value="Task">📌 Task</option>
                                        <option value="Meeting">🤝 Meeting</option>
                                        <option value="Test">🧪 Test</option>
                                    </select>
                                </div>
                            </div>
                            
                            {/* ส่วนสำหรับ Tag ทีมงาน (เลือกได้หลายคน) */}
                            <div className="pt-2 border-t border-glass/50">
                                <label className="block text-xs font-bold text-text mb-2 uppercase"><i className="fas fa-users text-indigo-400 mr-1.5"></i>มอบหมาย / Tag สมาชิก (เลือกได้หลายคน)</label>
                                <div className="flex flex-wrap gap-2">
                                    {tdTeamMembers.filter(u => u.uid !== user?.uid).map(u => {
                                        const isSelected = taskForm.taggedUsers.includes(u.uid);
                                        return (
                                            <button 
                                                type="button" 
                                                key={u.uid} 
                                                onClick={() => toggleTagUser(u.uid)}
                                                className={`px-3 py-1.5 text-[10px] font-bold rounded-full border transition-colors shadow-sm ${isSelected ? 'bg-indigo-600 border-indigo-400 text-text' : 'bg-surface border-glass text-text hover:border-glass'}`}
                                            >
                                                {u.name} {isSelected && <i className="fas fa-check ml-1"></i>}
                                            </button>
                                        )
                                    })}
                                </div>
                            </div>

                            <div>
                                <label className="block text-xs font-bold text-text mb-1.5 uppercase">รายละเอียดเพิ่มเติม (Optional)</label>
                                <textarea value={taskForm.details} onChange={(e) => setTaskForm({...taskForm, details: e.target.value})} rows="3" className="w-full p-2.5 bg-surface rounded-lg border border-glass text-text outline-none focus:border-indigo-500 placeholder-gray-600"></textarea>
                            </div>
                        </div>
                        <div className="p-4 border-t border-glass bg-surface flex justify-end gap-3 shrink-0">
                            <button type="button" onClick={() => setShowTaskModal(false)} className="px-5 py-2 text-text hover:text-text font-bold transition">ยกเลิก</button>
                            <button type="submit" disabled={isSubmitting} className="px-6 py-2 bg-indigo-600 hover:bg-indigo-500 text-text rounded-lg font-bold shadow-md transition disabled:opacity-50 flex items-center">
                                {isSubmitting ? <><i className="fas fa-spinner fa-spin mr-2"></i> บันทึก...</> : <><i className="fas fa-save mr-2"></i> บันทึกแผนงาน</>}
                            </button>
                        </div>
                    </form>
                </div>
            )}
        </div>
    );
};

export default MyPlannerPage;