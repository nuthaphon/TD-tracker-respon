import React, { useState, useEffect, useMemo, useRef } from 'react';
import { collection, onSnapshot, query } from 'firebase/firestore';
import { db } from '../firebase';
// 🌟 1. นำเข้า useAuth เพื่อตรวจสอบสิทธิ์
import { useAuth } from '../hooks/useAuth';

const MONTHS = [
    { value: 1, label: 'January' }, { value: 2, label: 'February' }, { value: 3, label: 'March' },
    { value: 4, label: 'April' }, { value: 5, label: 'May' }, { value: 6, label: 'June' },
    { value: 7, label: 'July' }, { value: 8, label: 'August' }, { value: 9, label: 'September' },
    { value: 10, label: 'October' }, { value: 11, label: 'November' }, { value: 12, label: 'December' }
];

const DashboardPage = () => {
    const dashboardRef = useRef(null);
    // 🌟 2. ดึงข้อมูล User จาก Context
    const { userData } = useAuth(); 
    
    const [jobs, setJobs] = useState([]);
    const [tdUsers, setTdUsers] = useState([]);
    const [loading, setLoading] = useState(true);

    const [selectedMonth, setSelectedMonth] = useState(new Date().getMonth() + 1);
    const [selectedYear, setSelectedYear] = useState(new Date().getFullYear());
    const [isFullscreen, setIsFullscreen] = useState(false);

    // 🌟 3. สร้างตัวแปรเช็คสิทธิ์ (Admin และ ทุกคนในแผนก TD)
    const isTD = userData?.dept === 'TD' || userData?.role === 'Admin';

    useEffect(() => {
        const unsubJobs = onSnapshot(query(collection(db, 'td_job_requests')), (snapshot) => {
            setJobs(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
            setLoading(false);
        });
        
        const unsubUsers = onSnapshot(query(collection(db, 'users')), (snapshot) => {
            const users = snapshot.docs.map(doc => doc.data());
            setTdUsers(users.filter(u => u.dept === 'TD' && u.role !== 'pending'));
        });

        const handleFullscreenChange = () => setIsFullscreen(!!document.fullscreenElement);
        document.addEventListener('fullscreenchange', handleFullscreenChange);

        return () => { unsubJobs(); unsubUsers(); document.removeEventListener('fullscreenchange', handleFullscreenChange); };
    }, []);

    const toggleFullScreen = () => {
        if (!document.fullscreenElement) {
            if (dashboardRef.current) dashboardRef.current.requestFullscreen().catch(err => alert(`Error: ${err.message}`));
        } else {
            if (document.exitFullscreen) document.exitFullscreen();
        }
    };

    const dashboardData = useMemo(() => {
        // --- 1. ข้อมูลกำลังพล (Manpower) ---
        const totalManpower = tdUsers.length;
        let mgrCount = 0, engCount = 0, techCount = 0;
        tdUsers.forEach(u => {
            const title = (u.jobTitle || '').toLowerCase();
            if (title.includes('manager') || title.includes('director')) mgrCount++;
            else if (title.includes('engineer') || title.includes('supervisor') || title.includes('lead')) engCount++;
            else techCount++;
        });

        // --- 2. ข้อมูลภาระงานปัจจุบัน (Current Workload Snapshot) ---
        const activeJobs = jobs.filter(j => !['Completed', 'Accepted', 'Reject', 'Cancelled', 'TD Reject'].includes(j.status));
        const totalActiveJobs = activeJobs.length;
        
        const workingStaff = (engCount + techCount) || 1; 
        const avgWorkload = (totalActiveJobs / workingStaff).toFixed(1);

        let workloadStatus = { label: 'Optimal', color: 'text-green-400', bg: 'bg-green-500', icon: 'fa-smile' };
        if (avgWorkload > 5) workloadStatus = { label: 'Overloaded', color: 'text-red-400', bg: 'bg-red-500', icon: 'fa-dizzy' };
        else if (avgWorkload >= 3) workloadStatus = { label: 'High Load', color: 'text-orange-400', bg: 'bg-orange-500', icon: 'fa-meh' };

        const workloadByPerson = tdUsers.map(u => {
            const count = activeJobs.filter(j => j.assignTo === u.name).length;
            return { name: u.name, count, role: u.jobTitle };
        }).filter(u => u.count > 0 || !((u.role || '').toLowerCase().includes('manager')))
          .sort((a,b) => b.count - a.count);

        // --- 3. ข้อมูลประจำเดือน (Monthly Data) ---
        const monthlyJobs = jobs.filter(j => {
            if (!j.createdAt) return false;
            const d = j.createdAt.toDate ? j.createdAt.toDate() : new Date(j.createdAt);
            return d.getMonth() + 1 === parseInt(selectedMonth) && d.getFullYear() === parseInt(selectedYear);
        });

        const mTotalJobs = monthlyJobs.length;
        const mCompletedJobs = monthlyJobs.filter(j => ['Completed', 'Accepted'].includes(j.status)).length;
        const successRate = mTotalJobs === 0 ? 0 : Math.round((mCompletedJobs / mTotalJobs) * 100);
        const mTotalCost = monthlyJobs.reduce((sum, j) => sum + (Number(j.cost) || 0), 0);

        const deptCount = {};
        monthlyJobs.forEach(j => { deptCount[j.group || 'Unknown'] = (deptCount[j.group || 'Unknown'] || 0) + 1; });
        const sortedDepts = Object.entries(deptCount).map(([dept, count]) => ({ dept, count })).sort((a, b) => b.count - a.count).slice(0, 5);

        let newCount = 0, repairCount = 0, otherCount = 0;
        monthlyJobs.forEach(j => {
            if (j.jobType === 'สร้างใหม่') newCount++;
            else if (j.jobType === 'ซ่อมแก้ไข') repairCount++;
            else otherCount++;
        });

        return {
            totalManpower, mgrCount, engCount, techCount,
            totalActiveJobs, avgWorkload, workloadStatus, workingStaff, workloadByPerson,
            mTotalJobs, mCompletedJobs, successRate, mTotalCost,
            sortedDepts, newCount, repairCount, otherCount
        };

    }, [jobs, tdUsers, selectedMonth, selectedYear]);

    if (loading) return <div className="flex justify-center items-center h-screen bg-surface"><div className="animate-spin rounded-full h-12 w-12 border-t-2 border-primary"></div></div>;

    const { 
        totalManpower, mgrCount, engCount, techCount, totalActiveJobs, avgWorkload, workloadStatus, workloadByPerson,
        mTotalJobs, mCompletedJobs, successRate, mTotalCost, sortedDepts, newCount, repairCount, otherCount 
    } = dashboardData;

    const getConicGradient = () => {
        if (mTotalJobs === 0) return 'conic-gradient(#374151 0% 100%)';
        const newP = (newCount / mTotalJobs) * 100;
        const repP = (repairCount / mTotalJobs) * 100;
        return `conic-gradient(#3b82f6 0% ${newP}%, #f97316 ${newP}% ${newP + repP}%, #8b5cf6 ${newP + repP}% 100%)`;
    };

    return (
        <div ref={dashboardRef} className="h-full min-h-screen bg-surface flex flex-col p-2 md:p-4 lg:p-6 relative overflow-y-auto custom-scrollbar print-bg-surface">
            
            {/* 🌟 CSS Print ฉบับแก้ปัญหาการซ้อนทับกันของกล่อง 🌟 */}
            <style dangerouslySetInnerHTML={{__html: `
                @media print {
                    @page { size: A4 landscape; margin: 8mm; }
                    body, html { background-color: #ffffff !important; color: #000000 !important; -webkit-print-color-adjust: exact !important; print-color-adjust: exact !important; }
                    #root { display: block !important; height: auto !important; }
                    nav, aside, header, .no-print { display: none !important; }
                    
                    .bg-surface, .bg-surface, .bg-surface\\/50 { background-color: #ffffff !important; border-color: #cbd5e1 !important; }
                    .text-text, .text-text, .text-text { color: #1e293b !important; }
                    .shadow-xl, .shadow-md, .shadow-inner { box-shadow: none !important; border: 1px solid #cbd5e1 !important; }
                    
                    /* 🌟 ปลดล็อกความสูง ปล่อยให้มันไหลไปตามธรรมชาติ 🌟 */
                    .print-bg-surface { padding: 0 !important; height: auto !important; max-height: none !important; display: block !important; overflow: visible !important;}
                    
                    /* บีบช่องไฟและ Margin เพื่อให้มันจุลง 1 หน้าได้พอดีโดยไม่ต้องบีบความสูงกล่อง */
                    .print-mb-shrink { margin-bottom: 8px !important; }
                    .print-gap-shrink { gap: 8px !important; }
                    .print-p-shrink { padding: 12px 14px !important; }
                    
                    .print-chart-bg { background-color: #f8fafc !important; }
                    .print-border { border: 1px solid #94a3b8 !important; }
                    .print-break-inside-avoid { page-break-inside: avoid !important; }
                    
                    /* ฟอนต์ขนาดใหญ่เหมือนเดิม แต่อ่านง่ายขึ้น */
                    .print-text-base { font-size: 16px !important; }
                    .print-text-sm { font-size: 14px !important; }
                    .print-text-xs { font-size: 12px !important; }
                    .print-val-lg { font-size: 28px !important; }
                    
                    /* Grid Control */
                    .print-grid-cols-4 { display: grid !important; grid-template-columns: repeat(4, minmax(0, 1fr)) !important; }
                    .print-col-span-1 { grid-column: span 1 / span 1 !important; }
                    .print-col-span-2 { grid-column: span 2 / span 2 !important; }
                    
                    /* ปรับขนาดโดนัทให้ไม่กินพื้นที่แนวตั้งมากเกินไป */
                    .print-donut-shrink { width: 90px !important; height: 90px !important; margin-top: 5px !important; margin-bottom: 5px !important; }
                    .print-donut-inner { width: 55px !important; height: 55px !important; }
                    .print-donut-text { font-size: 18px !important; }
                }
            `}} />

            {/* --- Header Controls (UI) --- */}
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-3 md:mb-6 print:mb-0 border-b border-glass pb-3 md:pb-4 gap-3 no-print shrink-0">
                <div>
                    <h1 className="text-lg md:text-2xl font-black text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-purple-400 tracking-wide uppercase">
                        <i className="fas fa-building text-primary mr-2"></i> Executive Dashboard
                    </h1>
                    <p className="text-xs md:text-sm text-text mt-1 font-bold">TD Management Review & Department Health</p>
                </div>
                
                <div className="flex flex-wrap items-center gap-2 bg-surface p-1.5 rounded-xl border border-glass shadow-inner w-full md:w-auto">
                    <div className="flex items-center gap-1 md:gap-2 flex-1 md:flex-none">
                        <i className="fas fa-calendar-alt text-text pl-2"></i>
                        <select value={selectedMonth} onChange={(e) => setSelectedMonth(e.target.value)} className="bg-surface border border-glass text-text text-sm md:text-base rounded-lg px-2 md:px-3 py-1 md:py-1.5 outline-none focus:border-primary font-bold">
                            {MONTHS.map(m => <option key={m.value} value={m.value} style={{ backgroundColor: 'var(--color-bg)', color: 'var(--color-text)' }}>{m.label}</option>)}
                        </select>
                        <select value={selectedYear} onChange={(e) => setSelectedYear(e.target.value)} className="bg-surface border border-glass text-text text-sm md:text-base rounded-lg px-2 md:px-3 py-1 md:py-1.5 outline-none focus:border-primary font-bold">
                            {[2024, 2025, 2026, 2027].map(y => <option key={y} value={y} style={{ backgroundColor: 'var(--color-bg)', color: 'var(--color-text)' }}>{y}</option>)}
                        </select>
                    </div>

                    <button onClick={toggleFullScreen} className="bg-surface hover:bg-surface text-text px-3 md:px-4 py-2 rounded-lg font-bold shadow transition flex items-center text-sm" title="Full Screen">
                        <i className={`fas ${isFullscreen ? 'fa-compress' : 'fa-expand'}`}></i>
                    </button>
                    
                    {/* 🌟 4. ให้สิทธิ์ Mgt. Report กับ TD ทุกคน และ Admin 🌟 */}
                    {isTD && (
                        <button onClick={() => window.print()} className="bg-primary text-text px-3 md:px-5 py-2 rounded-lg font-bold shadow-lg transition flex items-center text-sm">
                            <i className="fas fa-print mr-1 md:mr-2"></i><span className="hidden sm:inline">Mgt. Report</span><span className="sm:hidden">Print</span>
                        </button>
                    )}
                </div>
            </div>

            {/* --- Document Header (For Print Only) --- */}
            <div className="hidden print:flex justify-between items-end border-b-2 border-blue-900 pb-2 print-mb-shrink shrink-0">
                <div>
                    <img src="https://i.postimg.cc/y89YMCnp/logo_ttm_new_1_150x152_(1).png" alt="Logo" className="h-8 mb-1.5" />
                    <h1 className="text-xl font-black text-primary uppercase tracking-widest mb-0.5">Technology Development Department</h1>
                    <h2 className="text-base font-bold text-text">Executive Monthly Report & Capacity Analysis</h2>
                </div>
                <div className="text-right">
                    <p className="text-lg font-black text-primary bg-blue-100 px-4 py-1.5 rounded-lg border border-blue-200 uppercase tracking-widest">
                        {MONTHS.find(m => m.value === parseInt(selectedMonth)).label} {selectedYear}
                    </p>
                    <p className="text-xs text-text mt-2 font-medium">Exported on: {new Date().toLocaleString('th-TH')}</p>
                </div>
            </div>

            {/* --- ROW 1: Performance KPIs (4 Cols) --- */}
            <div className="grid grid-cols-2 md:grid-cols-4 print-grid-cols-4 gap-2 md:gap-4 print-gap-shrink mb-2 md:mb-4 print-mb-shrink shrink-0">
                
                <div className="bg-surface rounded-xl p-2 md:p-4 print-p-shrink border-l-4 border-primary shadow-lg print-border print-break-inside-avoid">
                    <p className="text-xs print-text-sm font-bold text-text uppercase tracking-wider mb-1">Total Jobs (Monthly)</p>
                    <div className="flex items-end gap-2">
                        <span className="text-2xl md:text-4xl print-val-lg font-black text-primary">{mTotalJobs}</span>
                        <span className="text-xs print-text-xs text-text mb-1.5 font-bold">Tickets</span>
                    </div>
                </div>

                <div className="bg-surface rounded-xl p-2 md:p-4 print-p-shrink border-l-4 border-green-500 shadow-lg print-border print-break-inside-avoid">
                    <p className="text-xs print-text-sm font-bold text-text uppercase tracking-wider mb-1">Completed (Monthly)</p>
                    <div className="flex items-end gap-2">
                        <span className="text-2xl md:text-4xl print-val-lg font-black text-green-400">{mCompletedJobs}</span>
                        <span className="text-xs print-text-xs text-text mb-1.5 font-bold">Tickets</span>
                    </div>
                </div>

                <div className="bg-surface rounded-xl p-2 md:p-4 print-p-shrink border-l-4 border-purple-500 shadow-lg print-border print-break-inside-avoid">
                    <p className="text-xs print-text-sm font-bold text-text uppercase tracking-wider mb-1">Success Rate</p>
                    <div className="flex items-end gap-1">
                        <span className="text-2xl md:text-4xl print-val-lg font-black text-purple-400">{successRate}</span>
                        <span className="text-lg font-bold text-purple-400/80 mb-1.5">%</span>
                    </div>
                    <div className="w-full bg-surface rounded-full h-1.5 mt-2"><div className="bg-purple-500 h-1.5 rounded-full" style={{ width: `${successRate}%` }}></div></div>
                </div>

                <div className="bg-surface rounded-xl p-2 md:p-4 print-p-shrink border-l-4 border-red-500 shadow-lg print-border print-break-inside-avoid">
                    <p className="text-xs print-text-sm font-bold text-text uppercase tracking-wider mb-1">Total Expense (Monthly)</p>
                    <div className="flex items-end gap-2">
                        <span className="text-xl md:text-3xl print-val-lg font-black text-red-400 truncate">{mTotalCost.toLocaleString()}</span>
                        <span className="text-xs print-text-xs text-text mb-1 font-bold">THB</span>
                    </div>
                </div>
            </div>

            {/* --- ROW 2: Manpower, Dept Load & Job Types --- */}
            <div className="grid grid-cols-1 md:grid-cols-4 print-grid-cols-4 gap-2 md:gap-4 print-gap-shrink mb-2 md:mb-4 print-mb-shrink shrink-0 h-auto md:h-56 print:h-auto">
                
                {/* Manpower (1 Col) */}
                <div className="md:col-span-1 print-col-span-1 bg-surface rounded-xl p-4 print-p-shrink border border-glass shadow-lg print-border print-break-inside-avoid print-chart-bg flex flex-col">
                    <h3 className="text-sm print-text-base font-bold text-text print:text-primary mb-3 uppercase flex items-center shrink-0"><i className="fas fa-users-cog mr-2 text-purple-400 print:text-purple-600"></i> Manpower</h3>
                    <div className="flex justify-between items-center mb-3 border-b border-glass print:border-glass pb-2">
                        <span className="text-xs print-text-sm text-text print:text-text">Total Headcount</span>
                        <span className="text-xl font-black text-text print:text-text">{totalManpower} <span className="text-[10px] font-normal">Pax</span></span>
                    </div>
                    <div className="space-y-3 text-xs print-text-sm mt-auto">
                        <div className="flex justify-between items-center"><span className="text-text print:text-text"><i className="fas fa-user-tie text-primary w-5"></i> Manager / Lead</span> <span className="font-bold text-text print:text-text">{mgrCount}</span></div>
                        <div className="flex justify-between items-center"><span className="text-text print:text-text"><i className="fas fa-hard-hat text-orange-400 w-5"></i> Engineer / Supervisor</span> <span className="font-bold text-text print:text-text">{engCount}</span></div>
                        <div className="flex justify-between items-center"><span className="text-text print:text-text"><i className="fas fa-wrench text-green-400 w-5"></i> Technician / Staff</span> <span className="font-bold text-text print:text-text">{techCount}</span></div>
                    </div>
                </div>

                {/* Overall Dept Workload (1 Col) */}
                <div className="md:col-span-1 print-col-span-1 bg-surface rounded-xl p-4 print-p-shrink border border-glass shadow-lg print-border print-break-inside-avoid print-chart-bg flex flex-col items-center justify-center text-center">
                    <h3 className="text-sm print-text-base font-bold text-text print:text-primary mb-3 uppercase w-full text-left shrink-0"><i className="fas fa-tachometer-alt mr-2 text-orange-400 print:text-orange-600"></i> Dept Load</h3>
                    
                    <div className={`flex flex-col items-center justify-center p-3 rounded-full w-28 h-28 border-[4px] ${workloadStatus.bg.replace('bg-', 'border-').replace('500', '500/50')} bg-surface print:bg-surface print-border shrink-0`}>
                        <span className={`text-4xl font-black ${workloadStatus.color} leading-none`}>{avgWorkload}</span>
                        <span className="text-[10px] text-text print:text-text font-bold uppercase mt-1">Jobs / Pax</span>
                    </div>
                    <span className={`text-xs font-bold uppercase px-4 py-1.5 rounded-full mt-4 text-text ${workloadStatus.bg} shadow-md`}>{workloadStatus.label}</span>
                </div>

                {/* Job Types (2 Cols) */}
                <div className="md:col-span-2 print-col-span-2 bg-surface rounded-xl p-4 print-p-shrink border border-glass shadow-lg print-border print-break-inside-avoid print-chart-bg flex flex-col">
                    <h3 className="text-sm print-text-base font-bold text-text print:text-primary mb-3 uppercase shrink-0"><i className="fas fa-tools mr-2 text-orange-400 print:text-orange-600"></i> Job Type Ratio</h3>
                    
                    <div className="flex flex-1 items-center justify-around px-2 md:px-8 mt-auto mb-auto">
                        {mTotalJobs > 0 ? (
                            <>
                                <div className="relative w-32 h-32 md:w-36 md:h-36 print-donut-shrink rounded-full flex items-center justify-center shadow-[0_0_15px_rgba(0,0,0,0.5)] print:shadow-none shrink-0" style={{ background: getConicGradient() }}>
                                    <div className="w-20 h-20 md:w-24 md:h-24 print-donut-inner bg-[var(--color-bg)] print-chart-bg rounded-full flex flex-col items-center justify-center z-10 shadow-inner print-border">
                                        <span className="text-3xl print-donut-text font-black text-text print:text-text">{mTotalJobs}</span>
                                        <span className="text-[10px] text-text font-bold uppercase">Total</span>
                                    </div>
                                </div>
                                
                                <div className="flex flex-col gap-3 w-1/2">
                                    <div className="flex flex-col">
                                        <div className="flex items-center gap-2 mb-0.5"><span className="w-3 h-3 rounded-full bg-blue-500 shadow"></span><span className="text-xs print-text-sm text-text print:text-text font-bold">สร้างใหม่ (New)</span></div>
                                        <span className="text-xl font-black text-text print:text-text ml-5">{newCount} <span className="text-[11px] text-text font-normal">({Math.round((newCount/mTotalJobs)*100)}%)</span></span>
                                    </div>
                                    <div className="flex flex-col">
                                        <div className="flex items-center gap-2 mb-0.5"><span className="w-3 h-3 rounded-full bg-orange-500 shadow"></span><span className="text-xs print-text-sm text-text print:text-text font-bold">ซ่อมแก้ไข (Repair)</span></div>
                                        <span className="text-xl font-black text-text print:text-text ml-5">{repairCount} <span className="text-[11px] text-text font-normal">({Math.round((repairCount/mTotalJobs)*100)}%)</span></span>
                                    </div>
                                    <div className="flex flex-col">
                                        <div className="flex items-center gap-2 mb-0.5"><span className="w-3 h-3 rounded-full bg-purple-500 shadow"></span><span className="text-xs print-text-sm text-text print:text-text font-bold">อื่นๆ (Others)</span></div>
                                        <span className="text-xl font-black text-text print:text-text ml-5">{otherCount} <span className="text-[11px] text-text font-normal">({Math.round((otherCount/mTotalJobs)*100)}%)</span></span>
                                    </div>
                                </div>
                            </>
                        ) : <p className="text-center text-text text-sm italic w-full">ไม่มีข้อมูลในเดือนนี้</p>}
                    </div>
                </div>

            </div>

            {/* --- SECTION 3: Visual Analytics & Individual Workload --- */}
            <div className="grid grid-cols-1 md:grid-cols-4 print-grid-cols-4 gap-2 md:gap-4 print-gap-shrink flex-1 h-auto md:h-64 print:h-auto pb-4 md:pb-6 print:pb-0">
                
                {/* Requesting Departments (2 Cols) */}
                <div className="md:col-span-2 print-col-span-2 bg-surface rounded-xl p-4 print-p-shrink border border-glass shadow-lg print-border print-break-inside-avoid print-chart-bg flex flex-col">
                    <h3 className="text-sm print-text-base font-bold text-text print:text-primary mb-4 uppercase flex items-center shrink-0"><i className="fas fa-building mr-2 text-primary print:text-primary"></i> Top Serviced Departments</h3>
                    <div className="space-y-4 print:space-y-3 overflow-y-auto custom-scrollbar flex-1 pr-3 mt-2">
                        {sortedDepts.map((d) => {
                            const maxCount = sortedDepts[0]?.count || 1;
                            const widthP = (d.count / maxCount) * 100;
                            return (
                                <div key={d.dept} className="flex items-center gap-4">
                                    <div className="w-24 text-right shrink-0">
                                        <span className="text-xs print-text-sm font-bold text-text print:text-text truncate block">{d.dept}</span>
                                    </div>
                                    <div className="flex-1 relative h-6 print:h-5 bg-surface print:bg-surface rounded-md overflow-hidden flex items-center shadow-inner print:shadow-none">
                                        <div className="absolute top-0 bottom-0 left-0 bg-blue-500 transition-all" style={{ width: `${widthP}%` }}></div>
                                        <span className="relative z-10 ml-3 text-xs print:text-[11px] font-black text-text">{d.count} Jobs</span>
                                    </div>
                                </div>
                            )
                        })}
                        {sortedDepts.length === 0 && <p className="text-center text-text text-sm italic">No data</p>}
                    </div>
                </div>

                {/* Individual Active Workload (2 Cols) */}
                <div className="md:col-span-2 print-col-span-2 bg-surface rounded-xl p-4 print-p-shrink border border-glass shadow-lg print-border print-break-inside-avoid print-chart-bg flex flex-col">
                    <h3 className="text-sm print-text-base font-bold text-text print:text-primary mb-4 uppercase flex items-center shrink-0">
                        <i className="fas fa-user-clock mr-2 text-pink-400 print:text-pink-600"></i> Individual Active Workload
                    </h3>
                    
                    <div className="space-y-4 print:space-y-3 overflow-y-auto custom-scrollbar flex-1 pr-3 mt-2">
                        {workloadByPerson.map(person => {
                            const barColor = person.count >= 5 ? 'bg-red-500 print:bg-red-600' : person.count >= 3 ? 'bg-orange-500 print:bg-orange-600' : 'bg-green-500 print:bg-green-600';
                            return (
                                <div key={person.name} className="flex items-center gap-4">
                                    <div className="w-32 text-right shrink-0 truncate">
                                        <span className="text-xs print-text-sm font-bold text-text print:text-text block truncate" title={person.name}>{person.name}</span>
                                    </div>
                                    <div className="flex-1 relative h-6 print:h-5 bg-surface print:bg-surface rounded-md overflow-hidden flex items-center shadow-inner print:shadow-none">
                                        <div className={`absolute top-0 bottom-0 left-0 ${barColor} transition-all`} style={{ width: `${Math.min((person.count / 10) * 100, 100)}%` }}></div>
                                        <span className="relative z-10 ml-3 text-xs print:text-[11px] font-black text-text drop-shadow-md print:drop-shadow-none">{person.count} <span className="font-normal opacity-70">Jobs</span></span>
                                    </div>
                                </div>
                            )
                        })}
                        {workloadByPerson.length === 0 && <p className="text-center text-text text-sm italic w-full">ไม่มีงานค้างในระบบ</p>}
                    </div>
                </div>

            </div>
            
        </div>
    );
};

export default DashboardPage;