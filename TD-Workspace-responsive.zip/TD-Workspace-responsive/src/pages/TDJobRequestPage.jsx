import React, { useState, useEffect, useRef, useMemo } from 'react';
import { collection, query, orderBy, onSnapshot, addDoc, updateDoc, doc, serverTimestamp, arrayUnion, where, limit } from 'firebase/firestore';
import { ref, uploadBytes, getDownloadURL } from 'firebase/storage';
import { db, storage } from '../firebase';
import { useAuth } from '../hooks/useAuth';
import { Html5Qrcode } from 'html5-qrcode';
import { useNavigate } from 'react-router-dom';
import { DEPT_OPTIONS, TD_JOB_CATEGORIES } from '../utils/constants';
import { logActivity } from '../utils/activityLogger';
import AutoPilotTower from '../components/kanban/AutoPilotTower';

const TDJobRequestPage = () => {
    const { userData, user } = useAuth();
    const navigate = useNavigate();
    
    const [activeJobs, setActiveJobs] = useState([]);
    const [historyJobs, setHistoryJobs] = useState([]);
    const [historyLimit, setHistoryLimit] = useState(20);
    const [hasMoreHistory, setHasMoreHistory] = useState(true);

    const [tdUsers, setTdUsers] = useState([]);
    const [loading, setLoading] = useState(true);
    const [activeTab, setActiveTab] = useState('kanban');

    const [isTowerMode, setIsTowerMode] = useState(false);

    const [selectedJob, setSelectedJob] = useState(null); 
    const [modalAction, setModalAction] = useState(''); 
    const [actionComment, setActionComment] = useState('');
    const [assignTarget, setAssignTarget] = useState('');
    const [jobCategory, setJobCategory] = useState('');
    const [historySearch, setHistorySearch] = useState('');
    const [isScanning, setIsScanning] = useState(false);

    const [linkedProject, setLinkedProject] = useState(null);

    const [jobAttachments, setJobAttachments] = useState([]);
    const [selectedFile, setSelectedFile] = useState(null);
    const [attachTitle, setAttachTitle] = useState('');
    const [isUploading, setIsUploading] = useState(false);
    const fileInputRef = useRef(null);

    const [formData, setFormData] = useState({
        jobType: '', group: userData?.dept || '', assignTo: '',
        what: '', who: '', when: '', where: '', why: '', how: '',
        cost: '', dueDate: ''
    });
    
    const [editFormData, setEditFormData] = useState({});
    const [isSubmitting, setIsSubmitting] = useState(false);

    // 🌟 Unified Permission Checks 🌟
    const isAdmin = userData?.role === 'Admin';
    const userJobTitle = (userData?.jobTitle || '').toLowerCase().trim();
    
    // 1. Manager/Director ทั่วไป (ต้องเช็คแผนกร่วมด้วย)
    const isDeptMgr = userJobTitle.includes('manager') || userJobTitle.includes('director') || isAdmin;
    
    // 2. ตำแหน่ง "Department Manager" แบบเจาะจง (ข้ามแผนกได้)
    const isGlobalDeptManager = userJobTitle === 'department manager' || isAdmin;

    const isTD = userData?.dept === 'TD' || isAdmin;
    const isTDManager = isTD && (userJobTitle.includes('manager') || userJobTitle.includes('director') || isAdmin);
    const isTDSup = isTD && (userJobTitle.includes('supervisor') || userJobTitle.includes('lead') || isAdmin);
    
    const isRequester = selectedJob?.requestBy === userData?.name || isAdmin;
    const isMyDept = selectedJob?.group === userData?.dept || isAdmin;
    const isAssignee = selectedJob?.assignTo === userData?.name;

    const checkCanReceive = (job) => {
        if (isAdmin) return true;
        if (!isTD) return false;
        
        const targetAssignee = job?.assignTo;
        if (!targetAssignee) return isTDManager; 

        const assigneeData = tdUsers.find(u => u.name === targetAssignee);
        const assigneeTitle = (assigneeData?.jobTitle || '').toLowerCase();
        
        if (assigneeTitle.includes('technician') || assigneeTitle.includes('supervisor')) {
            return isTDSup;
        } 
        else {
            return isTDManager;
        }
    };

    const isMyTask = (job) => {
        if (!userData) return false;
        const _isMyDept = job.group === userData?.dept || isAdmin;
        const _isRequester = job.requestBy === userData?.name || isAdmin;
        const _isAssignee = job.assignTo === userData?.name;

        if (job.status === 'Issued') return (isDeptMgr && _isMyDept) || isGlobalDeptManager;
        if (job.status === 'Revise') return _isRequester || (isDeptMgr && _isMyDept) || isGlobalDeptManager;
        if (job.status === 'Approved') return checkCanReceive(job);
        if (job.status === 'In Progress') return _isAssignee || isTDManager || isTDSup;
        if (job.status === 'Completed') return _isRequester || (isDeptMgr && _isMyDept) || isGlobalDeptManager;

        return false;
    };

    useEffect(() => {
        const qActive = query(
            collection(db, 'td_job_requests'), 
            where('status', 'in', ['Issued', 'Revise', 'Approved', 'Received', 'In Progress', 'Completed', 'TD Reject'])
        );
        const unsubActive = onSnapshot(qActive, (snapshot) => {
            const data = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
            data.sort((a,b) => (b.createdAt?.toDate() || 0) - (a.createdAt?.toDate() || 0));
            setActiveJobs(data);
            setLoading(false);
        });

        const qHistory = query(
            collection(db, 'td_job_requests'), 
            orderBy('createdAt', 'desc'), 
            limit(historyLimit)
        );
        const unsubHistory = onSnapshot(qHistory, (snapshot) => {
            const data = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
            setHistoryJobs(data);
            setHasMoreHistory(data.length === historyLimit); 
        });

        const qUser = query(collection(db, 'users'));
        const unsubscribeUsers = onSnapshot(qUser, (snapshot) => {
            const usersData = snapshot.docs.map(doc => doc.data());
            setTdUsers(usersData.filter(u => u.dept === 'TD' && u.role !== 'pending'));
        });

        return () => { unsubActive(); unsubHistory(); unsubscribeUsers(); };
    }, [historyLimit]);

    const allKnownJobs = useMemo(() => {
        const map = new Map();
        activeJobs.forEach(job => map.set(job.id, job));
        historyJobs.forEach(job => map.set(job.id, job));
        return Array.from(map.values());
    }, [activeJobs, historyJobs]);

    useEffect(() => {
        if (selectedJob && selectedJob.projectId) {
            const unsubProj = onSnapshot(doc(db, 'td_projects', selectedJob.projectId), (docSnap) => {
                if (docSnap.exists()) {
                    setLinkedProject({ id: docSnap.id, ...docSnap.data() });
                } else {
                    setLinkedProject(null);
                }
            });
            return () => unsubProj();
        } else {
            setLinkedProject(null);
        }
    }, [selectedJob]);

    const handleCloseModal = () => {
        setSelectedJob(null); setModalAction(''); setActionComment(''); setAssignTarget(''); setJobCategory(''); setLinkedProject(null);
    };

    useEffect(() => {
        let html5QrCode;
        if (isScanning) {
            html5QrCode = new Html5Qrcode("reader");
            html5QrCode.start({ facingMode: "environment" }, { fps: 10, qrbox: { width: 250, height: 250 } },
                (decodedText) => {
                    html5QrCode.stop().then(() => {
                        setIsScanning(false);
                        const targetJob = allKnownJobs.find(j => j.projectNo === decodedText);
                        if (targetJob) { setSelectedJob(targetJob); setModalAction(''); setHistorySearch(decodedText); } 
                        else { alert(`สแกนเจอ Project No: ${decodedText} แต่ไม่พบในระบบ`); }
                    }).catch(err => console.error(err));
                }, (errorMessage) => {}
            ).catch(err => {
                alert("ไม่สามารถเปิดกล้องได้"); setIsScanning(false);
            });
        }
        return () => { if (html5QrCode && html5QrCode.isScanning) html5QrCode.stop().catch(console.error); };
    }, [isScanning, allKnownJobs]);

    const handleChange = (e) => setFormData({ ...formData, [e.target.name]: e.target.value });
    const handleEditFormChange = (e) => setEditFormData({ ...editFormData, [e.target.name]: e.target.value });

    const handleFileUpload = async (e) => {
        e.preventDefault();
        if (!selectedFile || !attachTitle.trim()) return alert("กรุณาตั้งชื่อและเลือกไฟล์");
        if (selectedFile.size > 10 * 1024 * 1024) return alert("ขนาดไฟล์เกิน 10MB");

        setIsUploading(true);
        try {
            const uniqueFileName = `${Date.now()}_${selectedFile.name}`;
            const storageRef = ref(storage, `job_request_files/${uniqueFileName}`);
            
            const snapshot = await uploadBytes(storageRef, selectedFile);
            const downloadURL = await getDownloadURL(snapshot.ref);

            let fileType = 'document';
            if (selectedFile.type.includes('image')) fileType = 'image';
            else if (selectedFile.type.includes('spreadsheet') || selectedFile.type.includes('excel') || selectedFile.name.endsWith('.csv')) fileType = 'sheets';
            else if (selectedFile.type.includes('pdf')) fileType = 'docs';

            setJobAttachments([...jobAttachments, {
                id: Date.now().toString(), title: attachTitle, url: downloadURL, type: fileType,
                addedBy: userData?.name, timestamp: new Date().toISOString()
            }]);
            
            setAttachTitle(''); setSelectedFile(null);
            if(fileInputRef.current) fileInputRef.current.value = "";
            setIsUploading(false);
        } catch (error) { 
            console.error(error);
            alert("เกิดข้อผิดพลาดในการอัปโหลดไฟล์ไปยัง Storage"); 
            setIsUploading(false); 
        }
    };

    const handleIssueSubmit = async (e) => {
        e.preventDefault();
        setIsSubmitting(true);
        try {
            const randomId = Math.random().toString(36).substring(2, 10).toUpperCase();
            const today = new Date().toLocaleDateString('en-GB').replace(/\//g, '');
            const projNo = `TD-${formData.group}-${today}-${randomId}`;

            await addDoc(collection(db, 'td_job_requests'), {
                ...formData, 
                projectNo: projNo, 
                status: 'Issued',
                requestBy: userData?.name || 'Unknown', 
                requestEmail: user?.email || '',
                attachments: jobAttachments, 
                createdAt: serverTimestamp(),
                timeline: [{ status: 'Issued', by: userData?.name, timestamp: new Date().toISOString() }]
            });

            await logActivity(user, 'Created Job Request', `สร้างแจ้งซ่อม/แจ้งงานใหม่หมายเลข: ${projNo}`);

            alert('สร้าง Ticket สำเร็จ!');
            setFormData({ jobType: '', group: userData?.dept || '', assignTo: '', what: '', who: '', when: '', where: '', why: '', how: '', cost: '', dueDate: '' });
            setJobAttachments([]); 
            setActiveTab('kanban');
        } catch (error) { alert('เกิดข้อผิดพลาดในการบันทึกข้อมูล'); } 
        finally { setIsSubmitting(false); }
    };

    const handleActionSubmit = async () => {
        if (!selectedJob) return;
        setIsSubmitting(true);
        try {
            const jobRef = doc(db, 'td_job_requests', selectedJob.id);
            let nextStatus = '';
            if (modalAction === 'Approve') nextStatus = 'Approved';
            else if (modalAction === 'Reject') nextStatus = 'Reject';
            else if (modalAction === 'Revise') nextStatus = 'Revise';
            else if (modalAction === 'Receive') nextStatus = 'In Progress';
            else if (modalAction === 'TD Reject') nextStatus = 'TD Reject';
            else if (modalAction === 'Complete') nextStatus = 'Completed';
            else if (modalAction === 'Accept') nextStatus = 'Accepted'; 
            else if (modalAction === 'Resubmit') nextStatus = 'Issued'; 

            const newTimelineEvent = { 
                status: nextStatus, 
                by: userData?.name, 
                comment: actionComment || (modalAction === 'Resubmit' ? 'แก้ไขข้อมูลและส่งใหม่' : ''), 
                timestamp: new Date().toISOString() 
            };
            
            let updateData = { status: nextStatus, timeline: [...(selectedJob.timeline || []), newTimelineEvent] };

            if (modalAction === 'Receive') { updateData.assignTo = assignTarget; updateData.jobCategory = jobCategory; }
            if (modalAction === 'Resubmit') { updateData = { ...updateData, ...editFormData }; }

            await updateDoc(jobRef, updateData);
            
            if (selectedJob.projectId && ['Completed', 'Accepted', 'In Progress'].includes(nextStatus)) {
                await updateDoc(doc(db, 'td_projects', selectedJob.projectId), {
                    status: nextStatus
                });
            }
            
            await logActivity(user, 'Updated Job Status', `เปลี่ยนสถานะตั๋ว ${selectedJob.projectNo} เป็น ${nextStatus}`);

            alert(`ดำเนินการสำเร็จ!`); handleCloseModal();
        } catch (error) { alert('เกิดข้อผิดพลาด'); } 
        finally { setIsSubmitting(false); }
    };

    const handlePrintTicket = (job) => {
        const qrUrl = `https://quickchart.io/qr?text=${encodeURIComponent(job.projectNo)}&size=150`;
        const issueDate = job.createdAt?.toDate ? job.createdAt.toDate().toLocaleDateString('th-TH') : '-';
        
        const printContent = `
            <html>
            <head>
                <title>Print Label - ${job.projectNo}</title>
                <style>
                    body { font-family: 'Arial', sans-serif; margin: 0; padding: 10px; text-align: center; } 
                    .ticket { border: 2px dashed #000; padding: 15px; width: 300px; margin: 0 auto; border-radius: 8px; } 
                    .title { font-size: 18px; font-weight: bold; margin-bottom: 10px; background: #000; color: #fff; padding: 5px; border-radius: 4px; letter-spacing: 1px; } 
                    .qr-code { margin: 10px 0; } 
                    .info { font-size: 14px; text-align: left; margin-bottom: 8px; border-bottom: 1px solid #ddd; padding-bottom: 4px; line-height: 1.4; } 
                    .label { font-weight: bold; color: #555; font-size: 12px; } 
                    @media print { @page { margin: 0; } body { margin: 0.5cm; } }
                </style>
            </head>
            <body>
                <div class="ticket">
                    <div class="title">TD TICKET</div>
                    <img src="${qrUrl}" class="qr-code" width="120" height="120" />
                    <div class="info"><span class="label">Project No:</span><br><b style="font-size: 16px;">${job.projectNo}</b></div>
                    <div class="info"><span class="label">Req By:</span><br>${job.requestBy} (${job.group})</div>
                    <div class="info"><span class="label">Req To:</span><br>${job.assignTo || '-'}</div>
                    <div class="info"><span class="label">Issue Date:</span><br>${issueDate}</div>
                    <div class="info"><span class="label">Type:</span><br>${job.jobType}</div>
                </div>
                <script>window.onload = function() { setTimeout(function() { window.print(); window.close(); }, 500); }</script>
            </body>
            </html>
        `;

        const printWin = window.open('', '', 'width=400,height=600');
        if (printWin) { printWin.document.open(); printWin.document.write(printContent); printWin.document.close(); } 
        else { alert('กรุณาอนุญาตให้เว็บไซต์เปิด Pop-up เพื่อพิมพ์เอกสาร'); }
    };

    const handlePrintHandoverReport = () => {
        if (!linkedProject || !linkedProject.handoverReport) return;
        const hr = linkedProject.handoverReport;

        const renderSignBox = (roleStr, signData, title) => {
            if (signData) {
                const d = new Date(signData.date);
                const dateStr = `${d.toLocaleDateString('th-TH')} ${d.toLocaleTimeString('th-TH',{hour:'2-digit', minute:'2-digit'})}`;
                return `
                <div class="sign-item">
                    <div class="sign-line" style="display:flex; flex-direction:column; justify-content:end; align-items:center;">
                       <span style="color:#2563eb; font-size:14px; font-weight:bold; font-style:italic; letter-spacing:1px;">✔ E-APPROVED</span>
                    </div>
                    <p><b>${roleStr}</b><br>( ${signData.name} )<br>${title}<br>วันที่: ${dateStr}</p>
                </div>
                `;
            } else {
                return `
                <div class="sign-item">
                    <div class="sign-line"></div>
                    <p><b>${roleStr}</b><br>(..................................................)<br>${title}<br>วันที่: _____/_____/_____</p>
                </div>
                `;
            }
        };

        const ownerSignHtml = renderSignBox('ผู้ดำเนินงาน / ผู้ส่งมอบ', { name: hr.generatedBy, date: hr.generatedAt }, 'แผนก TD');
        const approverSignHtml = renderSignBox('ผู้ตรวจสอบ (TD Manager)', hr.approverSign, 'แผนก TD');
        const issuerSignHtml = renderSignBox('ผู้รับมอบ / ผู้แจ้งงาน', hr.issuerSign, `แผนก ${selectedJob.group || '-'}`);

        const logoUrl = 'https://i.postimg.cc/y89YMCnp/logo_ttm_new_1_150x152_(1).png';
        const printContent = `
        <html>
        <head>
            <title>Project Handover Report - ${linkedProject.projectName}</title>
            <link href="https://fonts.googleapis.com/css2?family=Sarabun:ital,wght@0,300;0,400;0,600;0,700;1,400&display=swap" rel="stylesheet">
            <style>
                body { font-family: 'Sarabun', sans-serif; padding: 0; margin: 0; color: #000; font-size: 14px; line-height: 1.5; }
                .header { display: flex; justify-content: space-between; align-items: flex-start; border-bottom: 2px solid #0f172a; padding-bottom: 10px; margin-bottom: 15px; }
                .logo { height: 70px; width: auto; object-fit: contain; }
                .title-area { text-align: right; }
                .doc-title { font-size: 20px; font-weight: 700; margin: 0 0 5px 0; color: #0f172a; text-transform: uppercase; }
                .doc-sub { font-size: 15px; color: #475569; margin: 0; }
                
                .section { margin-bottom: 20px; }
                .sec-title { font-size: 15px; font-weight: 700; background: #e2e8f0; padding: 4px 10px; border-left: 4px solid #3b82f6; margin-bottom: 10px; display: inline-block; width: calc(100% - 20px); }
                
                table { width: 100%; border-collapse: collapse; margin-bottom: 10px; font-size: 13px; }
                th, td { border: 1px solid #cbd5e1; padding: 8px; text-align: left; vertical-align: top; }
                th { background: #f8fafc; width: 25%; font-weight: 600; color: #334155; }
                
                .result-pass { color: #16a34a; font-weight: bold; }
                .result-cond { color: #d97706; font-weight: bold; }
                .result-fail { color: #dc2626; font-weight: bold; }

                .signature-box { display: flex; justify-content: space-between; margin-top: 40px; page-break-inside: avoid; }
                .sign-item { width: 30%; text-align: center; }
                .sign-line { border-bottom: 1px solid #000; margin-bottom: 5px; height: 35px; }
                .sign-item p { margin: 0; line-height: 1.5; font-size: 13px; }
                
                @media print { @page { size: A4 portrait; margin: 5mm; } body { -webkit-print-color-adjust: exact; print-color-adjust: exact; padding: 10px; } }
            </style>
        </head>
        <body>
            <div class="header">
                <img src="${logoUrl}" class="logo" alt="TTM Logo" onerror="this.style.display='none'"/>
                <div class="title-area">
                    <h1 class="doc-title">Project Handover & Evaluation Report</h1>
                    <p class="doc-sub">รายงานการทดสอบและส่งมอบโครงการ</p>
                    <p style="margin: 5px 0 0 0; font-size: 11px; color: #64748b;">พิมพ์อ้างอิงเมื่อ: ${new Date().toLocaleString('th-TH')} | พิมพ์โดย: ${userData.name}</p>
                </div>
            </div>

            <div class="section">
                <div class="sec-title">1. ข้อมูลทั่วไปของโครงการ (General Information)</div>
                <table>
                    <tr><th>ชื่อโครงการ (Project Name)</th><td colspan="3"><b style="font-size: 15px;">${linkedProject.projectName}</b></td></tr>
                    <tr><th>รหัสอ้างอิง (Ref No.)</th><td>${selectedJob.projectNo || '-'}</td><th>ผู้รับผิดชอบหลัก (Owner)</th><td>${linkedProject.owner}</td></tr>
                    <tr><th>ผู้แจ้งงาน (Requestor)</th><td>${selectedJob.requestBy || '-'}</td><th>แผนกผู้แจ้ง (Department)</th><td>${selectedJob.group || '-'}</td></tr>
                    <tr><th>วันที่เริ่มแผน (Plan Start)</th><td>${linkedProject.projectPlanStart ? new Date(linkedProject.projectPlanStart).toLocaleDateString('th-TH') : '-'}</td><th>วันที่สร้างเอกสาร (Doc Date)</th><td>${new Date(hr.generatedAt).toLocaleDateString('th-TH')}</td></tr>
                </table>
            </div>

            <div class="section">
                <div class="sec-title">2. ขอบเขตและรายละเอียด (Project Scope & Detail)</div>
                <table>
                    <tr><th>วัตถุประสงค์ (Why)</th><td>${selectedJob.why || '-'}</td></tr>
                    <tr><th>ลักษณะงาน/ปัญหา (What)</th><td>${selectedJob.what || '-'}</td></tr>
                    <tr><th>วิธีการดำเนินงาน (How)</th><td>${selectedJob.how || '-'}</td></tr>
                </table>
            </div>

            <div class="section">
                <div class="sec-title">3. สรุปผลการทดสอบและประเมิน (Validation & Evaluation)</div>
                <table>
                    <tr><th>สรุปผลการทดสอบ<br><span style="font-size:10px; font-weight:normal; color:#64748b;">(Test Summary / Result)</span></th><td style="min-height: 80px; white-space: pre-line;">${hr.testSummary || '-'}</td></tr>
                    <tr><th>ประสิทธิภาพที่ได้ / สิ่งที่ปรับปรุง<br><span style="font-size:10px; font-weight:normal; color:#64748b;">(Efficiency / Improvement)</span></th><td style="white-space: pre-line;">${hr.efficiencyGain || '-'}</td></tr>
                    <tr><th>ผลการประเมิน<br><span style="font-size:10px; font-weight:normal; color:#64748b;">(Evaluation Status)</span></th>
                        <td style="font-size: 15px;">
                            ${hr.isPass === 'Pass' ? '<span class="result-pass">☑️ ผ่านเกณฑ์ (Passed) - พร้อมใช้งาน</span>' : 
                              hr.isPass === 'Conditional' ? '<span class="result-cond">⚠️ ผ่านแบบมีเงื่อนไข (Passed with condition) - ต้องติดตามผล</span>' : 
                              '<span class="result-fail">❌ ไม่ผ่าน (Failed) - ต้องปรับปรุงแก้ไข</span>'}
                        </td>
                    </tr>
                </table>
            </div>

            <div class="signature-box">
                ${ownerSignHtml}
                ${approverSignHtml}
                ${issuerSignHtml}
            </div>
            <script>window.onload = function() { setTimeout(function() { window.print(); }, 500); }</script>
        </body>
        </html>
        `;
        const printWin = window.open('', '_blank');
        if (printWin) { printWin.document.open(); printWin.document.write(printContent); printWin.document.close(); } 
        else { alert('เบราว์เซอร์บล็อก Pop-up!'); }
    };

    const handleESignReport = async (roleType) => {
        if (!linkedProject || !linkedProject.handoverReport) return;
        if (!window.confirm('ยืนยันการประทับตรา E-Signature เพื่อรับรองเอกสารนี้?')) return;
        
        try {
            setIsSubmitting(true);
            const signData = { name: userData.name, date: new Date().toISOString() };
            const fieldToUpdate = roleType === 'approver' ? 'handoverReport.approverSign' : 'handoverReport.issuerSign';
            
            const projectUpdatePayload = { [fieldToUpdate]: signData };
            
            if (roleType === 'issuer') projectUpdatePayload.status = 'Accepted';
            
            await updateDoc(doc(db, 'td_projects', linkedProject.id), projectUpdatePayload);
            
            if (roleType === 'issuer') {
                await updateDoc(doc(db, 'td_job_requests', selectedJob.id), { 
                    status: 'Accepted', 
                    timeline: arrayUnion({ 
                        status: 'Accepted', 
                        by: userData.name, 
                        comment: 'ประทับตรา E-Signature รับมอบงานเรียบร้อยแล้ว', 
                        timestamp: new Date().toISOString() 
                    }) 
                });
                await logActivity(user, 'E-Signed Document', `ประทับตารับมอบงานในตั๋ว ${selectedJob.projectNo} สำเร็จ`);
                alert('เซ็นรับมอบงานสำเร็จ! ปิดตั๋วงานเรียบร้อย');
                handleCloseModal();
            } else {
                await logActivity(user, 'E-Signed Document', `ประทับตราตรวจสอบ (Manager) ในตั๋ว ${selectedJob.projectNo} สำเร็จ`);
                alert('ประทับตราอนุมัติ E-Signature สำเร็จ!');
            }
        } catch (error) {
            console.error(error); 
            alert('เกิดข้อผิดพลาดในการเซ็นเอกสาร');
        } finally {
            setIsSubmitting(false);
        }
    };

    const getCount = (status) => activeJobs.filter(j => j.status === status).length;

    const getActorByStatus = (job, targetStatusArray) => {
        for (let i = (job.timeline?.length || 0) - 1; i >= 0; i--) {
            if (targetStatusArray.includes(job.timeline[i].status)) return job.timeline[i].by;
        }
        return 'รอผู้ดำเนินการ';
    };

    const myTasksCount = activeJobs.filter(isMyTask).length;

    // 🌟 ดักสิทธิ์เข้าถึง: TD ปกติจะโดนบล็อคไม่ให้เห็นหน้านี้เลย 🌟
    if (userData?.dept === 'TD' && userData?.role !== 'Admin') {
        return (
            <div className="h-full flex flex-col items-center justify-center text-text bg-surface">
                <i className="fas fa-user-shield text-6xl mb-4 text-red-500 opacity-50"></i>
                <h2 className="text-2xl font-bold text-text mb-2">Restricted Area</h2>
                <p className="text-sm">หน้านี้สงวนไว้สำหรับแผนกต้นทาง (ผู้แจ้งงาน) เท่านั้น</p>
                <p className="text-xs text-text mt-1">เจ้าหน้าที่ TD โปรดใช้เมนู TD Workspace ในการจัดการงาน</p>
                <button onClick={() => navigate('/td-workspace')} className="mt-6 bg-purple-600 hover:bg-purple-500 text-text px-6 py-2.5 rounded-lg text-sm font-bold shadow-lg transition">
                    <i className="fas fa-laptop-code mr-2"></i> ไปที่ TD Workspace
                </button>
            </div>
        );
    }

    if (loading) return <div className="flex justify-center items-center h-full"><div className="animate-spin rounded-full h-12 w-12 border-t-2 border-blue-500"></div></div>;

    const JobCard = ({ job, barColor, statusColor }) => (
        <div onClick={() => { setSelectedJob(job); setModalAction(''); setActionComment(''); setAssignTarget(''); setJobCategory(''); }} className="bg-surface rounded-xl p-4 mb-3 cursor-pointer hover:-translate-y-1 hover:shadow-lg transition-all relative border border-glass shadow-md">
            <div className={`absolute left-0 top-0 bottom-0 w-1.5 ${barColor}`}></div>
            <div className="flex justify-between items-start mb-2 pl-1">
                <span className="font-bold text-[13px] text-primary truncate pr-2 w-3/4">{job.projectNo}</span>
                <span className={`text-[9px] px-2 py-0.5 rounded text-text font-bold ${statusColor} shrink-0 shadow-sm`}>{job.status}</span>
            </div>
            <div className="text-xs text-text mt-2 line-clamp-2 leading-relaxed border-l-2 pl-2 border-glass ml-1">
                <span className="font-bold text-text">What:</span> {job.what || '-'}
            </div>
            <div className="flex justify-between items-end mt-3 pt-2 pl-1 text-[10px]">
                <span className="text-text font-medium"><i className="fas fa-user-circle text-text"></i> {job.requestBy}</span>
                <span className="bg-surface px-2 py-0.5 rounded border border-glass font-bold text-text">{job.group}</span>
            </div>
        </div>
    );

    return (
        <div className="h-full flex flex-col pb-6 relative">
            <div className="flex flex-col xl:flex-row justify-between items-start xl:items-center mb-6 border-b border-glass pb-4 gap-4">
                
                {/* 🌟 ส่วน Header ซ้าย: ชื่อหน้า และ สวิตช์ตึก 🌟 */}
                <div className="flex items-center gap-4">
                    <h1 className="text-2xl font-bold text-primary"><i className="fas fa-wrench mr-2"></i> TD Job Request</h1>
                    
                    {/* Toggle Switch */}
                    <div className="flex items-center gap-3 bg-surface/80 px-4 py-1.5 rounded-full border border-1 shadow-inner ml-4">
                        <span className={`text-xs font-bold transition-colors ${!isTowerMode ? 'text-primary' : 'text-text/40'}`}>Normal</span>
                        <button
                            onClick={() => setIsTowerMode(!isTowerMode)}
                            className={`w-12 h-6 flex items-center rounded-full p-1 transition-colors duration-300 focus:outline-none ${isTowerMode ? 'bg-primary border border-glass shadow-inner' : 'bg-surface border border-glass shadow-inner'}`}
                        >
                            <div className={`w-4 h-4 rounded-full shadow-md transform transition-transform duration-300 ${isTowerMode ? 'bg-white border-1 translate-x-6' : 'bg-white border-1 translate-x-0'}`}></div>
                        </button>
                        <span className={`text-xs font-bold transition-colors flex items-center gap-1 ${isTowerMode ? 'text-primary neon-text' : 'text-text/40'}`}>
                            <i className="fas fa-building"></i> AutoPilot
                        </span>
                    </div>
                </div>

                {/* 🌟 ซ่อน Tab หากเปิดโหมดตึกอยู่ 🌟 */}
                {!isTowerMode && (
                    <div className="flex bg-surface p-1.5 rounded-xl border border-glass shadow-inner w-full xl:w-auto overflow-x-auto">
                        <button onClick={() => setActiveTab('kanban')} className={`flex-1 xl:flex-none whitespace-nowrap px-5 py-2 text-sm font-bold rounded-lg transition-all ${activeTab === 'kanban' ? 'bg-blue-600 text-text' : 'text-text hover:text-text'}`}>Kanban</button>
                        
                        <button onClick={() => setActiveTab('mytasks')} className={`flex-1 xl:flex-none whitespace-nowrap px-5 py-2 text-sm font-bold rounded-lg transition-all flex items-center justify-center gap-2 ${activeTab === 'mytasks' ? 'bg-green-600 text-text' : 'text-text hover:text-text'}`}>
                            My Tasks
                            {myTasksCount > 0 && <span className="bg-red-500 text-text text-[10px] px-2 py-0.5 rounded-full animate-pulse">{myTasksCount}</span>}
                        </button>
                        
                        <button onClick={() => setActiveTab('history')} className={`flex-1 xl:flex-none whitespace-nowrap px-5 py-2 text-sm font-bold rounded-lg transition-all ${activeTab === 'history' ? 'bg-purple-600 text-text' : 'text-text hover:text-text'}`}>History</button>
                        
                        <button onClick={() => setActiveTab('issue')} className={`flex-1 xl:flex-none whitespace-nowrap px-5 py-2 text-sm font-bold rounded-lg transition-all ${activeTab === 'issue' ? 'bg-orange-600 text-text' : 'text-text hover:text-text'}`}>+ Issue Job</button>
                    </div>
                )}
            </div>

            {myTasksCount > 0 && activeTab !== 'mytasks' && !isTowerMode && (
                <div className="bg-red-900/40 border border-red-500/50 text-red-200 p-3 rounded-xl mb-4 flex items-center justify-between shadow-lg">
                    <div className="flex items-center">
                        <i className="fas fa-bell text-red-400 text-xl mr-3 animate-bounce"></i>
                        <div>
                            <h3 className="font-bold text-sm text-red-500">คุณมีงานที่ต้องจัดการ ({myTasksCount} งาน)</h3>
                            <p className="text-[10px] text-red-500/80 mt-0.5">กรุณาตรวจสอบและดำเนินการในแท็บ My Tasks</p>
                        </div>
                    </div>
                    <button onClick={() => setActiveTab('mytasks')} className="bg-red-600 hover:bg-red-500 text-text px-4 py-2 rounded-lg text-xs font-bold transition shadow-md whitespace-nowrap">
                        ดูงานของฉัน
                    </button>
                </div>
            )}

            <div className="flex-1 overflow-hidden flex flex-col relative">
                
                {/* 🌟 ใช้งานโหมดตึก หรือ โหมดแท็บปกติ 🌟 */}
                {isTowerMode ? (
                    <AutoPilotTower 
                        activeJobs={activeJobs} 
                        onClickJob={(job, defaultAction = '') => {
                            setSelectedJob(job); // เปิด Modal โดยตั้งค่า selectedJob
                            
                            // ถ้าถูกส่งมาจากปุ่ม "แก้ไขข้อมูล 5W1H" ชั้นใต้ดิน ให้เตรียมข้อมูลรอไว้เลย
                            if (defaultAction === 'Resubmit') {
                                setEditFormData({
                                    what: job.what || '', who: job.who || '',
                                    when: job.when || '', where: job.where || '',
                                    why: job.why || '', how: job.how || '',
                                    cost: job.cost || '', dueDate: job.dueDate || ''
                                });
                                setModalAction('Resubmit');
                            } else {
                                setModalAction(''); // ล้าง Action เดิม
                            }
                        }}
                    />
                ) : (
                    <>
                        {/* TAB: KANBAN */}
                        {activeTab === 'kanban' && (
                            <div className="grid grid-cols-1 md:grid-cols-4 gap-4 h-full overflow-y-auto pb-4 custom-scrollbar">
                                {['Issued', 'Approved', 'In Progress', 'Completed'].map((status, idx) => {
                                    const colors = ['orange', 'yellow', 'blue', 'green'];
                                    const c = colors[idx];
                                    return (
                                        <div key={status} className={`bg-surface/40 rounded-2xl p-4 border-t-4 border-${c}-500 flex flex-col h-full shadow-inner border-l border-r border-b border-glass`}>
                                            <h3 className={`font-bold mb-4 text-${c}-400 flex justify-between items-center`}>
                                                <span>{status}</span>
                                                <span className={`bg-${c}-500/20 text-${c}-300 px-2.5 py-0.5 rounded-full text-xs border border-${c}-500/30`}>{getCount(status)}</span>
                                            </h3>
                                            <div className="flex-1 overflow-y-auto pr-1 custom-scrollbar space-y-3">
                                                {activeJobs.filter(j => j.status === status).map(job => <JobCard key={job.id} job={job} barColor={`bg-${c}-500`} statusColor={`text-${c}-500 bg-${c}-500/20`} />)}
                                                {getCount(status) === 0 && <p className="text-center text-text text-xs py-8 border-2 border-dashed border-glass rounded-xl mt-2">ไม่มีรายการ</p>}
                                            </div>
                                        </div>
                                    )
                                })}
                            </div>
                        )}

                        {/* TAB: MY TASKS */}
                        {activeTab === 'mytasks' && (
                            <div className="bg-surface/50 rounded-2xl p-4 h-full overflow-y-auto custom-scrollbar border border-glass shadow-xl">
                                {activeJobs.filter(isMyTask).map(job => (
                                    <div key={job.id} onClick={() => { setSelectedJob(job); setModalAction(''); setActionComment(''); setAssignTarget(''); setJobCategory(''); }} className="bg-surface border border-glass p-5 rounded-xl flex flex-col md:flex-row justify-between items-start md:items-center gap-4 hover:border-purple-500 transition shadow-lg mb-3 cursor-pointer group">
                                        <div>
                                            <div className="font-bold text-primary text-lg flex items-center gap-3">
                                                {job.projectNo} <span className="text-[10px] bg-red-500/20 text-red-400 px-2 py-0.5 rounded font-bold uppercase border border-red-500/50 flex items-center"><span className="w-1.5 h-1.5 bg-red-500 rounded-full mr-1.5 animate-pulse"></span> {job.status}</span>
                                            </div>
                                            <div className="text-sm text-text mt-2"><span className="font-bold text-text">What: </span>{job.what || '-'}</div>
                                        </div>
                                        <div className="text-right text-xs text-text">
                                            <div><i className="fas fa-user-circle"></i> {job.requestBy} ({job.group})</div>
                                            <div className="mt-1"><i className="fas fa-calendar-alt"></i> {job.createdAt?.toDate ? job.createdAt.toDate().toLocaleDateString('th-TH') : '-'}</div>
                                        </div>
                                    </div>
                                ))}
                                {activeJobs.filter(isMyTask).length === 0 && (
                                    <div className="flex flex-col items-center justify-center h-full text-text">
                                        <i className="fas fa-check-circle text-7xl mb-4 text-green-500/30"></i>
                                        <p className="text-xl font-bold text-text mb-2">ไม่มีงานรอการจัดการ</p>
                                    </div>
                                )}
                            </div>
                        )}

                        {/* TAB: HISTORY */}
                        {activeTab === 'history' && (
                            <div className="bg-surface rounded-2xl border border-glass shadow-xl flex-1 flex flex-col overflow-hidden">
                                <div className="p-4 border-b border-glass bg-surface/50 flex gap-2">
                                    <div className="relative w-full max-w-md">
                                        <i className="fas fa-search absolute left-4 top-1/2 transform -translate-y-1/2 text-text"></i>
                                        <input type="text" placeholder="ค้นหา Project No..." value={historySearch} onChange={(e) => setHistorySearch(e.target.value)} className="w-full bg-surface border border-glass rounded-full pl-11 pr-4 py-2 text-text text-sm focus:outline-none focus:border-purple-500" />
                                    </div>
                                    <button onClick={() => setIsScanning(true)} className="bg-blue-600 hover:bg-blue-500 text-text px-4 py-2 rounded-full shadow-lg text-sm font-bold flex items-center transition">
                                        <i className="fas fa-qrcode mr-2 text-lg"></i> Scan QR
                                    </button>
                                </div>
                                <div className="overflow-x-auto flex-1 custom-scrollbar">
                                    <table className="w-full text-left border-collapse whitespace-nowrap">
                                        <thead className="bg-surface text-text text-xs uppercase border-b border-glass sticky top-0 z-10">
                                            <tr>
                                                <th className="p-4 font-bold">Project No.</th>
                                                <th className="p-4 font-bold">Date</th>
                                                <th className="p-4 font-bold">Type</th>
                                                <th className="p-4 font-bold">Req By (Group)</th>
                                                <th className="p-4 font-bold">Status</th>
                                            </tr>
                                        </thead>
                                        <tbody className="divide-y divide-gray-700 text-sm text-text">
                                            {historyJobs.filter(j => j.projectNo?.toLowerCase().includes(historySearch.toLowerCase())).map(job => (
                                                <tr key={job.id} onClick={() => { setSelectedJob(job); setModalAction(''); setActionComment(''); setAssignTarget(''); setJobCategory(''); }} className="hover:bg-surface transition-colors cursor-pointer">
                                                    <td className="p-4 font-bold text-primary">{job.projectNo}</td>
                                                    <td className="p-4 text-xs text-text">{job.createdAt?.toDate ? job.createdAt.toDate().toLocaleDateString('th-TH') : '-'}</td>
                                                    <td className="p-4">{job.jobType}</td>
                                                    <td className="p-4">{job.requestBy} <span className="text-text font-bold ml-1">({job.group})</span></td>
                                                    <td className="p-4 font-bold">{job.status}</td>
                                                </tr>
                                            ))}
                                            
                                            {hasMoreHistory && !historySearch && (
                                                <tr>
                                                    <td colSpan="5" className="p-6 text-center bg-surface/30">
                                                        <button 
                                                            onClick={() => setHistoryLimit(prev => prev + 20)} 
                                                            className="bg-surface hover:bg-surface text-primary border border-blue-500/30 px-6 py-2.5 rounded-full text-xs font-bold shadow-lg transition-all flex items-center justify-center mx-auto gap-2"
                                                        >
                                                            <i className="fas fa-chevron-down"></i> โหลดประวัติเพิ่มเติม (Load More)
                                                        </button>
                                                    </td>
                                                </tr>
                                            )}
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        )}

                        {/* TAB: ISSUE JOB */}
                        {activeTab === 'issue' && (
                            <div className="bg-surface rounded-2xl p-8 h-full overflow-y-auto border border-glass custom-scrollbar shadow-xl">
                                <form onSubmit={handleIssueSubmit} className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-4xl mx-auto">
                                    <div className="md:col-span-2 bg-surface/60 p-6 rounded-xl border border-glass shadow-inner">
                                        <label className="block text-base text-primary mb-4 font-bold border-b border-glass pb-2">
                                            <i className="fas fa-info-circle mr-2"></i> ข้อมูลทั่วไป (General Info)
                                        </label>
                                        <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
                                            <div><label className="block text-xs text-text mb-1 font-bold">ประเภทงาน *</label><select name="jobType" value={formData.jobType} onChange={handleChange} className="w-full p-2.5 bg-surface rounded-lg border border-glass text-text focus:border-blue-500 outline-none" required style={{ backgroundColor: 'var(--color-bg)', color: 'var(--color-text)' }}><option value="">-- เลือก --</option><option value="สร้างใหม่">สร้างใหม่</option><option value="ซ่อมแก้ไข">ซ่อมแก้ไข</option><option value="อื่นๆ">อื่นๆ</option></select></div>
                                            <div>
                                                <label className="block text-xs text-text mb-1 font-bold">แผนก *</label>
                                                <select name="group" value={formData.group} onChange={handleChange} className="w-full p-2.5 bg-surface rounded-lg border border-glass text-text focus:border-blue-500 outline-none" required style={{ backgroundColor: 'var(--color-bg)', color: 'var(--color-text)' }}>
                                                    <option value="">-- เลือก --</option>
                                                    {DEPT_OPTIONS.map(d => <option key={d} value={d}>{d}</option>)}
                                                </select>
                                            </div>
                                            <div><label className="block text-xs text-text mb-1 font-bold">ส่งงานให้ (TD)</label><select name="assignTo" value={formData.assignTo} onChange={handleChange} className="w-full p-2.5 bg-surface rounded-lg border border-glass text-text focus:border-blue-500 outline-none" style={{ backgroundColor: 'var(--color-bg)', color: 'var(--color-text)' }}><option value="">-- กองกลาง --</option>{tdUsers.map(u => <option key={u.name} value={u.name}>{u.name}</option>)}</select></div>
                                        </div>
                                    </div>
                                    
                                    <div className="md:col-span-2 grid grid-cols-1 md:grid-cols-2 gap-5 mt-2">
                                        <div className="md:col-span-2"><label className="block text-xs text-text mb-1 font-bold">1. What? เกิดอะไรขึ้น *</label><textarea name="what" value={formData.what} onChange={handleChange} className="w-full p-3 bg-surface/80 rounded-lg border border-glass text-text focus:border-blue-500 outline-none" rows="2" required></textarea></div>
                                        <div><label className="block text-xs text-text mb-1 font-bold">2. Who? ใคร/สินค้าอะไร *</label><input type="text" name="who" value={formData.who} onChange={handleChange} className="w-full p-2.5 bg-surface/80 rounded-lg border border-glass text-text focus:border-blue-500 outline-none" required/></div>
                                        <div><label className="block text-xs text-text mb-1 font-bold">3. When? เกิดขึ้นเมื่อไหร่ *</label><input type="text" name="when" value={formData.when} onChange={handleChange} className="w-full p-2.5 bg-surface/80 rounded-lg border border-glass text-text focus:border-blue-500 outline-none" required/></div>
                                        <div><label className="block text-xs text-text mb-1 font-bold">4. Where? ที่ไหน *</label><input type="text" name="where" value={formData.where} onChange={handleChange} className="w-full p-2.5 bg-surface/80 rounded-lg border border-glass text-text focus:border-blue-500 outline-none" required/></div>
                                        <div><label className="block text-xs text-text mb-1 font-bold">5. Why? สาเหตุ *</label><input type="text" name="why" value={formData.why} onChange={handleChange} className="w-full p-2.5 bg-surface/80 rounded-lg border border-glass text-text focus:border-blue-500 outline-none" required/></div>
                                        <div className="md:col-span-2"><label className="block text-xs text-text mb-1 font-bold">6. How? สิ่งที่อยากให้ทำ *</label><textarea name="how" value={formData.how} onChange={handleChange} className="w-full p-3 bg-surface/80 rounded-lg border border-glass text-text focus:border-blue-500 outline-none" rows="2" required></textarea></div>
                                    </div>
                                    
                                    <div className="md:col-span-2 grid grid-cols-1 md:grid-cols-2 gap-5 mt-2">
                                        <div className="bg-red-900/20 p-4 rounded-xl border border-red-500/30"><label className="block text-xs text-red-400 mb-1 font-bold">Cost Estimate (THB)</label><input type="number" name="cost" value={formData.cost} onChange={handleChange} className="w-full p-2.5 bg-surface/80 rounded-lg border border-glass text-text focus:border-red-500 outline-none"/></div>
                                        <div className="bg-green-900/20 p-4 rounded-xl border border-green-500/30"><label className="block text-xs text-green-400 mb-1 font-bold">Due Date *</label><input type="date" name="dueDate" value={formData.dueDate} onChange={handleChange} className="w-full p-2.5 bg-surface/80 rounded-lg border border-glass text-text focus:border-green-500 outline-none" required/></div>
                                    </div>

                                    <div className="md:col-span-2 mt-2 bg-surface/50 p-5 rounded-xl border border-glass shadow-inner">
                                        <label className="block text-sm text-primary mb-3 font-bold"><i className="fas fa-cloud-upload-alt mr-2"></i> แนบไฟล์อ้างอิง</label>
                                        
                                        <div className="flex flex-col gap-2 mb-3">
                                            {jobAttachments.map((file, idx) => (
                                                <div key={idx} className="bg-surface border border-glass p-2 rounded-lg flex justify-between items-center">
                                                    <a href={file.url} target="_blank" rel="noreferrer" className="text-xs text-text hover:text-primary truncate">{file.title}</a>
                                                    <button type="button" onClick={() => setJobAttachments(jobAttachments.filter(f => f.id !== file.id))} className="text-text hover:text-red-500 text-xs transition"><i className="fas fa-trash"></i></button>
                                                </div>
                                            ))}
                                        </div>

                                        <div className="flex flex-col md:flex-row gap-2 items-center">
                                            <input type="text" value={attachTitle} onChange={(e)=>setAttachTitle(e.target.value)} placeholder="ตั้งชื่อไฟล์ (เช่น รูปหน้างาน)" className="w-full md:w-1/3 p-2.5 bg-surface rounded-lg border border-glass text-xs text-text focus:border-blue-500 outline-none" disabled={isUploading}/>
                                            <input type="file" ref={fileInputRef} onChange={(e)=>setSelectedFile(e.target.files[0])} className="w-full md:w-1/3 text-xs text-text file:mr-2 file:py-1.5 file:px-3 file:rounded-lg file:border-0 file:bg-surface file:text-text hover:file:bg-surface cursor-pointer bg-surface border border-glass rounded-lg pr-1" disabled={isUploading}/>
                                            <button type="button" onClick={handleFileUpload} disabled={!selectedFile || !attachTitle || isUploading} className="w-full md:w-1/3 bg-green-600 hover:bg-green-500 text-text py-2.5 rounded-lg text-xs font-bold transition disabled:opacity-50 shadow">
                                                {isUploading ? <i className="fas fa-spinner fa-spin"></i> : 'อัปโหลด'}
                                            </button>
                                        </div>
                                    </div>

                                    <div className="md:col-span-2 flex justify-end gap-3 mt-4 pt-6 border-t border-glass">
                                        <button type="submit" disabled={isSubmitting} className="bg-blue-600 hover:bg-blue-500 text-text px-10 py-3 rounded-xl font-bold shadow-xl transition disabled:opacity-50">
                                            {isSubmitting ? 'กำลังบันทึก...' : 'บันทึก Ticket'}
                                        </button>
                                    </div>
                                </form>
                            </div>
                        )}
                    </>
                )}
            </div>

            {/* Modal ตรวจสอบ/จัดการ Job */}
            {selectedJob && (
                <div className="fixed inset-0 bg-black/10 flex justify-center items-center z-50 p-4 backdrop-blur-sm">
                    <div className="bg-surface w-full max-w-4xl rounded-2xl shadow-2xl border border-glass overflow-hidden flex flex-col max-h-[95vh]">
                        
                        <div className="bg-surface p-6 border-b border-glass relative shrink-0">
                            <button onClick={handleCloseModal} className="absolute top-4 right-4 text-text hover:text-red-500 text-2xl font-bold">&times;</button>
                            <h2 className="text-xl font-bold text-text mb-6"><i className="fas fa-subway text-primary mr-2"></i> สถานะการดำเนินงาน (Status Tracking)</h2>
                            
                            {(() => {
                                const st = selectedJob.status;
                                let level = 1, isReject = false, isRevise = false;
                                if (st === 'Approved') level = 2;
                                else if (st === 'Reject') { level = 2; isReject = true; }
                                else if (st === 'Revise') { level = 1; isRevise = true; }
                                else if (['In Progress', 'Received'].includes(st)) level = 3;
                                else if (st === 'TD Reject') { level = 3; isReject = true; }
                                else if (st === 'Completed') level = 4;
                                else if (st === 'Accepted') level = 5;

                                const widths = ['0%', '25%', '50%', '75%', '100%'];
                                const lineWidth = isReject ? widths[level-2] : widths[level-1];
                                const lineColor = (isReject || isRevise) ? 'bg-red-500' : 'bg-green-500';

                                const getStepClass = (stepLevel) => {
                                    if (stepLevel === level) {
                                        if (isReject) return 'bg-red-600 border-red-400 text-text shadow-[0_0_15px_rgba(239,68,68,0.8)]';
                                        if (isRevise) return 'bg-pink-600 border-pink-400 text-text shadow-[0_0_15px_rgba(236,72,153,0.8)]';
                                        if (level === 5) return 'bg-green-600 border-green-400 text-text shadow-[0_0_15px_rgba(34,197,94,0.8)]';
                                        return 'bg-blue-600 border-blue-400 text-text shadow-[0_0_15px_rgba(59,130,246,0.8)]';
                                    } else if (stepLevel < level) return 'bg-green-600 border-green-400 text-text shadow-[0_0_10px_rgba(34,197,94,0.3)]';
                                    return 'bg-surface border-glass text-text';
                                };

                                return (
                                    <div className="flex items-start justify-between w-full relative px-2 md:px-8 mt-4 mb-2">
                                        <div className="absolute left-14 right-14 top-5 h-1.5 bg-surface z-0 rounded-full"></div>
                                        <div className="absolute left-14 right-14 top-5 h-1.5 z-0 rounded-full overflow-hidden">
                                            <div className={`h-full ${lineColor} transition-all duration-500`} style={{ width: lineWidth }}></div>
                                        </div>
                                        
                                        <div className="flex flex-col items-center w-24 z-10">
                                            <div className={`w-10 h-10 rounded-full flex items-center justify-center transition-all border-2 ${getStepClass(1)}`}><i className="fas fa-file-alt text-base"></i></div>
                                            <span className="text-[11px] md:text-xs font-bold mt-2 text-text">{isRevise ? 'ส่งกลับแก้ไข' : 'Issued'}</span>
                                            <span className="text-[9px] md:text-[10px] text-text text-center leading-tight mt-1 line-clamp-2">{getActorByStatus(selectedJob, ['Issued', 'Revise'])}</span>
                                        </div>
                                        <div className="flex flex-col items-center w-24 z-10">
                                            <div className={`w-10 h-10 rounded-full flex items-center justify-center transition-all border-2 ${getStepClass(2)}`}><i className="fas fa-check-double text-base"></i></div>
                                            <span className="text-[11px] md:text-xs font-bold mt-2 text-text">{isReject && level===2 ? 'Rejected' : 'Approved'}</span>
                                            <span className="text-[9px] md:text-[10px] text-text text-center leading-tight mt-1 line-clamp-2">{getActorByStatus(selectedJob, ['Approved', 'Reject']) || 'รออนุมัติ'}</span>
                                        </div>
                                        <div className="flex flex-col items-center w-24 z-10">
                                            <div className={`w-10 h-10 rounded-full flex items-center justify-center transition-all border-2 ${getStepClass(3)}`}><i className="fas fa-cogs text-base"></i></div>
                                            <span className="text-[11px] md:text-xs font-bold mt-2 text-text">{isReject && level===3 ? 'TD Reject' : 'In Progress'}</span>
                                            <span className="text-[9px] md:text-[10px] text-text text-center leading-tight mt-1 line-clamp-2">{getActorByStatus(selectedJob, ['In Progress', 'Received', 'TD Reject']) || 'รอรับงาน'}</span>
                                        </div>
                                        <div className="flex flex-col items-center w-24 z-10">
                                            <div className={`w-10 h-10 rounded-full flex items-center justify-center transition-all border-2 ${getStepClass(4)}`}><i className="fas fa-flag-checkered text-base"></i></div>
                                            <span className="text-[11px] md:text-xs font-bold mt-2 text-text">Completed</span>
                                            <span className="text-[9px] md:text-[10px] text-text text-center leading-tight mt-1 line-clamp-2">{level >= 4 ? selectedJob.assignTo : 'รอจบงาน'}</span>
                                        </div>
                                        <div className="flex flex-col items-center w-24 z-10">
                                            <div className={`w-10 h-10 rounded-full flex items-center justify-center transition-all border-2 ${getStepClass(5)}`}><i className="fas fa-handshake text-base"></i></div>
                                            <span className="text-[11px] md:text-xs font-bold mt-2 text-text">Accepted</span>
                                            <span className="text-[9px] md:text-[10px] text-text text-center leading-tight mt-1 line-clamp-2">{level >= 5 ? selectedJob.requestBy : 'รอตรวจรับ'}</span>
                                        </div>
                                    </div>
                                );
                            })()}
                        </div>

                        <div className="flex flex-col md:flex-row p-6 gap-6 overflow-y-auto custom-scrollbar flex-1">
                            
                            <div className="md:w-1/3 flex flex-col items-center border border-glass p-4 rounded-xl bg-surface/50 shadow-sm relative overflow-hidden h-fit">
                                <div className="absolute top-0 w-full h-2 bg-blue-600 left-0"></div>
                                <img src={`https://quickchart.io/qr?text=${encodeURIComponent(selectedJob.projectNo)}&size=200`} alt="QR" className="h-40 w-40 mb-4 bg-surface p-2 rounded-lg" />
                                <p className="font-black text-sm text-primary break-all text-center mb-2">{selectedJob.projectNo}</p>
                                <span className={`px-4 py-1.5 rounded-full text-text font-bold text-xs shadow mb-4 ${
                                    selectedJob.status.includes('Reject') ? 'bg-red-500' : 
                                    selectedJob.status === 'Revise' ? 'bg-pink-500' : 
                                    selectedJob.status.includes('Completed') || selectedJob.status === 'Accepted' ? 'bg-green-500' : 'bg-blue-500'
                                }`}>{selectedJob.status}</span>
                                
                                <div className="w-full text-xs text-text border-t border-glass pt-4 space-y-3">
                                    <p className="flex justify-between border-b border-glass/50 pb-2"><span>Req By :</span> <strong className="text-text text-right">{selectedJob.requestBy}</strong></p>
                                    <p className="flex justify-between border-b border-glass/50 pb-2"><span>Req To :</span> <strong className="text-text text-right">{selectedJob.assignTo || '-'}</strong></p>
                                    <p className="flex justify-between border-b border-glass/50 pb-2"><span>Type :</span> <strong className="text-text text-right">{selectedJob.jobType}</strong></p>
                                    {selectedJob.jobCategory && <p className="flex justify-between border-b border-glass/50 pb-2"><span>Category :</span> <strong className="text-primary text-right">{selectedJob.jobCategory}</strong></p>}
                                    <p className="flex justify-between"><span>Issue Date :</span> <strong className="text-text text-right">{selectedJob.createdAt?.toDate ? selectedJob.createdAt.toDate().toLocaleDateString('th-TH') : '-'}</strong></p>
                                </div>
                                <button onClick={() => handlePrintTicket(selectedJob)} className="mt-6 w-full bg-purple-600 hover:bg-purple-700 text-text py-3 rounded-lg shadow-md text-xs font-bold transition flex items-center justify-center gap-2">
                                    <i className="fas fa-print text-base"></i> สั่งพิมพ์ Label
                                </button>
                            </div>

                            <div className="md:w-2/3 relative">
                                <h3 className="text-lg font-bold mb-4 text-primary border-b border-glass pb-2"><i className="fas fa-list-alt text-text mr-2"></i> รายละเอียดงาน (Details)</h3>
                                
                                {modalAction === 'Resubmit' ? (
                                    <div className="bg-surface/80 p-5 rounded-xl border border-orange-500/50 shadow-inner mb-4 animate-fade-in">
                                        <h4 className="text-orange-400 font-bold mb-4 text-sm"><i className="fas fa-edit mr-2"></i> ฟอร์มแก้ไขข้อมูล 5W1H</h4>
                                        <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mb-4">
                                            <div className="md:col-span-2">
                                                <label className="block text-xs text-text mb-1">1. What? เกิดอะไรขึ้น</label>
                                                <textarea name="what" value={editFormData.what} onChange={handleEditFormChange} className="w-full p-2.5 bg-surface rounded border border-glass text-text outline-none focus:border-orange-500 text-sm" rows="2" required></textarea>
                                            </div>
                                            <div>
                                                <label className="block text-xs text-text mb-1">2. Who? ใคร/สินค้าอะไร</label>
                                                <input type="text" name="who" value={editFormData.who} onChange={handleEditFormChange} className="w-full p-2.5 bg-surface rounded border border-glass text-text outline-none focus:border-orange-500 text-sm" required/>
                                            </div>
                                            <div>
                                                <label className="block text-xs text-text mb-1">3. When? เกิดขึ้นเมื่อไหร่</label>
                                                <input type="text" name="when" value={editFormData.when} onChange={handleEditFormChange} className="w-full p-2.5 bg-surface rounded border border-glass text-text outline-none focus:border-orange-500 text-sm" required/>
                                            </div>
                                            <div>
                                                <label className="block text-xs text-text mb-1">4. Where? ที่ไหน</label>
                                                <input type="text" name="where" value={editFormData.where} onChange={handleEditFormChange} className="w-full p-2.5 bg-surface rounded border border-glass text-text outline-none focus:border-orange-500 text-sm" required/>
                                            </div>
                                            <div>
                                                <label className="block text-xs text-text mb-1">5. Why? สาเหตุ</label>
                                                <input type="text" name="why" value={editFormData.why} onChange={handleEditFormChange} className="w-full p-2.5 bg-surface rounded border border-glass text-text outline-none focus:border-orange-500 text-sm" required/>
                                            </div>
                                            <div className="md:col-span-2">
                                                <label className="block text-xs text-text mb-1">6. How? สิ่งที่อยากให้ทำ</label>
                                                <textarea name="how" value={editFormData.how} onChange={handleEditFormChange} className="w-full p-2.5 bg-surface rounded border border-glass text-text outline-none focus:border-orange-500 text-sm" rows="2" required></textarea>
                                            </div>
                                            <div>
                                                <label className="block text-xs text-red-400 mb-1">Cost Estimate (THB)</label>
                                                <input type="number" name="cost" value={editFormData.cost} onChange={handleEditFormChange} className="w-full p-2.5 bg-surface rounded border border-glass text-text outline-none focus:border-red-500 text-sm"/>
                                            </div>
                                            <div>
                                                <label className="block text-xs text-green-400 mb-1">Due Date</label>
                                                <input type="date" name="dueDate" value={editFormData.dueDate} onChange={handleEditFormChange} className="w-full p-2.5 bg-surface rounded border border-glass text-text outline-none focus:border-green-500 text-sm" required/>
                                            </div>
                                        </div>
                                    </div>
                                ) : (
                                    <div className="space-y-3">
                                        <div className="bg-surface/50 p-4 rounded-xl border border-glass shadow-sm flex flex-col gap-2">
                                            <div className="flex items-start gap-2"><span className="text-[11px] text-text uppercase font-bold whitespace-nowrap">1.What? เกิดอะไรขึ้น :</span> <span className="text-[11px] text-text">{selectedJob.what}</span></div>
                                            <div className="flex items-start gap-2"><span className="text-[11px] text-text uppercase font-bold whitespace-nowrap">2.Who? ใคร/สินค้าอะไร :</span> <span className="text-[11px] text-text">{selectedJob.who}</span></div>
                                            <div className="flex items-start gap-2"><span className="text-[11px] text-text uppercase font-bold whitespace-nowrap">3.When? เกิดขึ้นเมื่อไหร่ :</span> <span className="text-[11px] text-text">{selectedJob.when}</span></div>
                                            <div className="flex items-start gap-2"><span className="text-[11px] text-text uppercase font-bold whitespace-nowrap">4.Where? ที่ไหน :</span> <span className="text-[11px] text-text">{selectedJob.where}</span></div>
                                            <div className="flex items-start gap-2"><span className="text-[11px] text-text uppercase font-bold whitespace-nowrap">5.Why? สาเหตุเบื้องต้น :</span> <span className="text-[11px] text-text">{selectedJob.why}</span></div>
                                            <div className="flex items-start gap-2 pt-2 border-t border-glass"><span className="text-[11px] text-primary uppercase font-bold whitespace-nowrap">6.How? อยากให้ทำ :</span> <span className="text-[11px] text-primary">{selectedJob.how}</span></div>
                                        </div>

                                        <div className="grid grid-cols-2 gap-4 mt-2">
                                            <div className="bg-red-900/20 p-4 rounded-xl border border-red-500/30">
                                                <p className="text-[10px] text-red-700 uppercase font-bold tracking-wider mb-1">Budget (Cost)</p>
                                                <p className="text-base font-bold text-red-600">{selectedJob.cost ? `${Number(selectedJob.cost).toLocaleString()} THB` : '-'}</p>
                                            </div>
                                            <div className="bg-green-900/20 p-4 rounded-xl border border-green-500/30">
                                                <p className="text-[10px] text-green-600 uppercase font-bold tracking-wider mb-1">Due (Due Date)</p>
                                                <p className="text-base font-bold text-green-300">{selectedJob.dueDate || '-'}</p>
                                            </div>
                                        </div>

                                        {selectedJob.attachments && selectedJob.attachments.length > 0 && (
                                            <div className="mt-4 bg-surface/50 p-4 rounded-xl border border-glass shadow-sm">
                                                <p className="text-xs font-bold text-green-600 mb-3"><i className="fas fa-paperclip mr-2"></i> ไฟล์แนบอ้างอิง</p>
                                                <div className="flex flex-col gap-2">
                                                    {selectedJob.attachments.map((file, i) => (
                                                        <a key={i} href={file.url} target="_blank" rel="noreferrer" className="flex items-center text-xs text-primary hover:text-primary transition bg-surface p-2 rounded border border-glass hover:border-blue-500 group">
                                                            <div className="w-8 h-8 rounded bg-surface flex items-center justify-center shrink-0 mr-3 group-hover:bg-blue-900/50 transition">
                                                                <i className={`fas ${file.type === 'image' ? 'fa-image text-purple-400' : 'fa-file-pdf text-red-400'} text-lg`}></i> 
                                                            </div>
                                                            <span className="truncate flex-1 font-semibold">{file.title}</span>
                                                            <i className="fas fa-external-link-alt text-text group-hover:text-primary"></i>
                                                        </a>
                                                    ))}
                                                </div>
                                            </div>
                                        )}

                                        {linkedProject && linkedProject.handoverReport && (
                                            <div className="mt-4 bg-indigo-900/20 p-5 rounded-xl border border-indigo-500/50 shadow-inner">
                                                <div className="flex justify-between items-center mb-3 border-b border-indigo-500/30 pb-2">
                                                    <h4 className="text-indigo-600 font-bold text-sm flex items-center gap-2">
                                                        <i className="fas fa-file-contract"></i> เอกสารส่งมอบงาน (Handover Report)
                                                    </h4>
                                                    <button onClick={handlePrintHandoverReport} className="text-[10px] bg-indigo-600 hover:bg-indigo-500 text-text px-3 py-1.5 rounded transition shadow flex items-center gap-1">
                                                        <i className="fas fa-print"></i> ดู PDF
                                                    </button>
                                                </div>
                                                
                                                <div className="bg-surface/80 p-3 rounded border border-glass mb-4">
                                                    <p className="text-[10px] text-text mb-1">สรุปผลการทดสอบ:</p>
                                                    <p className="text-xs text-text mb-3">{linkedProject.handoverReport.testSummary || '-'}</p>
                                                    
                                                    <p className="text-[10px] text-text mb-1">ประสิทธิภาพที่ได้:</p>
                                                    <p className="text-xs text-text mb-3">{linkedProject.handoverReport.efficiencyGain || '-'}</p>
                                                    
                                                    <p className="text-[10px] text-text mb-1">ผลประเมิน (TD):</p>
                                                    <p className="text-sm font-bold text-green-600">
                                                        {linkedProject.handoverReport.isPass === 'Pass' ? '☑️ ผ่านเกณฑ์ พร้อมใช้งาน' : 
                                                         linkedProject.handoverReport.isPass === 'Conditional' ? '⚠️ ผ่านแบบมีเงื่อนไข' : '❌ ไม่ผ่าน'}
                                                    </p>
                                                </div>

                                                <div className="flex flex-col md:flex-row gap-3">
                                                    <div className="flex-1 bg-surface/50 p-3 rounded-lg border border-glass text-center relative overflow-hidden">
                                                        <p className="text-[10px] text-text mb-2 relative z-10">สถานะ Manager</p>
                                                        {linkedProject.handoverReport.approverSign ? (
                                                            <div className="relative z-10">
                                                                <span className="text-primary text-[10px] font-bold"><i className="fas fa-check-circle"></i> ตรวจสอบแล้ว</span>
                                                                <p className="text-[11px] text-text mt-0.5">{linkedProject.handoverReport.approverSign.name}</p>
                                                            </div>
                                                        ) : isTDManager ? (
                                                            <button onClick={() => handleESignReport('approver')} disabled={isSubmitting} className="bg-blue-600 hover:bg-blue-500 text-text text-[10px] px-3 py-1.5 rounded shadow transition relative z-10 w-full">ประทับตราอนุมัติ</button>
                                                        ) : (
                                                            <span className="text-[10px] text-yellow-500 relative z-10">รอตรวจสอบ</span>
                                                        )}
                                                        {linkedProject.handoverReport.approverSign && <i className="fas fa-stamp absolute -right-2 -bottom-2 text-4xl text-primary/10 -rotate-12"></i>}
                                                    </div>

                                                    <div className="flex-1 bg-surface/50 p-3 rounded-lg border border-glass text-center relative overflow-hidden">
                                                        <p className="text-[10px] text-text mb-1 z-10 relative">3. ผู้รับมอบ (Issuer)</p>
                                                        {linkedProject.handoverReport.issuerSign ? (
                                                            <div className="animate-fade-in z-10 relative">
                                                                <span className="text-green-400 text-[10px] font-bold"><i className="fas fa-check-circle"></i> รับมอบแล้ว</span>
                                                                <p className="text-[11px] text-text mt-0.5">{linkedProject.handoverReport.issuerSign.name}</p>
                                                            </div>
                                                        ) : (isRequester || (isDeptMgr && isMyDept) || isGlobalDeptManager) ? (
                                                            <button onClick={() => handleESignReport('issuer')} disabled={isSubmitting} className="bg-green-600 hover:bg-green-500 text-text text-[10px] px-3 py-1.5 rounded shadow transition relative z-10 w-full">ประทับตารับมอบงาน</button>
                                                        ) : (
                                                            <span className="text-[10px] text-yellow-500 relative z-10">รอรับมอบ</span>
                                                        )}
                                                        {linkedProject.handoverReport.issuerSign && <i className="fas fa-stamp absolute -right-2 -bottom-2 text-4xl text-green-500/10 -rotate-12"></i>}
                                                    </div>
                                                </div>
                                            </div>
                                        )}

                                        {selectedJob.timeline && selectedJob.timeline.length > 0 && (
                                            <div className="bg-surface/50 p-4 rounded-xl border border-glass shadow-sm mt-4">
                                                <p className="text-xs font-bold text-yellow-600 mb-4 border-b border-glass pb-2"><i className="fas fa-history mr-2"></i> ประวัติการดำเนินการ & คอมเมนต์</p>
                                                <div className="space-y-4 max-h-48 overflow-y-auto custom-scrollbar pr-2">
                                                    {[...selectedJob.timeline].reverse().map((event, idx) => (
                                                        <div key={idx} className="flex flex-col text-xs border-l-2 border-glass pl-3 ml-1">
                                                            <div className="flex justify-between items-start">
                                                                <span className="font-bold text-text">
                                                                    {event.by} 
                                                                    <span className={`text-[9px] px-1.5 py-0.5 rounded ml-2 font-bold ${
                                                                        event.status.includes('Reject') ? 'bg-red-500/20 text-red-400 border border-red-500/30' :
                                                                        event.status === 'Revise' ? 'bg-pink-500/20 text-pink-400 border border-pink-500/30' :
                                                                        event.status === 'Approved' ? 'bg-yellow-600/20 text-yellow-600 border border-yellow-500/30' :
                                                                        event.status === 'Completed' || event.status === 'Accepted' ? 'bg-green-500/20 text-green-400 border border-green-500/30' :
                                                                        'bg-blue-500/20 text-primary border border-blue-500/30'
                                                                    }`}>{event.status}</span>
                                                                </span>
                                                                <span className="text-[9px] text-text bg-surface px-1.5 py-0.5 rounded">{new Date(event.timestamp).toLocaleString('th-TH', { dateStyle: 'short', timeStyle: 'short' })}</span>
                                                            </div>
                                                            {event.comment && (
                                                                <div className="mt-2 bg-surface/80 p-2.5 rounded-lg border border-glass text-text italic shadow-inner">
                                                                    <i className="fas fa-quote-left text-text mr-2"></i>{event.comment}
                                                                </div>
                                                            )}
                                                        </div>
                                                    ))}
                                                </div>
                                            </div>
                                        )}
                                    </div>
                                )}

                                {/* Action Forms */}
                                {modalAction && (
                                    <div className={`bg-surface p-5 rounded-xl border ${modalAction === 'Resubmit' ? 'border-orange-500/50' : 'border-blue-500/50'} mt-4 animate-fade-in-down shadow-xl`}>
                                        <h3 className={`font-bold ${modalAction === 'Resubmit' ? 'text-orange-400' : 'text-primary'} mb-3`}><i className="fas fa-pen mr-2"></i> ดำเนินการ: {modalAction === 'Resubmit' ? 'แก้ไขข้อมูลและส่งใหม่' : modalAction}</h3>
                                        
                                        {modalAction === 'Receive' && (
                                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                                                <div>
                                                    <label className="block text-xs text-text mb-2">มอบหมายงานให้ (Assign To)</label>
                                                    <select value={assignTarget} onChange={(e) => setAssignTarget(e.target.value)} className="w-full p-2.5 bg-surface rounded-lg border border-glass text-text outline-none focus:border-blue-500">
                                                        <option value="">-- เลือกช่าง TD --</option>
                                                        {tdUsers.map(u => <option key={u.name} value={u.name}>{u.name}</option>)}
                                                    </select>
                                                </div>
                                                <div>
                                                    <label className="block text-xs text-text mb-2">หมวดหมู่งาน (Job Category) *</label>
                                                    <select value={jobCategory} onChange={(e) => setJobCategory(e.target.value)} className="w-full p-2.5 bg-surface rounded-lg border border-glass text-text outline-none focus:border-blue-500">
                                                        <option value="">-- เลือกหมวดหมู่งาน --</option>
                                                        {TD_JOB_CATEGORIES.map(c => <option key={c} value={c}>{c}</option>)}
                                                    </select>
                                                </div>
                                            </div>
                                        )}

                                        <textarea 
                                            value={actionComment} onChange={(e) => setActionComment(e.target.value)} 
                                            placeholder="ระบุคอมเมนต์ หรือ เหตุผลเพิ่มเติม..." 
                                            className={`w-full p-3 bg-surface rounded-lg border border-glass text-text outline-none focus:border-${modalAction === 'Resubmit' ? 'orange' : 'blue'}-500 mb-4`} rows="2"
                                        ></textarea>
                                        <div className="flex justify-end gap-3">
                                            <button onClick={() => setModalAction('')} className="px-5 py-2 bg-surface rounded-lg text-sm font-bold hover:bg-surface text-text transition">ยกเลิก</button>
                                            <button 
                                                onClick={handleActionSubmit} 
                                                disabled={isSubmitting || (modalAction === 'Receive' && (!assignTarget || !jobCategory))} 
                                                className={`px-6 py-2 rounded-lg text-sm font-bold text-text transition disabled:opacity-50 ${modalAction === 'Resubmit' ? 'bg-orange-600 hover:bg-orange-500' : 'bg-blue-600 hover:bg-blue-500'}`}
                                            >
                                                ยืนยัน
                                            </button>
                                        </div>
                                    </div>
                                )}

                                {!modalAction && (
                                    <div className="flex flex-wrap gap-2 mt-6 pt-6 border-t border-glass">
                                        
                                        {/* Rule 2.2: Approve / Reject / Revise -> Manager แผนกต้นทาง หรือ Department Manager ของแผนกใดก็ได้ */}
                                        {selectedJob.status === 'Issued' && ((isDeptMgr && isMyDept) || isGlobalDeptManager) && <>
                                            <button onClick={() => setModalAction('Approve')} className="bg-green-600 hover:bg-green-500 text-text px-5 py-2.5 rounded-lg text-xs font-bold transition shadow"><i className="fas fa-check mr-1.5"></i> Approve</button>
                                            <button onClick={() => setModalAction('Revise')} className="bg-orange-600 hover:bg-orange-500 text-text px-5 py-2.5 rounded-lg text-xs font-bold transition shadow"><i className="fas fa-undo mr-1.5"></i> Revise</button>
                                            <button onClick={() => setModalAction('Reject')} className="bg-red-600 hover:bg-red-500 text-text px-5 py-2.5 rounded-lg text-xs font-bold transition shadow"><i className="fas fa-times mr-1.5"></i> Reject</button>
                                        </>}
                                        
                                        {/* Rule 2.3: Resubmit -> Requester, Manager แผนกต้นทาง, หรือ Department Manager ของแผนกใดก็ได้ */}
                                        {selectedJob.status === 'Revise' && (isRequester || (isDeptMgr && isMyDept) || isGlobalDeptManager) && (
                                            <button 
                                                onClick={() => {
                                                    setEditFormData({
                                                        what: selectedJob.what || '', who: selectedJob.who || '',
                                                        when: selectedJob.when || '', where: selectedJob.where || '',
                                                        why: selectedJob.why || '', how: selectedJob.how || '',
                                                        cost: selectedJob.cost || '', dueDate: selectedJob.dueDate || ''
                                                    });
                                                    setModalAction('Resubmit');
                                                }} 
                                                className="bg-orange-600 hover:bg-orange-500 text-text px-5 py-2.5 rounded-lg text-xs font-bold transition shadow w-full md:w-auto text-center"
                                            >
                                                <i className="fas fa-edit mr-1.5"></i> แก้ไขข้อมูลและส่งใหม่ (Resubmit)
                                            </button>
                                        )}

                                        {/* Rule 2.4: Receive -> TD Mgr หรือ TD Sup ตามเงื่อนไข */}
                                        {selectedJob.status === 'Approved' && checkCanReceive(selectedJob) && (
                                            <button onClick={() => {
                                                setModalAction('Receive');
                                                setAssignTarget(selectedJob.assignTo || '');
                                                setJobCategory(selectedJob.jobCategory || '');
                                            }} className="bg-blue-600 hover:bg-blue-500 text-text px-5 py-2.5 rounded-lg text-xs font-bold transition shadow">
                                                <i className="fas fa-hand-holding mr-1.5"></i> Receive
                                            </button>
                                        )}
                                        
                                        {/* Rule 2.5: Complete -> Assignee หรือ TD Mgr / TD Sup */}
                                        {selectedJob.status === 'In Progress' && (isAssignee || isTDManager || isTDSup) && (
                                            <button onClick={() => setModalAction('Complete')} className="bg-green-600 hover:bg-green-500 text-text px-5 py-2.5 rounded-lg text-xs font-bold transition shadow"><i className="fas fa-flag-checkered mr-1.5"></i> Complete</button>
                                        )}
                                        
                                        {/* Rule 2.6: Accept -> Requester, Manager แผนกต้นทาง, หรือ Department Manager ของแผนกใดก็ได้ */}
                                        {selectedJob.status === 'Completed' && (isRequester || (isDeptMgr && isMyDept) || isGlobalDeptManager) && (!linkedProject || !linkedProject.handoverReport) && (
                                            <button onClick={() => setModalAction('Accept')} className="bg-purple-600 hover:bg-purple-500 text-text px-5 py-2.5 rounded-lg text-xs font-bold transition shadow"><i className="fas fa-handshake mr-1.5"></i> Accept</button>
                                        )}
                                    </div>
                                )}
                            </div>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};

export default TDJobRequestPage;