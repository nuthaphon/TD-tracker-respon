import React, { useState, useEffect, useRef } from 'react';
import { doc, updateDoc, collection, query, where, onSnapshot } from 'firebase/firestore';
import { EmailAuthProvider, reauthenticateWithCredential, updatePassword } from 'firebase/auth';
import { db, auth } from '../firebase';
import { useAuth } from '../hooks/useAuth';
import { DEPT_OPTIONS, JOB_TITLE_OPTIONS } from '../utils/constants';
// 🌟 เรียกใช้ฟังก์ชัน Log ส่วนกลางที่เราเพิ่งสร้าง
import { logActivity } from '../utils/activityLogger';
// 🌟 นำเข้าไลบรารีสำหรับทำ E-Business Card (เปลี่ยนมาใช้ html-to-image)
import { toPng } from 'html-to-image';
import { jsPDF } from 'jspdf';

const ProfilePage = () => {
    const { user, userData } = useAuth();
    
    // --- States สำหรับ Profile หลัก ---
    const [profile, setProfile] = useState({
        name: '', phone: '', dept: '', jobTitle: '', empId: ''
    });

    const [passwords, setPasswords] = useState({ current: '', new: '', confirm: '' });
    const [statusMsg, setStatusMsg] = useState({ type: '', text: '' });
    
    const [isUpdatingProfile, setIsUpdatingProfile] = useState(false);
    const [isUpdatingPassword, setIsUpdatingPassword] = useState(false);
    const [isUpdatingAvatar, setIsUpdatingAvatar] = useState(false); 
    
    const [logs, setLogs] = useState([]);
    const [visibleLogsCount, setVisibleLogsCount] = useState(20);

    // 🌟 --- States สำหรับ E-Business Card --- 🌟
    const cardRef = useRef(null);
    const [isSavingCard, setIsSavingCard] = useState(false);
    const [eCardData, setECardData] = useState({
        useSystemData: true,
        customName: '',
        customJobTitle: '',
        customDept: '',
        customPhone: '',
        customEmail: '',
        branch: 'Factory' // Default สาขา
    });

    useEffect(() => {
        if (userData) {
            setProfile({
                name: userData.name || '', phone: userData.phone || '', dept: userData.dept || '',
                jobTitle: userData.jobTitle || '', empId: userData.empId || '' 
            });

            // ดึงข้อมูลการตั้งค่านามบัตร (ถ้าเคยเซฟไว้)
            if (userData.eCard) {
                setECardData(userData.eCard);
            } else {
                setECardData(prev => ({ ...prev, customEmail: user?.email || '' }));
            }
        }
    }, [userData, user]);

    useEffect(() => {
        if (!user) return;
        const q = query(collection(db, 'activity_logs'), where('userId', '==', user.uid));

        const unsubscribe = onSnapshot(q, (snapshot) => {
            const fetchedLogs = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
            fetchedLogs.sort((a, b) => {
                const timeA = a.timestamp?.seconds || 0;
                const timeB = b.timestamp?.seconds || 0;
                return timeB - timeA; 
            });
            setLogs(fetchedLogs);
        }, (error) => {
            console.error("Error fetching logs:", error);
        });

        return unsubscribe;
    }, [user]);

    const handleProfileChange = (e) => setProfile({ ...profile, [e.target.name]: e.target.value });
    const handlePasswordChange = (e) => setPasswords({ ...passwords, [e.target.name]: e.target.value });

    const handleRandomizeAvatar = async () => {
        setIsUpdatingAvatar(true);
        setStatusMsg({ type: '', text: '' });

        try {
            const randomSeed = Math.random().toString(36).substring(7);
            const newAvatarUrl = `https://api.dicebear.com/7.x/avataaars/svg?seed=${randomSeed}&backgroundColor=b6e3f4,c0aede,ffdfbf,ffd5dc,d1d4f9`;
            
            const userRef = doc(db, 'users', user.uid);
            await updateDoc(userRef, { avatar: newAvatarUrl });

            await logActivity(user, 'Changed Avatar', 'ระบบได้ทำการสุ่มและเปลี่ยนรูปโปรไฟล์ใหม่เรียบร้อยแล้ว');
            setStatusMsg({ type: 'success', text: 'สุ่มรูปโปรไฟล์ใหม่สำเร็จ!' });
        } catch (error) {
            console.error(error);
            setStatusMsg({ type: 'error', text: 'ไม่สามารถเปลี่ยนรูปโปรไฟล์ได้' });
        } finally {
            setIsUpdatingAvatar(false);
            setTimeout(() => setStatusMsg({ type: '', text: '' }), 3000);
        }
    };

    const submitProfileUpdate = async (e) => {
        e.preventDefault();
        setIsUpdatingProfile(true);
        setStatusMsg({ type: '', text: '' });

        try {
            const userRef = doc(db, 'users', user.uid);
            await updateDoc(userRef, {
                pendingUpdate: {
                    name: profile.name, phone: profile.phone, dept: profile.dept,
                    jobTitle: profile.jobTitle, empId: profile.empId, requestedAt: new Date().toISOString()
                }
            });
            await logActivity(user, 'Requested Profile Update', 'ส่งคำร้องขอแก้ไขข้อมูลส่วนตัว รอผู้ดูแลระบบอนุมัติ');
            setStatusMsg({ type: 'success', text: 'ส่งคำร้องขอแก้ไขข้อมูลสำเร็จ! กรุณารอ Admin อนุมัติ' });
        } catch (error) {
            setStatusMsg({ type: 'error', text: 'เกิดข้อผิดพลาดในการส่งคำร้อง' });
        } finally {
            setIsUpdatingProfile(false);
            setTimeout(() => setStatusMsg({ type: '', text: '' }), 5000);
        }
    };

    const submitPasswordUpdate = async (e) => {
        e.preventDefault();
        setIsUpdatingPassword(true);
        setStatusMsg({ type: '', text: '' });

        if (passwords.new !== passwords.confirm) {
            setStatusMsg({ type: 'error', text: 'รหัสผ่านใหม่ไม่ตรงกัน กรุณาลองอีกครั้ง' });
            setIsUpdatingPassword(false); return;
        }
        if (passwords.new.length < 6) {
            setStatusMsg({ type: 'error', text: 'รหัสผ่านใหม่ต้องมีอย่างน้อย 6 ตัวอักษร' });
            setIsUpdatingPassword(false); return;
        }

        try {
            const credential = EmailAuthProvider.credential(user.email, passwords.current);
            await reauthenticateWithCredential(user, credential);
            await updatePassword(user, passwords.new);
            await logActivity(user, 'Changed Password', 'ผู้ใช้งานทำการเปลี่ยนรหัสผ่านใหม่สำเร็จ');
            setStatusMsg({ type: 'success', text: 'เปลี่ยนรหัสผ่านสำเร็จ!' });
            setPasswords({ current: '', new: '', confirm: '' }); 
        } catch (error) {
            if (error.code === 'auth/invalid-credential') setStatusMsg({ type: 'error', text: 'รหัสผ่านปัจจุบันไม่ถูกต้อง' });
            else setStatusMsg({ type: 'error', text: 'เกิดข้อผิดพลาด: ' + error.message });
            await logActivity(user, 'Failed Password Change', 'ความพยายามเปลี่ยนรหัสผ่านล้มเหลว');
        } finally {
            setIsUpdatingPassword(false);
            setTimeout(() => setStatusMsg({ type: '', text: '' }), 4000);
        }
    };

    const handleLoadMoreLogs = () => {
        setVisibleLogsCount(prevCount => prevCount + 20);
    };

    const fallbackAvatar = `https://ui-avatars.com/api/?name=${encodeURIComponent(userData?.name || 'User')}&background=8b5cf6&color=fff&size=128&bold=true`;

    const getLogIcon = (action) => {
        const a = (action || '').toLowerCase();
        if (a.includes('job') || a.includes('ticket')) return 'fa-ticket-alt text-primary';
        if (a.includes('project')) return 'fa-project-diagram text-purple-400';
        if (a.includes('password') || a.includes('profile') || a.includes('avatar')) return 'fa-user-edit text-orange-400';
        if (a.includes('sign') || a.includes('report') || a.includes('document')) return 'fa-file-signature text-green-400';
        return 'fa-history text-text';
    };

    // 🌟 --- ฟังก์ชันจัดการ E-Business Card --- 🌟
    const handleECardChange = (e) => {
        const value = e.target.type === 'checkbox' ? e.target.checked : e.target.value;
        setECardData({ ...eCardData, [e.target.name]: value });
    };

    const saveECardSettings = async () => {
        setIsSavingCard(true);
        setStatusMsg({ type: '', text: '' });
        try {
            await updateDoc(doc(db, 'users', user.uid), { eCard: eCardData });
            await logActivity(user, 'Updated E-Business Card', 'บันทึกการตั้งค่า E-Business Card สำเร็จ');
            setStatusMsg({ type: 'success', text: 'บันทึกข้อมูลนามบัตรสำเร็จ!' });
        } catch (error) {
            setStatusMsg({ type: 'error', text: 'บันทึกนามบัตรไม่สำเร็จ' });
        } finally {
            setIsSavingCard(false);
            setTimeout(() => setStatusMsg({ type: '', text: '' }), 3000);
        }
    };

    // 🌟 คำนวณข้อมูลที่จะนำไปแสดงในนามบัตร
    const displayData = {
        name: eCardData.useSystemData ? profile.name : eCardData.customName || profile.name,
        jobTitle: eCardData.useSystemData ? profile.jobTitle : eCardData.customJobTitle || profile.jobTitle,
        dept: eCardData.useSystemData ? profile.dept : eCardData.customDept || profile.dept,
        phone: eCardData.useSystemData ? profile.phone : eCardData.customPhone || profile.phone,
        email: eCardData.useSystemData ? user?.email : eCardData.customEmail || user?.email,
    };

    // 🌟 อัปเกรดฟังก์ชัน Export ใช้ html-to-image แก้ปัญหา oklch ของ Tailwind
    const exportToImage = async () => {
        if (!cardRef.current) return;
        
        try {
            setStatusMsg({ type: 'success', text: 'กำลังสร้างรูปภาพ กรุณารอสักครู่...' });
            
            // สร้างรูปด้วยความละเอียดสูง (pixelRatio)
            const dataUrl = await toPng(cardRef.current, { 
                quality: 1.0,
                pixelRatio: 3,
                backgroundColor: '#ffffff'
            });
            
            const link = document.createElement('a');
            link.download = `BusinessCard_${displayData.name || 'TTM'}.png`;
            link.href = dataUrl;
            link.click();
            
            await logActivity(user, 'Exported Business Card', 'ดาวน์โหลดนามบัตรเป็นไฟล์ PNG');
            setStatusMsg({ type: '', text: '' }); 
            
        } catch (err) {
            console.error("Export PNG Error:", err);
            setStatusMsg({ type: 'error', text: `เกิดข้อผิดพลาดในการโหลดรูป: ${err.message}` }); 
        }
    };

    const exportToPDF = async () => {
        if (!cardRef.current) return;
        
        try {
            setStatusMsg({ type: 'success', text: 'กำลังสร้าง PDF กรุณารอสักครู่...' });

            const dataUrl = await toPng(cardRef.current, { 
                quality: 1.0,
                pixelRatio: 3,
                backgroundColor: '#ffffff'
            });
            
            const pdf = new jsPDF({ orientation: 'landscape', unit: 'mm', format: [90, 55] });
            pdf.addImage(dataUrl, 'PNG', 0, 0, 90, 55);
            pdf.save(`BusinessCard_${displayData.name || 'TTM'}.pdf`);
            
            await logActivity(user, 'Exported Business Card', 'ดาวน์โหลดนามบัตรเป็นไฟล์ PDF');
            setStatusMsg({ type: '', text: '' }); 
            
        } catch (err) {
            console.error("Export PDF Error:", err);
            setStatusMsg({ type: 'error', text: `เกิดข้อผิดพลาดในการโหลด PDF: ${err.message}` }); 
        }
    };

    return (
        <div className="h-full flex flex-col pb-4 md:pb-6">
            <div className="mb-3 md:mb-6 border-b border-glass pb-3 md:pb-4">
                <h1 className="text-lg md:text-2xl font-bold text-primary"><i className="fas fa-user-circle mr-2"></i> โปรไฟล์ของฉัน (My Profile)</h1>
            </div>

            {statusMsg.text && (
                <div className={`mb-6 p-4 rounded-xl font-bold shadow-lg animate-fade-in-down flex items-center ${statusMsg.type === 'success' ? 'bg-green-500/20 text-green-400 border border-green-500/50' : 'bg-red-500/20 text-red-400 border border-red-500/50'}`}>
                    <i className={`fas ${statusMsg.type === 'success' ? 'fa-check-circle' : 'fa-exclamation-triangle'} text-xl mr-3`}></i>{statusMsg.text}
                </div>
            )}

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-3 md:gap-6">
                
                {/* --- ส่วนที่ 1: Avatar & Status --- */}
                <div className="lg:col-span-1 space-y-6">
                    <div className="bg-surface p-4 md:p-6 rounded-2xl border border-glass shadow-xl flex flex-col items-center text-center">
                        <div className="relative mb-3">
                            <img 
                                src={userData?.avatar || fallbackAvatar} 
                                alt="Profile" 
                                onError={(e) => { e.target.onerror = null; e.target.src = fallbackAvatar; }}
                                className={`w-32 h-32 rounded-full border-4 border-purple-500 shadow-[0_0_20px_rgba(168,85,247,0.4)] bg-surface object-cover ${isUpdatingAvatar ? 'opacity-50 animate-pulse' : ''}`} 
                            />
                            <span className={`absolute bottom-1 right-1 w-6 h-6 border-2 border-glass rounded-full ${userData?.role === 'pending' ? 'bg-orange-500' : 'bg-green-500'}`}></span>
                        </div>

                        <button 
                            onClick={handleRandomizeAvatar} 
                            disabled={isUpdatingAvatar}
                            className="mb-4 text-xs bg-surface hover:bg-surface text-text px-4 py-1.5 rounded-full shadow-md border border-glass transition flex items-center disabled:opacity-50"
                        >
                            {isUpdatingAvatar ? <i className="fas fa-spinner fa-spin mr-2"></i> : <i className="fas fa-dice mr-2 text-purple-400"></i>}
                            สุ่มรูปโปรไฟล์ใหม่
                        </button>
                        
                        <h2 className="text-xl font-bold text-text mb-1">{userData?.name || 'ผู้ใช้งานระบบ'}</h2>
                        <p className="text-xs text-text mb-2">{user?.email}</p>
                        {userData?.empId && <p className="text-xs bg-surface px-3 py-1 rounded-full text-primary font-bold mb-4">ID: {userData.empId}</p>}
                        
                        <div className="w-full grid grid-cols-2 gap-3 mb-2">
                            <div className="bg-surface/50 p-3 rounded-lg border border-glass">
                                <p className="text-[10px] text-text uppercase font-bold">Role</p>
                                <p className={`font-bold ${userData?.role === 'Admin' ? 'text-red-400' : userData?.role === 'pending' ? 'text-orange-400' : 'text-primary'}`}>{userData?.role?.toUpperCase()}</p>
                            </div>
                            <div className="bg-surface/50 p-3 rounded-lg border border-glass">
                                <p className="text-[10px] text-text uppercase font-bold">Department / Group</p>
                                <p className="font-bold text-text">{userData?.dept || '-'}</p>
                            </div>
                        </div>
                    </div>

                    {/* --- ส่วนที่ 3: ประวัติการใช้งาน --- */}
                    <div className="bg-surface p-4 md:p-5 rounded-2xl border border-glass shadow-xl flex flex-col h-[320px] md:h-[400px]">
                        <h3 className="text-md font-bold text-text mb-4 border-b border-glass pb-2 flex justify-between items-center">
                            <span><i className="fas fa-history text-purple-400 mr-2"></i> ประวัติกิจกรรมล่าสุด</span>
                            <span className="text-[10px] bg-surface text-text px-2 py-1 rounded-full">{logs.length} รายการ</span>
                        </h3>
                        
                        <div className="flex-1 overflow-y-auto custom-scrollbar pr-2 pb-4">
                            {logs.length === 0 ? (
                                <div className="h-full flex flex-col items-center justify-center text-text">
                                    <i className="fas fa-clipboard-list text-3xl mb-2 opacity-50"></i>
                                    <p className="text-sm">ไม่มีประวัติการใช้งาน</p>
                                </div>
                            ) : (
                                <div className="relative border-l-2 border-glass ml-4 space-y-5 pt-2 pb-2">
                                    {logs.slice(0, visibleLogsCount).map((log) => (
                                        <div key={log.id} className="relative pl-6 animate-fade-in">
                                            <span className="absolute -left-[13px] top-1.5 w-6 h-6 rounded-full bg-surface border-2 border-glass flex items-center justify-center shadow-inner">
                                                <i className={`fas ${getLogIcon(log.action)} text-[10px]`}></i>
                                            </span>
                                            
                                            <div className="bg-surface/60 p-3.5 rounded-xl border border-glass shadow-sm hover:border-purple-500/50 hover:bg-surface transition-all group">
                                                <div className="flex justify-between items-start mb-1.5 gap-2">
                                                    <span className="font-bold text-primary text-sm group-hover:text-purple-400 transition-colors">{log.action}</span>
                                                    <span className="text-[9px] text-text bg-surface px-2 py-0.5 rounded-full whitespace-nowrap border border-glass">
                                                        {log.timestamp?.toDate().toLocaleString('th-TH', { dateStyle: 'short', timeStyle: 'short' })}
                                                    </span>
                                                </div>
                                                <p className="text-xs text-text leading-relaxed">{log.details}</p>
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            )}

                            {logs.length > visibleLogsCount && (
                                <div className="mt-6 text-center pb-2">
                                    <button 
                                        onClick={handleLoadMoreLogs} 
                                        className="text-[11px] bg-surface hover:bg-surface hover:text-text text-text px-4 py-2 rounded-full transition shadow-md border border-glass flex items-center justify-center mx-auto group"
                                    >
                                        <i className="fas fa-plus mr-1.5 text-purple-400 group-hover:rotate-90 transition-transform"></i> 
                                        ดูเพิ่ม ({logs.length - visibleLogsCount})
                                    </button>
                                </div>
                            )}
                        </div>
                    </div>
                </div>

                {/* --- ส่วนที่ 2: ฟอร์มแก้ไขข้อมูล --- */}
                <div className="lg:col-span-2 space-y-6">
                    <div className="bg-surface p-4 md:p-6 rounded-2xl border border-glass shadow-xl relative overflow-hidden">
                        {userData?.pendingUpdate && (
                            <div className="absolute top-0 left-0 w-full bg-orange-500/20 border-b border-orange-500/50 p-2 text-center text-orange-300 font-bold text-sm z-10 backdrop-blur-sm">
                                <i className="fas fa-clock mr-2"></i> คุณมีคำร้องขอแก้ไขข้อมูลที่รอ Admin อนุมัติ (ไม่สามารถส่งคำร้องซ้ำได้)
                            </div>
                        )}

                        <h3 className={`text-lg font-bold text-text mb-4 border-b border-glass pb-2 ${userData?.pendingUpdate ? 'mt-8' : ''}`}>
                            <i className="fas fa-id-card text-primary mr-2"></i> ข้อมูลส่วนตัว
                        </h3>
                        
                        <form onSubmit={submitProfileUpdate} className="grid grid-cols-1 md:grid-cols-2 gap-4 relative">
                            {userData?.pendingUpdate && <div className="absolute inset-0 bg-surface/60 z-10 cursor-not-allowed"></div>}

                            <div className="md:col-span-2">
                                <label className="block text-xs text-text mb-1">ชื่อ - นามสกุล *</label>
                                <input type="text" name="name" value={profile.name} onChange={handleProfileChange} required className="w-full p-2.5 bg-surface rounded-lg border border-glass text-text focus:outline-none focus:border-blue-500" />
                            </div>
                            
                            <div>
                                <label className="block text-xs text-text mb-1">รหัสพนักงาน (Employee ID)</label>
                                <input type="text" name="empId" value={profile.empId} onChange={handleProfileChange} placeholder="เช่น TD-001" className="w-full p-2.5 bg-surface rounded-lg border border-glass text-text focus:outline-none focus:border-blue-500" />
                            </div>

                            <div>
                                <label className="block text-xs text-text mb-1">เบอร์โทรศัพท์ติดต่อ</label>
                                <input type="tel" name="phone" value={profile.phone} onChange={handleProfileChange} className="w-full p-2.5 bg-surface rounded-lg border border-glass text-text focus:outline-none focus:border-blue-500" />
                            </div>

                            <div>
                                <label className="block text-xs text-text mb-1">แผนก (Department) *</label>
                                <select name="dept" value={profile.dept} onChange={handleProfileChange} required className="w-full p-2.5 bg-surface rounded-lg border border-glass text-text focus:outline-none focus:border-blue-500" style={{ backgroundColor: 'var(--color-bg)', color: 'var(--color-text)' }}>
                                    <option value="">-- เลือกแผนก --</option>
                                    {DEPT_OPTIONS.map(d => <option key={d} value={d}>{d}</option>)}
                                </select>
                            </div>

                            <div>
                                <label className="block text-xs text-text mb-1">ตำแหน่ง (Position) *</label>
                                <select name="jobTitle" value={profile.jobTitle} onChange={handleProfileChange} required className="w-full p-2.5 bg-surface rounded-lg border border-glass text-text focus:outline-none focus:border-blue-500" style={{ backgroundColor: 'var(--color-bg)', color: 'var(--color-text)' }}>
                                    <option value="">-- เลือกตำแหน่ง --</option>
                                    {JOB_TITLE_OPTIONS.map(j => <option key={j} value={j}>{j}</option>)}
                                </select>
                            </div>

                            <div className="md:col-span-2 flex justify-end mt-2">
                                <button type="submit" disabled={isUpdatingProfile || userData?.pendingUpdate} className="bg-blue-600 hover:bg-blue-500 text-text px-6 py-2.5 rounded-lg font-bold shadow-md transition disabled:opacity-50 disabled:cursor-not-allowed">
                                    {isUpdatingProfile ? 'กำลังส่งคำร้อง...' : 'บันทึกเพื่อรออนุมัติ'}
                                </button>
                            </div>
                        </form>
                    </div>

                    <div className="bg-surface p-4 md:p-6 rounded-2xl border border-glass shadow-xl">
                        <h3 className="text-lg font-bold text-text mb-4 border-b border-glass pb-2"><i className="fas fa-key text-red-400 mr-2"></i> เปลี่ยนรหัสผ่าน</h3>
                        
                        {user?.providerData[0]?.providerId === 'google.com' ? (
                            <div className="bg-surface/50 p-6 rounded-lg border border-glass text-center">
                                <i className="fab fa-google text-4xl text-text mb-3"></i>
                                <p className="text-text text-sm">คุณเข้าสู่ระบบผ่าน Google Account<br/>ไม่สามารถเปลี่ยนรหัสผ่านจากหน้านี้ได้</p>
                            </div>
                        ) : (
                            <form onSubmit={submitPasswordUpdate} className="space-y-4">
                                <div>
                                    <label className="block text-xs text-text mb-1">รหัสผ่านปัจจุบัน (Current Password)</label>
                                    <input type="password" name="current" value={passwords.current} onChange={handlePasswordChange} required className="w-full p-2.5 bg-surface rounded-lg border border-glass text-text focus:outline-none focus:border-red-500" placeholder="••••••••" />
                                </div>
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                    <div>
                                        <label className="block text-xs text-text mb-1">รหัสผ่านใหม่ (New Password)</label>
                                        <input type="password" name="new" value={passwords.new} onChange={handlePasswordChange} required minLength="6" className="w-full p-2.5 bg-surface rounded-lg border border-glass text-text focus:outline-none focus:border-red-500" placeholder="ขั้นต่ำ 6 ตัวอักษร" />
                                    </div>
                                    <div>
                                        <label className="block text-xs text-text mb-1">ยืนยันรหัสผ่านใหม่ (Confirm New Password)</label>
                                        <input type="password" name="confirm" value={passwords.confirm} onChange={handlePasswordChange} required minLength="6" className="w-full p-2.5 bg-surface rounded-lg border border-glass text-text focus:outline-none focus:border-red-500" placeholder="พิมพ์ให้ตรงกันอีกครั้ง" />
                                    </div>
                                </div>
                                <div className="flex justify-end pt-2">
                                    <button type="submit" disabled={isUpdatingPassword} className="bg-red-600 hover:bg-red-500 text-text px-6 py-2.5 rounded-lg font-bold shadow-md transition disabled:opacity-50">
                                        {isUpdatingPassword ? 'กำลังเปลี่ยนรหัสผ่าน...' : 'ยืนยันเปลี่ยนรหัสผ่าน'}
                                    </button>
                                </div>
                            </form>
                        )}
                    </div>
                </div>

                {/* 🌟 --- ส่วนที่ 4: E-Business Card (นามบัตรอิเล็กทรอนิกส์) --- 🌟 */}
                <div className="lg:col-span-3 bg-surface p-4 md:p-6 rounded-2xl border border-glass shadow-xl mt-2">
                    <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-3 md:mb-6 border-b border-glass pb-3 md:pb-4 gap-3">
                        <div>
                            <h3 className="text-xl font-bold text-primary"><i className="fas fa-address-card mr-2"></i> E-Business Card</h3>
                            <p className="text-xs text-text mt-1">ตั้งค่าและส่งออกนามบัตรอิเล็กทรอนิกส์แบบเป็นทางการสำหรับแชร์ให้คู่ค้า</p>
                        </div>
                        <div className="flex gap-2 mt-4 md:mt-0">
                            <button onClick={exportToImage} className="bg-indigo-600 hover:bg-indigo-500 text-text px-3 md:px-4 py-2 rounded-lg text-xs md:text-sm font-bold shadow-md transition flex items-center">
                                <i className="fas fa-image mr-2"></i> บันทึกเป็น PNG
                            </button>
                            <button onClick={exportToPDF} className="bg-red-600 hover:bg-red-500 text-text px-3 md:px-4 py-2 rounded-lg text-xs md:text-sm font-bold shadow-md transition flex items-center">
                                <i className="fas fa-file-pdf mr-2"></i> บันทึกเป็น PDF
                            </button>
                        </div>
                    </div>

                    <div className="grid grid-cols-1 xl:grid-cols-2 gap-8 items-start">
                        
                        {/* 🌟 ฟอร์มตั้งค่านามบัตร 🌟 */}
                        <div className="space-y-4">
                            <div className="bg-surface/50 p-4 rounded-xl border border-glass">
                                <label className="flex items-center cursor-pointer mb-4">
                                    <div className="relative">
                                        <input type="checkbox" name="useSystemData" checked={eCardData.useSystemData} onChange={handleECardChange} className="sr-only" />
                                        <div className={`block w-10 h-6 rounded-full border border-glass transition ${eCardData.useSystemData ? 'bg-primary' : 'bg-surface'}`}></div>
                                        <div className={`dot absolute left-1 top-1 bg-surface border border-glass w-4 h-4 rounded-full transition transform ${eCardData.useSystemData ? 'translate-x-4' : ''}`}></div>
                                    </div>
                                    <span className="ml-3 text-sm font-bold text-text">ใช้ข้อมูลอ้างอิงจากระบบ (My Profile)</span>
                                </label>

                                {!eCardData.useSystemData && (
                                    <div className="space-y-3 animate-fade-in text-sm">
                                        <div>
                                            <label className="block text-xs text-text mb-1">ชื่อที่แสดงบนนามบัตร (Name)</label>
                                            <input type="text" name="customName" value={eCardData.customName} onChange={handleECardChange} placeholder={profile.name} className="w-full p-2 bg-surface rounded border border-glass text-text focus:border-blue-500 outline-none" />
                                        </div>
                                        <div className="grid grid-cols-2 gap-3">
                                            <div>
                                                <label className="block text-xs text-text mb-1">ตำแหน่ง (Job Title)</label>
                                                <input type="text" name="customJobTitle" value={eCardData.customJobTitle} onChange={handleECardChange} placeholder={profile.jobTitle} className="w-full p-2 bg-surface rounded border border-glass text-text focus:border-blue-500 outline-none" />
                                            </div>
                                            <div>
                                                <label className="block text-xs text-text mb-1">แผนก (Department)</label>
                                                <input type="text" name="customDept" value={eCardData.customDept} onChange={handleECardChange} placeholder={profile.dept} className="w-full p-2 bg-surface rounded border border-glass text-text focus:border-blue-500 outline-none" />
                                            </div>
                                        </div>
                                        <div>
                                            <label className="block text-xs text-text mb-1">เบอร์โทรศัพท์ (Phone)</label>
                                            <input type="text" name="customPhone" value={eCardData.customPhone} onChange={handleECardChange} placeholder={profile.phone} className="w-full p-2 bg-surface rounded border border-glass text-text focus:border-blue-500 outline-none" />
                                        </div>
                                        <div>
                                            <label className="block text-xs text-text mb-1">อีเมล (Email)</label>
                                            <input type="email" name="customEmail" value={eCardData.customEmail} onChange={handleECardChange} placeholder={user?.email} className="w-full p-2 bg-surface rounded border border-glass text-text focus:border-blue-500 outline-none" />
                                        </div>
                                    </div>
                                )}
                            </div>

                            <div>
                                <label className="block text-xs text-text mb-2 font-bold">เลือกสาขา / ที่อยู่บริษัท (Branch Address) *</label>
                                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                                    <label className={`border rounded-lg p-3 cursor-pointer transition text-sm flex items-center ${eCardData.branch === 'Factory' ? 'border-blue-500 bg-blue-500/10 text-primary' : 'border-glass bg-surface text-text hover:bg-surface'}`}>
                                        <input type="radio" name="branch" value="Factory" checked={eCardData.branch === 'Factory'} onChange={handleECardChange} className="mr-2" />
                                        <i className="fas fa-industry mr-2"></i> Factory (Head Office)
                                    </label>
                                    <label className={`border rounded-lg p-3 cursor-pointer transition text-sm flex items-center ${eCardData.branch === 'Bangkok' ? 'border-blue-500 bg-blue-500/10 text-primary' : 'border-glass bg-surface text-text hover:bg-surface'}`}>
                                        <input type="radio" name="branch" value="Bangkok" checked={eCardData.branch === 'Bangkok'} onChange={handleECardChange} className="mr-2" />
                                        <i className="fas fa-building mr-2"></i> Bangkok (Sale Office)
                                    </label>
                                </div>
                            </div>

                            <button onClick={saveECardSettings} disabled={isSavingCard} className="w-full bg-blue-600 hover:bg-blue-500 text-text py-2.5 rounded-lg font-bold shadow-md transition">
                                {isSavingCard ? 'กำลังบันทึก...' : 'บันทึกการตั้งค่านามบัตร'}
                            </button>
                        </div>

                        {/* 🌟 พรีวิวภาพนามบัตร (Preview) 🌟 */}
                        <div className="flex justify-center items-center bg-surface p-2 sm:p-4 md:p-8 rounded-xl border border-glass overflow-x-auto w-full">
                            
                            {/* --- Wrapper สำหรับแก้ไขการเรนเดอร์ Shadow ผิดพลาด --- */}
                            <div className="shadow-2xl rounded-xl overflow-hidden shrink-0">
                                
                                {/* --- โครงสร้าง E-Business Card ที่จะถูก Export เป็นภาพ --- */}
                                <div 
                                    ref={cardRef} 
                                    className="bg-surface text-text relative flex flex-col justify-between"
                                    style={{ width: '600px', height: '350px', padding: '32px' }} 
                                >
                                    {/* กราฟิกตกแต่ง */}
                                    <div className="absolute top-0 right-0 w-48 h-48 bg-[#003366] rounded-bl-full opacity-10"></div>
                                    <div className="absolute bottom-0 left-0 w-32 h-32 bg-red-600 rounded-tr-full opacity-5"></div>

                                    {/* 🌟 Header: ใช้ Local Assets จากโฟลเดอร์ /public 🌟 */}
                                    <div className="flex justify-between items-start z-10 w-full">
                                        <div className="flex items-center gap-4">
                                            <img 
                                                src="/logo_ttm.png" 
                                                alt="TTM Logo" 
                                                className="w-16 h-16 object-contain" 
                                            />
                                            <div>
                                                <h1 className="text-xl font-black text-[#003366] uppercase tracking-wider m-0 leading-tight">Top Trend</h1>
                                                <p className="text-xs font-bold text-text uppercase tracking-widest m-0">Manufacturing Co.,Ltd.</p>
                                            </div>
                                        </div>
                                        
                                        {/* โลโก้ Carbon Footprint แบบ Local */}
                                        <img 
                                            src="/logo_cfo.png" 
                                            alt="Carbon Footprint" 
                                            className="w-14 h-14 object-contain mt-1" 
                                        />
                                    </div>

                                    {/* Body: ชื่อพนักงาน และ แผนก */}
                                    <div className="z-10 mt-6">
                                        <h2 className="text-3xl font-extrabold text-text tracking-tight m-0">{displayData.name || 'ชื่อ นามสกุล'}</h2>
                                        <p className="text-sm text-[#003366] font-bold mt-1 uppercase tracking-wide">
                                            {displayData.jobTitle || 'ตำแหน่งงาน'}
                                            {displayData.dept && <span className="text-text ml-2 border-l-2 border-glass pl-2">{displayData.dept}</span>}
                                        </p>
                                    </div>

                                    {/* Footer: ข้อมูลติดต่อ & ที่อยู่ */}
                                    <div className="flex justify-between items-end mt-4 border-t-2 border-glass pt-4 z-10">
                                        
                                        {/* 🌟 เปลี่ยน Icon เป็น SVG ตรงนี้เพื่อแก้ปัญหากรอบสี่เหลี่ยม 🌟 */}
                                        <div className="space-y-1.5 text-xs font-semibold text-text">
                                            <div className="flex items-center">
                                                <div className="w-5 flex justify-center text-[#003366]">
                                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" fill="currentColor" className="w-3 h-3">
                                                        <path d="M164.9 24.6c-7.7-18.6-28-28.5-47.4-23.2l-88 24C12.1 30.2 0 46 0 64C0 311.4 200.6 512 448 512c18 0 33.8-12.1 38.6-29.5l24-88c5.3-19.4-4.6-39.7-23.2-47.4l-96-40c-16.3-6.8-35.2-2.1-46.3 11.6L304.7 368C234.3 334.7 177.3 277.7 144 207.3L193.3 167c13.7-11.2 18.4-30 11.6-46.3l-40-96z"/>
                                                    </svg>
                                                </div>
                                                <span className="ml-1">{displayData.phone || '-'}</span>
                                            </div>
                                            <div className="flex items-center">
                                                <div className="w-5 flex justify-center text-[#003366]">
                                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" fill="currentColor" className="w-3.5 h-3.5">
                                                        <path d="M48 64C21.5 64 0 85.5 0 112c0 15.1 7.1 29.3 19.2 38.4L236.8 313.6c11.4 8.5 27 8.5 38.4 0L492.8 150.4c12.1-9.1 19.2-23.3 19.2-38.4c0-26.5-21.5-48-48-48H48zM0 176V384c0 35.3 28.7 64 64 64H448c35.3 0 64-28.7 64-64V176L294.4 339.2c-22.8 17.1-54 17.1-76.8 0L0 176z"/>
                                                    </svg>
                                                </div>
                                                <span className="ml-1">{displayData.email || '-'}</span>
                                            </div>
                                            <div className="flex items-center">
                                                <div className="w-5 flex justify-center text-[#003366]">
                                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" fill="currentColor" className="w-3.5 h-3.5">
                                                        <path d="M352 256c0 22.2-1.2 43.6-3.3 64H163.3c-2.2-20.4-3.3-41.8-3.3-64s1.2-43.6 3.3-64H348.7c2.2 20.4 3.3 41.8 3.3 64zm28.8-64H503.9c5.3 20.5 8.1 41.9 8.1 64s-2.8 43.5-8.1 64H380.8c2.1-20.6 3.2-42 3.2-64s-1.1-43.4-3.2-64zm112.6-32H376.7c-10-63.9-29.8-117.4-55.3-151.6c78.3 20.7 142 77.5 171.9 151.6zm-149.1 0H167.7c6.1-36.4 15.5-68.6 27-94.7c10.5-23.6 22.2-40.7 33.5-51.5C239.4 3.2 248.7 0 256 0s16.6 3.2 27.8 13.8c11.3 10.8 23 27.9 33.5 51.5c11.6 26 20.9 58.2 27 94.7zm-209 0H18.6C48.6 85.9 112.2 29.1 190.6 8.4C165.1 42.6 145.3 96.1 135.3 160zM8.1 192H131.2c-2.1 20.6-3.2 42-3.2 64s1.1 43.4 3.2 64H8.1C2.8 299.5 0 278.1 0 256s2.8-43.5 8.1-64zM194.7 446.6c-11.6-26-20.9-58.2-27-94.6H344.3c-6.1 36.4-15.5 68.6-27 94.6c-10.5 23.6-22.2 40.7-33.5 51.5C272.6 508.8 263.3 512 256 512s-16.6-3.2-27.8-13.8c-11.3-10.8-23-27.9-33.5-51.5zM135.3 352c10 63.9 29.8 117.4 55.3 151.6C112.2 482.9 48.6 426.1 18.6 352H135.3zm358.1 0c-29.9 74.1-93.6 130.9-171.9 151.6c25.5-34.2 45.2-87.7 55.3-151.6H493.4z"/>
                                                    </svg>
                                                </div>
                                                <span className="ml-1">toptrendmfg.co.th</span>
                                            </div>
                                        </div>

                                        {/* คอลัมน์ขวา: ที่อยู่ตามสาขาที่เลือก */}
                                        <div className="text-right text-[10px] text-text max-w-[280px] leading-[1.4]">
                                            {eCardData.branch === 'Factory' ? (
                                                <>
                                                    <b className="text-[#003366] text-[11px]">Head Office & Factory</b><br/>
                                                    334 Moo 1, Sriracha Industrial Park,<br/>
                                                    Sukhapiban 8 Rd., Bung, Sriracha, Chonburi 20230 Thailand<br/>
                                                    Tel +66 38 480-848-51 | Fax : +66 38 760 763<br/>
                                                    Tax ID : 010 552 604 2901
                                                </>
                                            ) : (
                                                <>
                                                    <b className="text-[#003366] text-[11px]">Sale Office</b><br/>
                                                    553/2-6 Soi Sathupradit 41, Yannawa, Bangkok 10120<br/>
                                                    Thailand<br/>
                                                    Tel +66 2294 3409-10 | Fax : +66 2294 3480<br/>
                                                    Tax ID : 010 552 604 2901
                                                </>
                                            )}
                                        </div>
                                    </div>
                                </div>
                                {/* --- สิ้นสุดโครงสร้างนามบัตร --- */}
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    );
};

export default ProfilePage;