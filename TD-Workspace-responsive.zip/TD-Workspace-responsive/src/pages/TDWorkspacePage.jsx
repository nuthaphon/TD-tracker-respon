import React, { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { collection, query, orderBy, onSnapshot, addDoc, updateDoc, doc, serverTimestamp, where, deleteDoc } from 'firebase/firestore';
import { ref, uploadBytes, getDownloadURL } from 'firebase/storage';
import { db, storage } from '../firebase';
import { useAuth } from '../hooks/useAuth';
import { TD_JOB_CATEGORIES, DEPT_OPTIONS } from '../utils/constants';
import { logActivity } from '../utils/activityLogger';

const TDWorkspacePage = () => {
    const navigate = useNavigate(); 
    const { userData, user } = useAuth();
    const [loading, setLoading] = useState(true);
    const [activeTab, setActiveTab] = useState('inbox'); 

    const [approvedJobs, setApprovedJobs] = useState([]); 
    const [myPendingJobs, setMyPendingJobs] = useState([]); 
    const [projects, setProjects] = useState([]); 
    const [tdUsers, setTdUsers] = useState([]); 

    const [receiveModal, setReceiveModal] = useState({ isOpen: false, job: null });
    const [projectModal, setProjectModal] = useState({ isOpen: false, jobSource: null }); 

    const [receiveForm, setReceiveForm] = useState({ assignTo: '', jobCategory: '', comment: '' });
    
    const [projectForm, setProjectForm] = useState({ 
        projectName: '', details: '',
        jobCategory: '', what: '', who: '', when: '', where: '', why: '', how: '', cost: '', dueDate: '', requestingDept: ''
    });
    
    const [editingProjectId, setEditingProjectId] = useState(null); 
    const [viewArchive, setViewArchive] = useState(false);

    const [projectAttachments, setProjectAttachments] = useState([]);
    const [attachTitle, setAttachTitle] = useState('');
    const [selectedFile, setSelectedFile] = useState(null);
    const [isUploading, setIsUploading] = useState(false);
    const fileInputRef = useRef(null);

    const [isSubmitting, setIsSubmitting] = useState(false);

    // 🌟 Unified Permission Checks 🌟
    const isAdmin = userData?.role === 'Admin';
    const userJobTitle = (userData?.jobTitle || '').toLowerCase();
    
    const isTD = userData?.dept === 'TD' || isAdmin;
    const isTDMgrOrSup = isTD && (userJobTitle.includes('manager') || userJobTitle.includes('supervisor') || userJobTitle.includes('lead') || userJobTitle.includes('director') || isAdmin);

    useEffect(() => {
        if (!userData) return;

        // ดึงงานที่รอรับ (เฉพาะ Mgr/Sup ถึงจะใช้ข้อมูลส่วนนี้ แต่โหลดเผื่อไว้)
        const qApproved = query(collection(db, 'td_job_requests'), where('status', '==', 'Approved'));
        const unsubApproved = onSnapshot(qApproved, (snapshot) => {
            setApprovedJobs(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
        });

        // ดึงงานในคิวของตัวเอง (ทุกคนใน TD เห็นเฉพาะงานที่โดน Assign)
        const qMyJobs = query(collection(db, 'td_job_requests'), where('status', 'in', ['In Progress', 'Received']));
        const unsubMyJobs = onSnapshot(qMyJobs, (snapshot) => {
            const jobs = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
            setMyPendingJobs(jobs.filter(j => j.assignTo === userData.name && !j.projectId));
        });

        // ดึงโปรเจกต์ทั้งหมด
        const qProjects = query(collection(db, 'td_projects'), orderBy('createdAt', 'desc'));
        const unsubProjects = onSnapshot(qProjects, (snapshot) => {
            setProjects(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
            setLoading(false);
        });

        // ดึงรายชื่อทีม TD สำหรับ Assign งาน
        const unsubUsers = onSnapshot(collection(db, 'users'), (snapshot) => {
            const users = snapshot.docs.map(doc => doc.data());
            setTdUsers(users.filter(u => u.dept === 'TD' && u.role !== 'pending'));
        });

        return () => { unsubApproved(); unsubMyJobs(); unsubProjects(); unsubUsers(); };
    }, [userData]);

    const handleReceiveJob = async (e) => {
        e.preventDefault();
        setIsSubmitting(true);
        try {
            const jobRef = doc(db, 'td_job_requests', receiveModal.job.id);
            const newTimelineEvent = { status: 'In Progress', by: userData?.name, comment: receiveForm.comment, timestamp: new Date().toISOString() };
            await updateDoc(jobRef, {
                status: 'In Progress', assignTo: receiveForm.assignTo, jobCategory: receiveForm.jobCategory, timeline: [...(receiveModal.job.timeline || []), newTimelineEvent]
            });
            await logActivity(user, 'Received & Assigned Job', `รับงาน ${receiveModal.job.projectNo} และมอบหมายให้ ${receiveForm.assignTo}`);
            setReceiveModal({ isOpen: false, job: null });
            setReceiveForm({ assignTo: '', jobCategory: '', comment: '' });
        } catch (error) { alert("เกิดข้อผิดพลาด"); } 
        finally { setIsSubmitting(false); }
    };

    const handleFileUpload = async (e) => {
        e.preventDefault();
        if (!selectedFile || !attachTitle.trim()) return alert("กรุณาตั้งชื่อและเลือกไฟล์");
        setIsUploading(true);
        try {
            const uniqueFileName = `${Date.now()}_${selectedFile.name}`;
            const storageRef = ref(storage, `workspace_project_files/${uniqueFileName}`);
            
            const snapshot = await uploadBytes(storageRef, selectedFile);
            const downloadURL = await getDownloadURL(snapshot.ref);

            let fileType = 'document';
            if (selectedFile.type.includes('image')) fileType = 'image';
            else if (selectedFile.type.includes('spreadsheet') || selectedFile.type.includes('excel')) fileType = 'sheets';
            else if (selectedFile.type.includes('pdf')) fileType = 'docs';

            setProjectAttachments([...projectAttachments, {
                id: Date.now().toString(), title: attachTitle, url: downloadURL, type: fileType,
                addedBy: userData?.name, timestamp: new Date().toISOString()
            }]);
            await logActivity(user, 'Uploaded File', `แนบไฟล์ "${attachTitle}" สำหรับเตรียมสร้าง/แก้ไขโปรเจกต์`);
            setAttachTitle(''); setSelectedFile(null);
            if(fileInputRef.current) fileInputRef.current.value = "";
            setIsUploading(false);
        } catch (error) { 
            console.error(error);
            alert("เกิดข้อผิดพลาดในการอัปโหลดไฟล์ไปยัง Storage"); 
            setIsUploading(false); 
        }
    };

    const handleSaveProject = async (e) => {
        e.preventDefault();
        setIsSubmitting(true);
        try {
            if (editingProjectId) {
                await updateDoc(doc(db, 'td_projects', editingProjectId), {
                    projectName: projectForm.projectName, details: projectForm.details,
                    jobCategory: projectForm.jobCategory, what: projectForm.what, who: projectForm.who,
                    when: projectForm.when, where: projectForm.where, why: projectForm.why,
                    how: projectForm.how, cost: projectForm.cost, dueDate: projectForm.dueDate,
                    requestingDept: projectForm.requestingDept
                });
                await logActivity(user, 'Updated Project', `แก้ไขรายละเอียดโปรเจกต์: ${projectForm.projectName}`);
                alert("แก้ไขข้อมูลโปรเจกต์สำเร็จ!");
            } else {
                const sourceJob = projectModal.jobSource;
                const combinedAttachments = [...(sourceJob?.attachments || []), ...projectAttachments];
                
                const newProjectRef = await addDoc(collection(db, 'td_projects'), {
                    projectName: projectForm.projectName || '', details: projectForm.details || '',
                    owner: userData?.name || 'Unknown', ownerId: user?.uid || '',
                    coWorkers: [], status: 'Planning', progress: 0,
                    
                    jobRequestId: sourceJob ? sourceJob.id : null,
                    projectNoRef: sourceJob ? (sourceJob.projectNo || '-') : '-',
                    requestBy: sourceJob ? (sourceJob.requestBy || '') : userData?.name,
                    requestingDept: sourceJob ? (sourceJob.group || '') : (projectForm.requestingDept || userData?.dept),
                    attachments: combinedAttachments,
                    
                    jobCategory: sourceJob ? (sourceJob.jobCategory || '') : (projectForm.jobCategory || ''),
                    what: sourceJob ? (sourceJob.what || '') : (projectForm.what || ''),
                    who: sourceJob ? (sourceJob.who || '') : (projectForm.who || ''),
                    where: sourceJob ? (sourceJob.where || '') : (projectForm.where || ''),
                    when: sourceJob ? (sourceJob.when || '') : (projectForm.when || ''),
                    why: sourceJob ? (sourceJob.why || '') : (projectForm.why || ''),
                    how: sourceJob ? (sourceJob.how || '') : (projectForm.how || ''),
                    cost: projectForm.cost || sourceJob?.cost || '', 
                    dueDate: projectForm.dueDate || sourceJob?.dueDate || '', 
                    
                    schedule: {
                        problem: { planStart: '', planEnd: '', actualStart: '', actualEnd: '' },
                        concept: { planStart: '', planEnd: '', actualStart: '', actualEnd: '' },
                        trial: { planStart: '', planEnd: '', actualStart: '', actualEnd: '' },
                        implement: { planStart: '', planEnd: '', actualStart: '', actualEnd: '' }
                    },
                    createdAt: serverTimestamp()
                });

                if (sourceJob) {
                    await updateDoc(doc(db, 'td_job_requests', sourceJob.id), {
                        projectId: newProjectRef.id, projectName: projectForm.projectName
                    });
                }
                await logActivity(user, 'Created Project', `สร้างโปรเจกต์ใหม่: ${projectForm.projectName}`);
                alert("สร้างโปรเจกต์สำเร็จ! พร้อมลุยงานได้เลย");
            }

            setProjectModal({ isOpen: false, jobSource: null });
            setEditingProjectId(null);
            setProjectForm({ projectName: '', details: '', jobCategory: '', what: '', who: '', when: '', where: '', why: '', how: '', cost: '', dueDate: '', requestingDept: '' });
            setProjectAttachments([]);
            setActiveTab('projects'); 
        } catch (error) { alert("เกิดข้อผิดพลาดในการบันทึก"); } 
        finally { setIsSubmitting(false); }
    };

    const openEditProjectModal = (proj, e) => {
        e.stopPropagation(); 
        setProjectForm({
            projectName: proj.projectName || '', details: proj.details || '', jobCategory: proj.jobCategory || '',
            what: proj.what || '', who: proj.who || '', when: proj.when || '', where: proj.where || '',
            why: proj.why || '', how: proj.how || '', cost: proj.cost || '', dueDate: proj.dueDate || '',
            requestingDept: proj.requestingDept || ''
        });
        setEditingProjectId(proj.id);
        setProjectAttachments([]); 
        setProjectModal({ isOpen: true, jobSource: null });
    };

    const handleDeleteProject = async (id, name, e) => {
        e.stopPropagation();
        if (!window.confirm(`⚠️ คำเตือน!\nคุณแน่ใจหรือไม่ว่าต้องการลบโปรเจกต์ "${name}" อย่างถาวร?\n(ข้อมูลแผนงาน แชท และไฟล์ที่เชื่อมไว้จะหายไปทั้งหมด)`)) return;
        
        try {
            await deleteDoc(doc(db, 'td_projects', id));
            await logActivity(user, 'Deleted Project', `ลบโปรเจกต์: ${name}`);
        } catch (error) {
            alert('ไม่สามารถลบโปรเจกต์ได้');
        }
    };

    if (!isTD) {
        return (
            <div className="h-full flex flex-col items-center justify-center text-text bg-surface">
                <i className="fas fa-lock text-6xl mb-4 text-red-500 opacity-50"></i>
                <h2 className="text-2xl font-bold text-text mb-2">Access Denied</h2>
                <p className="text-sm">พื้นที่ส่วนนี้สงวนสิทธิ์เฉพาะพนักงานแผนก TD ในการจัดการโปรเจกต์เท่านั้น</p>
                <button onClick={() => navigate('/')} className="mt-6 bg-blue-600 hover:bg-blue-500 text-text px-6 py-2.5 rounded-lg text-sm font-bold shadow-lg transition">
                    <i className="fas fa-home mr-2"></i> กลับหน้าแรก (Dashboard)
                </button>
            </div>
        );
    }

    if (loading) return <div className="flex justify-center items-center h-full"><div className="animate-spin rounded-full h-12 w-12 border-t-2 border-purple-500"></div></div>;

    // 🌟 กรองโปรเจกต์ให้มองเห็นเฉพาะของตัวเอง หรือ ที่ตนมีสิทธิ์เข้าถึง (ยกเว้น Mgr/Sup เห็นทั้งหมด) 🌟
    const visibleProjects = projects.filter(p => {
        if (isTDMgrOrSup) return true;
        return p.owner === userData?.name || (p.coWorkers && p.coWorkers.includes(userData?.name));
    });

    const activeProjects = visibleProjects.filter(p => !['Completed', 'Accepted'].includes(p.status));
    const archivedProjects = visibleProjects.filter(p => ['Completed', 'Accepted'].includes(p.status));
    const displayProjects = viewArchive ? archivedProjects : activeProjects;

    return (
        <div className="h-full flex flex-col pb-6 relative">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6 border-b border-glass pb-4 gap-4">
                <h1 className="text-2xl font-bold text-purple-400 flex items-center">
                    <i className="fas fa-laptop-code mr-3"></i> TD Workspace
                </h1>
                
                <div className="flex bg-surface p-1.5 rounded-xl border border-glass shadow-inner w-full md:w-auto">
                    <button onClick={() => setActiveTab('inbox')} className={`flex-1 md:flex-none px-6 py-2 text-sm font-bold rounded-lg transition-all ${activeTab === 'inbox' ? 'bg-orange-600 text-text shadow-md' : 'text-text hover:text-text hover:bg-surface'}`}>
                        <i className="fas fa-inbox mr-2"></i> Job Inbox
                        {(myPendingJobs.length > 0 || (isTDMgrOrSup && approvedJobs.length > 0)) && (
                            <span className="ml-2 bg-red-500 text-text text-[10px] px-2 py-0.5 rounded-full animate-pulse">{myPendingJobs.length + (isTDMgrOrSup ? approvedJobs.length : 0)}</span>
                        )}
                    </button>
                    <button onClick={() => setActiveTab('projects')} className={`flex-1 md:flex-none px-6 py-2 text-sm font-bold rounded-lg transition-all ${activeTab === 'projects' ? 'bg-purple-600 text-text shadow-md' : 'text-text hover:text-text hover:bg-surface'}`}>
                        <i className="fas fa-project-diagram mr-2"></i> Projects Board
                    </button>
                </div>
            </div>

            <div className="flex-1 overflow-hidden flex flex-col">
                
                {/* 🟢 TAB 1: JOB INBOX */}
                {activeTab === 'inbox' && (
                    <div className="flex flex-col md:flex-row gap-6 h-full overflow-hidden">
                        
                        {/* แสดงกล่องรับงานเฉพาะ Manager/Supervisor */}
                        {isTDMgrOrSup && (
                            <div className="w-full md:w-1/2 bg-surface/50 rounded-2xl border border-glass p-5 flex flex-col h-full shadow-inner">
                                <h2 className="text-lg font-bold text-yellow-400 mb-4 border-b border-glass pb-2">
                                    <i className="fas fa-clipboard-check mr-2"></i> งานรอรับเข้าระบบ (Waiting Receive)
                                </h2>
                                <div className="flex-1 overflow-y-auto pr-2 custom-scrollbar space-y-3">
                                    {approvedJobs.map(job => (
                                        <div key={job.id} className="bg-surface border border-glass p-4 rounded-xl shadow-md hover:border-yellow-500 transition">
                                            <div className="flex justify-between items-start mb-2">
                                                <span className="font-bold text-primary text-sm">{job.projectNo}</span>
                                                <span className="bg-surface text-text text-[10px] px-2 py-1 rounded border border-glass">{job.group}</span>
                                            </div>
                                            <p className="text-xs text-text line-clamp-2 mb-3">What: {job.what}</p>
                                            
                                            <div className="flex justify-between items-center text-[10px] text-text mb-3 border-t border-glass pt-2">
                                                <span><i className="fas fa-calendar text-green-400"></i> Due: {job.dueDate || '-'}</span>
                                                {job.attachments && job.attachments.length > 0 && (
                                                    <span className="text-primary"><i className="fas fa-paperclip"></i> {job.attachments.length} files</span>
                                                )}
                                            </div>

                                            <button 
                                                onClick={() => {
                                                    setReceiveModal({ isOpen: true, job });
                                                    setReceiveForm({ assignTo: job.assignTo || '', jobCategory: job.jobCategory || '', comment: '' });
                                                }} 
                                                className="w-full bg-yellow-600 hover:bg-yellow-500 text-text text-xs font-bold py-2 rounded-lg transition"
                                            >
                                                <i className="fas fa-hand-holding mr-1"></i> ตรวจสอบและรับงาน
                                            </button>
                                        </div>
                                    ))}
                                    {approvedJobs.length === 0 && <div className="text-center text-text mt-10"><i className="fas fa-glass-cheers text-4xl mb-2 opacity-30"></i><p>ไม่มีงานรอรับ</p></div>}
                                </div>
                            </div>
                        )}

                        <div className={`w-full ${isTDMgrOrSup ? 'md:w-1/2' : 'w-full'} bg-surface/50 rounded-2xl border border-glass p-5 flex flex-col h-full shadow-inner`}>
                            <h2 className="text-lg font-bold text-orange-400 mb-4 border-b border-glass pb-2">
                                <i className="fas fa-hammer mr-2"></i> งานของฉัน รอเปิดโปรเจกต์ (My Queue)
                            </h2>
                            <div className="flex-1 overflow-y-auto pr-2 custom-scrollbar space-y-3">
                                {myPendingJobs.map(job => (
                                    <div key={job.id} className="bg-surface border border-glass p-4 rounded-xl shadow-md hover:border-orange-500 transition border-l-4 border-l-orange-500 group">
                                        <div className="flex justify-between items-start mb-2">
                                            <span className="font-bold text-primary text-sm">{job.projectNo}</span>
                                            <span className="bg-surface text-primary text-[10px] px-2 py-1 rounded border border-glass">{job.jobCategory || 'No Category'}</span>
                                        </div>
                                        <p className="text-xs text-text line-clamp-2 mb-2">Topic: {job.how}</p>

                                        <div className="bg-surface/50 p-2 rounded mt-2 mb-3 text-[10px] text-text space-y-1 border border-glass">
                                            <div className="flex justify-between"><span>Req By:</span> <span className="text-text">{job.requestBy} ({job.group})</span></div>
                                            <div className="flex justify-between"><span>Due Date:</span> <span className="text-green-400 font-bold">{job.dueDate || '-'}</span></div>
                                            {job.attachments && job.attachments.length > 0 && (
                                                <div className="flex justify-between text-primary border-t border-glass pt-1 mt-1">
                                                    <span><i className="fas fa-paperclip"></i> ไฟล์แนบ:</span> <span>{job.attachments.length} รายการ</span>
                                                </div>
                                            )}
                                        </div>

                                        <button 
                                            onClick={() => {
                                                setEditingProjectId(null);
                                                setProjectForm({ projectName: '', details: '', jobCategory: '', what: '', who: '', when: '', where: '', why: '', how: '', cost: '', dueDate: '', requestingDept: '' });
                                                setProjectForm(prev => ({...prev, dueDate: job.dueDate || '', cost: job.cost || ''}));
                                                setProjectAttachments([]);
                                                setProjectModal({ isOpen: true, jobSource: job });
                                            }} 
                                            className="w-full bg-gradient-to-r from-orange-600 to-red-600 hover:from-orange-500 hover:to-red-500 text-text text-xs font-bold py-2.5 rounded-lg transition shadow-lg group-hover:scale-[1.02]"
                                        >
                                            <i className="fas fa-rocket mr-1"></i> เปิดเป็น Project
                                        </button>
                                    </div>
                                ))}
                                {myPendingJobs.length === 0 && <div className="text-center text-text mt-10"><i className="fas fa-box-open text-4xl mb-2 opacity-30"></i><p>คิวงานว่างเปล่า</p></div>}
                            </div>
                            
                            {/* ปุ่มสร้าง Project (Standalone) ให้ทุกคนในแผนก TD กดได้ */}
                            <div className="mt-4 pt-4 border-t border-glass text-center flex flex-col items-center">
                                <button 
                                    onClick={() => {
                                        setEditingProjectId(null);
                                        setProjectForm({ projectName: '', details: '', jobCategory: '', what: '', who: '', when: '', where: '', why: '', how: '', cost: '', dueDate: '', requestingDept: '' });
                                        setProjectAttachments([]);
                                        setProjectModal({ isOpen: true, jobSource: null });
                                    }} 
                                    className="bg-surface hover:bg-purple-600 text-text px-6 py-2.5 rounded-full font-bold transition shadow-lg flex items-center gap-2 mb-2"
                                >
                                    <i className="fas fa-plus-circle"></i> สร้างโปรเจคใหม่
                                </button>
                                <p className="text-[10px] text-text">สร้าง Project โดยไม่อิงจาก Job Request</p>
                            </div>
                        </div>
                    </div>
                )}

                {/* 🟢 TAB 2: PROJECTS BOARD */}
                {activeTab === 'projects' && (
                    <div className="h-full overflow-y-auto custom-scrollbar pb-10 pr-2">
                        
                        {!viewArchive ? (
                            archivedProjects.length > 0 && (
                                <div className="mb-6 bg-surface border border-primary border border-glass rounded-2xl p-4 md:p-6 shadow-lg flex flex-col md:flex-row items-center justify-between cursor-pointer hover:border-purple-500 hover:shadow-[0_0_20px_rgba(168,85,247,0.2)] transition-all group gap-4" onClick={() => setViewArchive(true)}>
                                    <div className="flex items-center gap-4 w-full md:w-auto">
                                        <div className="w-14 h-14 md:w-16 md:h-16 bg-surface rounded-2xl flex items-center justify-center border border-glass bg-surface border border-primary group-hover:border-purple-500 transition-colors shadow-inner shrink-0">
                                            <svg className="w-8 h-8 text-text group-hover:text-purple-400 transition-colors" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" d="M5 8h14M5 8a2 2 0 110-4h14a2 2 0 110 4M5 8v10a2 2 0 002 2h10a2 2 0 002-2V8m-9 4h4"></path>
                                            </svg>
                                        </div>
                                        <div>
                                            <h2 className="text-lg md:text-xl font-bold text-text group-hover:text-purple-400 transition-colors flex items-center gap-2">
                                                คลังโปรเจคที่ปิดงานแล้ว
                                            </h2>
                                            <p className="text-xs md:text-sm text-text mt-0.5">คลิกเพื่อดูโปรเจคที่ส่งมอบเสร็จสมบูรณ์ ({archivedProjects.length} รายการ)</p>
                                        </div>
                                    </div>
                                    <div className="text-text group-hover:text-purple-400 bg-surface px-5 py-2 rounded-full font-bold text-xs md:text-sm transition-colors border border-glass w-full md:w-auto text-center shrink-0 shadow-sm">
                                        เปิดคลังโปรเจค <i className="fas fa-arrow-right ml-2 group-hover:translate-x-1 transition-transform"></i>
                                    </div>
                                </div>
                            )
                        ) : (
                            <div className="mb-6 bg-purple-900/20 border border-purple-500/50 rounded-2xl p-4 shadow-lg flex flex-col md:flex-row items-center justify-between gap-4 animate-fade-in">
                                <div className="flex items-center gap-3 w-full md:w-auto">
                                    <div className="w-10 h-10 bg-purple-900/50 rounded-lg flex items-center justify-center border border-purple-500/50 text-purple-400 shrink-0">
                                        <i className="fas fa-archive text-xl"></i>
                                    </div>
                                    <div>
                                        <h2 className="text-lg font-bold text-primary leading-tight">Project Archive</h2>
                                        <p className="text-xs text-text/80">ระบบจัดเก็บโปรเจกต์ที่ปิดงานแล้ว</p>
                                    </div>
                                </div>
                                <button onClick={() => setViewArchive(false)} className="bg-surface hover:bg-surface text-text px-5 py-2 rounded-lg text-sm font-bold shadow-md transition border border-glass w-full md:w-auto">
                                    <i className="fas fa-arrow-left mr-2"></i> กลับไปหน้า Active
                                </button>
                            </div>
                        )}

                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                            {displayProjects.map(proj => {
                                // สิทธิ์การแก้ไข/ลบโปรเจกต์: ทำได้เฉพาะ Mgr/Sup หรือ Owner
                                const canEditOrDelete = isTDMgrOrSup || proj.owner === userData?.name || proj.ownerId === user?.uid;

                                return (
                                    <div key={proj.id} className={`bg-surface rounded-2xl border border-glass shadow-xl overflow-hidden transition group flex flex-col h-64 relative ${viewArchive ? 'grayscale hover:grayscale-0 opacity-80 hover:opacity-100 hover:border-indigo-500' : 'hover:border-purple-500 hover:-translate-y-1'}`}>
                                        
                                        <div className="absolute top-3 right-3 flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity duration-200 z-10">
                                            {canEditOrDelete && !viewArchive && (
                                                <button onClick={(e) => openEditProjectModal(proj, e)} className="w-8 h-8 rounded-lg bg-blue-600/90 hover:bg-blue-500 text-text flex items-center justify-center backdrop-blur shadow-md transition-transform hover:scale-110" title="แก้ไขข้อมูลเบื้องต้น">
                                                    <i className="fas fa-edit text-xs"></i>
                                                </button>
                                            )}
                                            {canEditOrDelete && (
                                                <button onClick={(e) => handleDeleteProject(proj.id, proj.projectName, e)} className="w-8 h-8 rounded-lg bg-red-600/90 hover:bg-red-500 text-text flex items-center justify-center backdrop-blur shadow-md transition-transform hover:scale-110" title="ลบโปรเจกต์อย่างถาวร">
                                                    <i className="fas fa-trash-alt text-xs"></i>
                                                </button>
                                            )}
                                        </div>

                                        <div className="bg-surface p-4 border-b border-glass flex justify-between items-start" onClick={() => navigate(`/project/${proj.id}`)}>
                                            <div className="pr-16 cursor-pointer">
                                                <h3 className={`font-bold text-text text-lg line-clamp-1 transition ${viewArchive ? 'group-hover:text-indigo-400' : 'group-hover:text-purple-400'}`} title={proj.projectName}>{proj.projectName}</h3>
                                                {proj.projectNoRef !== '-' && <p className="text-[10px] text-primary mt-1">Ref: {proj.projectNoRef}</p>}
                                            </div>
                                        </div>
                                        <div className="p-4 flex-1 flex flex-col cursor-pointer" onClick={() => navigate(`/project/${proj.id}`)}>
                                            <p className="text-xs text-text line-clamp-3 mb-4 flex-1">{proj.details || proj.how}</p>
                                            
                                            <div className="mt-auto">
                                                <div className="flex justify-between items-end mb-1">
                                                    <span className={`text-[9px] font-bold uppercase ${viewArchive ? 'text-indigo-400' : 'text-text'}`}>
                                                        {viewArchive ? 'Status: Completed' : 'Progress'}
                                                    </span>
                                                    <span className={`font-black ${viewArchive ? 'text-indigo-400 text-xs' : 'text-purple-400 text-sm'}`}>{proj.progress}%</span>
                                                </div>
                                                <div className="w-full bg-surface rounded-full h-1.5 mb-3 overflow-hidden border border-glass">
                                                    <div className={`${viewArchive ? 'bg-indigo-500' : 'bg-purple-500'} h-full rounded-full transition-all duration-1000`} style={{ width: `${proj.progress}%` }}></div>
                                                </div>
                                                <div className="flex justify-between items-center border-t border-glass/50 pt-3">
                                                    <div className="flex -space-x-2 overflow-hidden" title={`Owner: ${proj.owner}`}>
                                                        <div className={`w-7 h-7 rounded-full border border-glass flex items-center justify-center text-[10px] text-text font-bold ${viewArchive ? 'bg-indigo-600' : 'bg-purple-600'}`}>
                                                            {proj.owner?.substring(0,2).toUpperCase()}
                                                        </div>
                                                    </div>
                                                    
                                                    <span className={`${viewArchive ? 'text-indigo-400 group-hover:text-indigo-300' : 'text-purple-400 group-hover:text-purple-300'} text-[10px] font-bold transition flex items-center gap-1`}>
                                                        เปิดพื้นที่ <i className="fas fa-arrow-right group-hover:translate-x-1 transition-transform"></i>
                                                    </span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                );
                            })}
                            {displayProjects.length === 0 && (
                                <div className="col-span-full text-center text-text py-10">
                                    {viewArchive ? 'ไม่มีโปรเจกต์ในคลัง' : 'คุณยังไม่มีโปรเจกต์ที่ต้องรับผิดชอบ'}
                                </div>
                            )}
                        </div>
                    </div>
                )}
            </div>

            {/* MODAL: หัวหน้ากด Receive Job */}
            {receiveModal.isOpen && (
                <div className="fixed inset-0 bg-black/10 flex justify-center items-center z-50 p-4 backdrop-blur-sm">
                    <form onSubmit={handleReceiveJob} className="bg-surface w-full max-w-md rounded-2xl shadow-2xl border border-glass overflow-hidden">
                        <div className="bg-surface p-4 border-b border-glass">
                            <h2 className="text-xl font-bold text-primary"><i className="fas fa-hand-holding mr-2"></i> Receive Job Request</h2>
                            <p className="text-xs text-text mt-1">Ref: {receiveModal.job?.projectNo}</p>
                        </div>
                        <div className="p-6 space-y-4">
                            <div>
                                <label className="block text-xs text-text mb-2">มอบหมายงานให้ (Assign To) *</label>
                                <select value={receiveForm.assignTo} onChange={(e) => setReceiveForm({...receiveForm, assignTo: e.target.value})} required className="w-full p-2.5 bg-surface rounded-lg border border-glass text-text outline-none focus:border-yellow-500">
                                    <option value="">-- เลือกช่าง/วิศวกร TD --</option>
                                    {tdUsers.map(u => <option key={u.name} value={u.name}>{u.name}</option>)}
                                </select>
                            </div>
                            <div>
                                <label className="block text-xs text-text mb-2">หมวดหมู่งาน (Job Category) *</label>
                                <select value={receiveForm.jobCategory} onChange={(e) => setReceiveForm({...receiveForm, jobCategory: e.target.value})} required className="w-full p-2.5 bg-surface rounded-lg border border-glass text-text outline-none focus:border-yellow-500">
                                    <option value="">-- เลือกหมวดหมู่งาน --</option>
                                    {TD_JOB_CATEGORIES.map(c => <option key={c} value={c}>{c}</option>)}
                                </select>
                            </div>
                            <div>
                                <label className="block text-xs text-text mb-2">ข้อความ/คำแนะนำเพิ่มเติม</label>
                                <textarea value={receiveForm.comment} onChange={(e) => setReceiveForm({...receiveForm, comment: e.target.value})} className="w-full p-2.5 bg-surface rounded-lg border border-glass text-text outline-none focus:border-yellow-500" rows="2"></textarea>
                            </div>
                        </div>
                        <div className="p-4 border-t border-glass bg-surface flex justify-end gap-3">
                            <button type="button" onClick={() => setReceiveModal({isOpen:false, job:null})} className="px-5 py-2 text-text hover:text-text font-bold">ยกเลิก</button>
                            <button type="submit" disabled={isSubmitting} className="px-6 py-2 bg-yellow-600 hover:bg-yellow-500 text-text rounded-lg font-bold transition disabled:opacity-50">รับงาน (Receive)</button>
                        </div>
                    </form>
                </div>
            )}

            {/* 🌟 MODAL: สร้าง หรือ แก้ไข Project 🌟 */}
            {projectModal.isOpen && (
                <div className="fixed inset-0 bg-black/10 flex justify-center items-center z-50 p-4 backdrop-blur-sm">
                    <form onSubmit={handleSaveProject} className="bg-surface w-full max-w-3xl rounded-2xl shadow-2xl border border-glass overflow-hidden flex flex-col max-h-[95vh]">
                        <div className={`p-5 border-b border-glass relative shrink-0 ${editingProjectId ? 'bg-gradient-to-r from-blue-900 to-indigo-900' : 'bg-gradient-to-r from-orange-900 to-red-900'}`}>
                            <button type="button" onClick={() => { setProjectModal({isOpen:false, jobSource:null}); setEditingProjectId(null); }} className="absolute top-4 right-4 text-text hover:text-text text-2xl font-bold">&times;</button>
                            <h2 className="text-xl font-bold text-white flex items-center gap-2">
                                {editingProjectId ? <><i className="fas fa-edit text-primary"></i> แก้ไขข้อมูลโปรเจกต์</> : <><i className="fas fa-rocket text-orange-400"></i> {projectModal.jobSource ? 'เปิดโปรเจกต์ใหม่จาก Ticket' : 'สร้างโปรเจคใหม่ (Standalone)'}</>}
                            </h2>
                            {projectModal.jobSource && !editingProjectId && <p className="text-xs text-orange-200 mt-1">อ้างอิงจาก Ticket: {projectModal.jobSource.projectNo}</p>}
                        </div>
                        
                        <div className="p-6 overflow-y-auto space-y-6 flex-1 custom-scrollbar">
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                                <div className="md:col-span-2">
                                    <label className={`block text-xs font-bold mb-1 ${editingProjectId ? 'text-primary' : 'text-orange-400'}`}>ตั้งชื่อโปรเจกต์ (Project Name) *</label>
                                    <input type="text" value={projectForm.projectName} onChange={(e) => setProjectForm({...projectForm, projectName: e.target.value})} required placeholder="เช่น โปรเจกต์ลดของเสียสายพาน A" className={`w-full p-3 bg-surface rounded-xl border border-glass text-text font-bold text-lg outline-none focus:border-${editingProjectId ? 'blue' : 'orange'}-500`} />
                                </div>
                                <div className="md:col-span-2">
                                    <label className="block text-xs text-text mb-1">รายละเอียด/วัตถุประสงค์ (Objective) *</label>
                                    <textarea value={projectForm.details} onChange={(e) => setProjectForm({...projectForm, details: e.target.value})} required rows="2" placeholder="เป้าหมายของโปรเจกต์นี้คืออะไร..." className={`w-full p-3 bg-surface rounded-xl border border-glass text-text outline-none focus:border-${editingProjectId ? 'blue' : 'orange'}-500 text-sm`}></textarea>
                                </div>
                            </div>

                            {projectModal.jobSource && !editingProjectId ? (
                                <div className="bg-surface/60 p-5 rounded-xl border border-glass shadow-inner space-y-4">
                                    <p className="text-sm text-primary font-bold uppercase border-b border-glass pb-2"><i className="fas fa-link mr-1"></i> ข้อมูลที่ดึงมาจาก Job Request อัตโนมัติ</p>
                                    
                                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm text-text">
                                        <div className="bg-surface p-3 rounded-lg border border-glass"><span className="text-xs text-text block mb-1">Category:</span> <span className="font-bold text-primary">{projectModal.jobSource.jobCategory || '-'}</span></div>
                                        <div className="bg-surface p-3 rounded-lg border border-glass"><span className="text-xs text-text block mb-1">Requested By:</span> <span className="font-bold text-text">{projectModal.jobSource.requestBy || '-'} ({projectModal.jobSource.group || '-'})</span></div>
                                        
                                        <div className="md:col-span-2 space-y-2 mt-2">
                                            <div className="flex gap-2"><span className="text-xs font-bold text-text whitespace-nowrap">1.What?:</span> <span>{projectModal.jobSource.what || '-'}</span></div>
                                            <div className="flex gap-2"><span className="text-xs font-bold text-text whitespace-nowrap">2.Who?:</span> <span>{projectModal.jobSource.who || '-'}</span></div>
                                            <div className="flex gap-2"><span className="text-xs font-bold text-text whitespace-nowrap">3.When?:</span> <span>{projectModal.jobSource.when || '-'}</span></div>
                                            <div className="flex gap-2"><span className="text-xs font-bold text-text whitespace-nowrap">4.Where?:</span> <span>{projectModal.jobSource.where || '-'}</span></div>
                                            <div className="flex gap-2"><span className="text-xs font-bold text-text whitespace-nowrap">5.Why?:</span> <span>{projectModal.jobSource.why || '-'}</span></div>
                                            <div className="flex gap-2 border-t border-glass pt-2"><span className="text-xs font-bold text-primary whitespace-nowrap">6.How?:</span> <span className="text-primary">{projectModal.jobSource.how || '-'}</span></div>
                                        </div>
                                    </div>
                                </div>
                            ) : (
                                <div className="bg-surface/60 p-5 rounded-xl border border-glass shadow-inner">
                                    <p className={`text-sm font-bold uppercase border-b border-glass pb-2 mb-4 ${editingProjectId ? 'text-primary' : 'text-orange-400'}`}><i className="fas fa-list mr-1"></i> ข้อมูลพื้นฐานโครงการ (5W1H)</p>
                                    
                                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                                        <div className="md:col-span-2">
                                            <label className="block text-xs text-text mb-1">หมวดหมู่งาน (Job Category) *</label>
                                            <select value={projectForm.jobCategory} onChange={(e) => setProjectForm({...projectForm, jobCategory: e.target.value})} required className="w-full p-2.5 bg-surface rounded-lg border border-glass text-text outline-none focus:border-blue-500">
                                                <option value="">-- เลือกหมวดหมู่งาน --</option>
                                                {TD_JOB_CATEGORIES.map(c => <option key={c} value={c}>{c}</option>)}
                                            </select>
                                        </div>
                                        <div className="md:col-span-2">
                                            <label className="block text-xs text-text mb-1">แผนกที่ร้องขอ (Requesting Dept) *</label>
                                            <select value={projectForm.requestingDept} onChange={(e) => setProjectForm({...projectForm, requestingDept: e.target.value})} required className="w-full p-2.5 bg-surface rounded-lg border border-glass text-text outline-none focus:border-blue-500">
                                                <option value="">-- เลือกแผนกต้นทาง --</option>
                                                {DEPT_OPTIONS ? DEPT_OPTIONS.map(d => <option key={d} value={d}>{d}</option>) : <option value="TD">TD</option>}
                                            </select>
                                        </div>

                                        <div className="md:col-span-2"><label className="block text-xs text-text mb-1">1. What? เกิดอะไรขึ้น/ต้องการทำอะไร *</label><textarea value={projectForm.what} onChange={(e) => setProjectForm({...projectForm, what: e.target.value})} className="w-full p-2.5 bg-surface rounded-lg border border-glass text-text outline-none focus:border-blue-500 text-sm" rows="2" required></textarea></div>
                                        <div><label className="block text-xs text-text mb-1">2. Who? ใคร/เครื่องจักรไหนเกี่ยวข้อง *</label><input type="text" value={projectForm.who} onChange={(e) => setProjectForm({...projectForm, who: e.target.value})} className="w-full p-2.5 bg-surface rounded-lg border border-glass text-text outline-none focus:border-blue-500 text-sm" required/></div>
                                        <div><label className="block text-xs text-text mb-1">3. When? เริ่มเมื่อไหร่ *</label><input type="text" value={projectForm.when} onChange={(e) => setProjectForm({...projectForm, when: e.target.value})} className="w-full p-2.5 bg-surface rounded-lg border border-glass text-text outline-none focus:border-blue-500 text-sm" required/></div>
                                        <div><label className="block text-xs text-text mb-1">4. Where? ที่ไหน *</label><input type="text" name="where" value={projectForm.where} onChange={(e) => setProjectForm({...projectForm, where: e.target.value})} className="w-full p-2.5 bg-surface rounded-lg border border-glass text-text outline-none focus:border-blue-500 text-sm" required/></div>
                                        <div><label className="block text-xs text-text mb-1">5. Why? ทำไมต้องทำ *</label><input type="text" value={projectForm.why} onChange={(e) => setProjectForm({...projectForm, why: e.target.value})} className="w-full p-2.5 bg-surface rounded-lg border border-glass text-text outline-none focus:border-blue-500 text-sm" required/></div>
                                        <div className="md:col-span-2"><label className="block text-xs text-text mb-1">6. How? แผนการทำงานคร่าวๆ *</label><textarea value={projectForm.how} onChange={(e) => setProjectForm({...projectForm, how: e.target.value})} className="w-full p-2.5 bg-surface rounded-lg border border-glass text-text outline-none focus:border-blue-500 text-sm" rows="2" required></textarea></div>
                                    </div>
                                </div>
                            )}

                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 p-4 bg-surface/80 rounded-xl border border-glass">
                                <div>
                                    <label className="block text-xs text-red-400 mb-1 font-bold">Cost Estimate (แก้ไขได้)</label>
                                    <input type="number" value={projectForm.cost} onChange={(e) => setProjectForm({...projectForm, cost: e.target.value})} className="w-full p-2.5 bg-surface rounded border border-glass text-text focus:border-red-500 outline-none" placeholder="บาท"/>
                                </div>
                                <div>
                                    <label className="block text-xs text-green-600 mb-1 font-bold">Due Date (กำหนดวันจบงาน) *</label>
                                    <input type="date" value={projectForm.dueDate} onChange={(e) => setProjectForm({...projectForm, dueDate: e.target.value})} className="w-full p-2.5 bg-surface rounded border border-glass text-text focus:border-green-500 outline-none" required/>
                                </div>
                            </div>

                            {/* 🌟 แสดงส่วนอัปโหลดไฟล์เฉพาะกรณีสร้างใหม่ 🌟 */}
                            {!editingProjectId && (
                                <div className="bg-surface/50 p-5 rounded-xl border border-glass">
                                    <label className="block text-sm text-primary mb-3 font-bold"><i className="fas fa-cloud-upload-alt mr-2"></i> ไฟล์แนบเอกสารโปรเจกต์</label>
                                    
                                    {projectModal.jobSource?.attachments && projectModal.jobSource.attachments.length > 0 && (
                                        <div className="mb-3 p-3 bg-surface/80 rounded-lg border border-glass text-xs">
                                            <p className="text-text font-bold mb-2">ไฟล์จาก Job Request ต้นทาง:</p>
                                            <div className="space-y-1.5">
                                                {projectModal.jobSource.attachments.map((f, i) => (
                                                    <a key={i} href={f.url} target="_blank" rel="noreferrer" className="flex items-center text-primary hover:text-primary">
                                                        <i className="fas fa-link mr-2 text-text"></i> {f.title}
                                                    </a>
                                                ))}
                                            </div>
                                        </div>
                                    )}

                                    {projectAttachments.length > 0 && (
                                        <div className="mb-3 space-y-1.5">
                                            {projectAttachments.map((file, idx) => (
                                                <div key={idx} className="bg-surface border border-glass p-2 rounded flex justify-between items-center text-xs">
                                                    <span className="text-green-400"><i className="fas fa-file mr-2"></i> {file.title}</span>
                                                    <button type="button" onClick={() => setProjectAttachments(projectAttachments.filter(f => f.id !== file.id))} className="text-red-500 hover:text-red-400"><i className="fas fa-times"></i></button>
                                                </div>
                                            ))}
                                        </div>
                                    )}

                                    <div className="flex flex-col md:flex-row gap-2 items-center">
                                        <input type="text" value={attachTitle} onChange={(e)=>setAttachTitle(e.target.value)} placeholder="ชื่อไฟล์เพิ่มเติม..." className="w-full md:w-1/3 p-2 bg-surface rounded border border-glass text-xs text-text outline-none focus:border-blue-500" disabled={isUploading}/>
                                        <input type="file" ref={fileInputRef} onChange={(e)=>setSelectedFile(e.target.files[0])} className="w-full md:w-1/3 text-xs text-text file:mr-2 file:py-1 file:px-2 file:rounded file:border-1 file:bg-surface file:text-text hover:file:bg-surface cursor-pointer" disabled={isUploading}/>
                                        <button type="button" onClick={handleFileUpload} disabled={!selectedFile || !attachTitle || isUploading} className="w-full md:w-1/3 bg-green-600 hover:bg-green-500 text-text py-2 rounded text-xs font-bold transition disabled:opacity-50 shadow">
                                            {isUploading ? <i className="fas fa-spinner fa-spin"></i> : '+ แนบไฟล์เพิ่ม'}
                                        </button>
                                    </div>
                                </div>
                            )}

                        </div>

                        <div className="p-5 border-t border-glass bg-surface flex justify-end gap-3 shrink-0">
                            <button type="button" onClick={() => { setProjectModal({isOpen:false, jobSource:null}); setEditingProjectId(null); }} className="px-6 py-2.5 text-text hover:text-text font-bold rounded-lg transition">ยกเลิก</button>
                            <button type="submit" disabled={isSubmitting} className={`px-8 py-2.5 text-text rounded-lg font-bold shadow-lg transition transform hover:scale-105 disabled:opacity-50 disabled:transform-none ${editingProjectId ? 'bg-blue-600 hover:bg-blue-500' : 'bg-gradient-to-r from-orange-600 to-red-600 hover:from-orange-500 hover:to-red-500'}`}>
                                {isSubmitting ? 'กำลังบันทึก...' : (editingProjectId ? 'บันทึกการแก้ไข' : 'สร้างโปรเจค')}
                            </button>
                        </div>
                    </form>
                </div>
            )}
        </div>
    );
};

export default TDWorkspacePage;