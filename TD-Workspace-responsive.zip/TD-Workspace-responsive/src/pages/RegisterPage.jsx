import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useAuth } from '../hooks/useAuth';
// 🌟 ดึงข้อมูลตัวเลือกมาจากไฟล์ constants
import { DEPT_OPTIONS, JOB_TITLE_OPTIONS } from '../utils/constants';

const RegisterPage = () => {
    const [formData, setFormData] = useState({
        email: '', password: '', confirmPassword: '',
        name: '', phone: '', dept: '', customDept: '', jobTitle: ''
    });
    
    const [acceptPDPA, setAcceptPDPA] = useState(false);
    const [error, setError] = useState('');
    const [loading, setLoading] = useState(false);
    
    const { register } = useAuth();
    const navigate = useNavigate();

    // ❌ ลบ hardcode array ของเดิมทิ้งไปได้เลย โค้ดดูสะอาดขึ้นเยอะครับ!

    const handleChange = (e) => setFormData({ ...formData, [e.target.name]: e.target.value });
    const handleCustomDeptChange = (e) => setFormData({ ...formData, customDept: e.target.value.toUpperCase().replace(/[^A-Z]/g, '').substring(0, 3) });

    const handleRegister = async (e) => {
        e.preventDefault();
        setError('');

        if (!acceptPDPA) return setError('กรุณายอมรับเงื่อนไขการใช้งานและนโยบาย PDPA');
        if (formData.password !== formData.confirmPassword) return setError('รหัสผ่านไม่ตรงกัน กรุณาตรวจสอบอีกครั้ง');
        if (formData.password.length < 6) return setError('รหัสผ่านต้องมีอย่างน้อย 6 ตัวอักษร');

        const finalDept = formData.dept === 'Other' ? formData.customDept : formData.dept;
        if (!finalDept) return setError('กรุณาระบุแผนกของคุณ');

        setLoading(true);
        try {
            // สุ่มรูปพื้นฐานให้เงียบๆ หลังบ้าน โดยไม่ระบุพารามิเตอร์ซับซ้อนให้ API งง
            const randomSeed = Math.random().toString(36).substring(7);
            const defaultAvatarUrl = `https://api.dicebear.com/7.x/avataaars/svg?seed=${randomSeed}&backgroundColor=b6e3f4,c0aede,ffdfbf,ffd5dc,d1d4f9`;

            await register(formData.email, formData.password, {
                name: formData.name,
                phone: formData.phone,
                dept: finalDept,
                jobTitle: formData.jobTitle,
                avatar: defaultAvatarUrl 
            });
            
            alert('🎉 สมัครสมาชิกสำเร็จ!\n\nระบบได้ส่ง "อีเมลยืนยันตัวตน" ไปที่อีเมลของคุณแล้ว\nกรุณาตรวจสอบกล่องจดหมาย (หรือ Junk Mail) และคลิกลิงก์เพื่อยืนยันอีเมลครับ');
            navigate('/');
        } catch (err) {
            console.error(err);
            setError('ไม่สามารถสมัครสมาชิกได้: ' + err.message);
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="min-h-screen flex items-center justify-center bg-surface text-text p-3 sm:p-4 py-6 sm:py-10 overflow-y-auto custom-scrollbar">
            <div className="bg-surface p-4 sm:p-6 md:p-8 rounded-xl shadow-2xl w-full max-w-2xl border border-glass mt-4 md:mt-0">
                <h1 className="text-2xl sm:text-3xl font-bold text-center mb-2 text-purple-400">สร้างบัญชีผู้ใช้งาน</h1>
                <p className="text-center text-text mb-6 text-sm">กรอกข้อมูลส่วนตัวเพื่อลงทะเบียนใช้งานระบบ</p>
                
                {error && <p className="bg-red-500/20 border border-red-500 text-red-300 p-3 rounded-md mb-6 text-sm text-center font-bold animate-pulse">{error}</p>}
                
                <form onSubmit={handleRegister} className="grid grid-cols-1 md:grid-cols-2 gap-5">
                    
                    {/* --- ฟอร์มข้อมูลส่วนตัว --- */}
                    <div className="md:col-span-2">
                        <label className="block mb-1 text-sm text-text">ชื่อ - นามสกุล *</label>
                        <input type="text" name="name" value={formData.name} onChange={handleChange} required className="w-full p-2.5 bg-surface rounded-lg border border-glass focus:outline-none focus:border-purple-500" placeholder="ระบุชื่อจริง..." />
                    </div>
                    
                    <div>
                        <label className="block mb-1 text-sm text-text">แผนก (Department) *</label>
                        <select name="dept" value={formData.dept} onChange={handleChange} required className="w-full p-2.5 bg-surface rounded-lg border border-glass focus:outline-none focus:border-purple-500 text-text">
                            <option value="">-- เลือกแผนก --</option>
                            {/* 🌟 เรียกใช้งาน DEPT_OPTIONS */}
                            {DEPT_OPTIONS.map(d => <option key={d} value={d}>{d}</option>)}
                            <option value="Other" className="text-purple-400 font-bold">+ เพิ่มแผนกใหม่ (อื่นๆ)</option>
                        </select>
                        
                        {formData.dept === 'Other' && (
                            <input type="text" value={formData.customDept} onChange={handleCustomDeptChange} placeholder="ตัวย่อแผนก (EN) ไม่เกิน 3 ตัว" required maxLength="3" className="w-full mt-2 p-2.5 bg-surface rounded-lg border border-purple-500 text-purple-300 focus:outline-none font-bold text-center uppercase placeholder:text-xs placeholder:font-normal" />
                        )}
                    </div>

                    <div>
                        <label className="block mb-1 text-sm text-text">ตำแหน่ง (Position) *</label>
                        <select name="jobTitle" value={formData.jobTitle} onChange={handleChange} required className="w-full p-2.5 bg-surface rounded-lg border border-glass focus:outline-none focus:border-purple-500 text-text">
                            <option value="">-- เลือกตำแหน่ง --</option>
                            {/* 🌟 เรียกใช้งาน JOB_TITLE_OPTIONS */}
                            {JOB_TITLE_OPTIONS.map(j => <option key={j} value={j}>{j}</option>)}
                        </select>
                    </div>

                    <div className="md:col-span-2">
                        <label className="block mb-1 text-sm text-text">เบอร์โทรศัพท์ติดต่อ</label>
                        <input type="tel" name="phone" value={formData.phone} onChange={handleChange} className="w-full p-2.5 bg-surface rounded-lg border border-glass focus:outline-none focus:border-purple-500" placeholder="08X-XXX-XXXX" />
                    </div>

                    <div className="md:col-span-2 border-t border-glass my-2 pt-4">
                        <h3 className="text-sm font-bold text-text mb-4"><i className="fas fa-lock text-purple-400"></i> ข้อมูลเข้าสู่ระบบ (ระบบจะส่งลิงก์ยืนยันไปที่อีเมลนี้)</h3>
                    </div>

                    <div className="md:col-span-2">
                        <label className="block mb-1 text-sm text-text">Email *</label>
                        <input type="email" name="email" value={formData.email} onChange={handleChange} required className="w-full p-2.5 bg-surface rounded-lg border border-glass focus:outline-none focus:border-purple-500" placeholder="example@email.com" />
                    </div>

                    <div>
                        <label className="block mb-1 text-sm text-text">รหัสผ่าน (ขั้นต่ำ 6 ตัว) *</label>
                        <input type="password" name="password" value={formData.password} onChange={handleChange} required className="w-full p-2.5 bg-surface rounded-lg border border-glass focus:outline-none focus:border-purple-500" />
                    </div>

                    <div>
                        <label className="block mb-1 text-sm text-text">ยืนยันรหัสผ่านอีกครั้ง *</label>
                        <input type="password" name="confirmPassword" value={formData.confirmPassword} onChange={handleChange} required className="w-full p-2.5 bg-surface rounded-lg border border-glass focus:outline-none focus:border-purple-500" />
                    </div>

                    <div className="md:col-span-2 mt-4 bg-surface/80 p-4 rounded-lg border border-glass flex items-start gap-3 hover:border-purple-500/50 transition">
                        <input 
                            type="checkbox" id="pdpa" checked={acceptPDPA} onChange={(e) => setAcceptPDPA(e.target.checked)}
                            className="mt-1 w-5 h-5 accent-purple-500 cursor-pointer shrink-0" 
                        />
                        <label htmlFor="pdpa" className="text-xs text-text cursor-pointer leading-relaxed select-none">
                            ข้าพเจ้ายินยอมให้แพลตฟอร์มจัดเก็บและประมวลผลข้อมูลส่วนบุคคลของข้าพเจ้า ตาม <span className="text-purple-400 font-bold">พระราชบัญญัติคุ้มครองข้อมูลส่วนบุคคล (PDPA)</span> เพื่อใช้ในการยืนยันตัวตนและการดำเนินงานภายในระบบเท่านั้น
                        </label>
                    </div>

                    <div className="md:col-span-2 mt-4">
                        <button type="submit" disabled={loading || !acceptPDPA} className={`w-full font-bold py-4 rounded-xl shadow-lg transition-all ${acceptPDPA ? 'bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-500 hover:to-blue-500 transform hover:scale-[1.02] text-text' : 'bg-surface text-text cursor-not-allowed'}`}>
                            {loading ? 'กำลังสร้างบัญชีและส่งอีเมล...' : 'สมัครสมาชิก (Register)'}
                        </button>
                    </div>
                </form>

                <div className="mt-6 text-center text-sm text-text">
                    มีบัญชีอยู่แล้วใช่ไหม? <Link to="/login" className="text-purple-400 hover:text-purple-300 font-bold ml-1 hover:underline">เข้าสู่ระบบที่นี่</Link>
                </div>
            </div>
        </div>
    );
};

export default RegisterPage;