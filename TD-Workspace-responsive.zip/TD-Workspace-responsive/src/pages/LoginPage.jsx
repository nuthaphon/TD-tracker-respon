import React, { useState, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useAuth } from '../hooks/useAuth';
// 🌟 นำเข้าฟังก์ชันสำหรับรีเซ็ตรหัสผ่านจาก Firebase
import { getAuth, sendPasswordResetEmail } from 'firebase/auth';

const LoginPage = () => {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [error, setError] = useState('');
    const [message, setMessage] = useState(''); // สำหรับแจ้งเตือนสีเขียวเมื่อส่งอีเมลสำเร็จ
    const [loading, setLoading] = useState(false);
    const [showResetForm, setShowResetForm] = useState(false); // ใช้สลับหน้าจอไปฟอร์มลืมรหัสผ่าน
    
    // 💡 ดึง userData มาใช้เช็คแทน user
    const { login, googleSignIn, userData } = useAuth(); 
    const navigate = useNavigate();

    // 🚀 ป้องกัน Ping-Pong Loop
    useEffect(() => {
        if (userData) {
            navigate('/');
        }
    }, [userData, navigate]);

    const handleLogin = async (e) => {
        e.preventDefault();
        setLoading(true);
        setError('');
        setMessage('');
        try {
            await login(email, password);
        } catch (err) {
            setError(err.message);
        } finally {
            setLoading(false);
        }
    };

    const handleGoogleSignIn = async () => {
        setLoading(true);
        setError('');
        setMessage('');
        try {
            await googleSignIn();
        } catch (err) {
            setError(err.message);
        } finally {
            setLoading(false);
        }
    };

    // 🌟 ฟังก์ชันจัดการการลืมรหัสผ่าน (ส่งอีเมลรีเซ็ต)
    const handleResetPassword = async (e) => {
        e.preventDefault();
        if (!email) {
            setError('กรุณากรอกอีเมลของคุณเพื่อรับลิงก์รีเซ็ตรหัสผ่าน');
            return;
        }
        setLoading(true);
        setError('');
        setMessage('');
        try {
            const auth = getAuth();
            await sendPasswordResetEmail(auth, email);
            setMessage('ส่งลิงก์รีเซ็ตรหัสผ่านไปยังอีเมลของคุณแล้ว กรุณาตรวจสอบกล่องข้อความ');
            setShowResetForm(false); // ส่งเสร็จให้สลับกลับมาหน้า Login
        } catch (err) {
            setError('เกิดข้อผิดพลาด: ไม่สามารถส่งอีเมลได้ หรือไม่พบอีเมลนี้ในระบบ');
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="min-h-screen flex items-center justify-center bg-slate-900 text-slate-100 font-sans p-3 sm:p-4">
            <div className="bg-slate-800 p-5 sm:p-8 md:p-10 rounded-xl shadow-2xl w-full max-w-md border border-slate-700">
                
                {/* 🌟 แสดงโลโก้บริษัท และ โลโก้แผนก คู่กัน 🌟 */}
                <div className="flex flex-col items-center mb-8">
                    <div className="flex justify-center items-center gap-5 mb-5">
                        <img 
                            src="https://i.postimg.cc/y89YMCnp/logo_ttm_new_1_150x152_(1).png" 
                            alt="Company Logo" 
                            className="w-16 h-16 sm:w-20 sm:h-20 object-contain drop-shadow-md"
                        />
                        {/* เส้นคั่นกลางเพื่อความเป็นระเบียบ */}
                        <div className="h-10 w-px bg-slate-600 rounded-full"></div>
                        <img 
                            src="https://i.postimg.cc/QCmHCrzW/b47a2d3d_2fef_4701_b6b7_00cdab1697c8.png" 
                            alt="Department Logo" 
                            className="w-16 h-16 sm:w-20 sm:h-20 object-contain drop-shadow-md"
                        />
                    </div>
                    <h1 className="text-2xl sm:text-3xl font-bold text-center text-primary tracking-wide">
                        TD Workspace
                    </h1>
                    <p className="text-slate-400 text-sm mt-2">
                        {showResetForm ? 'Reset your password' : 'Sign in to your account'}
                    </p>
                </div>

                {/* กล่องข้อความแจ้งเตือน */}
                {error && (
                    <div className="bg-red-500/10 border border-red-500/50 text-red-400 text-sm p-3 rounded-lg mb-6 text-center">
                        {error}
                    </div>
                )}
                {message && (
                    <div className="bg-green-500/10 border border-green-500/50 text-green-400 text-sm p-3 rounded-lg mb-6 text-center">
                        {message}
                    </div>
                )}
                
                {showResetForm ? (
                    /* ================== ฟอร์ม Forget Password ================== */
                    <form onSubmit={handleResetPassword} className="animate-fade-in">
                        <div className="mb-6">
                            <label className="block text-sm font-medium text-slate-300 mb-2">Email for Reset</label>
                            <input
                                type="email"
                                value={email}
                                onChange={(e) => setEmail(e.target.value)}
                                className="w-full p-3 bg-slate-900/50 rounded-lg border border-slate-600 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                                placeholder="name@company.com"
                                required
                            />
                        </div>
                        <button 
                            type="submit" 
                            className="w-full bg-blue-600 font-semibold py-3 rounded-lg hover:bg-blue-700 transition-colors duration-300 shadow-lg shadow-blue-500/30 mb-3"
                            disabled={loading}
                        >
                            {loading ? 'Sending...' : 'Send Reset Link'}
                        </button>
                        <button 
                            type="button"
                            onClick={() => {
                                setShowResetForm(false);
                                setError('');
                                setMessage('');
                            }}
                            className="w-full bg-slate-700 font-semibold py-3 rounded-lg hover:bg-slate-600 transition-colors duration-300"
                        >
                            Back to Login
                        </button>
                    </form>
                ) : (
                    /* ================== ฟอร์ม Login ปกติ ================== */
                    <form onSubmit={handleLogin} className="animate-fade-in">
                        <div className="mb-5">
                            <label className="block text-sm font-medium text-slate-300 mb-2">Email</label>
                            <input
                                type="email"
                                value={email}
                                onChange={(e) => setEmail(e.target.value)}
                                className="w-full p-3 bg-slate-900/50 rounded-lg border border-slate-600 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                                placeholder="name@company.com"
                                required
                            />
                        </div>
                        <div className="mb-6">
                            <div className="flex justify-between items-center mb-2">
                                <label className="block text-sm font-medium text-slate-300">Password</label>
                                {/* 🌟 ปุ่มสลับไปหน้าลืมรหัสผ่าน 🌟 */}
                                <button 
                                    type="button"
                                    onClick={() => {
                                        setShowResetForm(true);
                                        setError('');
                                        setMessage('');
                                    }}
                                    className="text-xs text-primary hover:text-primary hover:underline transition-colors focus:outline-none"
                                >
                                    Forgot password?
                                </button>
                            </div>
                            <input
                                type="password"
                                value={password}
                                onChange={(e) => setPassword(e.target.value)}
                                className="w-full p-3 bg-slate-900/50 rounded-lg border border-slate-600 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                                placeholder="••••••••"
                                required
                            />
                        </div>
                        <button 
                            type="submit" 
                            className="w-full bg-blue-600 font-semibold py-3 rounded-lg hover:bg-blue-700 transition-colors duration-300 shadow-lg shadow-blue-500/30"
                            disabled={loading}
                        >
                            {loading ? 'Authenticating...' : 'Sign In'}
                        </button>
                    </form>
                )}
                
                {/* ซ่อนส่วน Google Login และสมัครสมาชิก หากอยู่ในโหมด Forget Password */}
                {!showResetForm && (
                    <>
                        <div className="relative my-8">
                            <div className="absolute inset-0 flex items-center">
                                <div className="w-full border-t border-slate-700"></div>
                            </div>
                            <div className="relative flex justify-center text-sm">
                                <span className="px-4 bg-slate-800 text-slate-400">Or continue with</span>
                            </div>
                        </div>
                        
                        <button 
                            onClick={handleGoogleSignIn} 
                            className="w-full flex items-center justify-center gap-3 bg-slate-700 border border-slate-600 font-medium py-3 rounded-lg hover:bg-slate-600 transition-colors duration-300"
                            disabled={loading}
                        >
                            <svg className="w-5 h-5" viewBox="0 0 24 24">
                                <path fill="currentColor" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
                                <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
                                <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" />
                                <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" />
                            </svg>
                            {loading ? 'Signing in...' : 'Sign in with Google'}
                        </button>

                        <div className="mt-8 text-center text-sm text-slate-400">
                            ยังไม่มีบัญชีใช่ไหม? 
                            <Link to="/register" className="text-primary font-medium ml-2 hover:text-primary hover:underline transition-all">
                                สมัครสมาชิกใหม่
                            </Link>
                        </div>
                    </>
                )}

            </div>
        </div>
    );
};

export default LoginPage;