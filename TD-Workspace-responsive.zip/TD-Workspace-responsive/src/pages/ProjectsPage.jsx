import React from 'react';
import ProjectList from '../components/ProjectList';

const ProjectsPage = () => {
  return (
    <div className="p-6">
      <h1 className="text-3xl font-bold mb-6">Projects</h1>
      <ProjectList />
    </div>
  );
};

export default ProjectsPage;
