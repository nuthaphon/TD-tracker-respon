import React, { useState, useEffect } from 'react';
import { collection, onSnapshot, query, where } from 'firebase/firestore';
import { db } from '../firebase';

const TDTeamPage = () => {
    const [members, setMembers] = useState([]);
    const [projects, setProjects] = useState([]);
    const [jobs, setJobs] = useState([]); 
    
    const [loadingUsers, setLoadingUsers] = useState(true);
    const [loadingProj, setLoadingProj] = useState(true);
    const [loadingJobs, setLoadingJobs] = useState(true);

    const [searchTerm, setSearchTerm] = useState('');

    useEffect(() => {
        // 1. ดึงข้อมูลพนักงาน (เฉพาะ TD)
        const qUsers = query(collection(db, 'users'), where('role', '!=', 'pending'));
        const unsubUsers = onSnapshot(qUsers, (snapshot) => {
            const tdMembers = snapshot.docs
                .map(doc => ({ id: doc.id, ...doc.data() }))
                .filter(member => member.dept === 'TD')
                .sort((a, b) => (a.name || '').localeCompare(b.name || ''));
            setMembers(tdMembers);
            setLoadingUsers(false);
        });

        // 2. ดึงข้อมูล Projects
        const unsubProj = onSnapshot(collection(db, 'td_projects'), (snapshot) => {
            setProjects(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
            setLoadingProj(false);
        });

        // 3. ดึงข้อมูล Job Requests
        const unsubJobs = onSnapshot(collection(db, 'td_job_requests'), (snapshot) => {
            setJobs(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
            setLoadingJobs(false);
        });

        return () => { unsubUsers(); unsubProj(); unsubJobs(); };
    }, []);

    // 🌟 ฟังก์ชันคำนวณ Performance และ Workload 🌟
    const getRealPerformance = (memberName) => {
        if (!memberName) return { eff: 0, pendingJobs: 0, doneJobs: 0, total: 0 };

        const myProjs = projects.filter(p => p.owner === memberName || p.coWorkers?.includes(memberName));
        const myJobs = jobs.filter(j => j.assignTo === memberName);

        let pending = 0;
        let done = 0;
        
        const currentYear = new Date().getFullYear();

        const getCompletionYear = (item) => {
            if (item.completedAt) {
                return item.completedAt.toDate ? item.completedAt.toDate().getFullYear() : new Date(item.completedAt).getFullYear();
            }
            if (item.projectPlanEnd) return new Date(item.projectPlanEnd).getFullYear();
            if (item.createdAt) return item.createdAt.toDate ? item.createdAt.toDate().getFullYear() : new Date(item.createdAt).getFullYear();
            return currentYear; 
        };

        // ฝั่ง Project
        myProjs.forEach(p => {
            if (p.status === 'Completed' || p.status === 'Accepted') {
                if (getCompletionYear(p) === currentYear) done++;
            } else { 
                pending++; 
            }
        });

        // ฝั่ง Job Request (นับตั๋วที่ยังไม่ถูกปิด หรือยกเลิก)
        myJobs.forEach(j => {
            if (j.projectId) return; // ไม่นับซ้ำถ้าเปิดโปรเจกต์แล้ว
            if (['Completed', 'Accepted'].includes(j.status)) {
                if (getCompletionYear(j) === currentYear) done++;
            } else if (!['Reject', 'Cancelled', 'TD Reject'].includes(j.status)) {
                pending++; // งานที่กำลังรัน / รอรับ / แก้ไข ให้นับเป็น Workload ทั้งหมด
            }
        });

        const total = pending + done;
        const eff = total === 0 ? 0 : Math.round((done / total) * 100);

        return { eff, pendingJobs: pending, doneJobs: done, total };
    };

    // ฟังก์ชันจัด Level
    const getLevel = (member) => {
        const title = (member.jobTitle || '').toLowerCase();
        if (title.includes('manager') || title.includes('director') || title.includes('head')) return 1;
        if (title.includes('engineer') || title.includes('supervisor') || title.includes('lead') || title.includes('foreman')) return 2;
        return 3; 
    };

    const filteredMembers = members.filter(member => 
        (member.name?.toLowerCase() || '').includes(searchTerm.toLowerCase()) ||
        (member.jobTitle?.toLowerCase() || '').includes(searchTerm.toLowerCase())
    );

    const level1Members = filteredMembers.filter(m => getLevel(m) === 1);
    const level2Members = filteredMembers.filter(m => getLevel(m) === 2);
    const level3Members = filteredMembers.filter(m => getLevel(m) === 3);

    const getFallbackUrl = (name) => `https://ui-avatars.com/api/?name=${encodeURIComponent(name || 'U')}&background=6366f1&color=fff&size=128&bold=true`;

    if (loadingUsers || loadingProj || loadingJobs) {
        return <div className="flex justify-center items-center h-full"><div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-purple-500"></div></div>;
    }

    const MemberCard = ({ member, borderColorClass, gradientClass }) => {
        const perf = getRealPerformance(member.name); 
        
        // 🌟 คำนวณสีและสถานะ Workload 🌟
        const workloadCount = perf.pendingJobs;
        let wlStatus = { label: 'Optimal', color: 'text-green-400', bg: 'bg-green-500' };
        let dotClass = 'bg-green-500 animate-pulse';
        
        if (workloadCount >= 5) {
            wlStatus = { label: 'Overload', color: 'text-red-400', bg: 'bg-red-500' };
            dotClass = 'bg-red-500 animate-pulse';
        } else if (workloadCount >= 3) {
            wlStatus = { label: 'High Load', color: 'text-orange-400', bg: 'bg-orange-500' };
            dotClass = 'bg-orange-500 animate-pulse';
        } else if (workloadCount === 0) {
            dotClass = 'bg-surface';
        }

        return (
            <div className={`w-[280px] bg-surface rounded-2xl border-t-4 ${borderColorClass} shadow-xl overflow-hidden hover:-translate-y-2 hover:shadow-[0_0_25px_rgba(0,0,0,0.5)] transition-all duration-300 flex flex-col z-10`}>
                
                <div className={`h-16 w-full bg-gradient-to-r ${gradientClass}`}></div>

                <div className="p-5 flex flex-col items-center -mt-10 relative flex-1">
                    <div className="relative mb-3">
                        <img 
                            src={member.avatar || getFallbackUrl(member.name)} 
                            alt={member.name} 
                            onError={(e) => { e.target.onerror = null; e.target.src = getFallbackUrl(member.name); }}
                            className="w-20 h-20 rounded-full border-4 border-glass bg-surface object-cover shadow-lg" 
                        />
                        {/* 🌟 ไฟสถานะสีตาม Workload 🌟 */}
                        <span className={`absolute bottom-1 right-1 w-4 h-4 border-2 border-glass rounded-full shadow-lg ${dotClass}`} title={`Active Workload: ${workloadCount} Jobs`}></span>
                    </div>

                    <h2 className="text-base font-bold text-text text-center w-full truncate" title={member.name}>{member.name}</h2>
                    <span className="text-[11px] font-bold text-text flex items-center gap-1.5 mb-3 text-center uppercase tracking-wider">
                        <i className="fas fa-briefcase text-purple-400"></i> {member.jobTitle || 'STAFF'}
                    </span>

                    {/* 🌟 Performance & Workload Profile 🌟 */}
                    <div className="w-full bg-surface/80 rounded-xl p-3 mb-4 border border-glass/50 shadow-inner">
                        
                        {/* Active Workload Indicator */}
                        <div className="flex justify-between items-end mb-1">
                            <span className="text-[9px] font-bold text-text uppercase tracking-wider">Active Workload</span>
                            <span className={`text-[10px] font-black ${wlStatus.color}`}>
                                {workloadCount} <span className="font-normal opacity-80 text-[9px]">({wlStatus.label})</span>
                            </span>
                        </div>
                        <div className="w-full bg-surface rounded-full h-1 mb-3 overflow-hidden">
                            <div className={`h-1 rounded-full ${wlStatus.bg} transition-all`} style={{ width: `${Math.min((workloadCount / 10) * 100, 100)}%` }}></div>
                        </div>

                        {/* Yearly Efficiency */}
                        <div className="flex justify-between items-end mb-1">
                            <span className="text-[9px] font-bold text-text uppercase tracking-wider">Yearly Efficiency</span>
                            <span className={`text-[10px] font-black ${perf.total === 0 ? 'text-text' : perf.eff >= 80 ? 'text-green-400' : perf.eff >= 50 ? 'text-yellow-400' : 'text-orange-400'}`}>
                                {perf.total === 0 ? 'N/A' : `${perf.eff}%`}
                            </span>
                        </div>
                        <div className="w-full bg-surface rounded-full h-1 mb-3 overflow-hidden">
                            <div className={`h-1 rounded-full ${perf.eff >= 80 ? 'bg-green-500' : perf.eff >= 50 ? 'bg-yellow-500' : 'bg-orange-500'} transition-all`} style={{ width: `${perf.total === 0 ? 0 : perf.eff}%` }}></div>
                        </div>
                        
                        {/* Block สรุปตัวเลข รัน / รวม / จบ */}
                        <div className="flex justify-between gap-1.5 text-[10px] font-bold mt-1">
                            <span className="flex-1 text-center text-orange-500 bg-orange-900/30 py-1 rounded-lg border border-orange-500/30" title="งานที่กำลังถืออยู่ (My Queue + Projects)">
                                รัน: {perf.pendingJobs}
                            </span>
                            <span className="flex-1 text-center text-green-600 bg-green-900/30 py-1 rounded-lg border border-green-500/30" title="งานที่จบทั้งหมดในปีนี้">
                                จบ: {perf.doneJobs}
                            </span>
                            <span className="flex-1 text-center text-primary bg-blue-900/30 py-1 rounded-lg border border-blue-500/30" title="งานทั้งหมดที่เคยรับผิดชอบ">
                                รวม: {perf.total}
                            </span>
                        </div>
                    </div>

                    {/* ข้อมูลติดต่อ (เบอร์โทร & อีเมล) */}
                    <div className="w-full mt-auto space-y-2">
                        <a 
                            href={`tel:${member.phone || ''}`} 
                            onClick={(e) => !member.phone && e.preventDefault()}
                            className={`w-full flex items-center justify-center gap-2 py-1.5 px-3 rounded-lg text-xs font-bold transition-all border ${
                                member.phone ? 'bg-green-600/10 text-green-400 border-green-500/30 hover:bg-green-600 hover:text-text hover:border-green-600' : 'bg-surface text-text border-glass cursor-not-allowed'
                            }`}
                            title={member.phone ? "คลิกเพื่อโทรออก" : "ไม่มีเบอร์ติดต่อ"}
                        >
                            <i className="fas fa-phone-alt shrink-0"></i> 
                            <span className="truncate">{member.phone || 'ไม่มีเบอร์ติดต่อ'}</span>
                        </a>
                        
                        <a 
                            href={`mailto:${member.email}`} 
                            className="w-full flex items-center justify-center gap-2 py-1.5 px-3 rounded-lg text-xs font-bold bg-blue-600/10 text-primary border border-blue-500/30 hover:bg-blue-600 hover:text-text hover:border-blue-600 transition-all"
                            title="คลิกเพื่อส่งอีเมล"
                        >
                            <i className="fas fa-envelope shrink-0"></i> 
                            <span className="truncate">{member.email}</span>
                        </a>
                    </div>

                </div>
            </div>
        );
    };

    return (
        <div className="h-full flex flex-col pb-4 md:pb-6 relative overflow-hidden">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-4 md:mb-8 border-b border-glass pb-3 md:pb-4 gap-3 z-30 bg-surface">
                <div>
                    <h1 className="text-lg md:text-2xl font-black text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-blue-400 tracking-wide">
                        <i className="fas fa-sitemap text-purple-500 mr-2"></i> TD Organization Chart
                    </h1>
                    <p className="text-xs text-text mt-1 font-bold">โครงสร้างแผนกและประสิทธิภาพการทำงาน (Real-time Performance & Workload)</p>
                </div>
                
                <div className="relative w-full md:w-64 lg:w-72">
                    <i className="fas fa-search absolute left-3 top-1/2 transform -translate-y-1/2 text-text"></i>
                    <input 
                        type="text" 
                        placeholder="ค้นหาชื่อ หรือ ตำแหน่ง..." 
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        className="w-full bg-surface border border-glass rounded-full pl-10 pr-4 py-2.5 text-text text-sm focus:outline-none focus:border-purple-500 shadow-inner"
                    />
                </div>
            </div>

            <div className="flex-1 overflow-y-auto custom-scrollbar relative px-2 md:px-4 pb-16 md:pb-20">
                <div className="flex flex-col items-center gap-12 w-full relative max-w-7xl mx-auto pt-2">

                    {/* --- Level 1: Management --- */}
                    {level1Members.length > 0 && (
                        <div className="w-full flex flex-col items-center">
                            <div className="bg-surface text-purple-400 text-[11px] font-black px-8 py-2 rounded-full border border-purple-500 mb-6 shadow-md uppercase tracking-widest">
                                Level 1 : Management
                            </div>
                            <div className="flex flex-wrap justify-center gap-4 md:gap-8 w-full">
                                {level1Members.map(m => <MemberCard key={m.id} member={m} borderColorClass="border-purple-500" gradientClass="from-purple-900 to-purple-600" />)}
                            </div>
                        </div>
                    )}

                    {/* --- Level 2: Engineering & Supervision --- */}
                    {level2Members.length > 0 && (
                        <div className="w-full flex flex-col items-center">
                            <div className="bg-surface text-primary text-[11px] font-black px-8 py-2 rounded-full border border-blue-500 mb-6 shadow-md uppercase tracking-widest">
                                Level 2 : Engineering & Supervisor
                            </div>
                            <div className="flex flex-wrap justify-center gap-4 md:gap-8 w-full">
                                {level2Members.map(m => <MemberCard key={m.id} member={m} borderColorClass="border-blue-500" gradientClass="from-blue-900 to-blue-600" />)}
                            </div>
                        </div>
                    )}

                    {/* --- Level 3: Technical & Operations --- */}
                    {level3Members.length > 0 && (
                        <div className="w-full flex flex-col items-center">
                            <div className="bg-surface text-green-300 text-[11px] font-black px-8 py-2 rounded-full border border-green-500 mb-6 shadow-md uppercase tracking-widest">
                                Level 3 : Technical & Staff
                            </div>
                            <div className="flex flex-wrap justify-center gap-3 md:gap-6 w-full">
                                {level3Members.map(m => <MemberCard key={m.id} member={m} borderColorClass="border-green-500" gradientClass="from-green-900 to-green-600" />)}
                            </div>
                        </div>
                    )}

                    {filteredMembers.length === 0 && (
                        <div className="flex flex-col items-center justify-center h-64 text-text bg-surface/50 rounded-2xl border border-glass border-dashed w-full">
                            <i className="fas fa-user-slash text-4xl mb-4 opacity-30"></i>
                            <p className="font-bold">ไม่พบรายชื่อพนักงานที่ค้นหา</p>
                        </div>
                    )}

                </div>
            </div>
        </div>
    );
};

export default TDTeamPage;