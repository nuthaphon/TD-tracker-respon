import React, { useState, useEffect } from 'react';
import { collection, onSnapshot, doc, updateDoc, deleteDoc, addDoc, serverTimestamp, deleteField } from 'firebase/firestore';
import { db } from '../firebase';
import { useNavigate } from 'react-router-dom'; // 🌟 เพิ่มสำหรับการนำทาง
import { useAuth } from '../hooks/useAuth'; // 🌟 เพิ่มสำหรับเช็คสิทธิ์
// 🌟 ดึงข้อมูลตัวเลือกมาจากไฟล์ constants
import { DEPT_OPTIONS, JOB_TITLE_OPTIONS } from '../utils/constants';

const UserManagementPage = () => {
    const { userData } = useAuth(); // 🌟 ดึงข้อมูลผู้ใช้งานปัจจุบัน
    const navigate = useNavigate(); // 🌟 ใช้สำหรับปุ่มย้อนกลับ

    const [users, setUsers] = useState([]);
    const [loading, setLoading] = useState(true);
    const [searchTerm, setSearchTerm] = useState('');
    const [filterRole, setFilterRole] = useState('All');
    
    // State สำหรับ Modal ตรวจสอบคำร้องขอแก้ข้อมูลส่วนตัว
    const [reviewModal, setReviewModal] = useState({ isOpen: false, user: null });
    
    // State สำหรับ Modal อนุมัติผู้ใช้ใหม่ / แก้ไขข้อมูลโดย Admin
    const [editModal, setEditModal] = useState({ isOpen: false, user: null, formData: {} });
    
    const [isProcessing, setIsProcessing] = useState(false);

    useEffect(() => {
        const unsubscribe = onSnapshot(collection(db, 'users'), (snapshot) => {
            const usersData = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
            setUsers(usersData);
            setLoading(false);
        });
        return unsubscribe;
    }, []);

    // 🌟 ดักสิทธิ์การเข้าถึงหน้า: อนุญาตเฉพาะ Admin เท่านั้น 🌟
    if (userData?.role !== 'Admin') {
        return (
            <div className="h-full min-h-screen flex flex-col items-center justify-center text-text bg-surface">
                <i className="fas fa-shield-alt text-6xl mb-4 text-red-500 opacity-50"></i>
                <h2 className="text-2xl font-bold text-text mb-2">Restricted Access</h2>
                <p className="text-sm">หน้านี้สงวนสิทธิ์เฉพาะผู้ดูแลระบบ (Admin) เท่านั้น</p>
                <button onClick={() => navigate(-1)} className="mt-6 bg-blue-600 hover:bg-blue-500 text-text px-6 py-2.5 rounded-lg text-sm font-bold shadow-lg transition">
                    <i className="fas fa-arrow-left mr-2"></i> ย้อนกลับ
                </button>
            </div>
        );
    }

    // ฟังก์ชันลบผู้ใช้
    const handleDeleteUser = async (userId) => {
        if (window.confirm("คุณแน่ใจหรือไม่ว่าต้องการลบผู้ใช้งานรายนี้?")) {
            try {
                await deleteDoc(doc(db, 'users', userId));
            } catch (error) {
                console.error("Error deleting user:", error);
                alert("เกิดข้อผิดพลาดในการลบผู้ใช้งาน");
            }
        }
    };

    // ฟังก์ชันบันทึก Log กิจกรรม
    const logActivityForUser = async (targetUserId, targetUserEmail, actionName, details) => {
        try {
            await addDoc(collection(db, 'activity_logs'), {
                userId: targetUserId,
                email: targetUserEmail,
                action: actionName,
                details: details,
                timestamp: serverTimestamp()
            });
        } catch (error) {
            console.error("Error logging admin activity:", error);
        }
    };

    // --- ส่วนจัดการคำร้องขอแก้ไขข้อมูลส่วนตัว (Review Modal) ---
    const handleApproveUpdate = async () => {
        const targetUser = reviewModal.user;
        const pending = targetUser.pendingUpdate;
        setIsProcessing(true);
        try {
            await updateDoc(doc(db, 'users', targetUser.id), {
                name: pending.name, phone: pending.phone, dept: pending.dept,
                jobTitle: pending.jobTitle, empId: pending.empId, pendingUpdate: deleteField() 
            });
            await logActivityForUser(targetUser.id, targetUser.email, 'Profile Update Approved', 'ผู้ดูแลระบบ (Admin) อนุมัติการแก้ไขข้อมูลส่วนตัวของคุณเรียบร้อยแล้ว');
            setReviewModal({ isOpen: false, user: null });
        } catch (error) {
            alert('เกิดข้อผิดพลาดในการอนุมัติ');
        } finally { setIsProcessing(false); }
    };

    const handleRejectUpdate = async () => {
        const targetUser = reviewModal.user;
        setIsProcessing(true);
        try {
            await updateDoc(doc(db, 'users', targetUser.id), { pendingUpdate: deleteField() });
            await logActivityForUser(targetUser.id, targetUser.email, 'Profile Update Rejected', 'ผู้ดูแลระบบไม่อนุมัติการขอแก้ไขข้อมูล กรุณาติดต่อ Admin หากมีข้อสงสัย');
            setReviewModal({ isOpen: false, user: null });
        } catch (error) {
            alert('เกิดข้อผิดพลาดในการปฏิเสธคำร้อง');
        } finally { setIsProcessing(false); }
    };

    // --- ส่วนจัดการ อนุมัติผู้ใช้ใหม่ & แก้ไขข้อมูลโดย Admin (Edit Modal) ---
    const openEditModal = (user, isApproveAction = false) => {
        setEditModal({
            isOpen: true,
            user: user,
            isApproveAction: isApproveAction,
            formData: {
                role: isApproveAction ? 'user' : user.role, // ถ้ากดอนุมัติ ให้ default เป็น user ทั่วไป
                dept: user.dept || '',
                jobTitle: user.jobTitle || ''
            }
        });
    };

    const handleEditChange = (e) => {
        setEditModal({
            ...editModal,
            formData: { ...editModal.formData, [e.target.name]: e.target.value }
        });
    };

    const handleSaveUserEdit = async (e) => {
        e.preventDefault();
        setIsProcessing(true);
        const { user, formData, isApproveAction } = editModal;
        
        try {
            await updateDoc(doc(db, 'users', user.id), {
                role: formData.role,
                dept: formData.dept,
                jobTitle: formData.jobTitle
            });

            if (isApproveAction) {
                await logActivityForUser(user.id, user.email, 'Account Approved', `บัญชีของคุณได้รับการอนุมัติใช้งาน ในตำแหน่ง ${formData.jobTitle} แผนก ${formData.dept}`);
            } else {
                await logActivityForUser(user.id, user.email, 'Admin Updated Profile', `Admin ได้ปรับเปลี่ยนข้อมูลของคุณเป็น ตำแหน่ง: ${formData.jobTitle}, แผนก: ${formData.dept}, สิทธิ์: ${formData.role}`);
            }

            setEditModal({ isOpen: false, user: null, formData: {} });
        } catch (error) {
            console.error(error);
            alert("เกิดข้อผิดพลาดในการบันทึกข้อมูล");
        } finally {
            setIsProcessing(false);
        }
    };


    const filteredUsers = users.filter(user => {
        const matchesSearch = (user.name?.toLowerCase() || '').includes(searchTerm.toLowerCase()) || 
                              (user.email?.toLowerCase() || '').includes(searchTerm.toLowerCase());
        const matchesRole = filterRole === 'All' ? true : user.role === filterRole;
        return matchesSearch && matchesRole;
    });

    const fieldsToCompare = [
        { key: 'name', label: 'ชื่อ - นามสกุล' }, { key: 'empId', label: 'รหัสพนักงาน' },
        { key: 'dept', label: 'แผนก' }, { key: 'jobTitle', label: 'ตำแหน่ง' }, { key: 'phone', label: 'เบอร์โทรศัพท์' },
    ];

    if (loading) return <div className="flex justify-center items-center h-full"><div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-purple-500"></div></div>;

    return (
        <div className="h-full flex flex-col pb-4 md:pb-6">
            <div className="flex justify-between items-center mb-3 md:mb-6 border-b border-glass pb-3 md:pb-4">
                <h1 className="text-lg md:text-2xl font-bold text-purple-400"><i className="fas fa-users-cog mr-2"></i> User Management</h1>
            </div>

            <div className="bg-surface p-3 md:p-4 rounded-xl mb-3 md:mb-6 flex flex-col md:flex-row gap-3 border border-glass shadow-md">
                <input 
                    type="text" placeholder="ค้นหาชื่อ หรือ อีเมล..." value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)}
                    className="flex-1 bg-surface border border-glass rounded-lg px-4 py-2 text-text focus:outline-none focus:border-purple-500"
                />
                <select 
                    value={filterRole} onChange={(e) => setFilterRole(e.target.value)}
                    className="bg-surface border border-glass rounded-lg px-4 py-2 text-text focus:outline-none focus:border-purple-500"
                    style={{ backgroundColor: 'var(--color-bg)', color: 'var(--color-text)' }}
                >
                    <option value="All">ทุกระดับสิทธิ์ (All Roles)</option>
                    <option value="pending">รอการอนุมัติ (Pending)</option>
                    <option value="user">ผู้ใช้งานทั่วไป (User)</option>
                    <option value="td_lead">หัวหน้างาน TD (TD Lead)</option>
                    <option value="Admin">ผู้ดูแลระบบ (Admin)</option>
                </select>
            </div>

            <div className="bg-surface rounded-xl overflow-hidden shadow-xl border border-glass flex-1 min-h-0">
                <div className="overflow-x-auto h-full">
                    <table className="w-full text-left border-collapse whitespace-nowrap">
                        <thead className="bg-surface text-text text-sm border-b border-glass sticky top-0 z-10">
                            <tr>
                                <th className="p-4 font-semibold w-16 text-center">Profile</th>
                                <th className="p-4 font-semibold">User Info</th>
                                <th className="p-4 font-semibold">Role</th>
                                <th className="p-4 font-semibold">Status / Requests</th>
                                <th className="p-4 font-semibold text-center">Actions</th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-gray-700">
                            {filteredUsers.map(user => (
                                <tr key={user.id} className="hover:bg-surface transition-colors">
                                    <td className="p-4 text-center">
                                        <img 
                                            src={user.avatar || `https://api.dicebear.com/7.x/avataaars/svg?seed=${user.id}&backgroundColor=b6e3f4`} 
                                            alt="avatar" 
                                            onError={(e) => { e.target.onerror = null; e.target.src = `https://api.dicebear.com/7.x/avataaars/svg?seed=${user.id}&backgroundColor=b6e3f4`; }}
                                            className="w-10 h-10 rounded-full border border-glass mx-auto bg-surface" 
                                        />
                                    </td>
                                    <td className="p-4">
                                        <div className="font-bold text-text flex items-center gap-2">
                                            {user.name} 
                                            {user.empId && <span className="bg-surface text-primary text-[10px] px-2 py-0.5 rounded-full border border-glass">ID: {user.empId}</span>}
                                        </div>
                                        <div className="text-xs text-text">{user.email}</div>
                                        <div className="text-[10px] text-text mt-1">แผนก: <span className="text-text">{user.dept}</span> | ตำแหน่ง: <span className="text-text">{user.jobTitle}</span></div>
                                    </td>
                                    <td className="p-4">
                                        <span className={`px-3 py-1 rounded-full text-[10px] font-bold border ${
                                            user.role === 'Admin' ? 'bg-red-500/20 text-red-400 border-red-500/50' : 
                                            user.role === 'td_lead' ? 'bg-purple-500/20 text-purple-400 border-purple-500/50' : 
                                            user.role === 'user' ? 'bg-blue-500/20 text-primary border-blue-500/50' : 
                                            'bg-orange-500/20 text-orange-400 border-orange-500/50 animate-pulse'
                                        }`}>
                                            {user.role === 'pending' ? 'Pending (รออนุมัติ)' : user.role?.toUpperCase()}
                                        </span>
                                    </td>
                                    <td className="p-4">
                                        {user.pendingUpdate ? (
                                            <button 
                                                onClick={() => setReviewModal({ isOpen: true, user: user })}
                                                className="bg-orange-500/20 text-orange-400 border border-orange-500 px-3 py-1 rounded-lg text-xs font-bold animate-pulse hover:bg-orange-500 hover:text-text transition flex items-center"
                                            >
                                                <i className="fas fa-bell mr-2"></i> ขออัปเดตข้อมูล
                                            </button>
                                        ) : (
                                            <span className="text-text text-xs"><i className="fas fa-check-circle text-green-500/50 mr-1"></i> ปกติ</span>
                                        )}
                                    </td>
                                    <td className="p-4">
                                        <div className="flex justify-center items-center gap-2">
                                            {user.role === 'pending' && (
                                                <button onClick={() => openEditModal(user, true)} className="bg-green-600 hover:bg-green-500 text-text px-3 py-1.5 rounded-lg text-xs font-bold shadow transition flex items-center">
                                                    <i className="fas fa-user-check mr-1"></i> อนุมัติ
                                                </button>
                                            )}
                                            
                                            <button onClick={() => openEditModal(user, false)} className="bg-surface hover:bg-blue-600 text-text px-3 py-1.5 rounded-lg text-xs font-bold shadow transition flex items-center" title="แก้ไขข้อมูล/สิทธิ์">
                                                <i className="fas fa-edit mr-1"></i> แก้ไข
                                            </button>

                                            <button onClick={() => handleDeleteUser(user.id)} className="bg-surface hover:bg-red-600 text-text px-3 py-1.5 rounded-lg text-xs font-bold shadow transition" title="ลบผู้ใช้">
                                                <i className="fas fa-trash-alt"></i>
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                            ))}
                            {filteredUsers.length === 0 && (
                                <tr><td colSpan="5" className="p-8 text-center text-text">ไม่พบผู้ใช้งานในระบบ</td></tr>
                            )}
                        </tbody>
                    </table>
                </div>
            </div>

            {/* 🌟 MODAL: อนุมัติ / แก้ไขสิทธิ์และตำแหน่งโดย Admin 🌟 */}
            {editModal.isOpen && editModal.user && (
                <div className="fixed inset-0 bg-black/10 flex justify-center items-center z-50 p-4">
                    <div className="bg-surface w-full max-w-md rounded-2xl shadow-2xl border border-glass overflow-hidden animate-fade-in-down">
                        <div className={`p-4 border-b border-glass flex justify-between items-center ${editModal.isApproveAction ? 'bg-green-900/40' : 'bg-surface'}`}>
                            <h2 className={`text-xl font-bold ${editModal.isApproveAction ? 'text-green-400' : 'text-primary'}`}>
                                <i className={`fas ${editModal.isApproveAction ? 'fa-user-check' : 'fa-user-edit'} mr-2`}></i> 
                                {editModal.isApproveAction ? 'ตรวจสอบและอนุมัติผู้ใช้ใหม่' : 'แก้ไขข้อมูลและสิทธิ์เข้าถึง'}
                            </h2>
                            <button onClick={() => setEditModal({ isOpen: false, user: null, formData: {} })} className="text-text hover:text-text text-2xl font-bold">&times;</button>
                        </div>

                        <form onSubmit={handleSaveUserEdit} className="p-6 space-y-4">
                            
                            <div className="bg-surface/50 p-3 rounded-lg flex items-center gap-3 border border-glass">
                            <img 
                              src={editModal.user?.avatar || `https://ui-avatars.com/api/?name=${encodeURIComponent(editModal.user?.name || 'U')}&background=6366f1&color=fff&bold=true`} 
                              alt="Avatar" 
                              onError={(e) => { 
                              e.target.onerror = null; 
                              e.target.src = `https://ui-avatars.com/api/?name=${encodeURIComponent(editModal.user?.name || 'U')}&background=6366f1&color=fff&bold=true`; 
                              }}
                             className="w-12 h-12 rounded-full bg-surface border border-glass object-cover" 
                            />
                                <div>
                                    <p className="font-bold text-text text-sm">{editModal.user.name}</p>
                                    <p className="text-xs text-text">{editModal.user.email}</p>
                                </div>
                            </div>

                            <div>
                                <label className="block text-xs text-text mb-1">สิทธิ์การเข้าถึง (Role) *</label>
                                <select name="role" value={editModal.formData.role} onChange={handleEditChange} required className="w-full p-2.5 bg-surface rounded-lg border border-glass text-text focus:outline-none focus:border-purple-500 font-bold" style={{ backgroundColor: 'var(--color-bg)', color: 'var(--color-text)' }}>
                                    <option value="pending">Pending (รออนุมัติ)</option>
                                    <option value="user">User (ผู้ใช้งานทั่วไป)</option>
                                    <option value="td_lead">TD Lead (หัวหน้างาน TD)</option>
                                    <option value="Admin">Admin (ผู้ดูแลระบบ)</option>
                                </select>
                            </div>

                            <div className="grid grid-cols-2 gap-4">
                                <div>
                                    <label className="block text-xs text-text mb-1">แผนก (Department) *</label>
                                    <select name="dept" value={editModal.formData.dept} onChange={handleEditChange} required className="w-full p-2.5 bg-surface rounded-lg border border-glass text-text focus:outline-none focus:border-purple-500 text-sm" style={{ backgroundColor: 'var(--color-bg)', color: 'var(--color-text)' }}>
                                        <option value="">-- เลือกแผนก --</option>
                                        {/* 🌟 เรียกใช้งาน DEPT_OPTIONS */}
                                        {DEPT_OPTIONS.map(d => <option key={d} value={d}>{d}</option>)}
                                    </select>
                                </div>
                                <div>
                                    <label className="block text-xs text-text mb-1">ตำแหน่ง (Position) *</label>
                                    <select name="jobTitle" value={editModal.formData.jobTitle} onChange={handleEditChange} required className="w-full p-2.5 bg-surface rounded-lg border border-glass text-text focus:outline-none focus:border-purple-500 text-sm" style={{ backgroundColor: 'var(--color-bg)', color: 'var(--color-text)' }}>
                                        <option value="">-- เลือกตำแหน่ง --</option>
                                        {/* 🌟 เรียกใช้งาน JOB_TITLE_OPTIONS */}
                                        {JOB_TITLE_OPTIONS.map(j => <option key={j} value={j}>{j}</option>)}
                                    </select>
                                </div>
                            </div>

                            <div className="pt-4 border-t border-glass flex justify-end gap-3">
                                <button type="button" onClick={() => setEditModal({ isOpen: false, user: null, formData: {} })} className="px-5 py-2 text-text hover:text-text font-bold">ยกเลิก</button>
                                <button type="submit" disabled={isProcessing} className={`px-6 py-2.5 text-text rounded-lg font-bold shadow-lg transition flex items-center disabled:opacity-50 ${editModal.isApproveAction ? 'bg-green-600 hover:bg-green-500' : 'bg-blue-600 hover:bg-blue-500'}`}>
                                    {isProcessing ? <div className="animate-spin h-4 w-4 border-t-2 border-white rounded-full mr-2"></div> : null}
                                    {editModal.isApproveAction ? 'ยืนยันการอนุมัติ' : 'บันทึกการแก้ไข'}
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            )}

            {/* Modal ตรวจสอบข้อมูลคำร้อง */}
            {reviewModal.isOpen && reviewModal.user && (
                <div className="fixed inset-0 bg-black/80 flex justify-center items-center z-50 p-4">
                    <div className="bg-surface w-full max-w-2xl rounded-2xl shadow-2xl border border-glass overflow-hidden">
                        <div className="bg-surface p-4 border-b border-glass flex justify-between items-center">
                            <h2 className="text-xl font-bold text-orange-400"><i className="fas fa-user-edit mr-2"></i> ตรวจสอบคำร้องขอแก้ไขข้อมูล</h2>
                            <button onClick={() => setReviewModal({ isOpen: false, user: null })} className="text-text hover:text-text text-2xl font-bold">&times;</button>
                        </div>
                        
                        <div className="p-6">
                            <div className="flex items-center gap-4 mb-6">
                                <img 
                                    src={reviewModal.user.avatar || `https://api.dicebear.com/7.x/avataaars/svg?seed=${reviewModal.user.id}&backgroundColor=b6e3f4`} 
                                    alt="Avatar" 
                                    onError={(e) => { e.target.onerror = null; e.target.src = `https://api.dicebear.com/7.x/avataaars/svg?seed=${reviewModal.user.id}&backgroundColor=b6e3f4`; }}
                                    className="w-16 h-16 rounded-full bg-surface border-2 border-glass" 
                                />
                                <div>
                                    <h3 className="font-bold text-lg text-text">{reviewModal.user.email}</h3>
                                    <p className="text-xs text-text">ส่งคำร้องเมื่อ: {new Date(reviewModal.user.pendingUpdate.requestedAt).toLocaleString('th-TH')}</p>
                                </div>
                            </div>

                            <div className="bg-surface/50 rounded-xl overflow-hidden border border-glass">
                                <table className="w-full text-left text-sm text-text">
                                    <thead className="bg-surface border-b border-glass">
                                        <tr>
                                            <th className="p-3 w-1/3">ข้อมูล</th>
                                            <th className="p-3 w-1/3 border-l border-glass text-text">ข้อมูลปัจจุบัน (Current)</th>
                                            <th className="p-3 w-1/3 border-l border-glass text-orange-400">ข้อมูลที่ต้องการแก้ (New)</th>
                                        </tr>
                                    </thead>
                                    <tbody className="divide-y divide-gray-700">
                                        {fieldsToCompare.map(field => {
                                            const oldVal = reviewModal.user[field.key] || '-';
                                            const newVal = reviewModal.user.pendingUpdate[field.key] || '-';
                                            const isChanged = oldVal !== newVal;

                                            return (
                                                <tr key={field.key} className={isChanged ? 'bg-orange-500/10' : ''}>
                                                    <td className="p-3 font-bold text-text">{field.label}</td>
                                                    <td className="p-3 border-l border-glass">{oldVal}</td>
                                                    <td className={`p-3 border-l border-glass font-bold ${isChanged ? 'text-orange-400' : 'text-text'}`}>
                                                        {newVal} {isChanged && <i className="fas fa-star text-[8px] ml-1 mb-2 text-yellow-400"></i>}
                                                    </td>
                                                </tr>
                                            );
                                        })}
                                    </tbody>
                                </table>
                            </div>
                        </div>

                        <div className="p-4 border-t border-glass bg-surface flex justify-end gap-3">
                            <button 
                                onClick={handleRejectUpdate} disabled={isProcessing}
                                className="px-6 py-2.5 bg-red-600/20 text-red-500 border border-red-500/50 hover:bg-red-600 hover:text-text rounded-lg font-bold transition disabled:opacity-50"
                            >
                                ไม่อนุมัติ (Reject)
                            </button>
                            <button 
                                onClick={handleApproveUpdate} disabled={isProcessing}
                                className="px-6 py-2.5 bg-green-600 hover:bg-green-500 text-text rounded-lg font-bold shadow-lg transition flex items-center disabled:opacity-50"
                            >
                                {isProcessing ? <div className="animate-spin h-4 w-4 border-t-2 border-white rounded-full mr-2"></div> : <i className="fas fa-check mr-2"></i>}
                                อนุมัติการเปลี่ยนแปลง (Approve)
                            </button>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};

export default UserManagementPage;