import React, { useState, useEffect, useMemo, useRef } from 'react';
import { collection, onSnapshot, query } from 'firebase/firestore';
import { db } from '../firebase';

const MONTHS = [
    { value: 1, label: 'January' }, { value: 2, label: 'February' }, { value: 3, label: 'March' },
    { value: 4, label: 'April' }, { value: 5, label: 'May' }, { value: 6, label: 'June' },
    { value: 7, label: 'July' }, { value: 8, label: 'August' }, { value: 9, label: 'September' },
    { value: 10, label: 'October' }, { value: 11, label: 'November' }, { value: 12, label: 'December' }
];

const TDDashboardPage = () => {
    const dashboardRef = useRef(null); // 🌟 ใช้สำหรับอ้างอิงตอนทำ Full Screen
    
    const [jobs, setJobs] = useState([]);
    const [projects, setProjects] = useState([]);
    const [tdUsers, setTdUsers] = useState([]); // เก็บรายชื่อช่าง TD
    const [loading, setLoading] = useState(true);

    const [selectedMonth, setSelectedMonth] = useState(new Date().getMonth() + 1);
    const [selectedYear, setSelectedYear] = useState(new Date().getFullYear());
    
    const [isFullscreen, setIsFullscreen] = useState(false);
    
    // 🌟 โหมดรายบุคคล 🌟
    const [viewMode, setViewMode] = useState('all'); // 'all' หรือ 'personal'
    const [selectedPerson, setSelectedPerson] = useState('');

    useEffect(() => {
        const unsubJobs = onSnapshot(query(collection(db, 'td_job_requests')), (snapshot) => {
            setJobs(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
            setLoading(false);
        });
        const unsubProj = onSnapshot(query(collection(db, 'td_projects')), (snapshot) => {
            setProjects(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
        });
        const unsubUsers = onSnapshot(query(collection(db, 'users')), (snapshot) => {
            const users = snapshot.docs.map(doc => doc.data());
            setTdUsers(users.filter(u => u.dept === 'TD' && u.role !== 'pending').sort((a, b) => a.name.localeCompare(b.name)));
        });

        // ดักจับการกดออก Fullscreen ด้วยปุ่ม ESC
        const handleFullscreenChange = () => setIsFullscreen(!!document.fullscreenElement);
        document.addEventListener('fullscreenchange', handleFullscreenChange);

        return () => { 
            unsubJobs(); unsubProj(); unsubUsers(); 
            document.removeEventListener('fullscreenchange', handleFullscreenChange);
        };
    }, []);

    // 🌟 ฟังก์ชันจัดการ Full Screen เฉพาะโซนนี้ 🌟
    const toggleFullScreen = () => {
        if (!document.fullscreenElement) {
            if (dashboardRef.current) {
                dashboardRef.current.requestFullscreen().catch(err => alert(`ไม่สามารถเปิดโหมดเต็มจอได้: ${err.message}`));
            }
        } else {
            if (document.exitFullscreen) document.exitFullscreen();
        }
    };

    const monthlyData = useMemo(() => {
        let filteredJobs = jobs.filter(j => {
            if (!j.createdAt) return false;
            const d = j.createdAt.toDate ? j.createdAt.toDate() : new Date(j.createdAt);
            return d.getMonth() + 1 === parseInt(selectedMonth) && d.getFullYear() === parseInt(selectedYear);
        });

        // 🌟 ถ้าเปิดโหมดรายบุคคล ให้กรองเฉพาะงานของคนนั้น 🌟
        if (viewMode === 'personal' && selectedPerson) {
            filteredJobs = filteredJobs.filter(j => j.assignTo === selectedPerson);
        }

        const totalJobs = filteredJobs.length;
        const completedJobs = filteredJobs.filter(j => ['Completed', 'Accepted'].includes(j.status)).length;
        const pendingJobs = totalJobs - completedJobs;
        const successRate = totalJobs === 0 ? 0 : Math.round((completedJobs / totalJobs) * 100);
        
        const totalCost = filteredJobs.reduce((sum, j) => sum + (Number(j.cost) || 0), 0);

        const deptCount = {};
        filteredJobs.forEach(j => {
            const dept = j.group || 'Unknown';
            deptCount[dept] = (deptCount[dept] || 0) + 1;
        });
        const sortedDepts = Object.entries(deptCount)
            .map(([dept, count]) => ({ dept, count }))
            .sort((a, b) => b.count - a.count)
            .slice(0, 5); 

        let newCount = 0, repairCount = 0, otherCount = 0;
        filteredJobs.forEach(j => {
            if (j.jobType === 'สร้างใหม่') newCount++;
            else if (j.jobType === 'ซ่อมแก้ไข') repairCount++;
            else otherCount++;
        });

        const memberCount = {};
        filteredJobs.filter(j => ['Completed', 'Accepted'].includes(j.status)).forEach(j => {
            const name = j.assignTo;
            if (name) memberCount[name] = (memberCount[name] || 0) + 1;
        });
        const topPerformers = Object.entries(memberCount)
            .map(([name, count]) => ({ name, count }))
            .sort((a, b) => b.count - a.count)
            .slice(0, 3);

        return { 
            totalJobs, completedJobs, pendingJobs, successRate, totalCost, 
            sortedDepts, newCount, repairCount, otherCount, topPerformers, filteredJobs 
        };
    }, [jobs, selectedMonth, selectedYear, viewMode, selectedPerson]);

    if (loading) return <div className="flex justify-center items-center h-screen bg-surface"><div className="animate-spin rounded-full h-12 w-12 border-t-2 border-blue-500"></div></div>;

    const { totalJobs, completedJobs, successRate, totalCost, sortedDepts, newCount, repairCount, otherCount, topPerformers, filteredJobs } = monthlyData;

    const getConicGradient = () => {
        if (totalJobs === 0) return 'conic-gradient(#374151 0% 100%)';
        const newP = Math.round((newCount / totalJobs) * 100);
        const repP = Math.round((repairCount / totalJobs) * 100);
        return `conic-gradient(#3b82f6 0% ${newP}%, #f97316 ${newP}% ${newP + repP}%, #8b5cf6 ${newP + repP}% 100%)`;
    };

    return (
        <div ref={dashboardRef} className="h-full min-h-screen bg-surface flex flex-col p-2 md:p-4 lg:p-6 relative overflow-y-auto custom-scrollbar print-bg-surface">
            
            {/* 🌟 CSS Print แบบแนวตั้ง (Portrait) 1 หน้าเป๊ะ 🌟 */}
            <style dangerouslySetInnerHTML={{__html: `
                @media print {
                    @page { size: A4 portrait; margin: 10mm; }
                    body, html { 
                        background-color: #ffffff !important; 
                        color: #000000 !important; 
                        -webkit-print-color-adjust: exact !important; 
                        print-color-adjust: exact !important; 
                        margin: 0 !important;
                        padding: 0 !important;
                        height: 100% !important;
                        overflow: hidden !important; 
                    }
                    #root { display: block !important; height: 100% !important; }
                    nav, aside, header, .no-print { display: none !important; }
                    
                    /* Reset สีดำให้เป็นขาวตอน Print */
                    .bg-surface, .bg-surface, .bg-surface\\/50 { background-color: #ffffff !important; border-color: #cbd5e1 !important; }
                    .text-text, .text-text, .text-text { color: #1e293b !important; }
                    .shadow-xl, .shadow-2xl, .shadow-md, .shadow-inner { box-shadow: none !important; border: 1px solid #cbd5e1 !important; }
                    
                    /* หดระยะห่างต่างๆ ให้อยู่ในหน้าเดียว */
                    .print-bg-surface { padding: 0 !important; height: 100% !important; max-height: 100vh !important; display: flex !important; flex-direction: column !important; }
                    .print-mb-shrink { margin-bottom: 15px !important; }
                    .print-gap-shrink { gap: 15px !important; }
                    .print-p-shrink { padding: 12px !important; }
                    .print-text-shrink { font-size: 11px !important; }
                    .print-value-shrink { font-size: 26px !important; }
                    .print-icon-shrink { font-size: 24px !important; right: -5px !important; bottom: -5px !important; }
                    
                    /* ปรับขนาดกราฟ */
                    .print-chart-bg { background-color: #f8fafc !important; }
                    .print-donut-shrink { width: 90px !important; height: 90px !important; margin-top: 5px !important; margin-bottom: 5px !important; }
                    .print-donut-inner { width: 55px !important; height: 55px !important; }
                    .print-donut-text { font-size: 18px !important; }
                    
                    /* ปรับ Grid สำหรับแนวตั้ง */
                    .print-grid-cols-2 { grid-template-columns: repeat(2, minmax(0, 1fr)) !important; }
                    .print-grid-cols-3 { grid-template-columns: repeat(3, minmax(0, 1fr)) !important; }
                    .print-col-span-1 { grid-column: span 1 / span 1 !important; }
                    .print-col-span-2 { grid-column: span 2 / span 2 !important; }
                    
                    .print-table-py { padding-top: 5px !important; padding-bottom: 5px !important; font-size: 10px !important; }
                    .print-break-inside-avoid { page-break-inside: avoid !important; }
                }
            `}} />

            {/* --- Header & Filters --- */}
            <div className="flex flex-col xl:flex-row justify-between items-start xl:items-center mb-6 print:mb-0 border-b border-glass pb-4 gap-4 no-print shrink-0">
                <div>
                    <h1 className="text-2xl font-black text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-purple-400 tracking-wide">
                        <i className="fas fa-chart-line text-primary mr-2"></i> TD Monthly Report
                    </h1>
                    <p className="text-xs text-text mt-1 font-bold">รายงานสรุปผลการดำเนินงานแผนก Technology Development</p>
                </div>
                
                <div className="flex flex-col md:flex-row items-end md:items-center gap-3 w-full xl:w-auto">
                    
                    {/* 🌟 สวิตช์โหมดภาพรวม / รายบุคคล 🌟 */}
                    <div className="flex items-center gap-2 bg-surface p-1.5 rounded-xl border border-glass shadow-inner w-full md:w-auto">
                        <div className="flex bg-surface rounded-lg p-1">
                            <button onClick={() => { setViewMode('all'); setSelectedPerson(''); }} className={`px-4 py-1.5 text-xs font-bold rounded-md transition-all ${viewMode === 'all' ? 'bg-blue-600 text-text shadow' : 'text-text hover:text-text'}`}>ภาพรวม</button>
                            <button onClick={() => setViewMode('personal')} className={`px-4 py-1.5 text-xs font-bold rounded-md transition-all ${viewMode === 'personal' ? 'bg-purple-600 text-text shadow' : 'text-text hover:text-text'}`}>รายบุคคล</button>
                        </div>
                        {viewMode === 'personal' && (
                            <select value={selectedPerson} onChange={(e) => setSelectedPerson(e.target.value)} className="bg-surface border border-purple-500 text-text text-xs rounded-lg px-2 py-1.5 outline-none font-bold min-w-[120px]">
                                <option value="">-- เลือกช่าง TD --</option>
                                {tdUsers.map(u => <option key={u.name} value={u.name} style={{ backgroundColor: 'var(--color-bg)', color: 'var(--color-text)' }}>{u.name}</option>)}
                            </select>
                        )}
                    </div>

                    <div className="flex flex-wrap items-center gap-2 bg-surface p-1.5 rounded-xl border border-glass shadow-inner w-full md:w-auto">
                        <div className="flex items-center gap-2">
                            <i className="fas fa-calendar-alt text-text pl-2"></i>
                            <select value={selectedMonth} onChange={(e) => setSelectedMonth(e.target.value)} className="bg-surface border border-glass text-text text-sm rounded-lg px-2 py-1.5 outline-none focus:border-blue-500 font-bold">
                                {MONTHS.map(m => <option key={m.value} value={m.value} style={{ backgroundColor: 'var(--color-bg)', color: 'var(--color-text)' }}>{m.label}</option>)}
                            </select>
                            <select value={selectedYear} onChange={(e) => setSelectedYear(e.target.value)} className="bg-surface border border-glass text-text text-sm rounded-lg px-2 py-1.5 outline-none focus:border-blue-500 font-bold">
                                {[2024, 2025, 2026, 2027].map(y => <option key={y} value={y} style={{ backgroundColor: 'var(--color-bg)', color: 'var(--color-text)' }}>{y}</option>)}
                            </select>
                        </div>

                        {/* 🌟 ปุ่มกด Full Screen (ซ่อนหน้าต่างหลัก) 🌟 */}
                        <button onClick={toggleFullScreen} className="bg-surface hover:bg-surface text-text px-3 py-2 rounded-lg font-bold shadow transition flex items-center text-xs ml-auto md:ml-2">
                            <i className={`fas ${isFullscreen ? 'fa-compress' : 'fa-expand'}`}></i>
                        </button>
                        
                        <button onClick={() => window.print()} className="bg-gradient-to-r from-red-600 to-red-500 hover:from-red-500 hover:to-red-400 text-text px-4 py-2 rounded-lg font-bold shadow-lg transition flex items-center text-xs">
                            <i className="fas fa-print mr-1.5"></i> Export
                        </button>
                    </div>
                </div>
            </div>

            {/* --- Document Header (For Print Only) --- */}
            <div className="hidden print:flex justify-between items-end border-b-2 border-blue-900 pb-2 print-mb-shrink mt-2 shrink-0">
                <div>
                    <h1 className="text-xl font-black text-primary uppercase tracking-widest mb-0.5">Technology Development (TD)</h1>
                    <h2 className="text-sm font-bold text-text">
                        {viewMode === 'personal' && selectedPerson ? `Personal Performance Report: ${selectedPerson}` : 'Monthly Performance Report'}
                    </h2>
                </div>
                <div className="text-right">
                    <p className="text-sm font-black text-primary bg-blue-100 px-3 py-1 rounded-lg border border-blue-200">
                        {MONTHS.find(m => m.value === parseInt(selectedMonth)).label} {selectedYear}
                    </p>
                    <p className="text-[9px] text-text mt-1">Printed: {new Date().toLocaleDateString('th-TH')}</p>
                </div>
            </div>

            {/* --- 1. Executive Summary KPIs --- */}
            <div className="grid grid-cols-2 md:grid-cols-4 print-grid-cols-2 gap-4 md:gap-6 mb-6 print-mb-shrink print-gap-shrink shrink-0">
                
                {/* Total Requests */}
                <div className="bg-surface rounded-2xl p-5 print-p-shrink border-l-4 border-blue-500 shadow-xl print-break-inside-avoid relative overflow-hidden">
                    <i className="fas fa-ticket-alt absolute -right-4 -bottom-4 text-6xl print-icon-shrink text-primary/10 print:text-primary/5 -rotate-12"></i>
                    <p className="text-xs print-text-shrink font-bold text-text uppercase tracking-wider mb-1">Total {viewMode === 'personal' ? 'Assigned' : 'Requests'}</p>
                    <div className="flex items-end gap-3">
                        <span className="text-4xl print-value-shrink font-black text-text print:text-text">{totalJobs}</span>
                        <span className="text-xs print-text-shrink text-text mb-1 font-bold">Jobs</span>
                    </div>
                </div>

                {/* Completed */}
                <div className="bg-surface rounded-2xl p-5 print-p-shrink border-l-4 border-green-500 shadow-xl print-break-inside-avoid relative overflow-hidden">
                    <i className="fas fa-check-double absolute -right-4 -bottom-4 text-6xl print-icon-shrink text-green-500/10 print:text-green-500/5 -rotate-12"></i>
                    <p className="text-xs print-text-shrink font-bold text-text uppercase tracking-wider mb-1">Completed</p>
                    <div className="flex items-end gap-3">
                        <span className="text-4xl print-value-shrink font-black text-green-400">{completedJobs}</span>
                        <span className="text-xs print-text-shrink text-text mb-1 font-bold">Jobs</span>
                    </div>
                </div>

                {/* Success Rate */}
                <div className="bg-surface rounded-2xl p-5 print-p-shrink border-l-4 border-purple-500 shadow-xl print-break-inside-avoid relative overflow-hidden">
                    <i className="fas fa-chart-pie absolute -right-4 -bottom-4 text-6xl print-icon-shrink text-purple-500/10 print:text-purple-500/5 -rotate-12"></i>
                    <p className="text-xs print-text-shrink font-bold text-text uppercase tracking-wider mb-1">Success Rate</p>
                    <div className="flex items-end gap-2">
                        <span className="text-4xl print-value-shrink font-black text-purple-400">{successRate}</span>
                        <span className="text-xl print:text-base text-purple-400/80 font-bold mb-0.5">%</span>
                    </div>
                    <div className="w-full bg-surface rounded-full h-1.5 mt-3 print:mt-1.5">
                        <div className="bg-purple-500 h-1.5 rounded-full" style={{ width: `${successRate}%` }}></div>
                    </div>
                </div>

                {/* Total Cost */}
                <div className="bg-surface rounded-2xl p-5 print-p-shrink border-l-4 border-red-500 shadow-xl print-break-inside-avoid relative overflow-hidden">
                    <i className="fas fa-coins absolute -right-4 -bottom-4 text-6xl print-icon-shrink text-red-500/10 print:text-red-500/5 -rotate-12"></i>
                    <p className="text-xs print-text-shrink font-bold text-text uppercase tracking-wider mb-1">{viewMode === 'personal' ? 'Managed Budget' : 'Total Expense'}</p>
                    <div className="flex items-end gap-2">
                        <span className="text-3xl md:text-4xl print-value-shrink font-black text-red-400 truncate">{totalCost.toLocaleString()}</span>
                        <span className="text-xs print-text-shrink text-text mb-1 font-bold">THB</span>
                    </div>
                </div>

            </div>

            {/* --- 2. Analytics Charts --- */}
            <div className="grid grid-cols-1 lg:grid-cols-3 print-grid-cols-2 gap-6 mb-6 print-mb-shrink print-gap-shrink shrink-0">
                
                {/* Left: Department Demand */}
                <div className="lg:col-span-2 print-col-span-1 bg-surface rounded-2xl p-6 print-p-shrink border border-glass shadow-xl print-break-inside-avoid print-chart-bg">
                    <h3 className="text-sm print:text-xs font-bold text-primary mb-6 print:mb-3 uppercase tracking-widest flex items-center"><i className="fas fa-building mr-2"></i> {viewMode === 'personal' ? 'Serviced Departments' : 'Top 5 Requesting Departments'}</h3>
                    <div className="space-y-4 print:space-y-2 mt-2">
                        {sortedDepts.map((d, idx) => {
                            const maxCount = sortedDepts[0]?.count || 1;
                            const widthP = (d.count / maxCount) * 100;
                            return (
                                <div key={d.dept} className="flex items-center gap-4">
                                    <div className="w-24 text-right shrink-0">
                                        <span className="text-xs print:text-[10px] font-bold text-text print:text-text">{d.dept}</span>
                                    </div>
                                    <div className="flex-1 relative h-6 print:h-4 bg-surface print:bg-surface rounded-r-lg overflow-hidden flex items-center">
                                        <div className="absolute top-0 bottom-0 left-0 bg-gradient-to-r from-blue-600 to-blue-400 print:bg-blue-500 transition-all duration-1000" style={{ width: `${widthP}%` }}></div>
                                        <span className="relative z-10 ml-3 text-[10px] print:text-[8px] font-black text-text drop-shadow-md print:drop-shadow-none">{d.count} Jobs</span>
                                    </div>
                                </div>
                            )
                        })}
                        {sortedDepts.length === 0 && <p className="text-center text-text py-8 print:py-2 text-sm italic">ไม่มีข้อมูลในเดือนนี้</p>}
                    </div>
                </div>

                {/* Right: Job Type Ratio */}
                <div className="print-col-span-1 bg-surface rounded-2xl p-6 print-p-shrink border border-glass shadow-xl print-break-inside-avoid print-chart-bg flex flex-col items-center justify-center relative">
                    <h3 className="text-sm print:text-xs font-bold text-orange-400 mb-6 print:mb-0 uppercase tracking-widest absolute top-6 print:top-3 left-6 print:left-3"><i className="fas fa-tools mr-2"></i> Job Types</h3>
                    
                    {totalJobs > 0 ? (
                        <>
                            <div className="relative w-40 h-40 print-donut-shrink rounded-full flex items-center justify-center mt-8 print:mt-4 mb-6 print:mb-3 shadow-[0_0_20px_rgba(0,0,0,0.5)] print:shadow-none" style={{ background: getConicGradient() }}>
                                <div className="w-28 h-28 print-donut-inner bg-[var(--color-bg)] print-chart-bg rounded-full flex flex-col items-center justify-center z-10 shadow-inner">
                                    <span className="text-2xl print-donut-text font-black text-text print:text-text">{totalJobs}</span>
                                    <span className="text-[9px] print:text-[7px] text-text font-bold uppercase">Total</span>
                                </div>
                            </div>
                            <div className="w-full flex flex-col gap-2 print:gap-1 px-4">
                                <div className="flex justify-between items-center text-xs print:text-[10px]">
                                    <div className="flex items-center gap-2"><span className="w-3 h-3 print:w-2 print:h-2 rounded bg-blue-500"></span><span className="text-text font-bold">สร้างใหม่</span></div>
                                    <span className="text-text print:text-text font-black">{newCount} <span className="text-[9px] print:text-[7px] text-text font-normal">({Math.round((newCount/totalJobs)*100)}%)</span></span>
                                </div>
                                <div className="flex justify-between items-center text-xs print:text-[10px]">
                                    <div className="flex items-center gap-2"><span className="w-3 h-3 print:w-2 print:h-2 rounded bg-orange-500"></span><span className="text-text font-bold">ซ่อมแก้ไข</span></div>
                                    <span className="text-text print:text-text font-black">{repairCount} <span className="text-[9px] print:text-[7px] text-text font-normal">({Math.round((repairCount/totalJobs)*100)}%)</span></span>
                                </div>
                                <div className="flex justify-between items-center text-xs print:text-[10px]">
                                    <div className="flex items-center gap-2"><span className="w-3 h-3 print:w-2 print:h-2 rounded bg-purple-500"></span><span className="text-text font-bold">อื่นๆ</span></div>
                                    <span className="text-text print:text-text font-black">{otherCount} <span className="text-[9px] print:text-[7px] text-text font-normal">({Math.round((otherCount/totalJobs)*100)}%)</span></span>
                                </div>
                            </div>
                        </>
                    ) : (
                        <p className="text-center text-text text-sm italic mt-10">ไม่มีข้อมูล</p>
                    )}
                </div>

            </div>

            {/* --- 3. Bottom Row: Leaderboard & Recent Jobs --- */}
            <div className="grid grid-cols-1 lg:grid-cols-3 print-grid-cols-3 gap-6 print-gap-shrink min-h-0 flex-1">
                
                {/* TD Member Leaderboard (ซ่อนถ้าเปิดโหมดรายบุคคลและเลือกคนแล้ว) */}
                {!(viewMode === 'personal' && selectedPerson) && (
                    <div className="print-col-span-1 bg-surface rounded-2xl p-6 print-p-shrink border border-glass shadow-xl print-break-inside-avoid flex flex-col min-h-0">
                        <h3 className="text-sm print:text-xs font-bold text-green-400 mb-5 print:mb-2 uppercase tracking-widest flex items-center shrink-0"><i className="fas fa-trophy mr-2 text-yellow-400"></i> Top Performers</h3>
                        <div className="space-y-3 print:space-y-1 overflow-y-auto custom-scrollbar flex-1">
                            {topPerformers.map((p, idx) => (
                                <div key={p.name} className="flex items-center justify-between bg-surface/50 print:bg-surface p-3 print:p-2 rounded-xl border border-glass/50 print-border">
                                    <div className="flex items-center gap-3 print:gap-2">
                                        <div className={`w-8 h-8 print:w-5 print:h-5 rounded-full flex items-center justify-center font-black text-sm print:text-[9px] shadow-md ${
                                            idx === 0 ? 'bg-yellow-500 text-yellow-900 border-2 border-yellow-300' :
                                            idx === 1 ? 'bg-surface text-text border-2 border-glass' :
                                            'bg-orange-700 text-orange-200 border-2 border-orange-500'
                                        }`}>
                                            {idx + 1}
                                        </div>
                                        <span className="font-bold text-sm print:text-[10px] text-text print:text-text">{p.name}</span>
                                    </div>
                                    <div className="bg-surface print:bg-surface border border-glass px-3 print:px-2 py-1 print:py-0.5 rounded-lg text-green-400 font-black text-sm print:text-[9px] shadow-inner">
                                        {p.count} <span className="text-[10px] print:text-[7px] text-text font-normal">Jobs</span>
                                    </div>
                                </div>
                            ))}
                            {topPerformers.length === 0 && <p className="text-center text-text py-4 text-xs italic">ยังไม่มีการปิดงานในเดือนนี้</p>}
                        </div>
                    </div>
                )}

                {/* High Cost Projects / Jobs List */}
                <div className={`${viewMode === 'personal' && selectedPerson ? 'lg:col-span-3 print-col-span-3' : 'lg:col-span-2 print-col-span-2'} bg-surface rounded-2xl p-6 print-p-shrink border border-glass shadow-xl print-break-inside-avoid flex flex-col min-h-0`}>
                    <div className="flex justify-between items-center mb-4 print:mb-2 shrink-0">
                        <h3 className="text-sm print:text-xs font-bold text-red-400 uppercase tracking-widest flex items-center"><i className="fas fa-file-invoice-dollar mr-2"></i> Major Expenses (Top 5)</h3>
                    </div>
                    
                    <div className="overflow-x-auto overflow-y-auto custom-scrollbar flex-1">
                        <table className="w-full text-left whitespace-nowrap">
                            <thead className="text-[10px] text-text uppercase border-b border-glass sticky top-0 bg-surface print:bg-surface print:text-text">
                                <tr>
                                    <th className="pb-2 print:pb-1 font-bold pl-2">Job No.</th>
                                    <th className="pb-2 print:pb-1 font-bold">Category</th>
                                    <th className="pb-2 print:pb-1 font-bold">Request By</th>
                                    {viewMode === 'all' && <th className="pb-2 print:pb-1 font-bold">Assign To</th>}
                                    <th className="pb-2 print:pb-1 font-bold text-right">Cost (THB)</th>
                                </tr>
                            </thead>
                            <tbody className="divide-y divide-gray-700/50 text-xs print:text-[10px]">
                                {filteredJobs
                                    .filter(j => Number(j.cost) > 0)
                                    .sort((a, b) => Number(b.cost) - Number(a.cost))
                                    .slice(0, 5)
                                    .map(job => (
                                        <tr key={job.id} className="hover:bg-surface/20 transition">
                                            <td className="py-3 print-table-py pl-2 font-bold text-primary print:text-primary">{job.projectNo}</td>
                                            <td className="py-3 print-table-py text-text print:text-text">{job.jobType}</td>
                                            <td className="py-3 print-table-py text-text print:text-text">{job.requestBy} <span className="text-[9px] bg-surface print:bg-surface print:text-text px-1.5 py-0.5 rounded ml-1 border border-glass">{job.group}</span></td>
                                            {viewMode === 'all' && <td className="py-3 print-table-py text-text print:text-text">{job.assignTo || '-'}</td>}
                                            <td className="py-3 print-table-py text-right font-black text-red-400 print:text-red-600">{Number(job.cost).toLocaleString()}</td>
                                        </tr>
                                ))}
                            </tbody>
                        </table>
                        {filteredJobs.filter(j => Number(j.cost) > 0).length === 0 && (
                            <p className="text-center text-text py-6 text-xs italic border-b border-glass/50 print:border-none">ไม่มีข้อมูลค่าใช้จ่ายในเดือนนี้</p>
                        )}
                    </div>
                </div>

            </div>
            
        </div>
    );
};

export default TDDashboardPage;