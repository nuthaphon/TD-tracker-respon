import React from 'react';
import IssueJobRequestForm from '../components/forms/IssueJobRequestForm';
import HistoryTable from '../components/tables/HistoryTable';

const OtherDeptDashboardPage = () => {
  return (
    <div className="bg-surface text-text min-h-screen flex flex-col items-center p-6">
      <h1 className="text-3xl font-bold mb-6">Department Dashboard</h1>
      <IssueJobRequestForm />
      <HistoryTable />
    </div>
  );
};

export default OtherDeptDashboardPage;