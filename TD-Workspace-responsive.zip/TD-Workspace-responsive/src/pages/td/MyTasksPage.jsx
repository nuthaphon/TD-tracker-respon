import React, { useState, useEffect } from 'react';
import { collection, query, where, onSnapshot, doc, updateDoc } from 'firebase/firestore';
import { db } from '../../firebase';
import { useAuth } from '../../hooks/useAuth';
import JobOrderModal from '../../components/kanban/JobOrderModal';

const MyTasksPage = () => {
  const { user, userData } = useAuth();
  const [myProjects, setMyProjects] = useState([]);
  const [selectedProject, setSelectedProject] = useState(null);
  const [isModalOpen, setIsModalOpen] = useState(false);

  useEffect(() => {
    if (user && userData) {
      const q = query(collection(db, 'projects'), where('assignedTo', '==', userData.name));
      const unsubscribe = onSnapshot(q, (snapshot) => {
        const projects = snapshot.docs.map(doc => ({ ...doc.data(), id: doc.id }));
        setMyProjects(projects);
      });
      return unsubscribe;
    }
  }, [user, userData]);

  const handleStatusChange = async (projectId, newStatus) => {
    const projectRef = doc(db, 'projects', projectId);
    await updateDoc(projectRef, { status: newStatus });
  };

  const handleCardClick = (project) => {
    setSelectedProject(project);
    setIsModalOpen(true);
  };

  const handleCloseModal = () => {
    setIsModalOpen(false);
    setSelectedProject(null);
  };

  return (
    <div className="bg-surface text-text min-h-screen p-6">
      <h1 className="text-3xl font-bold mb-6">My Tasks</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {myProjects.map(project => (
          <div key={project.id} 
               className="bg-surface p-4 rounded-lg shadow-md cursor-pointer hover:bg-surface"
               onClick={() => handleCardClick(project)}>
            <h2 className="text-xl font-bold mb-2">{project.subject}</h2>
            <p className="text-text mb-2">{project.projectNo}</p>
            <p className="mb-4">{project.description}</p>
            <div className="flex justify-between items-center">
              <p>Status: {project.status}</p>
              <select 
                value={project.status} 
                onChange={(e) => handleStatusChange(project.id, e.target.value)}
                className="bg-surface border border-glass rounded-lg p-1">
                <option value="Issued">Issued</option>
                <option value="In Progress">In Progress</option>
                <option value="On Hold">On Hold</option>
                <option value="Completed">Completed</option>
              </select>
            </div>
          </div>
        ))}
      </div>
      {isModalOpen && selectedProject && (
          <JobOrderModal project={selectedProject} onClose={handleCloseModal} />
      )}
    </div>
  );
};

export default MyTasksPage;
