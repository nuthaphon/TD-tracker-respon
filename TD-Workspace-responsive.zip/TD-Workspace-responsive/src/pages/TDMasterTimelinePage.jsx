import React, { useState, useEffect, useMemo } from 'react';
import { collection, onSnapshot } from 'firebase/firestore';
import { db } from '../firebase';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../hooks/useAuth'; // 🌟 นำเข้า useAuth สำหรับเช็คสิทธิ์

const GlobalMonthHeaders = ({ minMs, maxMs }) => {
    if (!minMs || !maxMs) return null;
    const start = new Date(minMs);
    const end = new Date(maxMs);
    const totalMs = maxMs - minMs;
    
    const months = [];
    let curr = new Date(start.getFullYear(), start.getMonth(), 1); 
    
    while (curr <= end || (curr.getFullYear() === end.getFullYear() && curr.getMonth() === end.getMonth())) {
        let nextMonth = new Date(curr.getFullYear(), curr.getMonth() + 1, 1);
        let monthEnd = new Date(nextMonth.getTime() - 1);
        
        let mStart = Math.max(minMs, curr.getTime());
        let mEnd = Math.min(maxMs, monthEnd.getTime());
        
        let leftP = ((mStart - minMs) / totalMs) * 100;
        let widthP = ((mEnd - mStart) / totalMs) * 100;
        
        months.push({
            id: curr.getTime(),
            label: curr.toLocaleDateString('en-GB', { month: 'short', year: '2-digit' }), 
            left: leftP,
            width: widthP
        });
        curr = nextMonth;
    }

    return (
        <div className="relative w-full h-6 border-b border-glass flex text-[10px] text-text font-bold uppercase overflow-hidden print-month-header">
            {months.map(m => (
                <div key={m.id} className="absolute border-l border-glass h-full pl-2 flex items-center bg-surface/30 print-month-tick" style={{ left: `${m.left}%`, width: `${m.width}%` }}>
                    {m.width > 3 ? m.label : ''} 
                </div>
            ))}
        </div>
    );
};

const TDMasterTimelinePage = () => {
    const navigate = useNavigate();
    const { userData } = useAuth(); // 🌟 ดึงข้อมูลผู้ใช้งาน
    const [projects, setProjects] = useState([]);
    const [loading, setLoading] = useState(true);
    const [viewMode, setViewMode] = useState('project'); 
    
    const [searchTerm, setSearchTerm] = useState('');
    const [statusFilter, setStatusFilter] = useState('Active');
    
    // 🌟 State สำหรับฟีเจอร์ Hide/Unhide 🌟
    const [hiddenProjects, setHiddenProjects] = useState([]);
    const [showHiddenMode, setShowHiddenMode] = useState(false);

    useEffect(() => {
        const unsub = onSnapshot(collection(db, 'td_projects'), (snapshot) => {
            const projData = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
            const validProjects = projData
                .filter(p => p.projectPlanStart && p.projectPlanEnd)
                .sort((a, b) => new Date(a.projectPlanStart).getTime() - new Date(b.projectPlanStart).getTime());
            
            setProjects(validProjects);
            setLoading(false);
        });
        return () => unsub();
    }, []);

    // 🌟 ดักสิทธิ์การเข้าถึงหน้า: อนุญาตเฉพาะ TD และ Admin 🌟
    const isTD = userData?.dept === 'TD' || userData?.role === 'Admin';
    if (!isTD) {
        return (
            <div className="h-full min-h-screen flex flex-col items-center justify-center text-text bg-surface">
                <i className="fas fa-lock text-6xl mb-4 text-red-500 opacity-50"></i>
                <h2 className="text-lg md:text-2xl font-bold text-text mb-2">Access Denied</h2>
                <p className="text-sm">หน้านี้สงวนสิทธิ์เฉพาะพนักงานแผนก TD เท่านั้น</p>
                <button onClick={() => navigate(-1)} className="mt-6 bg-blue-600 hover:bg-blue-500 text-text px-6 py-2.5 rounded-lg text-sm font-bold shadow-lg transition">
                    <i className="fas fa-arrow-left mr-2"></i> ย้อนกลับ
                </button>
            </div>
        );
    }

    // 🌟 ฟังก์ชัน Toggle เปิด/ปิด การซ่อน 🌟
    const toggleHideProject = (projectId) => {
        setHiddenProjects(prev => 
            prev.includes(projectId) ? prev.filter(id => id !== projectId) : [...prev, projectId]
        );
    };

    // 🌟 ตัวกรองหลัก (Search + Status + Hidden) 🌟
    const finalProjectsToRender = projects.filter(p => {
        const search = searchTerm.toLowerCase();
        const allMembers = [p.owner, ...(p.coWorkers || [])].join(' ').toLowerCase();
        const matchSearch = 
            (p.projectName || '').toLowerCase().includes(search) ||
            (p.requestingDept || '').toLowerCase().includes(search) ||
            allMembers.includes(search);
        
        // 🌟 แก้ไข: เพิ่ม Accept/Accepted ในการกรองสถานะเป็น "จบงานแล้ว"
        const isDone = ['Completed', 'Accepted', 'Accept'].includes(p.status);
        
        const matchStatus = 
            statusFilter === 'All' ? true :
            statusFilter === 'Active' ? !isDone : 
            isDone;

        if (!matchSearch || !matchStatus) return false;

        // ถ้าอยู่ในสถานะซ่อน และไม่ได้เปิดโหมดดูที่ซ่อนไว้ ให้เอาออกไปเลย
        const isHidden = hiddenProjects.includes(p.id);
        if (isHidden && !showHiddenMode) return false;

        return true;
    });

    const timeAxis = useMemo(() => {
        let minMs = Date.now();
        let maxMs = Date.now() + (30 * 86400000); 

        if (finalProjectsToRender.length > 0) {
            minMs = Math.min(...finalProjectsToRender.map(p => new Date(p.projectPlanStart).getTime()));
            maxMs = Math.max(...finalProjectsToRender.map(p => new Date(p.projectPlanEnd).getTime()));
        }

        const paddingMs = 15 * 86400000; 
        const viewMinMs = minMs - paddingMs;
        const viewMaxMs = maxMs + paddingMs;
        const totalViewMs = viewMaxMs - viewMinMs;

        const viewMinDate = new Date(viewMinMs);
        const viewMaxDate = new Date(viewMaxMs);

        const years = [];
        for (let y = viewMinDate.getFullYear(); y <= viewMaxDate.getFullYear(); y++) {
            let start = Math.max(viewMinMs, new Date(y, 0, 1).getTime());
            let end = Math.min(viewMaxMs, new Date(y, 11, 31, 23, 59, 59).getTime());
            years.push({
                label: y,
                left: ((start - viewMinMs) / totalViewMs) * 100,
                width: ((end - start) / totalViewMs) * 100
            });
        }

        const months = [];
        let currM = new Date(viewMinDate.getFullYear(), viewMinDate.getMonth(), 1);
        while (currM.getTime() <= viewMaxMs) {
            let nextM = new Date(currM.getFullYear(), currM.getMonth() + 1, 1);
            let start = Math.max(viewMinMs, currM.getTime());
            let end = Math.min(viewMaxMs, nextM.getTime() - 1);
            months.push({
                label: currM.toLocaleDateString('en-GB', { month: 'short' }), 
                left: ((start - viewMinMs) / totalViewMs) * 100,
                width: ((end - start) / totalViewMs) * 100
            });
            currM = nextM;
        }

        const weeks = [];
        let currW = new Date(viewMinMs);
        let dayOfWeek = currW.getDay();
        let offset = dayOfWeek === 0 ? -6 : 1 - dayOfWeek;
        currW.setDate(currW.getDate() + offset);
        currW.setHours(0,0,0,0);

        while (currW.getTime() <= viewMaxMs) {
            let nextWk = new Date(currW.getTime() + 7 * 86400000); 
            let start = Math.max(viewMinMs, currW.getTime());
            let end = Math.min(viewMaxMs, nextWk.getTime() - 1);
            
            let dd = String(currW.getDate()).padStart(2, '0');
            let mmm = currW.toLocaleDateString('en-GB', { month: 'short' });

            weeks.push({
                id: currW.getTime(),
                dateNum: dd,
                monthStr: mmm,
                left: ((start - viewMinMs) / totalViewMs) * 100,
                width: ((end - start) / totalViewMs) * 100
            });
            currW = nextWk;
        }

        return { viewMinMs, viewMaxMs, totalViewMs, years, months, weeks };
    }, [finalProjectsToRender]);

    const { viewMinMs, totalViewMs, years, months, weeks } = timeAxis;
    const todayStr = new Date().toLocaleDateString('en-GB', { day: '2-digit', month: 'short' });
    const todayLeftP = ((Date.now() - viewMinMs) / totalViewMs) * 100;

    const getPersonData = () => {
        const personMap = {};
        finalProjectsToRender.forEach(proj => {
            const members = Array.from(new Set([proj.owner, ...(proj.coWorkers || [])]));
            members.forEach(member => {
                if (!member) return;
                if (!personMap[member]) personMap[member] = [];
                personMap[member].push(proj);
            });
        });
        return Object.keys(personMap).map(name => ({
            name, projects: personMap[name].sort((a, b) => new Date(a.projectPlanStart).getTime() - new Date(b.projectPlanStart).getTime())
        })).sort((a, b) => a.name.localeCompare(b.name));
    };

    const getDeptData = () => {
        const deptMap = {};
        finalProjectsToRender.forEach(proj => {
            const dept = proj.requestingDept || 'N/A';
            if (!deptMap[dept]) deptMap[dept] = [];
            deptMap[dept].push(proj);
        });
        return Object.keys(deptMap).map(dept => ({
            dept, projects: deptMap[dept].sort((a, b) => new Date(a.projectPlanStart).getTime() - new Date(b.projectPlanStart).getTime())
        })).sort((a, b) => a.dept.localeCompare(b.dept));
    };

    if (loading) return <div className="flex justify-center items-center h-screen bg-surface"><div className="animate-spin rounded-full h-12 w-12 border-t-2 border-blue-500"></div></div>;

    const personData = viewMode === 'person' ? getPersonData() : [];
    const deptData = viewMode === 'dept' ? getDeptData() : [];

    return (
        <div className="h-full min-h-screen bg-surface flex flex-col p-4 md:p-6 relative overflow-hidden">
            
            <style dangerouslySetInnerHTML={{__html: `
                @media print {
                    @page { size: A4 landscape; margin: 10mm; }
                    body, html { background-color: #ffffff !important; color: #000000 !important; -webkit-print-color-adjust: exact !important; print-color-adjust: exact !important; margin: 0 !important; padding: 0 !important; }
                    nav, aside, header, footer, button, .no-print, [class*="fixed"] { display: none !important; }
                    #root, main, #root > div, body > div { margin: 0 !important; padding: 0 !important; width: 100% !important; max-width: 100% !important; display: block !important; overflow: visible !important; }
                    .print-master-wrapper { position: relative !important; width: 100% !important; background-color: #ffffff !important; padding: 0 !important; margin: 0 !important; overflow: visible !important; box-shadow: none !important; border: none !important; }
                    .print-scroll-reset { overflow: visible !important; max-height: none !important; width: 100% !important; min-width: 100% !important; padding: 0 !important; }
                    .bg-surface, .bg-surface, .bg-surface\\/50 { background-color: transparent !important; }
                    .text-text, .text-text, .text-text, .text-primary, .text-orange-400 { color: #000000 !important; }
                    .print-header-bg { background-color: #0f233f !important; color: #ffffff !important; border: 2px solid #0f233f !important; }
                    .print-header-bg * { color: #ffffff !important; }
                    .print-left-col { background-color: #1e3a5f !important; color: #ffffff !important; border-right: 2px solid #ffffff !important; border-bottom: 1px solid #475569 !important; padding: 12px 10px !important; width: 250px !important; flex-shrink: 0 !important; }
                    .print-left-col * { color: #ffffff !important; }
                    .print-right-col { border-bottom: 1px solid #e2e8f0 !important; border-right: 2px solid #0f233f !important; }
                    .print-grid-line { border-left: 1px solid #cbd5e1 !important; }
                    .print-today-line { border-left: 3px solid #16a34a !important; z-index: 50 !important; }
                    .print-today-label { background-color: #16a34a !important; color: white !important; }
                    .gantt-row { page-break-inside: avoid !important; align-items: stretch !important; border-left: 2px solid #0f233f !important; }
                    
                    /* ถ้า Print ให้ opacity เป็นปกติเสมอ เพราะเรากรองตัวซ่อนออกไปแล้ว */
                    .print-bar { border: 1px solid #000 !important; box-shadow: none !important; opacity: 1 !important; }
                    
                    .doc-header { display: block !important; text-align: left; border-bottom: 3px double #0f233f; margin-bottom: 20px; padding-bottom: 10px; width: 100%; }
                    .doc-header h1 { font-size: 24px; font-weight: bold; color: #0f233f; text-transform: uppercase; margin: 0; letter-spacing: 1px; }
                    .doc-header p { font-size: 12px; color: #475569; margin-top: 5px; }
                    .print-hide-avatar { display: none !important; }
                }
                .custom-scrollbar::-webkit-scrollbar { height: 8px; width: 8px; }
                .custom-scrollbar::-webkit-scrollbar-thumb { background: #4b5563; border-radius: 10px; }
            `}} />

            <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6 border-b border-glass pb-4 gap-4 no-print">
                <div>
                    <h1 className="text-lg md:text-2xl font-black text-text flex items-center gap-3 tracking-wide">
                        <i className="fas fa-layer-group text-primary"></i> MASTER GANTT DASHBOARD
                    </h1>
                </div>
                
                <div className="flex flex-col items-end gap-3 w-full md:w-auto">
                    <div className="flex items-center gap-4 flex-wrap w-full justify-end">
                        <div className="flex bg-surface rounded-lg p-1 border border-glass shadow-inner">
                            <button onClick={() => setViewMode('project')} className={`px-4 py-1.5 text-xs font-bold rounded-md transition-all flex items-center gap-2 ${viewMode === 'project' ? 'bg-blue-600 text-text shadow' : 'text-text hover:text-text'}`}><i className="fas fa-project-diagram"></i> รายโปรเจกต์</button>
                            <button onClick={() => setViewMode('person')} className={`px-4 py-1.5 text-xs font-bold rounded-md transition-all flex items-center gap-2 ${viewMode === 'person' ? 'bg-purple-600 text-text shadow' : 'text-text hover:text-text'}`}><i className="fas fa-users"></i> รายบุคคล</button>
                            <button onClick={() => setViewMode('dept')} className={`px-4 py-1.5 text-xs font-bold rounded-md transition-all flex items-center gap-2 ${viewMode === 'dept' ? 'bg-orange-600 text-text shadow' : 'text-text hover:text-text'}`}><i className="fas fa-building"></i> รายแผนก</button>
                        </div>
                    </div>

                    <div className="flex flex-wrap items-center gap-2 w-full justify-end">
                        
                        {/* 🌟 ปุ่มสลับโหมดซ่อน/แสดง 🌟 */}
                        {hiddenProjects.length > 0 && (
                            <button 
                                onClick={() => setShowHiddenMode(!showHiddenMode)} 
                                className={`px-3 py-2 rounded-lg text-xs font-bold border transition-all flex items-center shadow-inner ${showHiddenMode ? 'bg-surface text-primary border-glass' : 'bg-surface text-text border-glass hover:text-text'}`}
                            >
                                <i className={`fas ${showHiddenMode ? 'fa-eye' : 'fa-eye-slash'} mr-2`}></i>
                                {showHiddenMode ? 'ซ่อนรายการที่ปิดไว้' : `ที่ถูกซ่อน (${hiddenProjects.length})`}
                            </button>
                        )}

                        <div className="relative w-48 lg:w-64">
                            <i className="fas fa-search absolute left-3 top-1/2 transform -translate-y-1/2 text-text"></i>
                            <input type="text" placeholder="ค้นหา ชื่อ, แผนก, คน..." value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} className="w-full bg-surface border border-glass text-text text-xs rounded-lg pl-9 pr-3 py-2 outline-none focus:border-blue-500"/>
                        </div>
                        <select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)} className="bg-surface border border-glass text-text text-xs rounded-lg px-3 py-2 outline-none focus:border-blue-500" style={{ backgroundColor: 'var(--color-bg)', color: 'var(--color-text)' }}>
                            <option value="All">ทุกสถานะ</option><option value="Active">กำลังดำเนินการ</option><option value="Completed">จบงานแล้ว</option>
                        </select>
                        <button onClick={() => window.print()} className="bg-red-600 hover:bg-red-500 text-text px-4 py-2 rounded-lg font-bold shadow-lg transition flex items-center text-xs ml-2"><i className="fas fa-print mr-2"></i> Print / PDF</button>
                    </div>
                </div>
            </div>

            <div className="flex-1 overflow-hidden relative print-master-wrapper print-scroll-reset">
                
                <div className="hidden print:block doc-header">
                    <h1>TD Master Schedule Plan</h1>
                    <p><b>View Mode:</b> {viewMode.toUpperCase()} | <b>Status Filter:</b> {statusFilter} | <b>Printed:</b> {new Date().toLocaleString('th-TH')}</p>
                </div>

                <div className="h-full bg-surface print:bg-surface rounded-2xl border border-glass print:border-none shadow-2xl p-4 flex flex-col print-scroll-reset">
                    
                    {finalProjectsToRender.length === 0 ? (
                        <div className="flex-1 flex flex-col items-center justify-center text-text opacity-50 py-20 no-print">
                            <i className="fas fa-search text-6xl mb-4"></i>
                            <p className="text-lg font-bold">ไม่พบโปรเจกต์ที่ตรงกับเงื่อนไข</p>
                        </div>
                    ) : (
                        <div className="flex-1 overflow-x-auto overflow-y-auto custom-scrollbar print-scroll-reset pb-10">
                            <div className="relative print-scroll-reset print:w-full print:min-w-0" style={{ minWidth: `max(1000px, ${weeks.length * 35}px)` }}> 
                                
                                <div className="flex w-full sticky top-0 z-40 bg-surface print-header-bg border-b border-glass shadow-md gantt-row">
                                    <div className="w-64 shrink-0 p-3 flex items-center justify-center print-left-col border-none">
                                        <span className="text-xs text-text print:text-text font-bold uppercase tracking-widest text-center">
                                            {viewMode === 'project' ? 'Project / Team' : viewMode === 'person' ? 'Team Member' : 'Department'}
                                        </span>
                                    </div> 

                                    <div className="flex-1 relative flex flex-col">
                                        <div className="relative w-full h-[20px] border-b border-glass print:border-glass/50 bg-surface/60 print:bg-transparent">
                                            {years.map((y, i) => (
                                                <div key={`y-${i}`} className="absolute h-full flex items-center justify-center text-[11px] text-text print:text-text font-bold border-l border-glass print:border-glass/50" style={{ left: `${y.left}%`, width: `${y.width}%` }}>{y.label}</div>
                                            ))}
                                        </div>
                                        <div className="relative w-full h-[20px] border-b border-glass print:border-glass/50 bg-surface/80 print:bg-transparent">
                                            {months.map((m, i) => (
                                                <div key={`m-${i}`} className="absolute h-full flex items-center justify-center text-[10px] text-primary print:text-text font-bold border-l border-glass print:border-glass/50 uppercase tracking-widest" style={{ left: `${m.left}%`, width: `${m.width}%` }}>{m.width > 2 ? m.label : ''}</div>
                                            ))}
                                        </div>
                                        <div className="relative w-full h-[20px] bg-surface/40 print:bg-transparent">
                                            {weeks.map(w => (
                                                <div key={`w-${w.id}`} className="absolute h-full flex items-center justify-center text-[9px] font-bold border-l border-glass print:border-glass/50 text-text print:text-text" style={{ left: `${w.left}%`, width: `${w.width}%` }}>
                                                    {w.width > 3 ? `${w.dateNum} ${w.monthStr}` : w.dateNum}
                                                </div>
                                            ))}
                                        </div>
                                    </div>
                                </div>

                                <div className="relative w-full print:border-b-2 print:border-black">
                                    
                                    <div className="absolute top-0 bottom-0 left-64 right-0 z-0 pointer-events-none hidden print:block">
                                        {weeks.map(w => (
                                            <div key={`grid-${w.id}`} className="absolute h-full print-grid-line" style={{ left: `${w.left}%` }}></div>
                                        ))}
                                        {todayLeftP >= 0 && todayLeftP <= 100 && (
                                            <div className="absolute top-0 bottom-[-30px] w-px print-today-line" style={{ left: `${todayLeftP}%` }}>
                                                <div className="absolute -bottom-6 left-1/2 transform -translate-x-1/2 print-today-label text-[10px] font-bold px-3 py-1 rounded shadow whitespace-nowrap">TODAY</div>
                                            </div>
                                        )}
                                    </div>

                                    <div className="absolute top-0 bottom-[-2000px] left-64 right-0 z-30 pointer-events-none no-print">
                                        {todayLeftP >= 0 && todayLeftP <= 100 && (
                                            <div className="absolute top-0 bottom-0 w-px bg-red-500/60 border-l border-dashed border-red-500" style={{ left: `${todayLeftP}%` }}>
                                                <div className="absolute top-2 left-1/2 transform -translate-x-1/2 bg-red-500 text-text text-[9px] font-bold px-2 py-0.5 rounded shadow whitespace-nowrap">TODAY ({todayStr})</div>
                                            </div>
                                        )}
                                    </div>

                                    <div className="relative z-10 w-full mt-2 print:mt-6">
                                        
                                        {/* 🟢 โหมด Project (รายโปรเจกต์) 🟢 */}
                                        {viewMode === 'project' && finalProjectsToRender.map((proj, index) => {
                                            const sMs = new Date(proj.projectPlanStart).getTime();
                                            const eMs = new Date(proj.projectPlanEnd).getTime();
                                            const leftP = Math.max(0, ((sMs - viewMinMs) / totalViewMs) * 100);
                                            const widthP = ((eMs - sMs) / totalViewMs) * 100;
                                            
                                            // 🌟 แก้ไข: รวม Accept เข้ากับ Completed
                                            const isCompleted = ['Completed', 'Accepted', 'Accept'].includes(proj.status);
                                            const barColor = isCompleted ? 'from-green-600 to-green-400 print:bg-green-600' : 'from-blue-600 to-purple-500 print:bg-blue-600';
                                            
                                            const allMembers = Array.from(new Set([proj.owner, ...(proj.coWorkers || [])]));
                                            
                                            // เช็คว่าถูกซ่อนไหม
                                            const isHidden = hiddenProjects.includes(proj.id);
                                            const rowOpacity = isHidden ? 'opacity-40 grayscale' : 'opacity-100';

                                            return (
                                                <div key={proj.id} className={`flex w-full group hover:bg-surface/30 transition cursor-pointer gantt-row relative hover:z-50 ${rowOpacity}`} onClick={() => navigate(`/project/${proj.id}`)}>
                                                    <div className="w-64 shrink-0 flex flex-col justify-center print-left-col py-3 relative">
                                                        
                                                        {/* 🌟 ปุ่ม Hide / Unhide 🌟 */}
                                                        <button 
                                                            onClick={(e) => { e.stopPropagation(); toggleHideProject(proj.id); }} 
                                                            className={`absolute top-2 right-2 no-print z-50 p-1.5 rounded transition-all ${isHidden ? 'text-red-400 opacity-100 bg-surface' : 'text-text hover:text-text opacity-0 group-hover:opacity-100 bg-surface/80 hover:bg-surface'}`}
                                                            title={isHidden ? "ยกเลิกการซ่อน" : "ซ่อนโปรเจกต์นี้"}
                                                        >
                                                            <i className={`fas ${isHidden ? 'fa-eye-slash' : 'fa-eye'}`}></i>
                                                        </button>

                                                        <div className="flex items-start justify-between gap-2 mb-2 pr-8">
                                                            {/* 🌟 รันลำดับ 1, 2, 3 อัตโนมัติ 🌟 */}
                                                            <h3 className={`font-bold text-text print:text-text text-[13px] leading-tight ${isHidden ? 'line-through text-text' : ''}`} title={proj.projectName}>
                                                                {index + 1}. {proj.projectName}
                                                            </h3>
                                                            <div className="flex flex-col items-end shrink-0">
                                                                <span className={`text-[8px] px-2 py-0.5 rounded-full font-bold uppercase border ${isCompleted ? 'bg-green-500/20 text-green-400 border-green-500' : 'bg-purple-500/20 text-purple-400 border-purple-500'} no-print`}>
                                                                    {proj.progress}%
                                                                </span>
                                                                <span className="hidden print:block text-[10px] font-bold print:text-text mt-1">[{proj.progress}%]</span>
                                                            </div>
                                                        </div>
                                                        
                                                        <div className="flex flex-col gap-1.5 mt-1 pr-2">
                                                            {allMembers.map((member, idx) => (
                                                                <div key={idx} className="flex items-center gap-2 bg-surface/80 print:bg-transparent p-1.5 rounded-md border border-glass/50 print:border-none print:p-0">
                                                                    <div className={`w-5 h-5 rounded-full flex items-center justify-center text-[8px] font-bold text-text shadow-inner shrink-0 ${idx === 0 ? 'bg-yellow-600 border border-yellow-500' : 'bg-surface border border-glass'} no-print`}>
                                                                        {member.substring(0, 2).toUpperCase()}
                                                                    </div>
                                                                    <span className={`text-[10px] truncate ${idx === 0 ? 'text-yellow-400 font-bold print:text-text' : 'text-text print:text-text'}`} title={member}>
                                                                        {idx === 0 ? <i className="fas fa-crown text-[8px] mr-1 text-yellow-500 print:text-text"></i> : <i className="fas fa-user text-[8px] mr-1 opacity-50 hidden print:inline"></i>}
                                                                        {member}
                                                                    </span>
                                                                </div>
                                                            ))}
                                                        </div>
                                                    </div>

                                                    <div className="flex-1 relative print-right-col min-h-[55px] flex items-center">
                                                        <div className={`absolute h-5 rounded shadow-md bg-gradient-to-r print:bg-none ${barColor} print-bar overflow-visible ${isHidden ? 'border-2 border-dashed border-red-500/50' : ''}`} style={{ left: `${leftP}%`, width: `${widthP}%` }}>
                                                            <div className="absolute -top-8 left-1/2 transform -translate-x-1/2 bg-surface text-text text-[10px] font-bold px-3 py-1 rounded shadow-xl opacity-0 group-hover:opacity-100 transition whitespace-nowrap pointer-events-none z-50 border border-glass no-print flex flex-col items-center">
                                                                <span className="text-[10px]">{new Date(sMs).toLocaleDateString('en-GB')} - {new Date(eMs).toLocaleDateString('en-GB')}</span>
                                                            </div>
                                                            <div className="hidden print:block absolute top-6 left-0 text-[8px] text-text font-bold whitespace-nowrap">
                                                                {new Date(sMs).toLocaleDateString('en-GB')} - {new Date(eMs).toLocaleDateString('en-GB')}
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            );
                                        })}

                                        {/* 🟢 โหมด Person (รายบุคคล) 🟢 */}
                                        {viewMode === 'person' && personData.map((person) => (
                                            <div key={person.name} className="flex w-full hover:bg-surface/30 transition gantt-row relative hover:z-50">
                                                <div className="w-64 shrink-0 flex items-center print-left-col gap-3">
                                                    <div className="w-8 h-8 rounded-full bg-purple-600 text-text font-bold text-xs flex items-center justify-center no-print">{person.name.substring(0, 2).toUpperCase()}</div>
                                                    <div>
                                                        <h3 className="font-bold text-text print:text-text text-[13px]">{person.name}</h3>
                                                        <span className="text-[10px] text-text print:text-text">{person.projects.length} Projects</span>
                                                    </div>
                                                </div>

                                                <div className="flex-1 relative print-right-col py-3" style={{ minHeight: `${Math.max(55, person.projects.length * 36)}px` }}>
                                                    {person.projects.map((proj, pIdx) => {
                                                        const sMs = new Date(proj.projectPlanStart).getTime();
                                                        const eMs = new Date(proj.projectPlanEnd).getTime();
                                                        const leftP = Math.max(0, ((sMs - viewMinMs) / totalViewMs) * 100);
                                                        const widthP = ((eMs - sMs) / totalViewMs) * 100;
                                                        
                                                        // 🌟 แก้ไข: รวม Accept เข้ากับ Completed
                                                        const isCompleted = ['Completed', 'Accepted', 'Accept'].includes(proj.status);
                                                        const barColor = isCompleted ? 'from-green-600 to-green-500 print:bg-green-600' : 'from-purple-600 to-blue-500 print:bg-purple-600';
                                                        
                                                        const isHidden = hiddenProjects.includes(proj.id);
                                                        const hiddenClass = isHidden ? 'opacity-40 grayscale border-2 border-dashed border-red-500/50' : '';

                                                        return (
                                                            <div key={proj.id} className={`absolute h-5 rounded shadow bg-gradient-to-r print:bg-none ${barColor} print-bar overflow-visible flex items-center px-2 group cursor-pointer hover:z-50 hover:scale-y-110 transition-all ${hiddenClass}`} onClick={() => navigate(`/project/${proj.id}`)} style={{ left: `${leftP}%`, width: `${widthP}%`, top: `${pIdx * 34 + 12}px` }}>
                                                                
                                                                {/* 🌟 รันลำดับ และเอาข้อความไว้ในแท่งเสมอ 🌟 */}
                                                                <span className="absolute inset-0 flex items-center px-2 text-[9px] font-bold text-text truncate drop-shadow-md print:drop-shadow-none pointer-events-none">
                                                                    {pIdx + 1}. {proj.projectName}
                                                                </span>
                                                                
                                                                {/* 🌟 วันที่ห้อยใต้แท่ง 🌟 */}
                                                                <span className="hidden print:block absolute top-full left-0 mt-0.5 text-[8px] font-bold text-text whitespace-nowrap">
                                                                    {new Date(sMs).toLocaleDateString('en-GB')} - {new Date(eMs).toLocaleDateString('en-GB')}
                                                                </span>
                                                                
                                                                <div className="absolute -top-10 left-1/2 transform -translate-x-1/2 bg-surface text-text text-[10px] font-bold px-3 py-1.5 rounded-lg shadow-2xl opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap pointer-events-none z-[60] border border-glass flex flex-col items-center no-print">
                                                                    <span className={`${isHidden ? 'text-red-400 line-through' : 'text-primary'}`}>{pIdx + 1}. {proj.projectName}</span>
                                                                    <span className="text-[8px] text-text mt-0.5">{new Date(sMs).toLocaleDateString('en-GB')} - {new Date(eMs).toLocaleDateString('en-GB')}</span>
                                                                </div>
                                                            </div>
                                                        )
                                                    })}
                                                </div>
                                            </div>
                                        ))}

                                        {/* 🟢 โหมด Dept (รายแผนก) 🟢 */}
                                        {viewMode === 'dept' && deptData.map((deptItem) => (
                                            <div key={deptItem.dept} className="flex w-full hover:bg-surface/30 transition gantt-row relative hover:z-50">
                                                <div className="w-64 shrink-0 flex items-center print-left-col gap-3">
                                                    <div className="w-8 h-8 rounded-full bg-orange-600 text-text font-bold text-xs flex items-center justify-center no-print">{deptItem.dept.substring(0, 3).toUpperCase()}</div>
                                                    <div>
                                                        <h3 className="font-bold text-text print:text-text text-[13px]">{deptItem.dept}</h3>
                                                        <span className="text-[10px] text-text print:text-text">{deptItem.projects.length} Projects</span>
                                                    </div>
                                                </div>

                                                <div className="flex-1 relative print-right-col py-3" style={{ minHeight: `${Math.max(55, deptItem.projects.length * 36)}px` }}>
                                                    {deptItem.projects.map((proj, pIdx) => {
                                                        const sMs = new Date(proj.projectPlanStart).getTime();
                                                        const eMs = new Date(proj.projectPlanEnd).getTime();
                                                        const leftP = Math.max(0, ((sMs - viewMinMs) / totalViewMs) * 100);
                                                        const widthP = ((eMs - sMs) / totalViewMs) * 100;
                                                        
                                                        // 🌟 แก้ไข: รวม Accept เข้ากับ Completed
                                                        const isCompleted = ['Completed', 'Accepted', 'Accept'].includes(proj.status);
                                                        const barColor = isCompleted ? 'from-green-600 to-green-500 print:bg-green-600' : 'from-orange-500 to-yellow-500 print:bg-orange-500';
                                                        
                                                        const isHidden = hiddenProjects.includes(proj.id);
                                                        const hiddenClass = isHidden ? 'opacity-40 grayscale border-2 border-dashed border-red-500/50' : '';

                                                        return (
                                                            <div key={proj.id} className={`absolute h-5 rounded shadow bg-gradient-to-r print:bg-none ${barColor} print-bar overflow-visible flex items-center px-2 group cursor-pointer hover:z-50 hover:scale-y-110 transition-all ${hiddenClass}`} onClick={() => navigate(`/project/${proj.id}`)} style={{ left: `${leftP}%`, width: `${widthP}%`, top: `${pIdx * 34 + 12}px` }}>
                                                                
                                                                {/* 🌟 รันลำดับ และเอาข้อความไว้ในแท่งเสมอ 🌟 */}
                                                                <span className="absolute inset-0 flex items-center px-2 text-[9px] font-bold text-text truncate drop-shadow-md print:drop-shadow-none pointer-events-none">
                                                                    {pIdx + 1}. {proj.projectName}
                                                                </span>
                                                                
                                                                {/* 🌟 วันที่ห้อยใต้แท่ง 🌟 */}
                                                                <span className="hidden print:block absolute top-full left-0 mt-0.5 text-[8px] font-bold text-text whitespace-nowrap">
                                                                    {new Date(sMs).toLocaleDateString('en-GB')} - {new Date(eMs).toLocaleDateString('en-GB')}
                                                                </span>
                                                                
                                                                <div className="absolute -top-10 left-1/2 transform -translate-x-1/2 bg-surface text-text text-[10px] font-bold px-3 py-1.5 rounded-lg shadow-2xl opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap pointer-events-none z-[60] border border-glass flex flex-col items-center no-print">
                                                                    <span className={`${isHidden ? 'text-red-400 line-through' : 'text-orange-300'}`}>{pIdx + 1}. {proj.projectName}</span>
                                                                    <span className="text-[8px] text-text mt-0.5">{new Date(sMs).toLocaleDateString('en-GB')} - {new Date(eMs).toLocaleDateString('en-GB')}</span>
                                                                </div>
                                                            </div>
                                                        )
                                                    })}
                                                </div>
                                            </div>
                                        ))}

                                    </div>
                                </div>
                            </div>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};

export default TDMasterTimelinePage;