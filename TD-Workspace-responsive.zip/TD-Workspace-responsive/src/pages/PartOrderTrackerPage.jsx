import React, { useState, useEffect, useRef } from 'react';
import { collection, doc, onSnapshot, query, orderBy, getDocs, serverTimestamp, writeBatch, updateDoc, setDoc, deleteDoc, arrayUnion } from 'firebase/firestore';
import { ref, uploadBytes, getDownloadURL } from 'firebase/storage';
import { db, storage } from '../firebase';
import { useAuth } from '../hooks/useAuth';
import { CSVLink } from 'react-csv';
import { useLocation, useNavigate } from 'react-router-dom';
import { logActivity } from '../utils/activityLogger';

const PartOrderTrackerPage = () => {
    const { userData, user } = useAuth();
    const location = useLocation();
    const navigate = useNavigate();
    
    // --- States ---
    const [orders, setOrders] = useState([]);
    const [activeProjects, setActiveProjects] = useState([]);
    const [vendors, setVendors] = useState([]); 
    const [csvData, setCsvData] = useState([]);
    const [loading, setLoading] = useState(true);
    const [showForm, setShowForm] = useState(false);
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [showChecklistModal, setShowChecklistModal] = useState(false);

    // --- Pagination & Filter States ---
    const [searchTerm, setSearchTerm] = useState('');
    const [filterStatus, setFilterStatus] = useState('All');
    const [currentPage, setCurrentPage] = useState(1);
    const itemsPerPage = 20;

    // --- Order Form States ---
    const [orderInfo, setOrderInfo] = useState({ projectNo: '', projectId: '', urgency: 'Normal' });
    const [partList, setPartList] = useState([]);
    const [currentPart, setCurrentPart] = useState({ partName: '', qty: 1, link: '', note: '', fileUrl: '', fileName: '' });
    
    // --- File Upload States ---
    const [isUploadingFile, setIsUploadingFile] = useState(false);
    const fileInputRef = useRef(null);

    // --- Status Update Modal States ---
    const [statusModal, setStatusModal] = useState({
        isOpen: false, orderId: '', status: '', prNo: '', pricePerUnit: '', vendorCode: '', vendorName: '', comment: '', timeline: []
    });

    const statusOptions = ["Pending (wait PR)", "Ordered (wait PO)", "Sending", "Shipped (income)", "Received", "Cancelled"];

    // 🌟 --- 1. กำหนดตัวแปรสิทธิ์ (Permissions) ตามกฎ --- 🌟
    const isAdmin = userData?.role === 'Admin';
    const userJobTitle = (userData?.jobTitle || '').toLowerCase();
    const isTD = userData?.dept === 'TD' || isAdmin;
    
    const isTDMgrOrSup = isTD && (userJobTitle.includes('manager') || userJobTitle.includes('supervisor') || userJobTitle.includes('lead') || userJobTitle.includes('director'));
    const isTDEngineer = isTD && userJobTitle.includes('engineer');
    
    // สิทธิ์การอัปเดตสถานะและราคา
    const canUpdateStatus = isTDMgrOrSup || isTDEngineer || isAdmin;

    // --- 1. Fetch Data ---
    useEffect(() => {
        const fetchProjects = async () => {
            const q = query(collection(db, 'td_projects'), orderBy('createdAt', 'desc'));
            const snapshot = await getDocs(q);
            const projData = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
            setActiveProjects(projData.filter(p => p.status !== 'Completed'));
        };
        fetchProjects();

        const unsubVendors = onSnapshot(collection(db, 'vendors'), (snapshot) => {
            setVendors(snapshot.docs.map(doc => doc.data()));
        });

        setLoading(true);
        const qOrders = query(collection(db, 'part_orders'), orderBy('createdAt', 'desc'));
        const unsubOrders = onSnapshot(qOrders, (snapshot) => {
            setOrders(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
            setLoading(false);
        });

        return () => { unsubVendors(); unsubOrders(); };
    }, []);

    useEffect(() => {
        if (location.state?.openOrderForm && activeProjects.length > 0) {
            setShowForm(true); 
            const targetId = location.state.projectId;
            
            if (targetId) {
                const selectedProj = activeProjects.find(p => p.id === targetId);
                if (selectedProj) {
                    setOrderInfo(prev => ({
                        ...prev,
                        projectId: selectedProj.id,
                        projectNo: selectedProj.projectNoRef !== '-' ? selectedProj.projectNoRef : selectedProj.projectName
                    }));
                }
            }
            navigate(location.pathname, { replace: true, state: {} });
        }
    }, [location.state, activeProjects, navigate, location.pathname]);

    // 🌟 ดักสิทธิ์การเข้าถึงหน้า: เฉพาะ TD และ Admin เท่านั้น 🌟
    if (!isTD) {
        return (
            <div className="h-full flex flex-col items-center justify-center text-text bg-surface">
                <i className="fas fa-lock text-6xl mb-4 text-red-500 opacity-50"></i>
                <h2 className="text-2xl font-bold text-text mb-2">Access Denied</h2>
                <p className="text-sm">หน้านี้สงวนสิทธิ์เฉพาะพนักงานแผนก TD เท่านั้น</p>
                <button onClick={() => navigate(-1)} className="mt-6 bg-blue-600 hover:bg-blue-500 text-text px-6 py-2.5 rounded-lg text-sm font-bold shadow-lg transition">
                    <i className="fas fa-arrow-left mr-2"></i> ย้อนกลับ
                </button>
            </div>
        );
    }

    // --- 2. Filter & Pagination Logic ---
    const filteredOrders = orders.filter(order => {
        const matchSearch = 
            (order.partName || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
            (order.projectNo || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
            (order.prNo || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
            (order.vendorName || '').toLowerCase().includes(searchTerm.toLowerCase());
        const matchStatus = filterStatus === 'All' || order.status === filterStatus;
        return matchSearch && matchStatus;
    });

    const totalPages = Math.ceil(filteredOrders.length / itemsPerPage);
    const currentOrders = filteredOrders.slice((currentPage - 1) * itemsPerPage, currentPage * itemsPerPage);

    useEffect(() => { setCurrentPage(1); }, [searchTerm, filterStatus]); 

    // --- 3. Export CSV ---
    useEffect(() => {
        const data = filteredOrders.map(order => ({
            'Project No': order.projectNo, 'Part Name': order.partName, 
            'Qty': order.qty, 'Price/Unit': order.pricePerUnit || 0, 'Total Price': order.qty * (order.pricePerUnit || 0),
            'PR No.': order.prNo || '-', 'Vendor': `${order.vendorCode || '-'} ${order.vendorName || ''}`,
            'Urgency': order.urgency, 'Status': order.status, 'Requestor': order.requestBy,
            'Order Date': order.createdAt?.toDate().toLocaleDateString('th-TH'),
            'ETA': order.eta ? order.eta.toDate().toLocaleDateString('th-TH') : 'N/A',
            'Link': order.link || 'N/A', 'Attached File': order.fileUrl || 'N/A', 'Note': order.note || '-'
        }));
        setCsvData(data);
    }, [orders, searchTerm, filterStatus]);

    const receivableOrders = filteredOrders.filter(order => 
        order.status === 'Sending' || order.status === 'Shipped (income)'
    );

    // --- ฟังก์ชันสร้างและ Export PDF ---
    const handlePrintPdf = () => {
        if (receivableOrders.length === 0) {
            alert('ไม่พบรายการอะไหล่ที่มีสถานะ "Sending" หรือ "Shipped (income)" สำหรับสร้างใบตรวจรับ');
            return;
        }

        const groupedOrders = receivableOrders.reduce((acc, order) => {
            const proj = order.projectNo || 'No-Project';
            if (!acc[proj]) acc[proj] = [];
            acc[proj].push(order);
            return acc;
        }, {});

        let printContent = `
        <html>
        <head>
            <title>Part Order Checklist</title>
            <style>
                body { font-family: 'Tahoma', 'Sarabun', sans-serif; margin: 20px; color: #000; font-size: 14px; }
                .header { text-align: center; margin-bottom: 20px; border-bottom: 2px solid #000; padding-bottom: 10px; }
                .header h1 { margin: 0; font-size: 22px; }
                .header h2 { margin: 5px 0 0 0; font-size: 16px; color: #333; }
                .print-date { font-size: 12px; color: #666; text-align: right; margin-top: 5px; }
                .project-section { margin-bottom: 40px; page-break-inside: avoid; }
                .project-title { font-size: 16px; font-weight: bold; background: #eee; padding: 8px; border: 1px solid #000; margin-bottom: 0; border-bottom: none; }
                table { width: 100%; border-collapse: collapse; margin-bottom: 15px; }
                th, td { border: 1px solid #000; padding: 8px; text-align: left; vertical-align: middle; }
                th { background-color: #f0f0f0; text-align: center; font-weight: bold; }
                .text-center { text-align: center; }
                .check-box { width: 22px; height: 22px; border: 2px solid #000; display: inline-block; border-radius: 3px; }
                .signature-area { display: flex; justify-content: space-around; margin-top: 30px; page-break-inside: avoid; }
                .sign-box { text-align: center; width: 25%; font-size: 12px; }
                .line { border-bottom: 1px solid #000; margin-bottom: 5px; height: 40px; }
                @media print { @page { margin: 1cm; size: A4 landscape; } body { -webkit-print-color-adjust: exact; } }
            </style>
        </head>
        <body>
            <div class="header">
                <h1>TOP TREND MANUFACTURING CO., LTD.</h1>
                <h2>ใบเบิกและตรวจรับอะไหล่ (Part Order Checklist)</h2>
                <div class="print-date">พิมพ์เมื่อ: ${new Date().toLocaleString('th-TH')}</div>
            </div>
        `;

        Object.keys(groupedOrders).forEach(projNo => {
            const items = groupedOrders[projNo];
            const requestor = items[0]?.requestBy || '-';
            
            printContent += `
            <div class="project-section">
                <div class="project-title">Ref Project: ${projNo} <span style="float: right; font-size: 14px; font-weight: normal;">ผู้ขอเบิก: ${requestor}</span></div>
                <table>
                    <thead>
                        <tr><th style="width: 5%;">No.</th><th style="width: 35%;">ชื่ออะไหล่ (Part Name)</th><th style="width: 10%;">Qty</th><th style="width: 15%;">สถานะล่าสุด</th><th style="width: 20%;">หมายเหตุ (Note)</th><th style="width: 15%;">ช่างตรวจรับ<br>(Check)</th></tr>
                    </thead>
                    <tbody>
            `;
            
            items.forEach((item, index) => {
                const machineText = item.machineNo ? ` | M/C: ${item.machineNo}` : '';
                printContent += `<tr><td class="text-center">${index + 1}</td><td><b>${item.partName}</b><br><span style="font-size: 12px; color: #555;">PR: ${item.prNo || '-'}${machineText}</span></td><td class="text-center" style="font-size: 16px;"><b>${item.qty}</b></td><td class="text-center" style="font-size: 12px;">${item.status}</td><td style="font-size: 12px;">${item.note || ''}</td><td class="text-center"><div class="check-box"></div></td></tr>`;
            });

            printContent += `
                    </tbody>
                </table>
                <div class="signature-area">
                    <div class="sign-box"><div class="line"></div><p>ผู้ขอเบิก (Requestor)<br>วันที่: ______/______/______</p></div>
                    <div class="sign-box"><div class="line"></div><p>ผู้จัดซื้อ (Purchaser)<br>วันที่: ______/______/______</p></div>
                    <div class="sign-box"><div class="line"></div><p>ช่างเทคนิคผู้ตรวจรับ (Receiver)<br>วันที่: ______/______/______</p></div>
                </div>
            </div>`;
        });

        printContent += `</body><script>window.onload = function() { setTimeout(function() { window.print(); window.close(); }, 500); }<\/script></html>`;

        const printWin = window.open('', '_blank');
        if (printWin) { printWin.document.open(); printWin.document.write(printContent); printWin.document.close(); } 
        else { alert('เบราว์เซอร์ของคุณบล็อก Pop-up! กรุณาอนุญาตให้เปิด Pop-up เพื่อพิมพ์ PDF'); }
    };

    // 🌟 ฟังก์ชันลบ Order สำหรับคนที่มีสิทธิ์ 🌟
    const handleDeleteOrder = async (orderId, partName) => {
        if (!window.confirm(`ต้องการลบรายการสั่งซื้อ "${partName}" ใช่หรือไม่?`)) return;
        try {
            await deleteDoc(doc(db, 'part_orders', orderId));
            await logActivity(user, 'Deleted Part Order', `ลบรายการสั่งอะไหล่: ${partName}`);
        } catch (error) { alert('ลบไม่สำเร็จ'); }
    };

    // 🌟 ฟังก์ชันติ๊กรับของจาก Checklist Modal 🌟
    const handleMarkAsReceived = async (orderId) => {
        try {
            const newTimelineEvent = { 
                status: 'Received', 
                by: userData?.name, 
                comment: 'ติ๊กรับของจาก Checklist', 
                timestamp: new Date().toISOString() 
            };

            await updateDoc(doc(db, 'part_orders', orderId), {
                status: 'Received',
                eta: new Date(), 
                updated_at: serverTimestamp(),
                timeline: arrayUnion(newTimelineEvent)
            });
            
            const part = orders.find(o => o.id === orderId);
            if (part) {
                await logActivity(user, 'Received Part', `รับอะไหล่ ${part.partName} เข้าสู่ระบบ (Project: ${part.projectNo})`);
            }
        } catch (error) {
            console.error("Error receiving part:", error);
            alert('เกิดข้อผิดพลาดในการอัปเดตสถานะ');
        }
    };

    const groupedChecklist = receivableOrders.reduce((acc, order) => {
        const proj = order.projectNo || 'No-Project';
        if (!acc[proj]) acc[proj] = [];
        acc[proj].push(order);
        return acc;
    }, {});


    // --- 4. จัดการ Form เพิ่มรายการ ---
    const handleFileUploadToStorage = async (e) => {
        const file = e.target.files[0];
        if (!file) return;
        if (file.size > 10 * 1024 * 1024) { // จำกัดขนาดไฟล์ 10MB
            alert("ขนาดไฟล์ใหญ่เกินไป (สูงสุด 10MB)");
            if(fileInputRef.current) fileInputRef.current.value = "";
            return;
        }

        setIsUploadingFile(true);
        try {
            const uniqueFileName = `${Date.now()}_${file.name}`;
            const storageRef = ref(storage, `part_orders/${uniqueFileName}`);
            const snapshot = await uploadBytes(storageRef, file);
            const downloadURL = await getDownloadURL(snapshot.ref);
            
            setCurrentPart(prev => ({ ...prev, fileUrl: downloadURL, fileName: file.name }));
            setIsUploadingFile(false);
        } catch (error) {
            console.error("Upload error:", error);
            alert("เกิดข้อผิดพลาดในการอัปโหลดไฟล์ไปยัง Storage");
            if(fileInputRef.current) fileInputRef.current.value = "";
            setIsUploadingFile(false);
        }
    };

    const handleAddToList = (e) => {
        e.preventDefault();
        if (!currentPart.partName) return;
        setPartList([...partList, { ...currentPart }]);
        setCurrentPart({ partName: '', qty: 1, link: '', note: '', fileUrl: '', fileName: '' });
        if (fileInputRef.current) fileInputRef.current.value = "";
    };

    const handleRemoveFromList = (index) => setPartList(partList.filter((_, i) => i !== index));

    const handleCsvUpload = (e) => {
        const file = e.target.files[0];
        if (!file) return;
        const reader = new FileReader();
        reader.onload = (event) => {
            const text = event.target.result;
            const rows = text.split('\n');
            const newItems = [];
            for (let i = 1; i < rows.length; i++) {
                const cols = rows[i].split(',');
                if (cols.length >= 2 && cols[0].trim() !== '') {
                    newItems.push({
                        partName: cols[0].trim(), qty: parseInt(cols[1].trim()) || 1,
                        link: cols[2] ? cols[2].trim() : '', note: cols[3] ? cols[3].trim() : '',
                        fileUrl: '', fileName: ''
                    });
                }
            }
            setPartList([...partList, ...newItems]);
            alert(`เพิ่ม ${newItems.length} รายการจาก CSV สำเร็จ!`);
        };
        reader.readAsText(file);
        e.target.value = null; 
    };

    const downloadTemplate = () => {
        const csvContent = "data:text/csv;charset=utf-8,\uFEFF" + "Part Name,Qty,Link,Note\nMotor 1HP,2,https://example.com,ด่วนมาก\nSensor Omron,5,,";
        const encodedUri = encodeURI(csvContent);
        const link = document.createElement("a");
        link.setAttribute("href", encodedUri);
        link.setAttribute("download", "PartOrder_Template.csv");
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    };

    // 🌟 บันทึก Order และสร้าง Log ประวัติ 🌟
    const handleSubmitOrder = async () => {
        if (!orderInfo.projectId) return alert('กรุณาเลือกโปรเจกต์!');
        if (partList.length === 0) return alert('ไม่มีรายการอะไหล่ในตะกร้า!');

        setIsSubmitting(true);
        try {
            const batch = writeBatch(db);
            const batchOrderNo = `PO-${Math.random().toString(36).substring(2, 8).toUpperCase()}`;

            partList.forEach(item => {
                const docRef = doc(collection(db, 'part_orders'));
                batch.set(docRef, {
                    orderNo: batchOrderNo, 
                    projectNo: orderInfo.projectNo, 
                    projectId: orderInfo.projectId,
                    urgency: orderInfo.urgency,
                    partName: item.partName, qty: Number(item.qty),
                    link: item.link || '', note: item.note || '',
                    fileUrl: item.fileUrl || '', fileName: item.fileName || '',
                    status: 'Pending (wait PR)', requestBy: userData?.name || userData?.email || 'Unknown',
                    createdAt: serverTimestamp(), eta: null, prNo: '', pricePerUnit: 0, vendorCode: '', vendorName: '',
                    timeline: [{ status: 'Pending (wait PR)', by: userData?.name || 'Unknown', comment: 'เปิดรายการสั่งซื้ออะไหล่ใหม่', timestamp: new Date().toISOString() }]
                });
            });
            await batch.commit();
            await logActivity(user, 'Ordered Part', `สั่งอะไหล่ ${partList.length} รายการ (Project: ${orderInfo.projectNo})`);

            alert(`สั่งอะไหล่สำเร็จ ${partList.length} รายการ!`);
            setOrderInfo({ projectNo: '', projectId: '', urgency: 'Normal' }); setPartList([]); setShowForm(false);
        } catch (error) { alert('เกิดข้อผิดพลาดในการสั่งอะไหล่'); } finally { setIsSubmitting(false); }
    };

    // --- 5. จัดการ Modal อัปเดตสถานะ & Vendor ---
    const openStatusModal = (order) => {
        setStatusModal({
            isOpen: true, orderId: order.id, status: order.status, prNo: order.prNo || '', 
            pricePerUnit: order.pricePerUnit || '', vendorCode: order.vendorCode || '', vendorName: order.vendorName || '',
            comment: '', timeline: order.timeline || []
        });
    };

    const handleVendorCodeChange = (e) => {
        const code = e.target.value.toUpperCase();
        setStatusModal({ ...statusModal, vendorCode: code });
        const foundVendor = vendors.find(v => v.code === code);
        if (foundVendor) setStatusModal(prev => ({ ...prev, vendorName: foundVendor.name }));
    };

    // 🌟 อัปเดตสถานะและเก็บ Log 🌟
    const handleSaveStatus = async (e) => {
        e.preventDefault();
        try {
            const newTimelineEvent = { 
                status: statusModal.status, 
                by: userData?.name, 
                comment: statusModal.comment || 'อัปเดตสถานะ', 
                timestamp: new Date().toISOString() 
            };

            await updateDoc(doc(db, 'part_orders', statusModal.orderId), {
                status: statusModal.status, prNo: statusModal.prNo, pricePerUnit: Number(statusModal.pricePerUnit),
                vendorCode: statusModal.vendorCode.toUpperCase(), vendorName: statusModal.vendorName, updated_at: serverTimestamp(),
                timeline: arrayUnion(newTimelineEvent)
            });

            if (statusModal.vendorCode && statusModal.vendorName) {
                await setDoc(doc(db, 'vendors', statusModal.vendorCode.toUpperCase()), {
                    code: statusModal.vendorCode.toUpperCase(), name: statusModal.vendorName
                }, { merge: true });
            }
            
            await logActivity(user, 'Updated Part Status', `อัปเดตสถานะอะไหล่เป็น ${statusModal.status} (PR: ${statusModal.prNo || '-'})`);
            setStatusModal({ ...statusModal, isOpen: false });
        } catch (error) { console.error(error); alert('อัปเดตสถานะไม่สำเร็จ'); }
    };

    const handleEtaChange = async (id, eta) => {
        if (eta) await updateDoc(doc(db, 'part_orders', id), { eta: new Date(eta), updated_at: serverTimestamp() });
    };

    // 🌟 กรองโปรเจกต์สำหรับ Dropdown เบิกอะไหล่ 🌟
    const myAvailableProjects = activeProjects.filter(p => {
        if (isAdmin) return true; 
        
        const userName = userData?.name || '';
        const userEmail = userData?.email || '';

        const isPIC = p.PIC === userName || p.PIC === userEmail;
        const isRequester = p.requester === userName || p.requester === userEmail;
        
        let isCoWorker = false;
        if (Array.isArray(p.coWorkers)) {
            isCoWorker = p.coWorkers.some(cw => 
                cw === userName || cw === userEmail || cw?.name === userName || cw?.email === userEmail
            );
        } else if (typeof p.coWorkers === 'string') {
            isCoWorker = p.coWorkers.includes(userName);
        }

        return isPIC || isRequester || isCoWorker;
    });

    // 🌟 ดึงข้อมูลชื่ออะไหล่แบบไม่ซ้ำกันจากออเดอร์ทั้งหมด เพื่อทำ Autocomplete 🌟
    const uniquePartNames = Array.from(new Set(orders.map(order => order.partName).filter(Boolean)));

    return (
        <div className="h-full flex flex-col pb-4 md:pb-6 relative">
            {/* --- Header & Actions --- */}
            <div className="flex flex-col xl:flex-row justify-between items-start xl:items-center mb-3 border-b border-glass pb-3 gap-3">
                <h1 className="text-lg md:text-2xl font-bold text-primary shrink-0"><i className="fas fa-tools mr-2"></i> Part Orders Tracker</h1>
                <div className="flex flex-wrap gap-2 w-full xl:w-auto">
                    
                    <button onClick={() => setShowChecklistModal(true)} className="flex-1 xl:flex-none bg-indigo-600 hover:bg-indigo-500 text-text px-4 py-2 rounded-lg font-bold shadow transition text-center text-sm">
                        <i className="fas fa-tasks mr-2"></i> Checklist รับของ
                    </button>

                    <button onClick={handlePrintPdf} className="flex-1 xl:flex-none bg-red-600 hover:bg-red-500 text-text px-4 py-2 rounded-lg font-bold shadow transition text-center text-sm">
                        <i className="fas fa-file-pdf mr-2"></i> Export PDF
                    </button>
                    
                    <CSVLink data={csvData} filename={`PartOrders_${new Date().toLocaleDateString('th-TH')}.csv`} className="flex-1 xl:flex-none bg-green-600 hover:bg-green-500 text-text px-4 py-2 rounded-lg font-bold shadow transition text-center text-sm">
                        <i className="fas fa-file-csv mr-2"></i> Export CSV
                    </CSVLink>
                    
                    <button onClick={() => setShowForm(!showForm)} className="flex-1 w-full md:w-auto xl:flex-none bg-blue-600 hover:bg-blue-500 text-text px-4 py-2 rounded-lg font-bold shadow transition text-sm">
                        {showForm ? 'ปิดฟอร์ม' : '+ แจ้งสั่งอะไหล่'}
                    </button>
                </div>
            </div>

            {/* --- Search & Filter Bar --- */}
            <div className="flex flex-col md:flex-row gap-2 md:gap-4 mb-3 md:mb-4">
                <div className="relative flex-1">
                    <i className="fas fa-search absolute left-3 top-3 text-text"></i>
                    <input type="text" placeholder="ค้นหา Part No, Project, PR No, Vendor..." value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} className="w-full pl-10 p-2 bg-surface border border-glass rounded-lg text-text focus:outline-none focus:border-blue-500" />
                </div>
                <select value={filterStatus} onChange={(e) => setFilterStatus(e.target.value)} className="p-2 bg-surface border border-glass rounded-lg text-text focus:outline-none focus:border-blue-500" style={{ backgroundColor: 'var(--color-bg)', color: 'var(--color-text)' }}>
                    <option value="All">All Status (สถานะทั้งหมด)</option>
                    {statusOptions.map(opt => <option key={opt} value={opt}>{opt}</option>)}
                </select>
            </div>

            {/* --- ฟอร์มเพิ่ม Order --- */}
            {showForm && (
                <div className="bg-surface p-3 md:p-6 rounded-xl border border-glass mb-4 md:mb-6 shadow-xl animate-fade-in-down">
                    <h2 className="text-xl font-bold text-text mb-4 border-b border-glass pb-2">แบบฟอร์มเบิกอะไหล่ (สั่งได้หลายรายการ)</h2>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mb-4 md:mb-6 bg-surface/50 p-3 md:p-4 rounded-lg border border-glass">
                        <div>
                            <label className="text-xs text-orange-400 font-bold">ผูกกับโปรเจกต์ (Project) *</label>
                            <select 
                                value={orderInfo.projectId} 
                                onChange={(e) => {
                                    const selectedProj = myAvailableProjects.find(p => p.id === e.target.value);
                                    setOrderInfo({
                                        ...orderInfo, 
                                        projectId: selectedProj?.id || '',
                                        projectNo: selectedProj ? (selectedProj.projectNoRef !== '-' ? selectedProj.projectNoRef : selectedProj.projectName) : ''
                                    });
                                }} 
                                className="w-full p-2 bg-surface rounded border border-orange-500/50 text-text focus:outline-none"
                                style={{ backgroundColor: 'var(--color-bg)', color: 'var(--color-text)' }}
                            >
                                <option value="">-- เลือกโปรเจกต์ของฉัน --</option>
                                {myAvailableProjects.map(p => (
                                    <option key={p.id} value={p.id}>
                                        {p.projectName} {p.projectNoRef !== '-' ? `(Ref: ${p.projectNoRef})` : ''} 
                                        {p.PIC ? ` [PIC: ${p.PIC}]` : ''}
                                    </option>
                                ))}
                            </select>
                        </div>
                        <div>
                            <label className="text-xs text-text">ความเร่งด่วน</label>
                            <select value={orderInfo.urgency} onChange={(e) => setOrderInfo({...orderInfo, urgency: e.target.value})} className="w-full p-2 bg-surface rounded border border-glass text-text focus:outline-none" style={{ backgroundColor: 'var(--color-bg)', color: 'var(--color-text)' }}>
                                <option value="Normal">ปกติ (Normal)</option><option value="Urgent">ด่วน (Urgent)</option><option value="Machine Down">เครื่องหยุด (Machine Down)</option>
                            </select>
                        </div>
                    </div>

                    <div className="flex flex-col xl:flex-row gap-6 mb-6">
                        <form onSubmit={handleAddToList} className="flex-1 bg-surface/50 p-4 rounded-lg border border-glass grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3 relative">
                            <h3 className="text-sm font-bold text-primary md:col-span-2 lg:col-span-4"><i className="fas fa-plus-circle"></i> เพิ่มทีละรายการ</h3>
                            
                            {/* แถวที่ 1 */}
                            <div className="lg:col-span-2">
                                {/* 🌟 เปลี่ยน Input ส่วนชื่ออะไหล่ให้มี list="part-names-datalist" 🌟 */}
                                <input 
                                    type="text" 
                                    list="part-names-datalist"
                                    placeholder="ชื่ออะไหล่ *" 
                                    value={currentPart.partName} 
                                    onChange={e => setCurrentPart({...currentPart, partName: e.target.value})} 
                                    className="w-full p-2 bg-surface rounded border border-glass text-text text-sm" 
                                    required
                                />
                                {/* 🌟 Datalist สำหรับคำใบ้ชื่ออะไหล่ 🌟 */}
                                <datalist id="part-names-datalist">
                                    {uniquePartNames.map((name, index) => (
                                        <option key={index} value={name} />
                                    ))}
                                </datalist>
                            </div>
                            <div>
                                <input type="number" placeholder="จำนวน *" min="1" value={currentPart.qty} onChange={e => setCurrentPart({...currentPart, qty: e.target.value})} className="w-full p-2 bg-surface rounded border border-glass text-text text-sm" required/>
                            </div>
                            <div className="relative flex items-center bg-surface rounded border border-glass overflow-hidden">
                                <input type="file" ref={fileInputRef} onChange={handleFileUploadToStorage} disabled={isUploadingFile} className="w-full text-[10px] text-text file:mr-2 file:py-1.5 file:px-2 file:border-1 file:bg-surface file:text-text hover:file:bg-surface cursor-pointer p-1" title="แนบไฟล์อ้างอิง (เช่น ใบเสนอราคา, รูปภาพ)"/>
                                {isUploadingFile && <div className="absolute right-2 bg-surface pl-2"><i className="fas fa-spinner fa-spin text-primary"></i></div>}
                            </div>

                            {/* แถวที่ 2 */}
                            <div className="lg:col-span-2">
                                <input type="text" placeholder="Link อ้างอิงเว็บสั่งซื้อ (ถ้ามี)" value={currentPart.link} onChange={e => setCurrentPart({...currentPart, link: e.target.value})} className="w-full p-2 bg-surface rounded border border-glass text-text text-sm"/>
                            </div>
                            <div>
                                <input type="text" placeholder="หมายเหตุ" value={currentPart.note} onChange={e => setCurrentPart({...currentPart, note: e.target.value})} className="w-full p-2 bg-surface rounded border border-glass text-text text-sm"/>
                            </div>
                            <div>
                                <button type="submit" disabled={isUploadingFile} className="w-full bg-blue-600 hover:bg-blue-500 disabled:bg-surface disabled:text-text text-text p-2 rounded text-sm font-bold shadow transition">เพิ่มลงตาราง ↓</button>
                            </div>

                            {/* แจ้งเตือนการแนบไฟล์สำเร็จ */}
                            {currentPart.fileName && (
                                <div className="text-xs text-green-400 lg:col-span-4 font-bold mt-1">
                                    <i className="fas fa-check-circle mr-1"></i> ไฟล์แนบพร้อมส่ง: {currentPart.fileName}
                                </div>
                            )}
                        </form>

                        <div className="xl:w-1/3 bg-surface/50 p-4 rounded-lg border border-glass flex flex-col justify-center">
                            <h3 className="text-sm font-bold text-green-400 mb-3"><i className="fas fa-file-upload"></i> อัปโหลดไฟล์ CSV (หลายรายการ)</h3>
                            <button onClick={downloadTemplate} className="text-xs text-primary underline mb-3 text-left hover:text-primary">ดาวน์โหลดไฟล์ Template (.csv)</button>
                            <input type="file" accept=".csv" onChange={handleCsvUpload} className="text-sm text-text file:mr-3 file:py-1 file:px-3 file:rounded file:border-0 file:text-xs file:font-semibold file:bg-green-600 file:text-text hover:file:bg-green-500 cursor-pointer"/>
                        </div>
                    </div>

                    {partList.length > 0 && (
                        <div className="bg-surface rounded-lg overflow-hidden mb-4">
                            <table className="w-full text-left text-sm text-text">
                                <thead className="bg-surface">
                                    <tr>
                                        <th className="p-2">ชื่ออะไหล่</th><th className="p-2">Qty</th>
                                        <th className="p-2">Link/Note</th><th className="p-2">ไฟล์แนบ</th><th className="p-2 text-center">ลบ</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {partList.map((item, i) => (
                                        <tr key={i} className="border-b border-glass">
                                            <td className="p-2">{item.partName}</td>
                                            <td className="p-2">{item.qty}</td>
                                            <td className="p-2 text-xs truncate max-w-[150px]">{item.note || item.link}</td>
                                            <td className="p-2 text-xs text-green-400">
                                                {item.fileName ? <><i className="fas fa-paperclip"></i> {item.fileName}</> : '-'}
                                            </td>
                                            <td className="p-2 text-center text-red-500 cursor-pointer hover:text-red-400" onClick={() => handleRemoveFromList(i)}><i className="fas fa-trash"></i></td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                            <button onClick={handleSubmitOrder} disabled={isSubmitting} className="w-full p-4 mt-2 bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-500 hover:to-purple-500 text-text font-bold text-lg rounded-xl shadow-xl transition-all">{isSubmitting ? 'กำลังบันทึก...' : `ยืนยันสั่งซื้อ (${partList.length} รายการ)`}</button>
                        </div>
                    )}
                </div>
            )}

            {/* --- ตารางหลัก --- */}
            <div className="flex-1 bg-surface rounded-xl shadow-md overflow-hidden border border-glass flex flex-col">
                {loading ? (
                    <div className="flex-1 flex justify-center items-center"><div className="animate-spin rounded-full h-10 w-10 border-t-2 border-blue-500"></div></div>
                ) : (
                    <>
                        <div className="overflow-x-auto">
                            <table className="w-full text-left text-sm text-text whitespace-nowrap">
                                <thead className="bg-surface text-text border-b border-glass">
                                    <tr>
                                        <th className="p-3 font-semibold">Part Info</th><th className="p-3 font-semibold">Project Ref.</th>
                                        <th className="p-3 font-semibold">PR No.</th><th className="p-3 font-semibold">Total Price</th>
                                        <th className="p-3 font-semibold">ETA (ของเข้า)</th>
                                        <th className="p-3 font-semibold">Status / Actions</th>
                                    </tr>
                                </thead>
                                <tbody className="divide-y divide-gray-700">
                                    {currentOrders.length === 0 ? <tr><td colSpan="6" className="p-8 text-center text-text">ไม่พบรายการข้อมูล</td></tr> : null}
                                    {currentOrders.map((order) => {
                                        const isMyOrder = order.requestBy === userData?.name;
                                        const isPending = order.status.includes('Pending');
                                        
                                        return (
                                            <tr key={order.id} className="hover:bg-surface transition-colors">
                                                <td className="p-3">
                                                    <div className="font-bold text-text">{order.partName} <span className="text-xs bg-surface px-2 py-0.5 rounded text-text ml-1">x{order.qty}</span></div>
                                                    <div className="text-[10px] text-text mt-1">
                                                        Req: <span className="text-text">{order.requestBy}</span> 
                                                        {order.machineNo && ` | M/C: ${order.machineNo}`}
                                                    </div>
                                                    
                                                    <div className="flex items-center gap-3 mt-1">
                                                        {order.link && <a href={order.link} target="_blank" rel="noreferrer" className="text-[10px] text-purple-500 hover:underline"><i className="fas fa-external-link-alt"></i> View Link</a>}
                                                        {order.fileUrl && <a href={order.fileUrl} target="_blank" rel="noreferrer" className="text-[10px] text-green-400 hover:underline"><i className="fas fa-paperclip"></i> {order.fileName || 'เปิดไฟล์แนบ'}</a>}
                                                    </div>
                                                    
                                                    {order.note && <div className="text-[10px] text-text mt-0.5 italic">Note: {order.note}</div>}
                                                </td>
                                                <td className="p-3"><span className="text-xs font-bold text-orange-400">{order.projectNo}</span></td>
                                                <td className="p-3">
                                                    <div className="font-bold text-primary">{order.prNo || '-'}</div>
                                                    {order.vendorCode && <div className="text-[10px] text-text mt-0.5">{order.vendorCode}</div>}
                                                </td>
                                                <td className="p-3 text-green-400 font-bold">
                                                    {order.pricePerUnit ? `฿ ${(order.qty * order.pricePerUnit).toLocaleString()}` : '-'}
                                                </td>
                                                <td className="p-3"><input type="date" defaultValue={order.eta ? order.eta.toDate().toISOString().split('T')[0] : ''} onBlur={(e) => handleEtaChange(order.id, e.target.value)} className="bg-surface p-1.5 rounded border border-glass text-text focus:outline-none focus:border-blue-500 text-xs w-32"/></td>
                                                <td className="p-3">
                                                    <div className="flex flex-col gap-1.5">
                                                        {canUpdateStatus && order.status !== 'Received' && order.status !== 'Cancelled' ? (
                                                            <button onClick={() => openStatusModal(order)} className={`px-3 py-1.5 rounded-lg text-xs font-bold shadow-sm border flex items-center justify-between hover:opacity-80 transition ${
                                                                order.status.includes('Pending') ? 'bg-surface text-text border-glass' :
                                                                order.status.includes('Ordered') ? 'bg-blue-600 text-text border-blue-500' :
                                                                order.status === 'Received' ? 'bg-green-600 text-text border-green-500' :
                                                                order.status === 'Cancelled' ? 'bg-red-600 text-text border-red-500' :
                                                                'bg-yellow-600 text-text border-yellow-500'
                                                            }`}>
                                                                <span>{order.status}</span> <i className="fas fa-edit ml-2"></i>
                                                            </button>
                                                        ) : (
                                                            <span className={`px-3 py-1.5 rounded-lg text-[10px] font-bold shadow-sm border inline-block text-center ${
                                                                order.status.includes('Pending') ? 'bg-surface text-text border-glass' :
                                                                order.status.includes('Ordered') ? 'bg-blue-600 text-text border-blue-500' :
                                                                order.status === 'Received' ? 'bg-green-600 text-text border-green-500' :
                                                                order.status === 'Cancelled' ? 'bg-red-600 text-text border-red-500' :
                                                                'bg-yellow-600 text-text border-yellow-500'
                                                            }`}>
                                                                {order.status}
                                                            </span>
                                                        )}
                                                        
                                                        {(isTDMgrOrSup || isAdmin || (isMyOrder && isPending)) && order.status !== 'Received' && (
                                                            <button onClick={() => handleDeleteOrder(order.id, order.partName)} className="mt-1 text-text hover:text-red-400 hover:bg-surface text-[10px] py-1 px-2 rounded border border-glass transition flex items-center justify-center w-full" title="ลบรายการนี้">
                                                                <i className="fas fa-trash-alt mr-1"></i> ลบออเดอร์
                                                            </button>
                                                        )}
                                                    </div>
                                                </td>
                                            </tr>
                                        );
                                    })}
                                </tbody>
                            </table>
                        </div>
                        
                        <div className="bg-surface p-3 border-t border-glass flex justify-between items-center text-xs text-text">
                            <span>แสดง {filteredOrders.length > 0 ? (currentPage - 1) * itemsPerPage + 1 : 0} - {Math.min(currentPage * itemsPerPage, filteredOrders.length)} จากทั้งหมด {filteredOrders.length} รายการ</span>
                            <div className="flex gap-2">
                                <button onClick={() => setCurrentPage(p => Math.max(1, p - 1))} disabled={currentPage === 1} className="px-3 py-1 bg-surface rounded border border-glass hover:bg-surface disabled:opacity-50">ก่อนหน้า</button>
                                <button onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))} disabled={currentPage === totalPages || totalPages === 0} className="px-3 py-1 bg-surface rounded border border-glass hover:bg-surface disabled:opacity-50">ถัดไป</button>
                            </div>
                        </div>
                    </>
                )}
            </div>

            {/* --- Modal Update Status (เพิ่มส่วนแสดงประวัติ Log) --- */}
            {statusModal.isOpen && (
                <div className="fixed inset-0 bg-black/10 flex justify-center items-center z-[70] p-4 backdrop-blur-sm">
                    <form onSubmit={handleSaveStatus} className="bg-surface w-full max-w-lg p-6 rounded-xl border border-glass shadow-2xl relative max-h-[90vh] overflow-y-auto custom-scrollbar flex flex-col">
                        <button type="button" onClick={() => setStatusModal({...statusModal, isOpen: false})} className="absolute top-4 right-4 text-text hover:text-text text-2xl font-bold">&times;</button>
                        <h2 className="text-xl font-bold text-text mb-4 border-b border-glass pb-2">อัปเดตสถานะ (Update Status)</h2>
                        
                        <div className="space-y-4">
                            <div>
                                <label className="text-xs text-primary font-bold mb-1 block">เปลี่ยนสถานะ</label>
                                <select value={statusModal.status} onChange={(e) => setStatusModal({...statusModal, status: e.target.value})} className="w-full p-2.5 bg-surface rounded border border-glass text-text font-bold">
                                    {statusOptions.map(opt => <option key={opt} value={opt} style={{ backgroundColor: 'var(--color-bg)', color: 'var(--color-text)' }}>{opt}</option>)}
                                </select>
                            </div>
                            
                            <div className="grid grid-cols-2 gap-4">
                                <div>
                                    <label className="text-xs text-text mb-1 block">PR No. (10 หลัก)</label>
                                    <input type="text" maxLength="10" value={statusModal.prNo} onChange={(e) => setStatusModal({...statusModal, prNo: e.target.value})} className="w-full p-2 bg-surface rounded border border-glass text-text" placeholder="เช่น 1000123456" required={statusModal.status !== 'Pending (wait PR)' && statusModal.status !== 'Cancelled'} />
                                </div>
                                <div>
                                    <label className="text-xs text-text mb-1 block">Price / Unit (บาท)</label>
                                    <input type="number" step="0.01" value={statusModal.pricePerUnit} onChange={(e) => setStatusModal({...statusModal, pricePerUnit: e.target.value})} className="w-full p-2 bg-surface rounded border border-glass text-text" placeholder="0.00" required={statusModal.status !== 'Pending (wait PR)' && statusModal.status !== 'Cancelled'} />
                                </div>
                            </div>

                            <div className="bg-surface/50 p-3 rounded-lg border border-glass">
                                <label className="text-xs text-green-600 font-bold mb-2 block"><i className="fas fa-store"></i> ข้อมูลผู้ขาย (Vendor)</label>
                                <div className="space-y-3">
                                    <div>
                                        <label className="text-xs text-text block mb-1">Vendor Code</label>
                                        <input type="text" list="vendor-list" value={statusModal.vendorCode} onChange={handleVendorCodeChange} className="w-full p-2 bg-surface rounded border border-glass text-text" placeholder="พิมพ์รหัส Vendor..." required={statusModal.status !== 'Pending (wait PR)' && statusModal.status !== 'Cancelled'} />
                                        <datalist id="vendor-list">
                                            {vendors.map(v => <option key={v.code} value={v.code} style={{ backgroundColor: 'var(--color-bg)', color: 'var(--color-text)' }}>{v.name}</option>)}
                                        </datalist>
                                    </div>
                                    <div>
                                        <label className="text-xs text-text block mb-1">Vendor Name</label>
                                        <input type="text" value={statusModal.vendorName} onChange={(e) => setStatusModal({...statusModal, vendorName: e.target.value})} className="w-full p-2 bg-surface rounded border border-glass text-text" placeholder="ชื่อบริษัท..." required={statusModal.status !== 'Pending (wait PR)' && statusModal.status !== 'Cancelled'} />
                                    </div>
                                </div>
                            </div>

                            <div>
                                <label className="text-xs text-text mb-1 block">คอมเมนต์ / หมายเหตุสำหรับการอัปเดต (จะถูกบันทึกใน Log)</label>
                                <input type="text" value={statusModal.comment} onChange={(e) => setStatusModal({...statusModal, comment: e.target.value})} className="w-full p-2 bg-surface rounded border border-glass text-text focus:border-blue-500 outline-none" placeholder="ระบุรายละเอียดเพิ่มเติม..." />
                            </div>
                        </div>

                        <button type="submit" className="w-full mt-6 bg-blue-600 hover:bg-blue-500 text-text font-bold py-3 rounded-lg shadow-lg mb-2">
                            บันทึกการเปลี่ยนแปลง
                        </button>

                        {statusModal.timeline && statusModal.timeline.length > 0 && (
                            <div className="mt-4 bg-surface/50 p-4 rounded-xl border border-glass shadow-sm shrink-0">
                                <p className="text-xs font-bold text-yellow-400 mb-4 border-b border-glass pb-2"><i className="fas fa-history mr-2"></i> ประวัติการดำเนินการ & คอมเมนต์</p>
                                <div className="space-y-4 max-h-48 overflow-y-auto custom-scrollbar pr-2">
                                    {[...statusModal.timeline].reverse().map((event, idx) => (
                                        <div key={idx} className="flex flex-col text-xs border-l-2 border-glass pl-3 ml-1">
                                            <div className="flex justify-between items-start">
                                                <span className="font-bold text-text">
                                                    {event.by} 
                                                    <span className={`text-[9px] px-1.5 py-0.5 rounded ml-2 font-bold ${
                                                        event.status.includes('Cancelled') ? 'bg-red-500/20 text-red-400 border border-red-500/30' :
                                                        event.status === 'Received' ? 'bg-green-500/20 text-green-400 border border-green-500/30' :
                                                        event.status.includes('Ordered') ? 'bg-blue-500/20 text-primary border border-blue-500/30' :
                                                        'bg-yellow-500/20 text-yellow-400 border border-yellow-500/30'
                                                    }`}>{event.status}</span>
                                                </span>
                                                <span className="text-[9px] text-text bg-surface px-1.5 py-0.5 rounded">{new Date(event.timestamp).toLocaleString('th-TH', { dateStyle: 'short', timeStyle: 'short' })}</span>
                                            </div>
                                            {event.comment && (
                                                <div className="mt-2 bg-surface/80 p-2.5 rounded-lg border border-glass text-text italic shadow-inner">
                                                    <i className="fas fa-quote-left text-text mr-2"></i>{event.comment}
                                                </div>
                                            )}
                                        </div>
                                    ))}
                                </div>
                            </div>
                        )}
                    </form>
                </div>
            )}

            {/* --- 🌟 MODAL: หน้าต่าง In-System Checklist รับของ 🌟 --- */}
            {showChecklistModal && (
                <div className="fixed inset-0 bg-black/10 flex justify-center items-center z-50 p-4 backdrop-blur-sm">
                    <div className="bg-surface w-full max-w-5xl p-6 rounded-xl border border-glass shadow-2xl relative my-4 md:my-8">
                        <button onClick={() => setShowChecklistModal(false)} className="absolute top-4 right-4 text-text hover:text-text text-3xl font-bold">&times;</button>
                        <h2 className="text-2xl font-bold text-text mb-6 border-b border-glass pb-3">
                            <i className="fas fa-clipboard-check text-indigo-400 mr-2"></i> ระบบตรวจรับอะไหล่ (In-System Checklist)
                        </h2>
                        
                        {Object.keys(groupedChecklist).length === 0 ? (
                            <div className="text-text text-center py-12 flex flex-col items-center">
                                <i className="fas fa-box-open text-4xl mb-3 opacity-50"></i>
                                <p>ไม่พบรายการที่ต้องตรวจรับ</p>
                                <p className="text-xs mt-1">กรุณาใช้ช่องค้นหา (Search) เพื่อเลือกโปรเจกต์ที่ต้องการ</p>
                                <p className="text-[10px] text-orange-400 mt-2">*แสดงเฉพาะรายการที่มีสถานะ Sending หรือ Shipped เท่านั้น</p>
                            </div>
                        ) : (
                            Object.keys(groupedChecklist).map(projNo => (
                                <div key={projNo} className="mb-6 bg-surface rounded-xl p-4 md:p-6 border border-glass shadow-inner">
                                    <div className="flex justify-between items-center mb-4 border-b border-glass pb-2">
                                        <h3 className="text-lg font-bold text-orange-400"><i className="fas fa-project-diagram mr-2"></i> Project: {projNo}</h3>
                                        <span className="text-xs text-text font-bold bg-surface px-3 py-1 rounded-full">รอรับ {groupedChecklist[projNo].length} รายการ</span>
                                    </div>
                                    <div className="overflow-x-auto">
                                        <table className="w-full text-left text-sm text-text whitespace-nowrap">
                                            <thead className="bg-surface text-text">
                                                <tr>
                                                    <th className="p-3 font-semibold rounded-tl-lg">Part Info</th>
                                                    <th className="p-3 font-semibold text-center">Qty</th>
                                                    <th className="p-3 font-semibold text-center">Current Status</th>
                                                    <th className="p-3 font-semibold text-center rounded-tr-lg">Action (ตรวจรับ)</th>
                                                </tr>
                                            </thead>
                                            <tbody className="divide-y divide-gray-800">
                                                {groupedChecklist[projNo].map(item => {
                                                    const canReceiveItem = canUpdateStatus || item.requestBy === userData?.name || item.requestBy === userData?.email;
                                                    
                                                    return (
                                                    <tr key={item.id} className="hover:bg-surface/80 transition-colors">
                                                        <td className="p-3">
                                                            <div className="font-bold text-text text-base">{item.partName}</div>
                                                            <div className="text-[10px] text-text mt-1">PR: {item.prNo || '-'}</div>
                                                            {item.note && <div className="text-[10px] text-orange-400 mt-0.5 italic">Note: {item.note}</div>}
                                                        </td>
                                                        <td className="p-3 text-center font-bold text-primary text-lg">{item.qty}</td>
                                                        <td className="p-3 text-center">
                                                            <span className={`px-2 py-1 rounded text-[10px] font-bold uppercase tracking-wider ${
                                                                item.status === 'Received' ? 'bg-green-500/20 text-green-400' :
                                                                item.status.includes('Ordered') ? 'bg-blue-500/20 text-primary' : 'bg-surface text-text'
                                                            }`}>
                                                                {item.status}
                                                            </span>
                                                        </td>
                                                        <td className="p-3 text-center flex flex-col items-center justify-center">
                                                            {item.status === 'Received' ? (
                                                                <div className="inline-flex items-center justify-center gap-1 bg-green-500/10 text-green-500 border border-green-500/30 px-3 py-1.5 rounded-lg text-xs font-bold mb-2 w-full">
                                                                    <i className="fas fa-check-circle"></i> รับของแล้ว
                                                                </div>
                                                            ) : (
                                                                <button 
                                                                    onClick={() => handleMarkAsReceived(item.id)}
                                                                    disabled={!canReceiveItem}
                                                                    className={`px-4 py-2 rounded-lg shadow-md text-xs font-bold transition transform mb-2 w-full flex items-center justify-center gap-2 ${
                                                                        canReceiveItem ? 'bg-indigo-600 hover:bg-indigo-500 text-text hover:scale-105 active:scale-95' : 'bg-surface text-text cursor-not-allowed'
                                                                    }`}
                                                                >
                                                                    <i className="fas fa-clipboard-check"></i> ติ๊กรับของ
                                                                </button>
                                                            )}
                                                            
                                                            {canUpdateStatus && (
                                                                <button onClick={() => openStatusModal(item)} className="text-[10px] text-primary hover:bg-surface w-full py-1.5 rounded border border-glass transition flex items-center justify-center gap-1">
                                                                    <i className="fas fa-history"></i> ดูประวัติ/อัปเดต
                                                                </button>
                                                            )}
                                                        </td>
                                                    </tr>
                                                )})}
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            ))
                        )}
                        <div className="mt-6 flex justify-center">
                             <button onClick={() => setShowChecklistModal(false)} className="bg-surface hover:bg-surface px-8 py-2 rounded-lg text-text font-bold transition">
                                ปิดหน้าต่าง
                             </button>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};

export default PartOrderTrackerPage;