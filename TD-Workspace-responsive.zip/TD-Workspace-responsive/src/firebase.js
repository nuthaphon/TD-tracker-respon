
// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";
import { getFirestore } from "firebase/firestore";
import { getStorage } from "firebase/storage";

// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyD7uq6iw8pKn7xX9NkvTxeti2R9OjFRMxE",
  authDomain: "td-tracker-a7c5a.firebaseapp.com",
  projectId: "td-tracker-a7c5a",
  storageBucket: "td-tracker-a7c5a.firebasestorage.app",
  messagingSenderId: "718113767327",
  appId: "1:718113767327:web:b8156ead7b7b4a6c4387aa",
  measurementId: "G-E3T4RC1XRJ"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app);
export const storage = getStorage(app);