import { useState, useEffect, createContext, useContext } from 'react';
import { 
  onAuthStateChanged, 
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword, 
  signInWithRedirect, 
  GoogleAuthProvider, 
  signOut,
  sendEmailVerification 
} from 'firebase/auth';
// 🌟 นำเข้า onSnapshot มาใช้งาน
import { doc, getDoc, setDoc, onSnapshot } from 'firebase/firestore'; 
import { auth, db } from '../firebase';

const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [userData, setUserData] = useState(null);

  useEffect(() => {
    let unsubscribeSnapshot = null; // 🌟 สร้างตัวแปรเก็บฟังก์ชันดักจับ Real-time

    const unsubscribeAuth = onAuthStateChanged(auth, async (currentUser) => {
      setUser(currentUser);
      
      if (currentUser) {
        try {
          const docRef = doc(db, 'users', currentUser.uid);
          
          // 1. เช็คก่อนว่ามีข้อมูลหรือยัง (สร้างข้อมูลกรณีล็อกอินด้วย Google ครั้งแรก)
          const docSnap = await getDoc(docRef);
          if (!docSnap.exists()) {
            const newUserData = {
              email: currentUser.email,
              name: currentUser.displayName || '',
              role: 'pending', 
              dept: ''
            };
            await setDoc(docRef, newUserData);
          }

          // 🌟 2. ดึงข้อมูลแบบ Real-time (เมื่อมีการกดสุ่มรูป ข้อมูลตรงนี้จะเด้งอัปเดตอัตโนมัติทันที)
          unsubscribeSnapshot = onSnapshot(docRef, (doc) => {
            if (doc.exists()) {
              setUserData(doc.data());
            }
            setLoading(false);
          });

        } catch (error) {
          console.error("Error fetching user data:", error);
          setUserData(null);
          setLoading(false);
        }
      } else {
        setUserData(null);
        setLoading(false);
        if (unsubscribeSnapshot) unsubscribeSnapshot(); // ยกเลิกการดักจับเมื่อล็อกเอาต์
      }
    });

    return () => {
      unsubscribeAuth();
      if (unsubscribeSnapshot) unsubscribeSnapshot();
    };
  }, []);

  const login = (email, password) => {
    return signInWithEmailAndPassword(auth, email, password);
  };

  const register = async (email, password, extraData) => {
    const userCredential = await createUserWithEmailAndPassword(auth, email, password);
    const newUser = userCredential.user;
    
    await sendEmailVerification(newUser);

    await setDoc(doc(db, 'users', newUser.uid), {
      email: newUser.email,
      name: extraData.name,
      phone: extraData.phone,
      dept: extraData.dept,
      jobTitle: extraData.jobTitle,
      avatar: extraData.avatar, 
      role: 'pending' 
    }, { merge: true });

    return newUser;
  };

  const googleSignIn = () => {
    const provider = new GoogleAuthProvider();
    return signInWithRedirect(auth, provider);
  };

  const logout = () => {
    return signOut(auth);
  };

  return (
    <AuthContext.Provider value={{ user, loading, userData, login, register, googleSignIn, logout }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const authContext = useContext(AuthContext);
  if (!authContext) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return authContext;
};