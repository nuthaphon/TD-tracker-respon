import React, { useState } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import LoginPage from './pages/LoginPage';
import RegisterPage from './pages/RegisterPage';
import TDJobRequestPage from './pages/TDJobRequestPage';
import TDWorkspacePage from './pages/TDWorkspacePage';
import ProjectSpacePage from './pages/ProjectSpacePage'; 
import TDMasterTimelinePage from './pages/TDMasterTimelinePage';
import MyPlannerPage from './pages/MyPlannerPage';
import NewsFeedPage from './pages/NewsFeedPage';
import TDSharingAreaPage from './pages/TDSharingAreaPage';
import DashboardPage from './pages/DashboardPage';
import TDDashboardPage from './pages/TDDashboardPage';
import PartOrderTrackerPage from './pages/PartOrderTrackerPage';
import TDReportPage from './pages/TDReportPage';
import UserManagementPage from './pages/UserManagementPage';
import TDTeamPage from './pages/TDTeamPage';
import ProfilePage from './pages/ProfilePage';
import { AuthProvider, useAuth } from './hooks/useAuth';
import Sidebar from './components/layout/Sidebar';

import { sendEmailVerification } from 'firebase/auth';
import { auth } from './firebase';

const AuthenticatedRoutes = () => {
  const { user, userData, loading, logout } = useAuth(); 
  const [verifyMsg, setVerifyMsg] = useState('');

  if (loading) {
    return (
      <div className="h-screen bg-bg flex flex-col items-center justify-center text-text transition-colors duration-300">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary mb-4"></div>
        <p className="animate-pulse font-bold text-primary">กำลังตรวจสอบสิทธิ์เข้าใช้งาน...</p>
      </div>
    );
  }

  if (!user) return <Navigate to="/login" />;

  if (!user.emailVerified) {
    const handleCheckStatus = async () => {
        setVerifyMsg('กำลังตรวจสอบสถานะ...');
        await auth.currentUser.reload(); 
        if (auth.currentUser.emailVerified) {
            window.location.reload(); 
        } else {
            setVerifyMsg('ยังไม่พบการยืนยัน กรุณาตรวจสอบลิงก์ในอีเมลของคุณ (หรือ Junk Mail)');
        }
    };

    const handleResend = async () => {
        try {
            setVerifyMsg('กำลังส่งอีเมล...');
            await sendEmailVerification(auth.currentUser);
            setVerifyMsg('ส่งอีเมลยืนยันตัวตนไปใหม่อีกครั้งแล้ว! กรุณาตรวจสอบกล่องจดหมาย');
        } catch (error) {
            if (error.code === 'auth/too-many-requests') {
                setVerifyMsg('คุณขอส่งอีเมลบ่อยเกินไป กรุณารอสักครู่แล้วลองใหม่');
            } else {
                setVerifyMsg('เกิดข้อผิดพลาด: ' + error.message);
            }
        }
    };

    return (
      <div className="h-screen bg-bg flex flex-col items-center justify-center text-text p-6 transition-colors duration-300">
        <div className="bg-surface glass-panel p-8 rounded-base shadow-glass max-w-md w-full text-center border-glass animate-fade-in-down transition-all duration-300">
          <i className="fas fa-envelope-open-text text-6xl text-primary mb-6 animate-pulse neon-text"></i>
          <h2 className="text-2xl font-bold mb-3 text-text">กรุณายืนยันอีเมลของคุณ</h2>
          <p className="text-text/80 mb-6 text-sm leading-relaxed">
            ระบบได้ส่งลิงก์ยืนยันตัวตนไปที่อีเมล<br/>
            <span className="text-primary font-bold text-base bg-primary/20 px-3 py-1 rounded-full inline-block mt-2">{user.email}</span><br/><br/>
            กรุณาคลิกลิงก์ในอีเมลดังกล่าวเพื่อเปิดใช้งานบัญชี
          </p>
          {verifyMsg && (
            <div className="mb-6 text-sm font-bold text-orange-400 bg-orange-400/10 p-3 rounded-lg border border-orange-500/30">
              {verifyMsg}
            </div>
          )}
          <div className="space-y-3">
            <button onClick={handleCheckStatus} className="w-full bg-primary hover:bg-secondary text-white font-bold py-3.5 rounded-base shadow-glass transition-all duration-300 hover:scale-[1.02]">
              <i className="fas fa-sync-alt mr-2"></i> ฉันยืนยันอีเมลเรียบร้อยแล้ว
            </button>
            <button onClick={handleResend} className="w-full bg-surface glass-panel hover:bg-surface/80 text-text font-bold py-3 rounded-base shadow-glass transition-all duration-300 border-glass">
              <i className="fas fa-paper-plane mr-2"></i> ส่งอีเมลยืนยันอีกครั้ง
            </button>
            <button onClick={logout} className="w-full text-red-400 hover:text-red-300 font-bold py-2 mt-4 transition text-sm underline">
              ออกจากระบบ (สลับบัญชี)
            </button>
          </div>
        </div>
      </div>
    );
  }

  if (!userData) {
    return (
        <div className="h-screen bg-bg flex flex-col items-center justify-center text-text transition-colors duration-300">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-primary mb-4"></div>
          <p className="animate-pulse">กำลังโหลดข้อมูลโปรไฟล์...</p>
        </div>
      );
  }

  return (
    <div className="flex h-screen w-full bg-bg text-text transition-colors duration-300 overflow-hidden print:h-auto print:block print:bg-white print:text-black">
      
      {/* Sidebar — hidden on mobile (uses floating drawer), shown on lg+ */}
      <div className="print:hidden z-50 h-full shrink-0">
        <Sidebar />
      </div>

      {/* Main Content */}
      {/* pt-14 on mobile to clear the floating hamburger button */}
      <div className="flex-1 flex flex-col h-screen overflow-hidden relative transition-all duration-300 print:block print:w-full print:overflow-visible print:h-auto">
        <main className="flex-1 p-3 pt-14 md:p-4 md:pt-14 lg:p-6 lg:pt-6 overflow-x-hidden overflow-y-auto print:p-0 print:overflow-visible print:bg-white print:h-auto">
          <Routes>
            <Route path="/job-request" element={<TDJobRequestPage />} />
            <Route path="/td-workspace" element={<TDWorkspacePage />} />
            <Route path="/project/:id" element={<ProjectSpacePage />} />
            <Route path="/td-master-timeline" element={<TDMasterTimelinePage />} />
            <Route path="/my-planner" element={<MyPlannerPage />} />
            <Route path="/news-feed" element={<NewsFeedPage />} />
            <Route path="/td-sharing" element={<TDSharingAreaPage />} />
            <Route path="/" element={<DashboardPage />} />
            <Route path="/td/*" element={<TDDashboardPage />} />
            <Route path="/team" element={<TDTeamPage />} />
            <Route path="/profile" element={<ProfilePage />} />
            <Route path="/admin/users" element={userData?.role === 'Admin' ? <UserManagementPage /> : <Navigate to="/" />} />
            <Route path="/part-orders" element={['Engineer', 'TD', 'Admin'].includes(userData.dept) || userData.role === 'Admin' ? <PartOrderTrackerPage /> : <Navigate to="/" />} /> 
            <Route path="/report/:reportId" element={<TDReportPage />} />
            <Route path="*" element={<Navigate to="/" />} />
          </Routes>
        </main>
      </div>
    </div>
  );
};

function App() {
  return (
    <AuthProvider>
      <Router>
        <Routes>
          <Route path="/login" element={<LoginPage />} />
          <Route path="/register" element={<RegisterPage />} />
          <Route path="/*" element={<AuthenticatedRoutes />} />
        </Routes>
      </Router>
    </AuthProvider>
  );
}

export default App;
