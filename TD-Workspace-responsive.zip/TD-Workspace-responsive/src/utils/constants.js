// src/constants.js

export const DEPT_OPTIONS = [
    "AC", "BKK", "BM", "DC", "DM", "DR", "EG", "HR", "IJ", "IN", 
    "MC", "MS", "NP1", "NP2", "PB", "PI", "QA", "SC", "ST", "TD", "TTM", "TU", "Test"
];

export const JOB_TITLE_OPTIONS = [
    "Department manager", "Manager", "Supervisor", "Engineer", "Technician", "Operator", "Staff", "อื่นๆ"
];

export const TD_JOB_CATEGORIES = [
    "1.งานพัฒนาเทคโนโลยี", "2.เพิ่มผลิตภาพ", "3.ลดต้นทุนการผลิต", 
    "4.คุณภาพและงานเคลม", "5.อนุรักษ์พลังงาน", "6.ความปลอดภัยและสิ่งแวดล้อม", "7.สนับสนุนด้านอื่นๆ"
];