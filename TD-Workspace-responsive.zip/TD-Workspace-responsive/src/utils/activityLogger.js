import { collection, addDoc, serverTimestamp } from 'firebase/firestore';
import { db } from '../firebase';

export const logActivity = async (user, actionName, details = '') => {
    if (!user || !user.uid) return;
    try {
        await addDoc(collection(db, 'activity_logs'), {
            userId: user.uid,
            email: user.email,
            // 🌟 เพิ่มบรรทัดนี้ เพื่อให้ News Feed ดึงชื่อไปโชว์ได้
            userName: user.displayName || user.email.split('@')[0],
            action: actionName,
            details: details,
            timestamp: serverTimestamp()
        });
    } catch (error) {
        console.error("Error logging activity:", error);
    }
};