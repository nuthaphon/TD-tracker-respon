/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  darkMode: 'class', // Enable class-based dark mode (though we are using custom classes)
  theme: {
    extend: {
      colors: {
        bg: 'var(--color-bg)',
        text: 'var(--color-text)',
        primary: 'var(--color-primary)',
        secondary: 'var(--color-secondary)',
        accent: 'var(--color-accent)',
        surface: 'var(--color-surface)',
      },
      borderColor: {
        glass: 'var(--border-color)',
      },
      boxShadow: {
        glass: 'var(--shadow-glass)',
      },
      borderRadius: {
        base: 'var(--radius-base)',
      }
    },
  },
  plugins: [],
}
