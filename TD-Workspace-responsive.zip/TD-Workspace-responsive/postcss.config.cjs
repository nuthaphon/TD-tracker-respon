module.exports = {
  plugins: {
    '@tailwindcss/postcss': {}, // แก้ไขบรรทัดนี้ครับ
    autoprefixer: {},
  },
}
